# Core Module — `config.py` Final Technical Report

**File:** `app/core/config.py`  
**Role:** Central application-wide configuration and shared backend path definition.

---

# 1. File Purpose

`config.py` provides the **central configuration contract for the backend**.

It owns shared settings for:

- application/API metadata;
    
- runtime environment flags;
    
- project-root resolution;
    
- input-file restrictions;
    
- logging defaults;
    
- common storage locations;
    
- model-artifact locations;
    
- run-specific path construction;
    
- initialization of shared parent directories.
    

Configuration values can come from:

```text
code defaults
      +
environment variables
      +
<default project root>/.env
```

and are validated through Pydantic Settings.

## What this file does not own

It does not:

- create individual pipeline run directory structures;
    
- generate run IDs;
    
- write log files;
    
- configure Python logging handlers;
    
- read or write CSV/JSON files;
    
- manage manifests;
    
- train/load models;
    
- perform ML processing;
    
- define API routes;
    
- decide production workflow state.
    

The comment in `create_base_directories()` explicitly states that individual run directories are expected to be created later by `run_directory_service.py`.

---

# 2. Public Classes / Functions / Constants

|Name|Type|Purpose|Inputs|Returns|Side effects|
|---|---|---|---|---|---|
|`DEFAULT_PROJECT_ROOT`|`Final[Path]`|Resolve backend root from `config.py` location|None|Absolute `Path`|Resolves filesystem path|
|`Settings`|`BaseSettings` subclass|Main backend configuration model|Defaults, environment variables, `.env` values, explicit constructor values|Validated settings object|Reads environment / `.env` during construction|
|`Settings.normalise_project_root()`|Validator|Normalize project-root configuration|`str \| Path`|Resolved `Path`|Filesystem path resolution only|
|`Settings.validate_log_level()`|Validator|Validate and normalize logging level|`str`|Uppercase logging level|None|
|`Settings.app_directory`|Property|Application package path|None|`Path`|None|
|`Settings.runs_directory`|Property|Parent run-output path|None|`Path`|None|
|`Settings.logs_directory`|Property|Parent run-log path|None|`Path`|None|
|`Settings.model_artifacts_directory`|Property|Parent model-artifact path|None|`Path`|None|
|`Settings.xgboost_artifacts_directory`|Property|XGBoost artifact path|None|`Path`|None|
|`Settings.isolation_forest_artifacts_directory`|Property|Isolation Forest artifact path|None|`Path`|None|
|`Settings.model_metadata_directory`|Property|Model metadata path|None|`Path`|None|
|`Settings.max_input_file_size_bytes`|Property|Convert configured GiB limit to bytes|None|`int`|None|
|`Settings.get_run_directory()`|Method|Construct path for one run|`run_id`|`Path`|None|
|`Settings.get_run_log_directory()`|Method|Construct log directory for one run|`run_id`|`Path`|None|
|`Settings.get_component_log_path()`|Method|Construct one component log path|`run_id`, `component_name`|`Path`|None|
|`Settings.create_base_directories()`|Method|Create common persistent parent directories|None|`None`|Creates directories|
|`settings`|Singleton `Settings` object|Shared configuration instance imported by backend|Environment/default configuration at import|`Settings`|Settings validation occurs at module import|

---

# 3. Main Configuration Contract

## `Settings`

### Purpose

`Settings` is the project's application-wide Pydantic Settings model.

It centralizes configuration that multiple backend layers can consume without redefining the same constants.

### Configuration source lifecycle

```text
Hard-coded defaults
        │
        ├────────────┐
        │            │
Environment      .env file
variables        at DEFAULT_PROJECT_ROOT/.env
        │            │
        └──────┬─────┘
               ▼
           Settings()
               │
               ▼
       Pydantic validation
               │
               ▼
          settings
    shared singleton object
```

The model configuration uses:

```python
SettingsConfigDict(
    env_file=DEFAULT_PROJECT_ROOT / ".env",
    env_file_encoding="utf-8",
    case_sensitive=False,
    extra="ignore",
)
```

Therefore environment-setting names are handled case-insensitively and unsupported extra settings are ignored rather than rejected.

---

# 4. Default Project Root

```python
DEFAULT_PROJECT_ROOT = Path(__file__).resolve().parents[2]
```

The file assumes the following physical structure:

```text
telecom_anomaly_backend/
└── app/
    └── core/
        └── config.py
```

Resolution is:

```text
config.py
  ↓ parent
core/
  ↓
app/
  ↓
telecom_anomaly_backend/
```

Therefore:

```text
DEFAULT_PROJECT_ROOT
=
directory two levels above app/core
```

This value is calculated when the module is imported.

---

# 5. Application Metadata Settings

The following application-wide metadata is defined:

|Field|Default|
|---|---|
|`app_name`|`Telecom Anomaly Detection Backend`|
|`app_version`|`0.1.0`|
|`api_prefix`|`/api/v1`|
|`environment`|`local`|
|`debug`|`False`|

These fields are configuration only.

This file does not itself use them to:

- construct a FastAPI application;
    
- enable debugging;
    
- distinguish local/development/production execution.
    

Those uses must occur elsewhere.

**Exact downstream consumers:** **UNKNOWN / NOT CONFIRMED** from this file alone.

---

# 6. Project Root Configuration

## Field

```text
project_root: Path
```

Default:

```text
DEFAULT_PROJECT_ROOT
```

The project root can also be supplied through configuration/environment settings.

---

## `normalise_project_root()`

### Function/Class

`Settings.normalise_project_root`

### Purpose

Normalize the configured backend project root before normal Pydantic type processing completes.

### Inputs

```text
str | Path
```

### Validation

No existence or directory check is performed.

### Processing

```text
value
 ↓
Path(value)
 ↓
expanduser()
 ↓
resolve()
```

`~` is expanded and the resulting path is resolved.

### Return

```text
Path
```

### Exceptions

Normal path-construction/resolution failures may propagate.

No custom project exception is raised here.

### Side effects

No directory is created.

---

# 7. Important Project-Root Boundary

The configuration model normalizes a path but does **not** verify that:

```text
project_root exists
project_root is a directory
app/ exists
runs/ exists
logs/ exists
```

Directory existence is therefore a later runtime/filesystem concern.

---

# 8. Input File Configuration

The file defines three common input-file settings.

## Maximum file size

```text
max_input_file_size_gb = 5.0
```

Validation:

```text
value > 0
```

through:

```python
Field(gt=0)
```

---

## Allowed extensions

Default:

```text
(".csv",)
```

Therefore only CSV is configured by default.

The actual extension validation is not performed here.

That is expected to occur in whichever file/service consumes this setting.

---

## Default encoding

```text
utf-8
```

Again, `config.py` stores the value but does not itself open files.

---

# 9. `max_input_file_size_bytes`

### Purpose

Translate the user-friendly GB configuration into the integer byte limit needed by filesystem validation.

### Processing

```text
max_input_file_size_gb × 1024³
```

then converted to:

```text
int
```

Therefore the code uses binary gigabyte-style conversion:

```text
1 configured GB = 1,073,741,824 bytes
```

### Example with default

```text
5 × 1024³
=
5,368,709,120 bytes
```

### Side effects

None.

---

# 10. Logging Configuration

The settings model defines global logging defaults but does **not configure logging itself**.

Fields include:

```text
log_level
log_format
log_date_format
log_file_names
```

These are intended to be consumed by the separate logging subsystem.

---

# 11. `log_level`

Default:

```text
INFO
```

Supported values:

```text
DEBUG
INFO
WARNING
ERROR
CRITICAL
```

---

## `validate_log_level()`

### Purpose

Normalize and validate the configured Python logging level.

### Inputs

```text
str
```

### Processing

```text
value.upper().strip()
```

### Validation

The normalized value must belong to the five supported levels.

### Return

The normalized uppercase value.

Example:

```text
" debug "
        ↓
"DEBUG"
```

### Exceptions

Invalid values raise:

```text
ValueError
```

which Pydantic will incorporate into settings validation.

No project-specific custom exception is used here.

---

# 12. Log Format

Default format:

```text
%(asctime)s |
%(levelname)s |
%(name)s |
%(filename)s:%(lineno)d |
%(message)s
```

The individual string fragments are concatenated into one format string.

A generated log entry therefore conceptually contains:

```text
timestamp | level | logger | source-file:line | message
```

Date formatting uses:

```text
%Y-%m-%d %H:%M:%S
```

Actual handler/formatter construction belongs elsewhere.

---

# 13. Configured Log Components

The default `log_file_names` mapping is:

|Component|File|
|---|---|
|`pipeline`|`pipeline.log`|
|`preprocessing`|`preprocessing.log`|
|`xgboost`|`xgboost.log`|
|`isolation_forest`|`isolation_forest.log`|
|`reporting`|`reporting.log`|
|`agents`|`agents.log`|
|`api`|`api.log`|

The mapping is created through `default_factory`, so each `Settings` instance receives its own dictionary rather than sharing one mutable class-level dictionary.

---

# 14. Derived Directory Paths

The following paths are calculated dynamically from:

```text
settings.project_root
```

rather than separately configured.

## Application

```text
app_directory
=
<project_root>/app
```

## Runs

```text
runs_directory
=
<project_root>/runs
```

## Logs

```text
logs_directory
=
<project_root>/logs
```

## Model artifacts

```text
model_artifacts_directory
=
<project_root>/model_artifacts
```

Subdirectories:

```text
<project_root>/model_artifacts/
├── xgboost/
├── isolation_forest/
└── model_metadata/
```

These properties only **construct paths**.

They do not create them.

---

# 15. Run-Specific Path Helpers

## `get_run_directory()`

### Purpose

Construct the filesystem location assigned to one pipeline run.

### Input

```text
run_id: str
```

### Processing

```text
runs_directory / run_id
```

### Return

```text
<project_root>/runs/<run_id>
```

### Validation

No validation of `run_id` occurs.

### Side effects

None.

The directory is not created.

---

# 16. `get_run_log_directory()`

### Purpose

Construct the log directory associated with one run.

### Input

```text
run_id
```

### Return

```text
<project_root>/logs/<run_id>
```

### Validation

No run-ID validation is performed.

### Side effects

None.

---

# 17. `get_component_log_path()`

### Purpose

Construct the log-file path for one configured backend component within one run.

### Inputs

```text
run_id
component_name
```

### Validation

`component_name` must exist in:

```text
log_file_names
```

### Processing

```text
component_name
      ↓
configured filename
      ↓
get_run_log_directory(run_id)
      +
filename
```

### Return

Example:

```text
<project_root>/logs/<run_id>/pipeline.log
```

### Exceptions

Unknown components raise:

```text
ValueError
```

with the valid component names included in the message.

### Side effects

None.

It does not:

- create the run log directory;
    
- create the log file;
    
- configure a handler.
    

---

# 18. Base Directory Initialization

## `create_base_directories()`

### Purpose

Create the common persistent backend storage parents.

### Inputs

None.

### Directories created

```text
<project_root>/
├── runs/
├── logs/
└── model_artifacts/
    ├── xgboost/
    ├── isolation_forest/
    └── model_metadata/
```

### Processing

Each path uses:

```python
mkdir(
    parents=True,
    exist_ok=True,
)
```

Therefore:

- missing parents are created automatically;
    
- execution succeeds when the directory already exists;
    
- existing directories are not cleared.
    

### Return

```text
None
```

### Files/directories affected

Directories listed above.

### Exceptions

Filesystem exceptions from `Path.mkdir()` can propagate.

This method does not convert those failures into a custom backend exception.

### Architectural boundary

The method explicitly does **not create**:

```text
runs/<run_id>/
logs/<run_id>/
```

Individual run-directory ownership is delegated elsewhere, with `run_directory_service.py` named directly in the source comments.

---

# 19. Settings Singleton Lifecycle

At the end of the file:

```python
settings = Settings()
```

creates one shared settings object immediately when `app.core.config` is imported.

Therefore the lifecycle is:

```text
Python imports app.core.config
           │
           ▼
DEFAULT_PROJECT_ROOT resolved
           │
           ▼
Settings() constructed
           │
           ├── defaults considered
           ├── environment considered
           ├── .env considered
           └── validators run
           │
           ▼
settings singleton available
           │
           ▼
other backend modules import/use settings
```

This means configuration validation occurs **during module import**, rather than being delayed until some explicit application-startup function calls it.

---

# 20. Environment Variable Behaviour

The code explicitly documents examples such as:

```text
PROJECT_ROOT=...
LOG_LEVEL=DEBUG
MAX_INPUT_FILE_SIZE_GB=5
```

and `Settings` inherits from `BaseSettings`.

The settings configuration specifies:

```text
case_sensitive=False
```

so configuration names are not case-sensitive.

The configured `.env` file is:

```text
DEFAULT_PROJECT_ROOT/.env
```

using UTF-8 encoding.

Unexpected extra environment/`.env` settings are ignored because:

```text
extra="ignore"
```

---

# 21. Important `.env` Path Behaviour

The `.env` location is established using:

```text
DEFAULT_PROJECT_ROOT
```

not the configured:

```text
project_root
```

Therefore if an environment variable later overrides:

```text
PROJECT_ROOT
```

the `.env` file location itself is still based on where `config.py` was originally located.

Conceptually:

```text
config.py physical location
        ↓
DEFAULT_PROJECT_ROOT
        ↓
DEFAULT_PROJECT_ROOT/.env
        ↓
load settings
        ↓
PROJECT_ROOT may then resolve to another path
```

This is the actual current configuration lifecycle.

---

# 22. Dependencies

## Imports from the project

```text
None
```

`config.py` is intentionally independent of other `app.*` modules.

This allows other parts of the backend to depend on configuration without configuration importing the ML/services/workflow layers.

---

## External packages

### `pydantic`

Used for:

- `Field`;
    
- validation decorators;
    
- numeric constraints.
    

### `pydantic-settings`

Used for:

```text
BaseSettings
SettingsConfigDict
```

and provides environment/`.env` backed application configuration.

---

## Python standard library

### `pathlib.Path`

Used for all path construction, normalization, and directory creation.

### `typing.Final`

Used to identify:

```text
DEFAULT_PROJECT_ROOT
```

as a constant-level value for type-checking/documentation purposes.

---

# 23. Validation and Failure Behaviour

## Configuration errors

Potential configuration failures include:

### Invalid maximum file size

```text
max_input_file_size_gb <= 0
```

Rejected by Pydantic.

### Invalid log level

Anything outside:

```text
DEBUG
INFO
WARNING
ERROR
CRITICAL
```

raises validation failure.

### Invalid configuration representation

Other Pydantic conversion/validation errors may occur while constructing `Settings`.

Because the global `settings` instance is constructed at import time, these errors can prevent successful import of this module.

---

# 24. Input Validation Errors

This file does not validate actual uploaded/input files.

It only defines configuration such as:

```text
allowed_input_extensions
max_input_file_size_gb
default_file_encoding
```

Actual file validation belongs elsewhere.

---

# 25. Filesystem Errors

`create_base_directories()` may experience errors such as:

- insufficient permissions;
    
- invalid filesystem destination;
    
- conflicting non-directory filesystem object;
    
- underlying OS/path errors.
    

These exceptions propagate directly.

No custom `FileProcessingError` conversion exists here.

---

# 26. Internal Processing Errors

There is almost no computational processing in this module.

The explicit runtime error generated by its own code is:

```text
ValueError
```

from:

```text
get_component_log_path()
```

when an unknown component name is supplied.

---

# 27. Side Effects / Global Behaviour

## At module import

The file:

- resolves `DEFAULT_PROJECT_ROOT`;
    
- constructs `settings`;
    
- reads settings configuration/environment;
    
- validates values;
    
- normalizes `project_root`.
    

It does **not create directories automatically** simply because the module is imported.

---

## When `create_base_directories()` is called

The file creates common persistent storage folders.

---

## What it does not do

It does not:

- change the working directory;
    
- configure global Python logging;
    
- create log handlers;
    
- write log files;
    
- write configuration files;
    
- mutate environment variables;
    
- create per-run folders automatically.
    

---

# 28. Expected Callers

From the module comments, fields and helper methods, the expected consumer categories include:

```text
API layer
pipeline/workflow orchestration
preprocessing
ML modules
reporting components
agents
services
logging configuration
server/application startup
```

The `Settings` class docstring explicitly identifies:

- API;
    
- preprocessing pipeline;
    
- machine-learning modules;
    
- reporting;
    
- agents;
    
- services.
    

Exact source files importing `settings` are **UNKNOWN / NOT CONFIRMED** from `config.py` alone.

---

# 29. Architectural Significance

`config.py` forms the **central application configuration layer**.

Instead of individual backend modules independently deciding:

```text
Where is the project root?
Where are runs stored?
Where are logs stored?
Where are trained models stored?
How large may an input file be?
Which file formats are permitted?
What log format/level should be used?
What API prefix/version is configured?
```

those decisions can be read from one shared `settings` object.

The resulting architecture is conceptually:

```text
Environment / .env / defaults
            │
            ▼
        config.py
            │
            ▼
         settings
            │
     ┌──────┼─────────┬───────────┐
     ▼      ▼         ▼           ▼
    API   Services  Workflows   ML modules
```

The file therefore acts as the backend's **configuration and common-path source of truth**.

---

# 30. Relationship to Run Management

This file establishes only the parent locations:

```text
runs/
logs/
```

and can calculate:

```text
runs/<run_id>
logs/<run_id>
```

It does not own:

- generation of `run_id`;
    
- stage directory creation;
    
- KPI folder creation;
    
- reopening runs;
    
- manifest creation;
    
- workflow state.
    

Those responsibilities are expected to be documented in the Services module, particularly `run_directory_service.py` and `run_manifest_service.py`.

---

# 31. Relationship to Model Artifacts

The configuration defines three persistent model-storage paths:

```text
model_artifacts/
├── xgboost/
├── isolation_forest/
└── model_metadata/
```

This establishes shared filesystem destinations at the configuration level.

This file does not determine:

- artifact filenames;
    
- model versions;
    
- KPI/site subdirectory structure;
    
- model serialization;
    
- metadata schema;
    
- training-run/model relationships.
    

Those behaviours are **UNKNOWN / NOT CONFIRMED** here.

---

# 32. Potential Issues / Observations

## Important — `.env` location does not follow overridden `project_root`

The `.env` path is defined from:

```text
DEFAULT_PROJECT_ROOT
```

before the configurable `project_root` is resolved.

Therefore changing `PROJECT_ROOT` does not automatically make the settings loader search:

```text
<new project root>/.env
```

This may be fully intentional, but the distinction matters for deployment.

---

## Important — `settings` is instantiated during import

```python
settings = Settings()
```

means configuration validation occurs as soon as the module is imported.

A malformed setting such as an invalid `LOG_LEVEL` can therefore prevent modules importing `settings` from loading successfully.

This is a deliberate singleton pattern, but it has application-startup consequences.

---

## Important — run IDs are not validated by this file

Both:

```text
get_run_directory(run_id)
get_run_log_directory(run_id)
```

append the supplied value directly to a parent `Path`.

No:

- sanitization;
    
- allowed-character validation;
    
- UUID validation;
    
- run-ID generation
    

occurs here.

That may be intentional because another service is expected to own run IDs, but callers should not assume this file validates them.

---

## Minor — `environment` is unrestricted

The default is:

```text
local
```

but no validator restricts values to concepts such as:

```text
local
development
staging
production
```

Therefore environment naming is currently free-form.

This may be intentional.

---

## Minor — `debug` is independent of `environment`

No rule links:

```text
environment
```

and:

```text
debug
```

For example, the configuration model itself would not reject:

```text
environment = production
debug = True
```

Whether another application layer controls this is **UNKNOWN / NOT CONFIRMED**.

---

## Minor — log-file mapping receives no file-name validation here

`get_component_log_path()` validates the component key, but `config.py` contains no explicit validation that configured log filenames:

- are unique;
    
- contain no path components;
    
- use `.log`;
    
- are non-empty.
    

The default mapping itself is valid and simple.

---

## No issue / intentional — derived paths do not create directories

Properties such as:

```text
runs_directory
logs_directory
xgboost_artifacts_directory
```

only return paths.

Filesystem creation happens through an explicit method.

This keeps path calculation separate from filesystem mutation.

---

## No issue / intentional — base initialization avoids run directories

`create_base_directories()` creates only shared parents and explicitly leaves per-run directory creation to the run-directory service.

This is a clear responsibility boundary rather than missing functionality.

---

# 33. Configuration Lifecycle

```text
config.py physical location
        │
        ▼
DEFAULT_PROJECT_ROOT
        │
        ├──────────────► .env location
        │
        ▼
Settings defaults
        +
environment / .env overrides
        │
        ▼
Pydantic Settings validation
        │
        ├── normalize project_root
        ├── validate max file size
        └── normalize/validate log level
        │
        ▼
settings singleton
        │
        ├── application metadata
        ├── input-file configuration
        ├── logging configuration
        ├── derived paths
        └── run-path helpers
```

---

# 34. Filesystem Contract

```text
settings.project_root
        │
        ├── app/
        │
        ├── runs/
        │    └── <run_id>/       # path helper only
        │
        ├── logs/
        │    └── <run_id>/
        │         └── component.log
        │
        └── model_artifacts/
             ├── xgboost/
             ├── isolation_forest/
             └── model_metadata/
```

Only these base directories are directly created by this file:

```text
runs/
logs/
model_artifacts/xgboost/
model_artifacts/isolation_forest/
model_artifacts/model_metadata/
```

when:

```text
create_base_directories()
```

is explicitly called.

---

# 35. Responsibility Boundary

## `config.py` owns

```text
application-wide configuration
configuration defaults
environment/.env-backed settings
project-root normalization
shared path definitions
input-file restrictions
logging defaults
component-log filename mapping
base-directory initialization
```

## `config.py` does not own

```text
actual file validation
CSV/JSON reading and writing
run-ID generation
per-run directory lifecycle
manifest lifecycle
logging-handler configuration
log-file writing
ML-stage logic
API routing
workflow execution
model serialization
```

---

# 36. Compact File Contract

```text
FILE:
app/core/config.py

RESPONSIBILITY:
Provide the central validated application configuration and common
filesystem-path definitions for the backend.

PUBLIC INTERFACE:
DEFAULT_PROJECT_ROOT
Settings
settings
Settings path properties
get_run_directory()
get_run_log_directory()
get_component_log_path()
create_base_directories()

INPUTS:
Code defaults
Environment variables
DEFAULT_PROJECT_ROOT/.env
Explicit Settings constructor values
run_id
component_name

OUTPUTS:
Validated Settings object
Derived Path objects
Maximum file size in bytes

SIDE EFFECTS:
Settings/environment loading at module import.
Filesystem directories are created only when create_base_directories()
is explicitly called.

ERRORS:
Pydantic settings-validation errors
ValueError for unsupported LOG_LEVEL
ValueError for unknown logging component
Underlying filesystem/path errors

USED BY:
Expected application-wide consumers including API, workflows, services,
ML/preprocessing modules, reporting, agents and logging infrastructure.
Exact importing files are UNKNOWN / NOT CONFIRMED from this file alone.

ARCHITECTURAL ROLE:
Central backend configuration and shared filesystem-path source of truth.
It establishes application-wide defaults and parent storage locations while
leaving run lifecycle, file persistence, logging handlers and ML processing
to their dedicated modules.
```

---

# Final Assessment

`config.py` is a **small but application-wide infrastructure file**.

Its primary architecture is:

```text
defaults / environment / .env
              ↓
           Settings
              ↓
            settings
              ↓
     shared backend configuration
              ↓
API / Services / Workflows / ML
```

Its most important responsibility boundary is that it **defines where shared backend resources should live without itself managing individual workflow runs**.

In particular:

```text
config.py
→ knows <project_root>/runs
→ can calculate runs/<run_id>

run-directory service
→ expected to actually manage individual run directories
```

This separation will be important when the later Services reports reconstruct the run-ID, directory and manifest lifecycle.