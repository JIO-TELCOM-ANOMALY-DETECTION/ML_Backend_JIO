# Core Module — `exceptions.py` Final Technical Report

**File:** `app/core/exceptions.py`  
**Role:** Shared structured exception hierarchy for backend failures.

---

# 1. File Purpose

`exceptions.py` defines the backend's **common custom exception contract**.

Its purpose is to let the rest of the application raise meaningful backend-specific failures instead of relying only on generic Python exceptions such as:

```text
ValueError
RuntimeError
FileNotFoundError
```

The file provides:

- one common base exception;
    
- structured error metadata;
    
- machine-readable error codes;
    
- optional contextual details;
    
- dictionary serialization;
    
- specialized exception categories for major backend responsibilities.
    

The module is intentionally designed so higher layers can later catch:

```text
TelecomBackendError
```

to handle all known backend exceptions, or catch one specialized subclass when different handling is required.

The source explicitly anticipates later use by:

- FastAPI exception handlers;
    
- pipeline manifests;
    
- logging functions.
    

It does **not itself implement HTTP exception handling, logging, manifest writing, or recovery behavior**.

---

# 2. Public Classes / Functions / Constants

|Name|Type|Purpose|Inputs|Returns|Side effects|
|---|---|---|---|---|---|
|`TelecomBackendError`|Exception class|Base class for all project-specific backend exceptions|`message`, optional `error_code`, optional `details`|Exception instance|Stores structured error state|
|`TelecomBackendError.__str__()`|Method|Produce human-readable exception text|Instance state|`str`|None|
|`TelecomBackendError.to_dict()`|Method|Serialize error into structured dictionary|Instance state|`dict`|None|
|`ConfigurationError`|Exception subclass|Configuration failures|Same as base|Exception instance|None beyond base state|
|`InputValidationError`|Exception subclass|Invalid request/input-data failures|Same as base|Exception instance|None beyond base state|
|`FileProcessingError`|Exception subclass|File read/write/copy/transformation failures|Same as base|Exception instance|None beyond base state|
|`RunDirectoryError`|Exception subclass|Run-directory lifecycle failures|Same as base|Exception instance|None beyond base state|
|`RunManifestError`|Exception subclass|Manifest creation/update failures|Same as base|Exception instance|None beyond base state|
|`PipelineExecutionError`|Exception subclass|Workflow/pipeline-level failures|Same as base|Exception instance|None beyond base state|
|`PreprocessingError`|Exception subclass|Preprocessing-stage failures|Same as base|Exception instance|None beyond base state|
|`ModelExecutionError`|Exception subclass|Model training/prediction/loading failures|Same as base|Exception instance|None beyond base state|
|`ModelNotFoundError`|Exception subclass|Missing model/artifact failures|Same as base|Exception instance|None beyond base state|
|`ResultCombinationError`|Exception subclass|Failures combining model outputs|Same as base|Exception instance|None beyond base state|
|`ReportingError`|Exception subclass|Reporting/plot/metric generation failures|Same as base|Exception instance|None beyond base state|
|`AgentExecutionError`|Exception subclass|Internal agent failures|Same as base|Exception instance|None beyond base state|
|`EmailDeliveryError`|Exception subclass|Email preparation/delivery failures|Same as base|Exception instance|None beyond base state|

There are no constants, enums, helper functions, or exported singleton objects in this file.

---

# 3. Exception Hierarchy

The complete hierarchy is:

```text
Exception
   │
   ▼
TelecomBackendError
   │
   ├── ConfigurationError
   ├── InputValidationError
   ├── FileProcessingError
   ├── RunDirectoryError
   ├── RunManifestError
   ├── PipelineExecutionError
   ├── PreprocessingError
   ├── ModelExecutionError
   ├── ModelNotFoundError
   ├── ResultCombinationError
   ├── ReportingError
   ├── AgentExecutionError
   └── EmailDeliveryError
```

Every specialized backend exception directly inherits from:

```text
TelecomBackendError
```

There are no deeper subclass branches in the current implementation.

---

# 4. `TelecomBackendError`

## Function/Class

`TelecomBackendError`

## Purpose

Provide the common implementation inherited by every custom backend exception.

It adds structured metadata beyond a normal Python exception.

---

## Inputs

Constructor:

```python
TelecomBackendError(
    message: str,
    *,
    error_code: str | None = None,
    details: dict | None = None,
)
```

### `message`

Required human-readable error description.

### `error_code`

Optional machine-readable identifier.

Examples could conceptually be:

```text
MISSING_DATASET_COLUMN
INVALID_LOG_LEVEL
FILE_READ_FAILED
```

but no fixed error-code registry is defined in this file.

### `details`

Optional dictionary containing additional structured context.

Examples of actual keys are determined by callers.

The schema of `details` is unrestricted here.

---

## Validation

The class itself performs **no explicit validation** of:

- empty messages;
    
- error-code format;
    
- allowed error codes;
    
- `details` keys;
    
- values stored inside `details`.
    

Python type hints document the intended shape, but runtime validation is not implemented.

---

## Processing

The constructor calls:

```python
super().__init__(message)
```

so the standard `Exception` base receives the human-readable message.

It then stores:

```text
self.message
self.error_code
self.details
```

If:

```text
details is None
```

the stored value becomes:

```text
{}
```

through:

```python
self.details = details or {}
```

---

## Return

An initialized exception instance.

---

## Exceptions

The constructor itself does not deliberately raise another exception.

---

## Side Effects

None outside the exception object's state.

---

# 5. Stored Error Fields

Every custom backend exception inherits the following fields:

```text
message
error_code
details
```

Therefore all specialized exception types share one consistent structured representation.

Conceptually:

```text
Backend Exception
│
├── type       → class name
├── message    → human-readable explanation
├── error_code → machine-readable identifier or None
└── details    → structured contextual dictionary
```

This creates a common error contract across otherwise unrelated backend modules.

---

# 6. `__str__()`

## Purpose

Return the human-readable string representation of the exception.

## Processing

If an error code exists:

```text
[<ERROR_CODE>] <message>
```

Example conceptually:

```text
[MISSING_COLUMN] Required KPI column was not found.
```

If no error code exists:

```text
<message>
```

only.

## Return

```text
str
```

## Side Effects

None.

---

# 7. `to_dict()`

## Purpose

Convert any backend exception into a serializable structured representation.

The source explicitly notes future/current usefulness for:

```text
FastAPI exception handlers
pipeline manifests
logging functions
```

---

## Return Structure

```python
{
    "error_type": self.__class__.__name__,
    "message": self.message,
    "error_code": self.error_code,
    "details": self.details,
}
```

Example conceptually:

```json
{
  "error_type": "InputValidationError",
  "message": "Required dataset column is missing.",
  "error_code": "MISSING_DATASET_COLUMN",
  "details": {
    "column": "computedValue"
  }
}
```

---

## Important behavior

`error_type` is automatically derived from the actual subclass.

Therefore:

```python
InputValidationError(...).to_dict()
```

produces:

```text
error_type = "InputValidationError"
```

rather than the base class name.

---

## Serialization support

This is the only explicit serialization helper provided by the file.

It serializes to a Python dictionary.

The module does **not** provide:

- JSON serialization;
    
- Pydantic model serialization;
    
- HTTP response models;
    
- database serialization;
    
- custom JSON encoders.
    

Those would have to be implemented elsewhere.

---

# 8. `ConfigurationError`

## Purpose

Represent invalid, missing, or internally inconsistent backend configuration.

Examples documented by the file include:

```text
invalid project-root path
unsupported logging level
missing required environment settings
```

## Inputs / Return / Side Effects

Uses the inherited `TelecomBackendError` constructor unchanged.

## Architectural category

```text
CONFIGURATION ERROR
```

No additional fields or methods are added.

---

# 9. `InputValidationError`

## Purpose

Represent failures caused by invalid incoming input or pipeline request data.

Examples documented include:

```text
unsupported file extension
file larger than permitted size
missing required dataset columns
invalid request parameters
```

## Architectural category

```text
INPUT VALIDATION ERROR
```

This is the exception type most directly associated with invalid user/request/dataset input before internal processing can safely proceed.

No specialized methods or fields are added.

---

# 10. `FileProcessingError`

## Purpose

Represent failures while performing file operations or transformations.

Examples include:

```text
CSV reading failure
permission error
output file creation failure
unsupported file encoding
```

## Architectural category

```text
FILESYSTEM / FILE PROCESSING ERROR
```

It differs from `InputValidationError` conceptually:

```text
InputValidationError
→ input is structurally/semantically unacceptable

FileProcessingError
→ an expected file operation could not be completed
```

No implementation beyond the inherited base behavior is added.

---

# 11. `RunDirectoryError`

## Purpose

Represent errors specifically associated with pipeline run directories.

Examples include:

```text
duplicate run directory
missing run folder
permission failure while creating run folders
```

This gives the run-directory service a dedicated error category rather than requiring all directory failures to be represented as generic `FileProcessingError`.

## Architectural category

```text
RUN FILESYSTEM / RUN LIFECYCLE ERROR
```

No additional methods or fields are defined.

---

# 12. `RunManifestError`

## Purpose

Represent failures involving creation, modification, or validation of a run manifest.

Examples include:

```text
invalid manifest structure
manifest file write failure
missing run metadata
```

## Architectural category

```text
RUN METADATA / MANIFEST ERROR
```

This separation indicates that the backend treats the run manifest as a distinct operational resource rather than merely an arbitrary JSON file.

The actual manifest schema and lifecycle are **UNKNOWN / NOT CONFIRMED** from this file alone.

---

# 13. `PipelineExecutionError`

## Purpose

Represent failure of an overall pipeline/workflow execution.

The source specifically describes this as a:

```text
workflow-level failure
```

particularly when the orchestrator cannot complete the requested sequence.

## Architectural category

```text
PIPELINE / WORKFLOW EXECUTION ERROR
```

It is distinct from errors occurring inside specific ML/file/configuration components.

Whether workflows wrap lower-level exceptions into this type or allow them to propagate directly is **UNKNOWN / NOT CONFIRMED** from this file alone.

---

# 14. `PreprocessingError`

## Purpose

Represent errors arising within preprocessing-style stages.

Examples documented include:

```text
timeline generation failure
outlier-detection failure
missing-value filling failure
feature-generation failure
```

## Architectural category

```text
PREPROCESSING / DATA-TRANSFORMATION ERROR
```

### Observation

The examples include:

```text
feature-generation failure
```

even though the current backend architecture separates feature engineering as Part C from Part B preprocessing.

The exception name therefore appears broader than only Part B preprocessing.

This is discussed later under observations.

---

# 15. `ModelExecutionError`

## Purpose

Represent failures during model execution.

Examples:

```text
model training failure
prediction failure
invalid model input features
model artifact loading failure
```

## Architectural category

```text
ML MODEL EXECUTION ERROR
```

This type can logically represent both:

- training;
    
- inference.
    

The file does not define separate training and inference exception subclasses.

---

# 16. `ModelNotFoundError`

## Purpose

Represent a specifically missing model or model artifact.

Examples:

```text
missing XGBoost model file
missing Isolation Forest model file
unknown model name in model registry
```

## Architectural category

```text
MODEL LOOKUP / ARTIFACT NOT FOUND ERROR
```

This is intentionally separated from generic `ModelExecutionError`.

Conceptually:

```text
ModelNotFoundError
→ required model resource does not exist

ModelExecutionError
→ model exists or processing started, but execution cannot complete
```

The existence of a model registry is only mentioned as an example.

Its actual implementation is **UNKNOWN / NOT CONFIRMED**.

---

# 17. `ResultCombinationError`

## Purpose

Represent failures while combining outputs produced by multiple models.

Examples:

```text
missing model-result columns
incompatible row identifiers
conflicting result schemas
```

## Architectural category

```text
MULTI-MODEL RESULT INTEGRATION ERROR
```

The exact result-combination implementation is **UNKNOWN / NOT CONFIRMED** from this file.

---

# 18. `ReportingError`

## Purpose

Represent failures while generating metrics, visualizations, or reports.

Examples:

```text
plot creation failure
missing summary data
report-file write failure
```

## Architectural category

```text
REPORTING ERROR
```

No report schemas or output formats are defined here.

---

# 19. `AgentExecutionError`

## Purpose

Represent failure of internal summary/email agents.

Examples:

```text
summary-generation failure
invalid agent input
email-content generation failure
```

## Architectural category

```text
AGENT EXECUTION ERROR
```

The actual agent implementation is **UNKNOWN / NOT CONFIRMED** from this file.

---

# 20. `EmailDeliveryError`

## Purpose

Represent failures while preparing or delivering email.

The docstring explicitly states that this exception is intended to become useful after an external email service is connected.

## Architectural category

```text
EMAIL DELIVERY ERROR
```

This strongly suggests the exception exists in preparation for future integration rather than necessarily being actively used today.

Whether it has current callers is:

**UNKNOWN / NOT CONFIRMED**.

---

# 21. Error Category Map

The current exception taxonomy can be grouped as:

|Category|Exception|
|---|---|
|Configuration|`ConfigurationError`|
|Input/request validation|`InputValidationError`|
|General file processing|`FileProcessingError`|
|Run-directory filesystem|`RunDirectoryError`|
|Run manifest|`RunManifestError`|
|Workflow execution|`PipelineExecutionError`|
|Data preprocessing/transformation|`PreprocessingError`|
|Model execution|`ModelExecutionError`|
|Model lookup|`ModelNotFoundError`|
|Result integration|`ResultCombinationError`|
|Reporting|`ReportingError`|
|Agent processing|`AgentExecutionError`|
|Email|`EmailDeliveryError`|

All of these can also be handled together by catching:

```text
TelecomBackendError
```

---

# 22. Dependencies

## Imports from the project

```text
None
```

The file has no dependency on:

```text
app.*
```

modules.

This makes the exception layer independent and safe for use by essentially every other project package.

---

## External packages

```text
None
```

The module uses only the Python built-in:

```text
Exception
```

class.

It does not depend on:

- FastAPI;
    
- Pydantic;
    
- logging;
    
- pathlib;
    
- JSON libraries.
    

That keeps the core exception definitions lightweight and infrastructure-independent.

---

# 23. Validation and Failure Behaviour

The module itself mainly **defines failures** rather than performing processing that can fail.

Still, several important behaviors exist.

---

## Configuration errors

Represented by:

```text
ConfigurationError
```

Intended for invalid backend-level configuration.

---

## Input validation errors

Represented by:

```text
InputValidationError
```

Intended for invalid requests or unacceptable incoming files/data.

---

## Filesystem errors

There are two main categories:

```text
FileProcessingError
RunDirectoryError
```

and manifest write failures may use:

```text
RunManifestError
```

The exact rules determining which one a caller chooses are not enforced in this module.

---

## Internal processing errors

Potential categories include:

```text
PipelineExecutionError
PreprocessingError
ModelExecutionError
ResultCombinationError
ReportingError
AgentExecutionError
```

---

# 24. No Built-In Exception Conversion

The file does **not** automatically translate generic Python exceptions such as:

```text
ValueError
OSError
PermissionError
FileNotFoundError
```

into custom exceptions.

A consuming module must explicitly do something conceptually like:

```text
try:
    ...
except SomeError as exc:
    raise FileProcessingError(...) from exc
```

if it wants to convert the underlying failure.

Whether individual modules consistently do this must be determined from those modules themselves.

---

# 25. No Built-In HTTP Mapping

Although the module explicitly anticipates API use, it does not define:

```text
HTTP status codes
FastAPI exception handlers
HTTPException objects
response schemas
validation-response mapping
```

Therefore there is currently no HTTP behavior inside `exceptions.py`.

The API layer can later decide how, for example:

```text
InputValidationError
```

maps to a specific HTTP status.

That future mapping should not be inferred from this file alone.

---

# 26. Serialization / API Readiness

The `to_dict()` representation creates a natural application-level error payload:

```text
error_type
message
error_code
details
```

This is suitable for later translation into:

```text
API response
manifest failure entry
structured log entry
database/run registry record
```

However, the file itself only returns a Python dictionary.

No automatic persistence or transmission occurs.

---

# 27. Side Effects / Global Behaviour

This file has effectively **no global runtime side effects**.

Importing it:

- defines exception classes;
    
- does not create objects;
    
- does not read environment variables;
    
- does not create files/directories;
    
- does not configure logging;
    
- does not register FastAPI handlers;
    
- does not mutate process state.
    

Creating an exception instance only stores its local error data.

This makes `exceptions.py` safe as a widely imported Core dependency.

---

# 28. Expected Callers

Based on the exception categories and source comments, expected caller types include:

```text
configuration/startup code
file services
run-directory service
run-manifest service
API validation/routes
pipeline/workflow orchestration
Parts A–E ML modules
training/inference code
reporting components
agents
email integration
```

Some are strongly implied by class names.

Exact file-level callers are **UNKNOWN / NOT CONFIRMED** from this source alone.

---

# 29. Architectural Significance

This file creates the backend's **common failure vocabulary**.

Without it, individual files might expose unrelated low-level errors:

```text
ValueError
KeyError
FileNotFoundError
PermissionError
RuntimeError
```

to higher application layers.

Instead, errors can conceptually travel as:

```text
low-level failure
      │
      ▼
backend-specific exception
      │
      ├── message
      ├── error_code
      ├── details
      └── error_type
      │
      ▼
workflow / logging / manifest / API
```

This is especially important in a production architecture because different consumers may need the same failure represented differently without changing the underlying ML/service logic.

---

# 30. Future API/UI Significance

The existing structure already provides information useful to future interfaces.

For example:

```text
message
→ human-readable UI/API description

error_code
→ stable machine-readable condition

details
→ contextual values useful for debugging or UI explanation

error_type
→ broad backend failure category
```

Conceptually:

```json
{
  "error_type": "InputValidationError",
  "message": "Missing required dataset columns.",
  "error_code": "MISSING_DATASET_COLUMNS",
  "details": {
    "missing_columns": ["computedValue"]
  }
}
```

could be surfaced by an API handler without requiring the ML module to understand HTTP.

The actual HTTP/UI implementation does not yet exist in this file and should be documented separately.

---

# 31. Relationship to Pipeline Manifests

The base exception docstring explicitly identifies pipeline manifests as a potential consumer of:

```text
to_dict()
```

This means the current exception design is already compatible with storing structured failure information such as:

```text
error_type
error_code
message
details
```

inside a run manifest.

Whether the current `run_manifest_service.py` actually does this remains:

**UNKNOWN / NOT CONFIRMED**

until that file is analysed.

---

# 32. Responsibility Boundary

## `exceptions.py` owns

```text
backend exception hierarchy
common base exception
message storage
optional error codes
structured contextual details
human-readable formatting
dictionary serialization
high-level failure categories
```

## `exceptions.py` does not own

```text
detecting validation failures
catching filesystem errors
HTTP status mapping
API response generation
log writing
manifest persistence
workflow recovery
retry behaviour
user-facing error wording policy
database error recording
```

Those responsibilities belong to whichever layer catches or raises the exception.

---

# 33. Potential Issues / Observations

## Important — no controlled error-code registry

`error_code` accepts:

```text
str | None
```

with no centralized enum or validation.

Therefore different callers could theoretically use inconsistent codes for equivalent errors.

For example:

```text
MISSING_FILE
FILE_NOT_FOUND
INPUT_FILE_MISSING
```

could all be used unless callers coordinate externally.

This is not necessarily a current bug, but it means the exception type hierarchy is standardized more strongly than the machine-readable error-code layer.

---

## Important — `details` structure is unrestricted

`details` is a plain:

```text
dict
```

with no required schema.

This provides flexibility but means the structure may vary across modules.

Future API/manifest consumers cannot infer a universal details schema from this file alone.

---

## Important — specialized subclasses contain no specialized state

Every subclass currently inherits the exact same constructor and fields.

For example:

```text
RunManifestError
ModelExecutionError
InputValidationError
```

differ only through their Python class/type identity and docstring meaning.

This is intentional and keeps the hierarchy simple, but no subclass-specific structured fields are enforced.

---

## Minor — `details or {}` replaces any falsy mapping

The constructor uses:

```python
self.details = details or {}
```

For a normal empty dictionary this produces another empty dictionary.

This has no meaningful negative effect for current usage, but the implementation treats all falsy supplied values equivalently to `None`.

---

## Minor — `PreprocessingError` terminology is broader than Part B

Its documented examples include:

```text
feature-generation failure
```

while the completed architecture treats feature engineering as a distinct Part C module.

Therefore this exception appears to represent broader data-processing failures rather than strictly Part B preprocessing.

This may simply reflect an earlier/broader naming convention.

---

## Minor / future-facing — several exceptions may not yet have active implementations

Classes such as:

```text
ReportingError
AgentExecutionError
EmailDeliveryError
ResultCombinationError
```

refer to backend components that may be future or partially implemented.

The `EmailDeliveryError` docstring explicitly describes future usefulness after an external email service is connected.

Actual current usage is:

**UNKNOWN / NOT CONFIRMED**.

---

## No issue / intentional — no FastAPI dependency

Despite anticipating API conversion, the module does not import FastAPI.

This keeps Core exception definitions independent from transport/API concerns.

That is a clean responsibility boundary.

---

## No issue / intentional — all errors share one base

Because every custom exception inherits from:

```text
TelecomBackendError
```

higher layers can implement either:

```text
specific handling
```

or:

```text
catch all known backend failures
```

without also catching unrelated Python exceptions.

---

# 34. Error Handling Lifecycle

The current intended architecture can be represented as:

```text
backend operation
      │
      ▼
specific failure occurs
      │
      ▼
specialized exception
      │
      ├── ConfigurationError
      ├── InputValidationError
      ├── FileProcessingError
      ├── ...
      │
      ▼
TelecomBackendError contract
      │
      ├── message
      ├── error_code
      └── details
      │
      ▼
to_dict() if structured representation needed
      │
      ├── logging
      ├── manifest
      └── API handler
```

The last three consumers are supported conceptually, but their actual behavior belongs to other modules.

---

# 35. Complete Exception Hierarchy Contract

```text
TelecomBackendError
│
│  Common data:
│  ├── message
│  ├── error_code
│  └── details
│
│  Common methods:
│  ├── __str__()
│  └── to_dict()
│
├── ConfigurationError
│     configuration problems
│
├── InputValidationError
│     invalid external/request/data input
│
├── FileProcessingError
│     generic file operation failures
│
├── RunDirectoryError
│     pipeline run-directory failures
│
├── RunManifestError
│     run-manifest failures
│
├── PipelineExecutionError
│     overall workflow execution failures
│
├── PreprocessingError
│     data preprocessing/transformation failures
│
├── ModelExecutionError
│     model training/prediction/loading failures
│
├── ModelNotFoundError
│     missing model/artifact
│
├── ResultCombinationError
│     model-output integration failures
│
├── ReportingError
│     reporting/metric/plot failures
│
├── AgentExecutionError
│     internal agent failures
│
└── EmailDeliveryError
      email preparation/delivery failures
```

---

# 36. Compact File Contract

```text
FILE:
app/core/exceptions.py

RESPONSIBILITY:
Define the shared structured exception hierarchy used throughout the
telecom anomaly detection backend.

PUBLIC INTERFACE:
TelecomBackendError
ConfigurationError
InputValidationError
FileProcessingError
RunDirectoryError
RunManifestError
PipelineExecutionError
PreprocessingError
ModelExecutionError
ModelNotFoundError
ResultCombinationError
ReportingError
AgentExecutionError
EmailDeliveryError

INPUTS:
message: str
error_code: str | None
details: dict | None

OUTPUTS:
Custom exception objects
Human-readable exception strings
Structured dictionaries via to_dict()

SIDE EFFECTS:
None beyond storing state inside exception instances.

ERRORS:
The module defines backend errors rather than performing operations that
normally produce them. It performs no custom validation of message,
error-code, or details structure.

USED BY:
Expected callers include configuration code, services, API layers,
pipeline workflows, Parts A-E, model execution, reporting, agents, and
email integration. Exact callers are UNKNOWN / NOT CONFIRMED from this
file alone.

ARCHITECTURAL ROLE:
Provide one common failure vocabulary between backend implementation
layers and higher-level consumers such as logging, manifests, workflows,
and future API/UI exception handling.
```

---

# Final Assessment

`exceptions.py` is the **common structured error contract for the entire backend**.

Its central design is:

```text
specific backend failure
        ↓
specialized exception class
        ↓
TelecomBackendError
        ↓
message + error_code + details
        ↓
string or structured dictionary
        ↓
higher application layer
```

The strongest architectural feature is that it separates **what failed** from **how that failure is ultimately presented**.

For example:

```text
ML/file/service code
→ raises InputValidationError

exceptions.py
→ provides structured representation

future API layer
→ decides HTTP response

run manifest service
→ may record the same structured failure

logging layer
→ may log the same information
```

This means Core establishes the shared failure language while leaving HTTP behavior, persistence, logging, and workflow recovery to their respective backend layers.