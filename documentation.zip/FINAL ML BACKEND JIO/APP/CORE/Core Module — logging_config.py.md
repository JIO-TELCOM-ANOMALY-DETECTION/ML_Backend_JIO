# Core Module — `logging_config.py` Final Technical Report

**File:** `app/core/logging_config.py`  
**Role:** Run-specific and component-specific logging setup, file/console handler creation, and logger cleanup.

---

# 1. File Purpose

`logging_config.py` owns the backend's **runtime logging lifecycle for pipeline runs**.

Its main responsibilities are to:

- validate run IDs before using them in log paths;
    
- validate logging component names;
    
- create the shared logging formatter;
    
- create file handlers;
    
- create console handlers;
    
- create/retrieve one logger per run and component;
    
- create all configured component loggers for a run;
    
- prevent duplicate handlers;
    
- isolate loggers from the root logger;
    
- create run-specific log directories;
    
- close and remove handlers after a run.
    

The logging structure is:

```text
logs/
└── <run_id>/
    ├── pipeline.log
    ├── preprocessing.log
    ├── xgboost.log
    ├── isolation_forest.log
    ├── reporting.log
    ├── agents.log
    └── api.log
```

The exact component filenames are not hardcoded here; they come from `settings.log_file_names` in `config.py`.

## What this file does not own

It does not:

- generate run IDs;
    
- create the main `runs/<run_id>` artifact directory;
    
- create manifests;
    
- write ML results;
    
- decide pipeline execution status;
    
- rotate/archive logs;
    
- delete old logs;
    
- configure Python's root logger;
    
- dynamically choose component names beyond those configured in `settings`.
    

---

# 2. Public Classes / Functions / Constants

|Name|Type|Purpose|Inputs|Returns|Side effects|
|---|---|---|---|---|---|
|`LOGGER_NAMESPACE`|`str` constant|Prefix all backend logger names|None|`"telecom_anomaly_backend"`|None|
|`validate_run_id()`|Function|Validate/sanitize run identifier before path/logger use|`run_id`|Cleaned `str`|None|
|`validate_component_name()`|Function|Validate component against configured log components|`component_name`|Normalized `str`|Reads global settings|
|`create_log_formatter()`|Function|Build shared formatter|None|`logging.Formatter`|None|
|`create_file_handler()`|Function|Create and configure component file handler|`log_file_path`|`logging.FileHandler`|Creates parent dirs/file|
|`create_console_handler()`|Function|Create configured console handler|None|`logging.StreamHandler`|None|
|`build_logger_name()`|Function|Build unique logger namespace for run/component|`run_id`, `component_name`|`str`|None|
|`get_run_logger()`|Function|Create or retrieve one run/component logger|`run_id`, `component_name`, `include_console`|`logging.Logger`|May create handler/file|
|`setup_run_logging()`|Function|Configure all component loggers for one run|`run_id`, `include_console`|`dict[str, Logger]`|Creates run log dir/files|
|`close_run_logging()`|Function|Flush, close, and remove all handlers for one run|`run_id`|`None`|Closes file/stream resources|

---

# 3. Detailed Callable Contracts

## `validate_run_id()`

### Purpose

Protect run-specific logging paths from unsafe or malformed identifiers.

### Inputs

```text
run_id: str
```

### Validation

The function:

1. strips surrounding whitespace;
    
2. rejects an empty result;
    
3. rejects:
    
    ```text
    .
    ..
    ```
    
4. rejects `/`;
    
5. rejects `\`.
    

### Processing

```text
input run_id
    ↓
strip()
    ↓
empty?
    ↓
"." / ".."?
    ↓
contains path separator?
    ↓
validated run_id
```

### Return

The stripped/validated run ID.

### Exceptions

Raises:

```text
RunDirectoryError
```

with either:

```text
EMPTY_RUN_ID
INVALID_RUN_ID
```

### Side effects

None.

### Architectural importance

This closes a gap left intentionally by `config.py`, where path helpers simply append `run_id` without validating it.

---

# 4. Run-ID Safety Rules

The following are invalid:

```text
""
"   "
"."
".."
"abc/def"
"abc\def"
```

A run ID such as:

```text
run_20260826_120000
```

passes.

The validator does not otherwise restrict:

- spaces inside the value;
    
- punctuation;
    
- length;
    
- UUID format;
    
- timestamp format;
    
- reserved filesystem characters other than separators.
    

Therefore this file provides **basic path-safety validation**, not a complete run-ID schema.

---

# 5. `validate_component_name()`

## Purpose

Verify that a requested logger component exists in the global logging configuration.

### Input

```text
component_name: str
```

### Processing

```text
strip()
↓
lower()
↓
lookup in settings.log_file_names
```

### Return

Normalized lowercase component name.

### Exceptions

Raises:

```text
ConfigurationError
```

with:

```text
error_code = "UNKNOWN_LOG_COMPONENT"
```

and details containing:

```text
received_component
available_components
```

### Side effects

None.

---

# 6. Component Name Contract

Because component names are converted to lowercase:

```text
"XGBOOST"
" xgboost "
"xgboost"
```

all resolve to:

```text
xgboost
```

provided `xgboost` exists in:

```text
settings.log_file_names
```

This makes component lookup case-insensitive at this layer.

---

# 7. `create_log_formatter()`

## Purpose

Create the standard formatter shared by both file and console handlers.

### Inputs

None.

### Processing

Uses:

```text
settings.log_format
settings.log_date_format
```

### Return

```text
logging.Formatter
```

### Side effects

None.

The formatter itself does not write logs.

---

# 8. Formatter Structure

From `config.py`, the configured format is conceptually:

```text
timestamp
|
severity
|
logger name
|
filename:line
|
message
```

`logging_config.py` does not hardcode this structure; it consumes the configured values.

Therefore:

```text
config.py
→ defines logging format

logging_config.py
→ instantiates formatter
```

This is a clear Core responsibility split.

---

# 9. `create_file_handler()`

## Purpose

Create a component-specific log file handler.

### Input

```text
log_file_path: Path
```

### Processing

First:

```python
log_file_path.parent.mkdir(
    parents=True,
    exist_ok=True,
)
```

Then creates:

```python
logging.FileHandler(
    filename=log_file_path,
    mode="a",
    encoding="utf-8",
)
```

Then applies:

```text
settings.log_level
shared formatter
```

### Return

```text
logging.FileHandler
```

### Files/directories affected

May create:

```text
parent logging directory
```

and opens/creates:

```text
log_file_path
```

### Overwrite behavior

Mode:

```text
"a"
```

means logs are **appended**, not truncated.

### Encoding

Explicit:

```text
utf-8
```

### Exceptions

Only `OSError` from parent-directory/file creation is converted to:

```text
RunDirectoryError
```

with:

```text
LOG_FILE_CREATION_FAILED
```

Details include:

```text
log_file_path
original_error
```

The original `OSError` is retained as the Python exception cause via:

```python
raise ... from error
```

---

# 10. File Handler Failure Contract

Conceptually:

```text
create/open log file
        │
        ├── success
        │      ↓
        │   FileHandler
        │
        └── OSError
               ↓
        RunDirectoryError
               │
               ├── LOG_FILE_CREATION_FAILED
               ├── file path
               └── original OS error
```

This is one of the places where low-level filesystem errors are deliberately converted into the project's structured Core exception hierarchy.

---

# 11. `create_console_handler()`

## Purpose

Create a stream handler for terminal output.

### Inputs

None.

### Processing

Creates:

```python
logging.StreamHandler()
```

then applies:

```text
settings.log_level
shared formatter
```

### Return

```text
logging.StreamHandler
```

### Side effects

No file-system side effects.

The stream itself is determined by Python logging's default `StreamHandler` behavior.

The code does not explicitly configure stdout/stderr.

---

# 12. `build_logger_name()`

## Purpose

Create a unique Python logger name for one run/component combination.

### Inputs

```text
run_id
component_name
```

### Processing

Produces:

```text
telecom_anomaly_backend.<run_id>.<component_name>
```

### Example

```text
telecom_anomaly_backend.run_123.xgboost
```

### Return

`str`

### Validation

This helper performs none itself.

It expects callers to supply already validated values where needed.

### Side effects

None.

---

# 13. Logger Namespace

The constant:

```text
LOGGER_NAMESPACE = "telecom_anomaly_backend"
```

creates an identifiable namespace for all loggers managed by this module.

Logger hierarchy becomes:

```text
telecom_anomaly_backend
└── <run_id>
    ├── pipeline
    ├── preprocessing
    ├── xgboost
    ├── isolation_forest
    ├── reporting
    ├── agents
    └── api
```

This namespace is later crucial for targeted cleanup in `close_run_logging()`.

---

# 14. `get_run_logger()`

## Purpose

Create or retrieve one logger dedicated to:

```text
one run
+
one backend component
```

### Inputs

```text
run_id: str
component_name: str
include_console: bool = True
```

### Validation

Runs:

```text
validate_run_id()
validate_component_name()
```

first.

### Processing

```text
run_id
   ↓ validation

component_name
   ↓ normalization/validation

build_logger_name()
   ↓

logging.getLogger(name)
   ↓

set logger level
set propagate=False
   ↓
handlers already exist?
   ├── yes → return existing logger
   └── no
        ↓
resolve component log path
        ↓
create file handler
        ↓
attach
        ↓
include_console?
        ├── yes → attach console handler
        └── no
        ↓
return logger
```

### Return

```text
logging.Logger
```

### Side effects

Potentially:

- creates log parent directory;
    
- creates/opens the component log file;
    
- registers/retrieves a logger in Python's global logging manager;
    
- attaches handlers.
    

---

# 15. Per-Run Log Path

`get_run_logger()` resolves:

```text
settings.get_component_log_path(
    run_id,
    component_name,
)
```

which gives:

```text
<project_root>/logs/<run_id>/<component_log_file>
```

Therefore responsibility is divided as:

```text
config.py
→ knows path rules

logging_config.py
→ validates run/component
→ creates handler/file
→ attaches logger
```

---

# 16. Handler Duplication Prevention

One of the most important behaviors is:

```python
if logger.handlers:
    return logger
```

This means a previously configured logger is returned immediately.

Therefore repeated calls such as:

```text
get_run_logger("run1", "pipeline")
get_run_logger("run1", "pipeline")
```

do not add a second file or console handler.

This prevents duplicated log lines caused by repeated handler attachment.

---

# 17. Important Consequence of Handler Reuse

Handler reuse also means that once a logger is configured, later calls do **not modify its handler set**.

Example:

```text
first call:
include_console = False
```

creates only a file handler.

A later call:

```text
include_console = True
```

will see existing handlers and immediately return the logger.

Therefore it will **not add a console handler later**.

Likewise:

```text
first call include_console=True
later call include_console=False
```

will not remove the existing console handler.

This is genuine current behavior and matters to callers.

Classification:

```text
Important observation
```

---

# 18. Logger Propagation

The function explicitly sets:

```python
logger.propagate = False
```

This prevents messages from flowing upward into the root logger.

Purpose:

```text
avoid duplicate terminal/log output
```

when root logging is also configured.

Therefore these run loggers are deliberately self-contained.

---

# 19. Logger Level

Every run/component logger is assigned:

```text
settings.log_level
```

File handlers and console handlers are also individually assigned the same level.

Therefore level filtering exists at both:

```text
logger
handler
```

levels.

---

# 20. `setup_run_logging()`

## Purpose

Initialize the complete logging environment for one pipeline run.

### Inputs

```text
run_id
include_console=True
```

### Validation

First runs:

```text
validate_run_id()
```

### Processing

Constructs:

```text
settings.get_run_log_directory(run_id)
```

then creates:

```text
<project_root>/logs/<run_id>/
```

using:

```python
mkdir(parents=True, exist_ok=True)
```

Then iterates through:

```text
settings.log_file_names
```

and calls:

```text
get_run_logger()
```

for every configured component.

### Return

```text
dict[str, logging.Logger]
```

Example conceptually:

```text
{
    "pipeline": <Logger ...>,
    "preprocessing": <Logger ...>,
    "xgboost": <Logger ...>,
    ...
}
```

### Side effects

Creates:

- run log directory;
    
- one component logfile per configured component;
    
- logger objects and handlers.
    

---

# 21. `setup_run_logging()` Directory Failure

If:

```text
run_log_directory.mkdir(...)
```

raises `OSError`, it is converted to:

```text
RunDirectoryError
```

with:

```text
error_code =
RUN_LOG_DIRECTORY_CREATION_FAILED
```

and details containing:

```text
run_id
directory
original_error
```

The original exception is chained.

This creates a structured distinction between:

```text
cannot create run log directory
```

and:

```text
cannot create a specific component log file
```

which uses `LOG_FILE_CREATION_FAILED`.

---

# 22. Full Run Logging Creation Flow

```text
run_id
  │
  ▼
validate_run_id()
  │
  ▼
logs/<run_id>/
  │
  ▼
mkdir()
  │
  ▼
for every configured component
  │
  ├── pipeline
  ├── preprocessing
  ├── xgboost
  ├── isolation_forest
  ├── reporting
  ├── agents
  └── api
       │
       ▼
get_run_logger()
       │
       ├── FileHandler
       └── optional StreamHandler
       │
       ▼
dict of component loggers
```

---

# 23. `close_run_logging()`

## Purpose

Release logging resources associated with one pipeline run.

This is intended to be called when the run has completed and file handlers no longer need to remain open.

### Inputs

```text
run_id
```

### Validation

Calls:

```text
validate_run_id()
```

### Processing

Builds prefix:

```text
telecom_anomaly_backend.<run_id>.
```

Then obtains all registered logger names from:

```python
logging.Logger.manager.loggerDict.keys()
```

For every logger whose name starts with the run prefix:

```text
for each handler:
    flush()
    close()
    removeHandler()
```

### Return

```text
None
```

### Side effects

- flushes buffered logging output;
    
- closes handlers;
    
- releases associated file resources;
    
- removes handlers from logger objects.
    

---

# 24. Cleanup Scope

Cleanup applies to every logger matching:

```text
telecom_anomaly_backend.<run_id>.*
```

rather than only the currently configured component list.

This means cleanup is based on the logger namespace and run identity.

That is useful if additional namespaced loggers were created for the run.

---

# 25. Logger Objects Are Not Removed From `loggerDict`

`close_run_logging()` removes the handlers but does not explicitly remove the logger objects themselves from:

```text
logging.Logger.manager.loggerDict
```

Therefore the logger can remain registered globally with zero handlers.

If `get_run_logger()` is called again later:

```text
logger.handlers
```

will be empty and the file/console handlers will be recreated.

Classification:

```text
No issue / intentional lifecycle behavior
```

---

# 26. Run-Specific vs Global Logging

This module uses Python's global logging registry but creates **run-scoped logger identities**.

Therefore:

```text
global process logging registry
          │
          ├── telecom_anomaly_backend.run_A.pipeline
          ├── telecom_anomaly_backend.run_A.xgboost
          ├── telecom_anomaly_backend.run_B.pipeline
          └── telecom_anomaly_backend.run_B.xgboost
```

Each run/component combination receives its own logger and normally its own file.

Thus the backend has process-global logger registration but run-specific logger configuration/output.

---

# 27. Dependencies

## Project Imports

### `app.core.config.settings`

Used for:

- log level;
    
- format;
    
- date format;
    
- component filename mapping;
    
- run log directory paths;
    
- component logfile paths.
    

This makes `config.py` the source of logging defaults and paths.

### `ConfigurationError`

Used when a caller requests an unknown logging component.

### `RunDirectoryError`

Used for:

- invalid run IDs;
    
- run log directory creation failure;
    
- component log file creation failure.
    

---

## External / Standard Library

### `logging`

Provides:

- `Formatter`;
    
- `FileHandler`;
    
- `StreamHandler`;
    
- `Logger`;
    
- logger manager/registry.
    

### `pathlib.Path`

Used in the file-handler path contract.

No third-party logging package is used.

---

# 28. Validation and Failure Behaviour

## Configuration Error

Raised when:

```text
component_name
```

is not configured.

Exception:

```text
ConfigurationError
UNKNOWN_LOG_COMPONENT
```

---

## Input / Run-Identifier Validation Error

Unsafe run IDs raise:

```text
RunDirectoryError
```

with:

```text
EMPTY_RUN_ID
or
INVALID_RUN_ID
```

Although the problem is technically validation-related, this module categorizes it as a run-directory concern.

---

## Filesystem Error

Run log directory creation failure:

```text
RunDirectoryError
RUN_LOG_DIRECTORY_CREATION_FAILED
```

Component log creation failure:

```text
RunDirectoryError
LOG_FILE_CREATION_FAILED
```

---

## Internal Processing Errors

No custom general internal-processing error is used.

Unexpected errors outside the explicitly caught `OSError` cases propagate normally.

---

# 29. Side Effects / Global Behaviour

This file has important process-level behavior.

## Logger registry mutation

Calling:

```text
logging.getLogger(name)
```

creates/retrieves objects in Python's process-global logging registry.

---

## Handler attachment

`get_run_logger()` attaches:

```text
FileHandler
StreamHandler
```

to logger objects.

---

## Filesystem changes

May create:

```text
logs/<run_id>/
```

and:

```text
logs/<run_id>/<component>.log
```

---

## File resources

File handlers keep log files open until handlers are closed.

`close_run_logging()` explicitly releases these resources.

---

## Root logger behavior

This module does not modify the root logger, but individual run loggers use:

```text
propagate=False
```

to stop propagation to it.

---

# 30. Files Written

The module writes log output through Python's logging subsystem to files configured under:

```text
<project_root>/logs/<run_id>/
```

Default component filenames inherited from `config.py` are:

```text
pipeline.log
preprocessing.log
xgboost.log
isolation_forest.log
reporting.log
agents.log
api.log
```

The handlers are opened in append mode.

Therefore an existing logfile is preserved and new messages are appended.

---

# 31. Per-Run Logging Lifecycle

The intended lifecycle is:

```text
Pipeline/workflow receives run_id
             │
             ▼
setup_run_logging(run_id)
             │
             ├── validate run ID
             ├── create logs/<run_id>
             └── create component loggers
             │
             ▼
Backend stages execute
             │
             ├── pipeline logger
             ├── preprocessing logger
             ├── model logger
             ├── reporting logger
             └── etc.
             │
             ▼
component log files
             │
             ▼
run finishes
             │
             ▼
close_run_logging(run_id)
             │
             ├── flush handlers
             ├── close handlers
             └── remove handlers
```

---

# 32. Interaction With Run Directories

This module owns:

```text
logs/<run_id>/
```

logging directories.

It does **not** own the general pipeline artifact directory:

```text
runs/<run_id>/
```

That distinction is important.

Conceptually:

```text
config.py
├── runs root
└── logs root

run_directory_service.py
→ expected to manage runs/<run_id>/...

logging_config.py
→ manages logs/<run_id>/...
```

The exact run-directory service behavior will need to be confirmed from that service file.

---

# 33. Expected Callers

Likely callers based on the implementation include:

```text
pipeline/workflow orchestrator
application startup/run setup
API test/workflow routes
preprocessing runner
training workflows
inference workflows
reporting layer
agents
```

Typical expected usage is likely:

```text
setup_run_logging()
        ↓
receive logger dictionary
        ↓
pass specific logger to processing modules
```

or:

```text
get_run_logger(run_id, component)
```

for direct component access.

Exact callers are **UNKNOWN / NOT CONFIRMED** from this file alone.

---

# 34. Architectural Significance

`logging_config.py` gives the backend a consistent **run-aware observability boundary**.

Without it, modules could:

- use unrelated logger names;
    
- log everything into one file;
    
- accidentally duplicate handlers;
    
- propagate records multiple times;
    
- leave files open after runs;
    
- use inconsistent formatting.
    

Instead:

```text
config.py
      ↓
global logging settings
      ↓
logging_config.py
      ↓
run + component-specific logger
      ↓
logs/<run_id>/<component>.log
```

This allows operational information to be traced by both:

```text
run
```

and:

```text
backend component
```

which is particularly useful for long multi-stage training/inference pipelines.

---

# 35. Relationship to Future Run Registry / Database

The logger hierarchy already relies on:

```text
run_id
```

as a stable shared identifier.

That means a later database/run registry can logically associate:

```text
run_id
→ run metadata
→ artifact directory
→ logging directory
```

However, this file does not store:

- database records;
    
- run creation timestamps;
    
- user identity;
    
- run status;
    
- stage status.
    

It only uses a run ID supplied by another layer.

---

# 36. Potential Issues / Observations

## Important — handler configuration is fixed on first call

Because:

```python
if logger.handlers:
    return logger
```

the first configuration wins.

Example:

```text
first:
get_run_logger(..., include_console=False)

later:
get_run_logger(..., include_console=True)
```

The second call does not add a console handler.

The reverse also applies.

Therefore `include_console` is not dynamically reconfigurable while handlers already exist.

---

## Important — existing logger handlers are trusted blindly

The duplication-prevention logic checks only:

```text
logger.handlers
```

It does not confirm that existing handlers are:

- the expected file handler;
    
- pointing at the expected logfile;
    
- using the current log level;
    
- using the current formatter.
    

If some other code modifies the logger first, this function will treat it as already configured.

This is a genuine architectural observation, though likely low-risk in the intended controlled backend.

---

## Important — log-level changes after logger creation do not fully propagate automatically

`settings.log_level` is read when:

- the logger is configured;
    
- handlers are configured.
    

If configuration were mutated later, existing logger/handler levels are not automatically refreshed.

Since `settings` is normally treated as application-wide configuration, this is likely intentional.

---

## Minor — run-ID validation is intentionally limited

It blocks:

```text
empty
.
..
/
\
```

but permits other potentially filesystem-sensitive characters.

Whether those are valid depends on operating system and the run-ID generator.

Since another service is expected to generate run IDs, this may be sufficient for current usage.

---

## Minor — console handler target is implicit

`logging.StreamHandler()` is called without specifying a stream.

Therefore Python's default stream behavior is used.

The module does not explicitly state:

```text
stdout
or
stderr
```

in the implementation.

---

## Minor — file encoding is fixed here instead of using `settings.default_file_encoding`

File handlers explicitly use:

```text
encoding="utf-8"
```

rather than:

```text
settings.default_file_encoding
```

This creates a small configuration asymmetry.

It may be intentional because log encoding can remain fixed even when input-file encoding changes.

---

## Minor — `setup_run_logging()` eagerly creates all component loggers

Calling it initializes loggers/files for every entry in:

```text
settings.log_file_names
```

even if some components are not used in that particular run.

Therefore a run may contain empty component log files.

This is not necessarily a problem; it is a consequence of eager all-component setup.

---

## No issue / intentional — append mode

Log files use:

```text
mode="a"
```

so reopening the same run logger does not destroy prior run log content.

This is consistent with safe continuation/reopening behavior, although actual run-reopen semantics belong elsewhere.

---

## No issue / intentional — logger propagation disabled

```text
logger.propagate = False
```

is explicitly used to prevent duplicate output through the root logger.

---

## No issue / intentional — cleanup is run scoped

`close_run_logging()` targets logger names by the run namespace rather than globally closing unrelated application loggers.

---

# 37. Logging Responsibility Boundary

## `logging_config.py` owns

```text
run-ID safety for logging paths
component validation
formatter creation
file handler creation
console handler creation
logger naming
logger setup
handler deduplication
run logging directory creation
run-specific component log files
logger cleanup
```

## `logging_config.py` does not own

```text
run-ID generation
general artifact-run directory structure
manifest state
log rotation
log retention
log upload
database persistence
pipeline status
API error responses
actual business/ML log messages
```

---

# 38. Interaction With `config.py`

The dependency direction is:

```text
config.py
   │
   ├── log level
   ├── log format
   ├── date format
   ├── log component filenames
   ├── log root path
   └── component path helper
        │
        ▼
logging_config.py
   │
   ├── validate
   ├── instantiate handlers
   ├── instantiate loggers
   ├── create directories/files
   └── clean up
```

Therefore:

```text
config.py
→ defines logging configuration

logging_config.py
→ operationalizes it
```

---

# 39. Interaction With `exceptions.py`

The module uses two exception categories:

```text
ConfigurationError
RunDirectoryError
```

Conceptually:

```text
unknown logging component
        ↓
ConfigurationError

unsafe run ID
run log directory failure
component log file failure
        ↓
RunDirectoryError
```

This is a concrete example of `exceptions.py` acting as the shared Core error contract.

---

# 40. Compact File Contract

```text
FILE:
app/core/logging_config.py

RESPONSIBILITY:
Create, configure, retrieve, and clean up run-specific and
component-specific Python loggers.

PUBLIC INTERFACE:
LOGGER_NAMESPACE
validate_run_id()
validate_component_name()
create_log_formatter()
create_file_handler()
create_console_handler()
build_logger_name()
get_run_logger()
setup_run_logging()
close_run_logging()

INPUTS:
run_id
component_name
include_console
settings.log_level
settings.log_format
settings.log_date_format
settings.log_file_names
settings logging paths

OUTPUTS:
Validated run/component identifiers
logging.Formatter
logging.FileHandler
logging.StreamHandler
logging.Logger
dict[str, logging.Logger]

SIDE EFFECTS:
Creates logs/<run_id>/ directories.
Creates/opens component log files in append mode.
Registers/retrieves Python logger objects.
Attaches handlers.
Writes logs when callers emit records.
Flushes/closes/removes handlers during cleanup.

ERRORS:
RunDirectoryError:
- EMPTY_RUN_ID
- INVALID_RUN_ID
- LOG_FILE_CREATION_FAILED
- RUN_LOG_DIRECTORY_CREATION_FAILED

ConfigurationError:
- UNKNOWN_LOG_COMPONENT

Unexpected non-OSError failures may propagate normally.

USED BY:
Expected pipeline/workflow setup, ML stages, API routes, reporting,
agents, and other backend components requiring run-scoped logging.
Exact callers are UNKNOWN / NOT CONFIRMED from this file alone.

ARCHITECTURAL ROLE:
Provide the backend's run-aware logging lifecycle, separating logging
configuration from runtime logger/handler management and giving each
pipeline run and backend component an independently traceable log file.
```

---

# Final Assessment

`logging_config.py` converts the static logging definitions in `config.py` into the backend's **actual runtime logging infrastructure**.

The core lifecycle is:

```text
settings
   ↓
run_id + component
   ↓
validated logger identity
   ↓
telecom_anomaly_backend.<run_id>.<component>
   ↓
FileHandler
+
optional StreamHandler
   ↓
logs/<run_id>/<component>.log
   ↓
pipeline executes
   ↓
close_run_logging()
   ↓
flush + close + remove handlers
```

The most important architectural distinction is:

```text
config.py
→ defines where/how logging should work

logging_config.py
→ creates and manages the actual loggers

run/workflow layer
→ supplies run_id and uses those loggers
```

Together with `exceptions.py`, this file already demonstrates the intended Core architecture: centralized configuration, structured errors, and reusable run-scoped infrastructure with ML/workflow logic remaining outside Core.