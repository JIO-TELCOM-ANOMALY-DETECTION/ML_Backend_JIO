# Core Module — Final Technical Summary

**Module Location:** `app/core/`

### Files

| File                | Main Responsibility                                                                                       |
| ------------------- | --------------------------------------------------------------------------------------------------------- |
| `config.py`         | Central application-wide configuration, common paths, logging defaults, and base-directory initialization |
| `exceptions.py`     | Shared structured exception hierarchy for backend failures                                                |
| `logging_config.py` | Run-specific/component-specific logger creation, handler management, and cleanup                          |
| `__init__.py`       | Stable public import surface for the Core package                                                         |

## Together these files provide the backend's **shared infrastructure layer** for configuration, structured failures, and run-aware logging.

# 1. Purpose of `app/core`

`app/core` contains infrastructure that is intended to be usable across the entire backend rather than belonging to one ML stage.

Its current responsibilities are:

```text
application-wide configuration
+
shared filesystem locations
+
structured backend exception types
+
run-specific logging infrastructure
```

Conceptually:

```text
                    app/core
                       │
        ┌──────────────┼──────────────┐
        ▼              ▼              ▼
   Configuration    Exceptions      Logging
        │              │              │
        └──────────────┼──────────────┘
                       ▼
          Rest of backend application
```

Core does **not** implement Parts A–E, workflow orchestration, file persistence, run manifests, or model execution itself.

## Instead, it supplies common infrastructure those layers can depend on.

# 2. File Responsibility Map

|File|Main responsibility|
|---|---|
|`config.py`|Define validated global settings and shared paths|
|`exceptions.py`|Define one common backend error vocabulary|
|`logging_config.py`|Turn logging settings into run/component-specific loggers and log files|
|`__init__.py`|Expose the intended public Core API|

The dependency direction inside Core is:

```text
config.py           exceptions.py
    │                    │
    └────────┬───────────┘
             ▼
      logging_config.py
             │
             ▼
         __init__.py
```

`config.py` and `exceptions.py` do not depend on other project modules.

`logging_config.py` depends on both:

```text
settings
ConfigurationError
RunDirectoryError
```

## `__init__.py` then imports selected public objects from all three files.

# 3. `__init__.py` — Public Core Interface

`__init__.py` deliberately provides a stable package-level import surface:

```python
from app.core import ...
```

rather than requiring every consumer to know whether an object lives inside:

```text
config.py
exceptions.py
logging_config.py
```

Its public API is explicitly controlled through `__all__`.

---

# 4. Public API Map

## Configuration

Exported:

```text
Settings
settings
```

Therefore consumers can either:

```text
use the shared singleton
```

or:

```text
construct/use the Settings class
```

where appropriate.

---

## Exceptions

All custom backend exception classes are publicly exported:

```text
TelecomBackendError

ConfigurationError
InputValidationError
FileProcessingError

RunDirectoryError
RunManifestError
PipelineExecutionError

PreprocessingError

ModelExecutionError
ModelNotFoundError
ResultCombinationError

ReportingError
AgentExecutionError
EmailDeliveryError
```

This makes the complete shared exception taxonomy available from:

```python
from app.core import ...
```

---

## Logging

Only the primary lifecycle functions are exported:

```text
get_run_logger
setup_run_logging
close_run_logging
```

Several lower-level helpers remain internal to `logging_config.py`, including:

```text
validate_run_id
validate_component_name
create_log_formatter
create_file_handler
create_console_handler
build_logger_name
LOGGER_NAMESPACE
```

This is an important interface boundary.

## External modules are encouraged to depend on the high-level logging lifecycle rather than manually building handlers or logger names.

# 5. Configuration Lifecycle

The global configuration lifecycle begins when `config.py` is imported.

```text
Physical config.py location
          │
          ▼
DEFAULT_PROJECT_ROOT
          │
          ├──────────────► <default root>/.env
          │
          ▼
       Settings()
          │
          ├── hard-coded defaults
          ├── environment variables
          └── .env values
          │
          ▼
   Pydantic validation
          │
          ├── project-root normalization
          ├── file-size validation
          └── log-level normalization
          │
          ▼
       settings
   shared singleton
          │
          ▼
 application-wide usage
```

The singleton is created directly at module import:

```python
settings = Settings()
```

so configuration resolution and validation occur during import rather than through a later explicit startup function.

---

# 6. Application-Wide Configuration Provided

`Settings` currently centralizes four main categories.

## Application metadata

```text
app_name
app_version
api_prefix
environment
debug
```

Defaults include:

```text
app_name    = Telecom Anomaly Detection Backend
app_version = 0.1.0
api_prefix  = /api/v1
environment = local
debug       = False
```

The file stores these settings but does not itself construct the API or enforce environment-specific application behavior.

---

## Input-file configuration

```text
max_input_file_size_gb
allowed_input_extensions
default_file_encoding
```

Current defaults:

```text
maximum file size = 5.0 GB
extensions        = .csv
encoding          = utf-8
```

The derived property:

```text
max_input_file_size_bytes
```

converts the configured size into bytes.

Actual input-file checking remains outside Core.

---

## Logging configuration

```text
log_level
log_format
log_date_format
log_file_names
```

Current component mapping:

```text
pipeline          → pipeline.log
preprocessing     → preprocessing.log
xgboost           → xgboost.log
isolation_forest  → isolation_forest.log
reporting         → reporting.log
agents            → agents.log
api               → api.log
```

`config.py` defines these values.

## `logging_config.py` operationalizes them.

## Shared filesystem locations

All major paths are derived from:

```text
project_root
```

Current shared path model:

```text
<project_root>/
│
├── app/
│
├── runs/
│
├── logs/
│
└── model_artifacts/
    ├── xgboost/
    ├── isolation_forest/
    └── model_metadata/
```

`config.py` can also derive:

```text
runs/<run_id>
logs/<run_id>
logs/<run_id>/<component_log_file>
```

but path construction does not necessarily mean directory creation.

---

# 7. Base Directory Initialization

`Settings.create_base_directories()` explicitly creates only the shared parent storage areas:

```text
runs/
logs/
model_artifacts/xgboost/
model_artifacts/isolation_forest/
model_artifacts/model_metadata/
```

using:

```text
parents=True
exist_ok=True
```

It does not create individual:

```text
runs/<run_id>/
```

directories.

The source explicitly delegates individual run-directory creation to:

```text
run_directory_service.py
```

which establishes a clear Core → Services responsibility boundary.

---

# 8. Exception Hierarchy

The complete exception hierarchy is:

```text
Exception
   │
   ▼
TelecomBackendError
   │
   ├── ConfigurationError
   ├── InputValidationError
   ├── FileProcessingError
   ├── RunDirectoryError
   ├── RunManifestError
   ├── PipelineExecutionError
   ├── PreprocessingError
   ├── ModelExecutionError
   ├── ModelNotFoundError
   ├── ResultCombinationError
   ├── ReportingError
   ├── AgentExecutionError
   └── EmailDeliveryError
```

Every custom backend exception therefore satisfies:

```text
isinstance(error, TelecomBackendError)
```

allowing higher layers to either catch individual categories or all recognized backend failures together.

---

# 9. Common Exception Contract

Every custom backend error inherits:

```text
message
error_code
details
```

Constructor:

```text
message: str
error_code: str | None
details: dict | None
```

The common structured form returned by:

```text
to_dict()
```

is:

```text
{
    "error_type": <actual exception class>,
    "message": ...,
    "error_code": ...,
    "details": ...
}
```

This provides a common internal representation suitable for later consumption by:

```text
logging
manifests
API handlers
workflow state
```

where implemented.

`exceptions.py` itself does not perform those operations.

---

# 10. Error Responsibility Categories

The hierarchy creates the following broad backend vocabulary:

|Failure area|Exception|
|---|---|
|Backend configuration|`ConfigurationError`|
|Request/dataset validation|`InputValidationError`|
|Generic file operations|`FileProcessingError`|
|Run directory|`RunDirectoryError`|
|Run manifest|`RunManifestError`|
|Pipeline/workflow|`PipelineExecutionError`|
|Data transformation|`PreprocessingError`|
|Model execution|`ModelExecutionError`|
|Missing model|`ModelNotFoundError`|
|Result integration|`ResultCombinationError`|
|Reporting|`ReportingError`|
|Agent|`AgentExecutionError`|
|Email|`EmailDeliveryError`|

The Core module therefore standardizes **what type of backend failure occurred** while leaving recovery or transport-specific behavior to higher layers.

---

# 11. Logging Lifecycle

Logging is explicitly tied to a:

```text
run_id
+
component
```

combination.

Overall lifecycle:

```text
workflow / pipeline run
        │
        ▼
setup_run_logging(run_id)
        │
        ├── validate run ID
        ├── create logs/<run_id>/
        └── configure component loggers
        │
        ▼
telecom_anomaly_backend.<run_id>.<component>
        │
        ├── FileHandler
        └── optional StreamHandler
        │
        ▼
backend processing
        │
        ▼
logs/<run_id>/<component>.log
        │
        ▼
run finishes
        │
        ▼
close_run_logging(run_id)
        │
        ├── flush
        ├── close
        └── remove handlers
```

---

# 12. Run ID Validation for Logging

Before run IDs are used in logging paths, `logging_config.py` rejects:

```text
empty values
"."
".."
"/"
"\"
```

and strips surrounding whitespace.

Unsafe identifiers raise:

```text
RunDirectoryError
```

with structured error codes such as:

```text
EMPTY_RUN_ID
INVALID_RUN_ID
```

## This is important because the lower-level path helpers in `config.py` intentionally perform no run-ID sanitization themselves.

# 13. Component Validation

Logging component names are normalized using:

```text
strip()
lower()
```

then validated against:

```text
settings.log_file_names
```

Unknown components raise:

```text
ConfigurationError
```

with:

```text
UNKNOWN_LOG_COMPONENT
```

This means component ownership is centralized in configuration rather than hardcoded separately throughout the logging subsystem.

---

# 14. Per-Run / Per-Component Logging

Logger names follow:

```text
telecom_anomaly_backend.<run_id>.<component>
```

while log files follow:

```text
<project_root>/logs/<run_id>/<component_log_file>
```

Example:

```text
Python logger:
telecom_anomaly_backend.run_123.xgboost

File:
logs/run_123/xgboost.log
```

This gives logs two useful dimensions:

```text
which run?
which backend component?
```

---

# 15. Logging Handlers

## File handler

Uses:

```text
mode = append
encoding = utf-8
```

and creates missing parent directories.

Filesystem `OSError`s are translated into:

```text
RunDirectoryError
LOG_FILE_CREATION_FAILED
```

---

## Console handler

Uses Python's standard:

```text
logging.StreamHandler
```

with the same configured log level and formatter.

Console output is optional through:

```text
include_console
```

---

# 16. Handler Duplication Prevention

`get_run_logger()` checks:

```python
if logger.handlers:
    return logger
```

before attaching handlers.

Therefore repeated retrieval of an already-configured run/component logger does not add duplicate handlers.

Additionally:

```python
logger.propagate = False
```

prevents run logger messages from automatically propagating to the root logger and potentially appearing twice.

---

# 17. Logging Cleanup

`close_run_logging()` finds registered loggers beginning with:

```text
telecom_anomaly_backend.<run_id>.
```

and then:

```text
flushes handlers
closes handlers
removes handlers
```

This releases file resources after pipeline execution.

Logger objects themselves may remain in Python's global logger registry, but with their handlers removed they can later be configured again.

---

# 18. Core Interaction With ML Modules

Core does not contain ML logic.

Instead it can provide Parts A–E with infrastructure such as:

```text
settings
        ↓
shared configuration/path information

custom exceptions
        ↓
structured failures

run/component loggers
        ↓
runtime observability
```

For example, the existing ML reports already establish that Parts A–C use Core exception types and logging infrastructure as dependencies.

However, exact import relationships for every Part A–E source file are outside the four Core files themselves and are therefore not reconstructed here beyond previously confirmed module documentation.

---

# 19. Core Interaction With Workflows

The Core package provides several elements that naturally support workflow execution:

```text
run_id path helpers
run-specific loggers
PipelineExecutionError
structured error serialization
```

But Core itself does not:

```text
generate run IDs
start pipelines
track stage completion
resume pipelines
record workflow status
```

Those are workflow/service concerns.

## The run ID is **supplied to Core**, not generated by Core.

# 20. Core Interaction With Services

The current implementation already establishes boundaries relevant to Services.

## Run directory service

`config.py` explicitly states that individual run directories are expected to be created by:

```text
run_directory_service.py
```

Core supplies the root/path concept:

```text
runs/
runs/<run_id>
```

but does not manage the run's artifact hierarchy.

---

## Manifest service

Core defines:

```text
RunManifestError
```

and its base error can produce:

```text
to_dict()
```

which the exception documentation explicitly identifies as potentially useful for manifests.

The actual manifest format and lifecycle remain the responsibility of Services and are **UNKNOWN / NOT CONFIRMED** from Core alone.

---

## File service

Core defines:

```text
FileProcessingError
```

and input restrictions such as:

```text
allowed_input_extensions
maximum file size
default file encoding
```

but it does not implement CSV/JSON reading or writing.

## That belongs to the Services layer.

# 21. Core Filesystem Responsibilities

The current filesystem responsibility split is:

```text
config.py
│
├── calculate paths
└── optionally create shared base directories

logging_config.py
│
├── create logs/<run_id>/
└── create/open component log files

exceptions.py
└── no filesystem behavior

__init__.py
└── no direct filesystem behavior
```

Core does **not** currently create:

```text
runs/<run_id>/<pipeline stages...>
```

or write ML datasets/manifests.

---

# 22. Global / Process-Level Side Effects

There are several important process-level behaviors.

## Importing Core

Because `__init__.py` imports:

```text
Settings
settings
```

from `config.py`, importing the Core package causes the shared:

```text
settings = Settings()
```

object to exist.

## Therefore configuration/environment resolution occurs as part of Core import.

## Logging

Run logger creation interacts with Python's process-global logger registry.

Each logger is still run-specific by name, but the actual logger objects exist inside Python's global logging manager.

---

## Directory creation

No base directories are automatically created merely by importing Core.

They are created only when:

```text
settings.create_base_directories()
```

## or logging setup/file-handler creation explicitly performs `mkdir()`.

# 23. What Belongs Inside Core

Based on the current implementation, Core clearly owns application-wide infrastructure that should not depend on a specific ML stage.

Current examples are:

```text
shared settings
application metadata
environment-level configuration
common storage-root definitions
logging defaults
custom exception types
run-specific logger setup
logger cleanup
```

The characteristic pattern is:

> functionality broadly reusable across API, services, workflows, and ML modules without implementing their business logic.

---

# 24. What Clearly Does NOT Belong Inside Core

Based on the current responsibility boundaries, the following are outside Core:

```text
CSV/JSON persistence
run directory hierarchy management
run manifest state management
Part A EDA
Part B preprocessing
Part C feature calculation
Part D training
Part E inference
model serialization
pipeline orchestration
database/run registry logic
HTTP route implementation
report generation itself
email delivery implementation
```

Core may provide configuration or exception types for these systems, but it does not perform their domain operations.

---

# 25. Public Import Surface

The final intended package-level usage is:

```text
app.core
│
├── Settings
├── settings
│
├── TelecomBackendError
├── ConfigurationError
├── InputValidationError
├── FileProcessingError
├── RunDirectoryError
├── RunManifestError
├── PipelineExecutionError
├── PreprocessingError
├── ModelExecutionError
├── ModelNotFoundError
├── ResultCombinationError
├── ReportingError
├── AgentExecutionError
├── EmailDeliveryError
│
├── get_run_logger
├── setup_run_logging
└── close_run_logging
```

Lower-level implementation helpers are intentionally not exported through `__all__`.

---

# 26. Architectural Flow

The completed Core architecture can be summarized as:

```text
              Environment / .env / defaults
                         │
                         ▼
                     config.py
                         │
                         ▼
                      settings
                         │
         ┌───────────────┼────────────────┐
         │               │                │
         ▼               ▼                ▼
      Paths          Log defaults     App settings
         │               │
         │               ▼
         │       logging_config.py
         │               │
         │               ▼
         │        per-run/component logs
         │
         ▼
       Services / Workflows / ML


              Backend operation failure
                         │
                         ▼
                   exceptions.py
                         │
                         ▼
                TelecomBackendError
                         │
           message + code + details
                         │
                         ▼
          workflow / logs / manifest / API
```

---

# 27. Issues / Open Observations

## Important — `.env` path is tied to the physical default project root

The `.env` file is configured as:

```text
DEFAULT_PROJECT_ROOT/.env
```

rather than:

```text
settings.project_root/.env
```

Therefore overriding `PROJECT_ROOT` does not change where the initial `.env` file is searched.

This may be intentional, but deployment code must understand the distinction.

---

## Important — settings are instantiated during import

Because:

```python
settings = Settings()
```

is global, malformed configuration can cause importing Core-dependent modules to fail immediately.

This creates a straightforward singleton lifecycle but makes configuration validity part of application import/startup.

---

## Important — machine-readable error codes are not centrally constrained

`TelecomBackendError.error_code` is:

```text
str | None
```

with no enum/registry.

The exception classes themselves are standardized, but callers remain responsible for maintaining consistent error-code naming.

---

## Important — exception `details` has no fixed schema

`details` is a plain dictionary.

This gives callers flexibility but means API/manifest consumers cannot assume one universal internal shape beyond:

```text
details = dictionary
```

---

## Important — logging handler configuration is fixed by the first setup

Once a logger has any handlers:

```python
if logger.handlers:
    return logger
```

Therefore later calls cannot dynamically change:

```text
include_console
```

without first cleaning up the logger.

The first logger configuration effectively wins.

---

## Important edge case — dotted run IDs can overlap logger cleanup prefixes

`validate_run_id()` rejects path separators and `.`/`..` as complete IDs, but it allows periods inside an otherwise valid identifier.

Cleanup uses:

```text
telecom_anomaly_backend.<run_id>.
```

as a prefix.

Therefore, theoretically:

```text
run ID = abc
```

and another run such as:

```text
abc.xyz
```

share part of the same logger namespace.

Calling cleanup for `abc` could match loggers belonging to `abc.xyz`.

Whether this is practically reachable depends on the run-ID generator, which is outside Core and remains to be verified in `run_directory_service.py`.

---

## Minor — logging encoding is independently fixed to UTF-8

`config.py` provides:

```text
default_file_encoding
```

but logfile handlers explicitly use:

```text
utf-8
```

rather than that setting.

## This may be intentional because source-data encoding and log encoding are separate concerns.

## Minor — environment names are unrestricted

`environment` defaults to:

```text
local
```

but there is no allowed-value enum or relationship with `debug`.

This is configuration flexibility rather than a confirmed defect.

---

## Minor — `PreprocessingError` currently has broader terminology than Part B

The class documentation includes feature-generation failure even though the final backend separates feature engineering into Part C.

The class therefore appears to represent a broader processing-stage error category than its name strictly implies.

---

## No issue / intentional — low-level logging helpers are not public Core exports

`__init__.py` exports:

```text
get_run_logger
setup_run_logging
close_run_logging
```

but not internal formatter/handler construction helpers.

This keeps the package-level logging interface small and stable.

---

# 28. Production-Relevant Information Already Established

Without designing future systems, Core already establishes several facts important to production architecture:

### One shared project root

Most storage paths derive from:

```text
settings.project_root
```

### Separate run artifacts and logs

```text
runs/<run_id>
logs/<run_id>
```

are separate path trees.

### Run ID is an external/shared identifier

Core consumes the ID but does not generate it.

### Model artifact parents already exist conceptually

```text
model_artifacts/xgboost
model_artifacts/isolation_forest
model_artifacts/model_metadata
```

### Errors already support structured metadata

```text
error_type
message
error_code
details
```

### Logging is already run-aware

```text
run_id + component
→ independent logfile
```

These will matter later when Services/workflows/database responsibilities are analyzed, but Core itself does not implement those layers.

---

# 29. Final Compact Contract

```text
CORE PURPOSE:
Provide application-wide infrastructure shared by the telecom anomaly
backend: configuration, structured exceptions, and run-specific logging.

PROVIDES:
Settings / settings
Shared filesystem path definitions
Input-file configuration
Logging configuration
Custom exception hierarchy
Run/component logger lifecycle

CONFIGURATION:
Pydantic BaseSettings-backed configuration.
Values come from defaults, environment variables, and the default project
root .env file.
A shared Settings singleton is created when config.py is imported.

ERROR HANDLING:
All custom backend errors inherit TelecomBackendError and expose:
message
error_code
details
to_dict()

LOGGING:
One logger namespace per:
run_id + component

Logger pattern:
telecom_anomaly_backend.<run_id>.<component>

Log path:
logs/<run_id>/<configured_component_file>

Supports:
file handler
optional console handler
duplicate-handler prevention
root propagation prevention
run-scoped cleanup

FILESYSTEM SIDE EFFECTS:
config.py can create shared base directories when explicitly requested.
logging_config.py creates run log directories and component log files.
Core does not create the complete runs/<run_id> artifact hierarchy.

EXPECTED CALLERS:
API layer
pipeline/workflow orchestration
Services
Parts A-E / ML modules
reporting
agents
application startup

Exact source-level callers not visible from these four files are
UNKNOWN / NOT CONFIRMED.

IMPORTANT PRODUCTION CONSIDERATIONS:
Run IDs are shared identifiers but are not generated by Core.
Configuration is instantiated during import.
.env discovery is based on DEFAULT_PROJECT_ROOT.
Machine-readable error codes/details remain caller-controlled.
Logger handler configuration is effectively fixed on first creation.
Run-directory, manifest, persistence, and workflow state remain outside
Core.
```

---

# 30. Final Architectural Summary

The completed Core module can be reduced to four clear responsibilities:

```text
config.py
→ Defines application-wide settings, common storage locations, logging
  defaults, and shared base-directory initialization.

exceptions.py
→ Defines the common structured error vocabulary used throughout the
  backend.

logging_config.py
→ Converts the logging configuration into per-run/per-component logger
  instances, files, handlers, and cleanup behavior.

__init__.py
→ Exposes the stable public Core API and hides lower-level implementation
  helpers from normal package-level consumers.
```

The overall architecture is therefore:

```text
                     APP / WORKFLOW
                           │
                           ▼
                     app.core
                           │
        ┌──────────────────┼──────────────────┐
        │                  │                  │
        ▼                  ▼                  ▼
   Configuration       Exceptions          Logging
        │                  │                  │
        ▼                  ▼                  ▼
shared settings      shared failure      run-specific
and paths             contract           observability
        │                  │                  │
        └──────────────────┼──────────────────┘
                           ▼
              Services + Parts A-E
```

`app/core` therefore acts as the backend's **shared application-infrastructure foundation**. It establishes common configuration, failure representation, and logging behavior while deliberately leaving persistence, run-directory management, manifests, workflows, and ML processing to their respective modules.