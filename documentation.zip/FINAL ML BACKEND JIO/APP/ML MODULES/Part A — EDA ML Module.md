# [[Part A Shared Dataset Schema — schema common.dataset.py]]
# Part A — EDA ML Module Final Technical Report

**Module:** Part A — Exploratory Data Analysis (EDA)  
**Module Location:** Part A EDA package containing the five files below

### Files

|File|Main Responsibility|
|---|---|
|`runner.py`|Orchestrates complete Part A execution|
|`data_preparation.py`|Validates/prepares the input dataset and separates KPIs|
|`site_analysis.py`|Identifies unique sites and calculates row counts|
|`server_validation.py`|Checks server-type consistency per site|
|`data_integrity.py`|Performs timestamp, missing-gap, duplicate, NaN and coverage analysis|

The runner explicitly expects these four processing files to live in the same package and imports them using relative imports.

---

# 1. Purpose of Part A

Part A is the **dataset understanding and structural-integrity stage** of the ML backend.

Its job is to take one configured source CSV and determine:

- which KPIs are present;
    
- which sites belong to each KPI;
    
- how many rows each site contains;
    
- whether server identity is consistent;
    
- what timestamp timeline should exist;
    
- which timestamps are missing;
    
- how missing timestamps form continuous gaps;
    
- whether duplicate timestamps exist;
    
- whether timestamps occur outside the expected grid;
    
- how many KPI values are NaN;
    
- overall and per-site timeline coverage.
    

Part A is primarily an **analysis stage**.

It does not:

- repair timelines;
    
- insert missing timestamps;
    
- fill missing KPI values;
    
- remove duplicates;
    
- remove outliers;
    
- generate features;
    
- train models;
    
- perform inference.
    

Those responsibilities remain with later pipeline stages.

---

# 2. Project Components Used by Part A

Part A depends on a small number of components outside its own module.

## Shared Dataset Schema

From:

`app/schemas/common/dataset.py`

Part A uses:

- `DatasetInputConfig`
    
- `DatasetColumnMapping`
    
- `BucketConfig`
    

The schema supplies:

- input-file path;
    
- source-column mappings;
    
- KPI information;
    
- bucket configuration;
    
- expected timeline configuration.
    

This is the same shared dataset schema used by other pipeline stages and is therefore documented separately.

---

## Core Exceptions

Part A uses:

- `InputValidationError`
    
- `FileProcessingError`
    

These provide structured backend failures when dataset validation or file processing cannot continue.

Their internal implementation belongs to the separate Core report.

---

## File Service

Part A uses the shared file service for operations such as:

- validating source files;
    
- reading CSV files;
    
- writing CSV files;
    
- creating directories;
    
- generating safe filenames.
    

The file-service implementation itself belongs to its separate service report.

---

# 3. Overall Part A Architecture

```text
DatasetInputConfig
        │
        ▼
┌─────────────────────────────┐
│      runner.py              │
│   run_eda_pipeline()        │
└──────────────┬──────────────┘
               │
               ▼
┌─────────────────────────────┐
│ data_preparation.py         │
│                             │
│ Validate input              │
│ Resolve KPI identity        │
│ Resolve bucket metadata     │
│ Split into KPI datasets     │
└──────────────┬──────────────┘
               │
               ▼
       One prepared CSV
          for each KPI
               │
        ┌──────┴──────┐
        │  For every  │
        │     KPI     │
        └──────┬──────┘
               │
               ▼
┌─────────────────────────────┐
│ site_analysis.py            │
│                             │
│ Identify unique sites       │
│ Calculate rows/site         │
└──────────────┬──────────────┘
               │
               ▼
     site-summary CSV
               │
               ├───────────────────────────┐
               │                           │
               ▼                           ▼
┌─────────────────────────┐   ┌──────────────────────────┐
│ server_validation.py    │   │ data_integrity.py        │
│                         │   │                          │
│ Check server types/site │   │ Timeline integrity       │
│ Log inconsistencies     │   │ Missing timestamps       │
└─────────────────────────┘   │ Gaps / duplicates / NaNs │
                              │ Coverage / off-grid       │
                              └──────────────────────────┘
```

The runner therefore serves as the orchestration layer while the individual files remain responsible for their own specific analysis.

---

# 4. `data_preparation.py`

## Responsibility

`data_preparation.py` performs the **common preparation required before Part A operates on individual KPI datasets**.

It:

1. validates the source file;
    
2. loads the CSV;
    
3. checks mandatory base columns;
    
4. resolves KPI identity;
    
5. resolves bucket configuration;
    
6. separates multiple KPIs;
    
7. writes one normalized CSV per KPI.
    

Even when the source contains only one KPI, one normalized KPI-specific file is still produced.

---

# 5. Dataset Preparation Outputs

Two result structures are defined.

## `PreparedKPIDataset`

Represents one prepared KPI file.

Contains:

- `kpi_name`
    
- `file_path`
    
- `row_count`
    

---

## `DatasetPreparationResult`

Represents the complete preparation operation.

Contains:

- original source file;
    
- prepared-dataset directory;
    
- resolved `BucketConfig`;
    
- all prepared KPI datasets;
    
- total input rows;
    
- whether the source had to be split.
    

---

# 6. Base Dataset Validation

### `validate_base_columns()`

Before KPI or bucket processing occurs, the dataset must contain the base columns defined by the shared schema.

These correspond logically to:

```text
Circle
Cluster
Site
Timestamp
KPI value
```

The physical column names come from `DatasetColumnMapping`.

If any are absent, preparation stops with:

`MISSING_BASE_DATASET_COLUMNS`

This means datasets can use custom physical column names as long as the schema maps them correctly.

---

# 7. KPI Resolution

### `resolve_kpi_column()`

Part A supports both:

```text
KPI identity inside CSV
```

and

```text
single_kpi_name supplied in request
```

Several cases are handled.

### KPI column absent + `single_kpi_name` supplied

The KPI column is created and filled with the declared KPI.

### KPI column absent + no declaration

Execution fails because KPI identity cannot be determined.

### KPI column and declaration both present

Existing non-empty KPI values must agree with the declared KPI.

Conflicting KPI values are rejected.

### Blank KPI values

If `single_kpi_name` exists, blank values may be filled using it.

Without a declared KPI, unresolved blank KPI values are rejected.

### Multiple KPIs

All valid KPI names are preserved so that separate KPI-specific datasets can later be written.

---

# 8. Bucket Resolution

### `resolve_bucket_config()`

Bucket information may come from:

```text
request
CSV
or both
```

The function resolves one uniform bucket configuration for the complete dataset.

---

## Case 1 — Bucket only in request

The corresponding bucket columns are added to the dataframe.

---

## Case 2 — Bucket only in CSV

CSV values are validated and converted into a `BucketConfig`.

---

## Case 3 — Bucket in both

The request and CSV values must agree.

Conflicts are rejected.

---

## Bucket Validation

Part A checks for:

- missing bucket metadata;
    
- only one of the two bucket columns existing;
    
- non-numeric bucket size;
    
- non-positive bucket size;
    
- fractional bucket size;
    
- multiple bucket types;
    
- multiple bucket sizes;
    
- request/CSV conflicts;
    
- unresolved missing bucket values.
    

After resolution, all rows receive a uniform bucket type and bucket size.

---

# 9. KPI File Creation

### `write_kpi_datasets()`

Once KPI and bucket information are resolved, the dataset is separated by KPI.

For each KPI:

```text
Complete dataset
      │
      ├── KPI A → KPI_A.csv
      ├── KPI B → KPI_B.csv
      └── KPI C → KPI_C.csv
```

Filenames are sanitized and collision protection is applied.

Therefore downstream Part A processing always operates on **one KPI at a time**.

---

# 10. Main Preparation Entry Point

### `prepare_dataset()`

This is the public orchestration function of `data_preparation.py`.

Execution flow:

```text
Input config
    │
    ▼
Validate source file
    │
    ▼
Read CSV
    │
    ▼
Reject empty dataset
    │
    ▼
Validate base columns
    │
    ▼
Resolve KPI information
    │
    ▼
Resolve bucket configuration
    │
    ▼
Write one file per KPI
    │
    ▼
DatasetPreparationResult
```

The destination directory is not decided inside this file.

Instead, the **runner supplies the exact prepared-dataset directory**, keeping folder-layout ownership with the runner.

---

# 11. `site_analysis.py`

## Responsibility

This is the first actual EDA analysis performed for every prepared KPI.

It answers two questions:

1. **What unique sites exist?**
    
2. **How many rows belong to each site?**
    

A unique site is defined using:

```text
Circle
+
Cluster
+
AMF Site Name
```

using whichever physical columns were configured through `DatasetColumnMapping`.

---

# 12. Site Analysis Validation

### `validate_site_analysis_input()`

Checks:

- dataframe is not empty;
    
- all configured site identity columns exist.
    

Missing site identity columns stop execution.

---

# 13. Missing Site Identity Detection

### `count_rows_with_missing_site_identity()`

Counts rows where at least one site identity component is missing.

For example:

```text
Circle = Mumbai
Cluster = <missing>
Site = AMF_01
```

is considered an incomplete site identity.

These rows are **not automatically removed**.

Instead, Part A records and logs them.

---

# 14. Unique Site Row Counts

### `create_site_row_count_summary()`

Uses the three site identity columns to group the KPI dataset.

Rows containing missing identity values are retained using:

```text
dropna=False
```

The resulting dataset contains:

```text
Circle
Cluster
Site
Row_Count
```

for every identified site combination.

The summary is sorted starting with sites having the smallest row counts.

---

# 15. Site Analysis Output

For each KPI, the following CSV is written:

```text
<prepared_KPI_name>_unique_site_row_counts.csv
```

The structured `SiteAnalysisResult` additionally records:

- source file;
    
- summary file;
    
- total rows;
    
- total unique sites;
    
- minimum rows/site;
    
- maximum rows/site;
    
- average rows/site;
    
- rows with missing site identity.
    

---

# 16. `server_validation.py`

## Responsibility

Checks whether each unique site has a consistent server type.

The same three-part site identity is used:

```text
Circle + Cluster + Site
```

The server column itself is optional.

---

# 17. Server Validation Rules

For every site, the module examines its non-blank server values.

### Exactly one server type

Site is considered:

```text
consistent
```

### More than one server type

Site is:

```text
inconsistent
```

A warning is logged.

### No usable server value

Site is:

```text
unresolved
```

### Some rows have blank server values

The missing values are counted and logged separately.

---

# 18. Optional Server Column Behaviour

If the configured server column does not exist:

```text
server validation is skipped
```

This does **not fail Part A**.

`check_skipped=True` is returned in the result.

Server consistency problems are therefore treated as **informational/warning-level EDA findings rather than fatal dataset errors**.

---

# 19. Server Validation Output

Unlike site analysis and integrity analysis:

**no CSV report is created.**

The result is returned as `ServerValidationResult`, containing:

- whether the check was skipped;
    
- total sites;
    
- consistent sites;
    
- inconsistent sites;
    
- unresolved sites;
    
- rows with missing server values;
    
- sites containing missing server values.
    

Detailed issues are written to the run logger.

---

# 20. `data_integrity.py`

## Responsibility

This is the largest analytical component of Part A.

It audits **timestamp completeness and integrity for every site belonging to one KPI**.

Importantly, the site list is not independently regenerated here.

Instead, it reads the unique-site summary produced by `site_analysis.py`, making site analysis the authoritative source of sites for integrity analysis.

---

# 21. Expected Timeline

The data-integrity module creates an `ExpectedTimeline` containing:

- selected method;
    
- timeline start;
    
- timeline end;
    
- expected frequency;
    
- complete expected timestamp index.
    

Three timeline methods are supported.

---

## A. `date_range`

Uses explicit:

```text
expected_start
expected_end
```

---

## B. `num_days`

Starts at the earliest valid timestamp and creates the configured number of complete days.

---

## C. `global_min_max`

Uses:

```text
earliest valid timestamp
        →
latest valid timestamp
```

for the prepared KPI dataset after site filtering.

Only **one method can be selected**.

---

# 22. Bucket → Timestamp Frequency

The bucket produced during preparation is converted by the runner into a Pandas `Timedelta`.

Supported units are:

- second / seconds
    
- minute / minutes
    
- hour / hours
    
- day / days
    

For example:

```text
Minutes + 15
```

becomes:

```text
15-minute expected frequency
```

This frequency is then supplied to data-integrity analysis.

---

# 23. Composite Site ID

`data_integrity.py` constructs:

```text
Composite_ID
```

from:

```text
Circle | Cluster | Site
```

Missing identity components are represented using:

```text
<MISSING>
```

This gives integrity analysis one stable identifier with which to track each site series.

---

# 24. Integrity Data Preparation

Before integrity calculations:

1. required columns are validated;
    
2. timestamps are parsed;
    
3. invalid timestamps become unusable and are counted;
    
4. KPI values are converted to numeric form;
    
5. composite IDs are created;
    
6. rows are filtered to sites present in the site-analysis summary.
    

If no rows remain after site filtering, integrity analysis stops.

---

# 25. Invalid and Out-of-Timeline Rows

Part A separately tracks:

```text
Rows with invalid timestamps
Rows before expected timeline
Rows after expected timeline
Rows inside expected timeline
```

Rows outside the timeline are recorded but are not treated as missing expected timestamps.

Integrity calculations operate on rows falling inside the selected timeline boundaries.

---

# 26. Global Missing Timestamps

### `create_global_missing_timestamps()`

Checks timestamps that are completely absent from the **entire KPI dataset**.

Example:

```text
Expected:
00:00
00:15
00:30
00:45

Observed anywhere:
00:00
00:15
00:45

Global missing:
00:30
```

This is different from a timestamp missing for only one individual site.

---

# 27. Per-Site Missing Timestamps

For each site:

```text
Expected Timeline
      -
Observed Site Timestamps
      =
Missing Site Timestamps
```

The module calculates:

- expected timestamps;
    
- observed timestamps;
    
- missing timestamps;
    
- coverage percentage.
    

---

# 28. Gap Detection

Consecutive missing timestamps are grouped into **continuous gap events**.

For each gap Part A stores:

- `Composite_ID`
    
- `Gap_Start`
    
- `Gap_End`
    
- number of missing timestamps;
    
- duration;
    
- category.
    

---

# 29. Gap Categories

Five point-count categories are used:

|Category|Missing Points|
|---|--:|
|`Gap_1_15min`|1|
|`Gap_2_4_30_60min`|2–4|
|`Gap_5_24_75min_6hr`|5–24|
|`Gap_25_96_6hr_24hr`|25–96|
|`Gap_GT_96_GT_24hr`|>96|

These names reflect the established 15-minute interpretation, while the actual gap duration is calculated from the resolved frequency.

---

# 30. Duplicate Timestamp Detection

Part A groups data by:

```text
Composite_ID
+
Timestamp
```

Any combination occurring more than once is considered a duplicate timestamp group.

The duplicate report records:

- site;
    
- timestamp;
    
- number of occurrences.
    

Dataset-level statistics additionally calculate:

- duplicate groups;
    
- total duplicate occurrences;
    
- extra duplicate rows;
    
- sites containing duplicates.
    

---

# 31. Off-Grid Timestamp Detection

A site's unique timestamps are compared against the expected timestamp index.

Any observed timestamp that does not belong to the expected grid is counted as:

```text
Off_Grid_Timestamps
```

Part A records:

- total off-grid timestamps;
    
- number of affected series.
    

These are identified but **not corrected**.

---

# 32. NaN Analysis

The integrity stage also counts NaN values in the configured KPI value column.

For every series it stores:

```text
NaN_Values
```

It then calculates dataset-level:

- total NaNs;
    
- series containing NaNs;
    
- minimum NaNs/site;
    
- maximum NaNs/site;
    
- mean NaNs/site;
    
- median NaNs/site.
    

Part A therefore observes value completeness without attempting to fill those values.

---

# 33. Per-Series Summary

Each site receives a row containing:

```text
Composite_ID
Site identity columns

Expected_Timestamps
Observed_Timestamps
Missing_Timestamps
Coverage_Percent

Gap_Events
Gap category counts
Longest_Gap

NaN_Values
Duplicate_Timestamps
Off_Grid_Timestamps
```

This becomes the main machine-readable site-level integrity report.

---

# 34. Dataset-Level Integrity Statistics

Part A additionally calculates:

### Coverage

- total expected timestamps;
    
- total observed timestamps;
    
- total missing timestamps;
    
- overall coverage;
    
- min/max/mean/median site coverage.
    

### Missing Data

- minimum missing/site;
    
- maximum missing/site;
    
- mean missing/site;
    
- median missing/site.
    

### Gaps

- total gap events;
    
- count of each gap category;
    
- longest gap;
    
- site containing the longest gap.
    

### NaNs

- total NaNs;
    
- affected sites;
    
- distribution statistics.
    

### Duplicates

- duplicate groups;
    
- occurrences;
    
- extra rows;
    
- affected sites.
    

### Off-grid observations

- total off-grid timestamps;
    
- affected sites.
    

---

# 35. Data-Integrity Output Files

For every KPI, integrity analysis produces:

```text
summary.txt
series_summary.csv
gap_details.csv
global_missing_timestamps.csv
duplicate_timestamp_details.csv
```

---

# 36. `runner.py`

## Responsibility

`runner.py` owns the **complete execution order and output directory structure for Part A**.

Individual analysis modules do not determine where the main Part A folders live.

The runner does.

---

# 37. Runner Output Structure

Given:

```text
<output_directory>/
```

the runner creates:

```text
<output_directory>/
│
├── prepared_datasets/
│   ├── KPI_A.csv
│   ├── KPI_B.csv
│   └── ...
│
└── summaries/
    │
    ├── KPI_A/
    │   ├── KPI_A_unique_site_row_counts.csv
    │   ├── summary.txt
    │   ├── series_summary.csv
    │   ├── gap_details.csv
    │   ├── global_missing_timestamps.csv
    │   └── duplicate_timestamp_details.csv
    │
    └── KPI_B/
        └── ...
```

## Server validation has no separate output CSV because its findings are returned structurally and written to logs.

# 38. Main Runner Entry Point

### `run_eda_pipeline()`

This is the public orchestration function for the complete Part A module.

Its execution sequence is:

```text
1. Receive DatasetInputConfig
        │
2. Create Part A directories
        │
3. prepare_dataset()
        │
4. Resolve bucket frequency
        │
5. Resolve timeline settings
        │
6. For each prepared KPI:
        │
        ├── Read KPI CSV
        │
        ├── Create KPI summary directory
        │
        ├── analyse_sites()
        │
        ├── validate_server_consistency()
        │
        └── analyse_data_integrity()
        │
7. Combine structured results
        │
8. Return EDARunnerResult
```

---

# 39. Result Hierarchy

The runner maintains structured Python result objects in addition to files.

```text
EDARunnerResult
│
├── output_directory
├── prepared_datasets_directory
├── summaries_directory
│
├── preparation
│   └── DatasetPreparationResult
│
└── kpi_results[]
    │
    └── KPIEDARunResult
        │
        ├── PreparedKPIDataset
        ├── summary_directory
        ├── SiteAnalysisResult
        ├── ServerValidationResult
        └── DataIntegrityResult
```

This gives the higher workflow layer access to generated paths and important statistics without needing to rediscover the files manually.

---

# 40. Failure Behaviour

The runner deliberately does not wrap every lower-level error.

Fatal validation/file-processing exceptions are allowed to propagate to the higher workflow layer.

Examples of fatal conditions include:

- unusable input file;
    
- empty dataset;
    
- missing mandatory columns;
    
- unresolved KPI identity;
    
- invalid bucket configuration;
    
- invalid timeline configuration;
    
- no usable timestamps;
    
- impossible output-file operation.
    

The higher workflow layer can therefore mark the entire pipeline run as failed.

---

# 41. Warning / Non-Fatal Behaviour

Not every abnormal condition causes failure.

Part A intentionally records or logs several findings while continuing.

Examples include:

- incomplete site identity values;
    
- missing server values;
    
- inconsistent server types;
    
- absent optional server column;
    
- NaN KPI values;
    
- timestamp gaps;
    
- duplicate timestamps;
    
- off-grid timestamps.
    

These are **EDA findings**, not necessarily reasons to reject the dataset.

---

# 42. Read-Only vs Data-Changing Behaviour

Part A has an important distinction.

### Dataset Preparation

Can normalize metadata by:

- inserting/filling KPI identity when allowed;
    
- inserting/filling uniform bucket metadata;
    
- splitting the source into KPI-specific files.
    

### EDA Analysis

After KPI preparation, the analytical stages are effectively diagnostic.

They do not:

```text
insert missing timeline rows
fill KPI values
remove duplicates
repair timestamps
correct server identity
remove abnormal sites
```

Instead they produce information that later stages can use.

---

# 43. Responsibility Separation Between Files

The module deliberately divides responsibility as follows:

### `data_preparation.py`

**Make the dataset structurally ready for per-KPI processing.**

### `site_analysis.py`

**Determine what sites exist and how much data each contains.**

### `server_validation.py`

**Determine whether server metadata is internally consistent for those sites.**

### `data_integrity.py`

**Determine whether each site's temporal series is complete and structurally sound.**

### `runner.py`

**Control execution order, folder structure and result aggregation.**

This prevents one large EDA file from becoming responsible for dataset preparation, analysis, filesystem structure and orchestration simultaneously.

---

# 44. Complete Part A Data Flow

```text
Source CSV
   │
   │ + DatasetInputConfig
   ▼
────────────────────────────────────────────
DATA PREPARATION
────────────────────────────────────────────
Validate input
Validate base columns
Resolve KPI identity
Resolve bucket configuration
Split by KPI
   │
   ▼
prepared_datasets/
   │
   ├──────────── KPI A ────────────────┐
   │                                   │
   ├──────────── KPI B ────────────┐   │
   │                               │   │
   ▼                               ▼   ▼

For each KPI:
   │
   ▼
────────────────────────────────────────────
SITE ANALYSIS
────────────────────────────────────────────
Identify sites
Calculate rows/site
Record missing identities
Write site summary
   │
   ├──────────────────────┐
   │                      │
   ▼                      ▼
──────────────────   ────────────────────────
SERVER VALIDATION    DATA INTEGRITY
──────────────────   ────────────────────────
Server/site          Resolve timeline
consistency          Validate timestamps
Missing server       Find missing timestamps
Multiple servers     Detect gaps
                     Detect duplicates
                     Detect off-grid timestamps
                     Count NaNs
                     Calculate coverage
   │                      │
   └──────────┬───────────┘
              ▼
        KPI Part A Results
              │
              ▼
       KPIEDARunResult
              │
              ▼
        EDARunnerResult
```

---

# 45. Final Part A Outputs

Part A ultimately produces two forms of output.

## Files

### Prepared data

```text
prepared_datasets/<KPI>.csv
```

### Site analysis

```text
<KPI>_unique_site_row_counts.csv
```

### Integrity analysis

```text
summary.txt
series_summary.csv
gap_details.csv
global_missing_timestamps.csv
duplicate_timestamp_details.csv
```

### Logs

Contain additional information such as:

- server inconsistencies;
    
- missing server metadata;
    
- skipped optional checks;
    
- missing site identities;
    
- stage progress.
    

---

## Structured Runtime Results

```text
EDARunnerResult
    └── KPIEDARunResult[]
```

which expose the important paths and high-level metrics programmatically.

---

# 46. Key Architectural Role of Part A

Part A converts an unknown source CSV into a **well-understood collection of KPI/site time series**.

Before Part A:

```text
Source CSV
```

The backend does not yet have a structured understanding of:

- KPI separation;
    
- site populations;
    
- server consistency;
    
- timeline completeness;
    
- temporal gaps;
    
- duplicate observations;
    
- missing KPI values;
    
- expected timestamp coverage.
    

After Part A:

```text
Prepared KPI datasets
+
Site inventory
+
Server consistency information
+
Timestamp-integrity reports
+
Structured EDA results
```

The later pipeline stages therefore receive both a normalized per-KPI dataset structure and a detailed understanding of the quality and temporal structure of that data.

---

# 47. Final Summary

The Part A EDA module contains five clearly separated responsibilities:

```text
data_preparation.py
→ Validates and normalizes the source dataset and creates one file per KPI.

site_analysis.py
→ Identifies unique telecom sites and measures rows per site.

server_validation.py
→ Checks whether server metadata remains consistent within each site.

data_integrity.py
→ Audits expected timelines, coverage, missing timestamps, continuous
  gaps, NaNs, duplicates and off-grid timestamps.

runner.py
→ Connects all stages, controls the directory layout and returns the
  complete structured Part A result.
```

Together, these files form the backend's **dataset structural-analysis layer**. They establish what data exists, how it is organized and where its major integrity problems lie, while deliberately leaving actual cleaning and correction to the subsequent preprocessing stage.