# [[Part D Training Schema — app.schemas.training]]

# [[Part C — Feature Engineering ML Module]]

# [[Part A Shared Dataset Schema — schema common.dataset.py]]
# Part D — Model Training ML Module Final Technical Report

**Module Location:** `app/ml/training/`

## Files

|File|Main Responsibility|
|---|---|
|`__init__.py`|Public Part D training interface|
|`validation.py`|Validate the Part C engineered dataset and resolve exact model feature/target contracts|
|`loader.py`|Reserve Part C history and calculate per-site chronological split boundaries|
|`model_output.py`|Persist per-site models and final training-package JSON artifacts|
|`runner.py`|Orchestrate complete Part D execution across valid site series|

### XGBoost branch

|File|Responsibility|
|---|---|
|`xgboost/__init__.py`|Public XGBoost training/calibration/testing interface|
|`xgboost/training/__init__.py`|Exposes fixed/direct and Optuna training implementations through one result contract|
|`xgboost/training/fixed_training.py`|Direct training or predefined-candidate tuning|
|`xgboost/training/optuna_training.py`|Optuna hyperparameter optimization|
|`xgboost/residual_calibration.py`|Calibrate residual anomaly thresholds|
|`xgboost/testing.py`|Evaluate final XGBoost model on untouched test data|

### Isolation Forest branch

|File|Responsibility|
|---|---|
|`isolation_forest/__init__.py`|Public Isolation Forest interface|
|`isolation_forest/training/__init__.py`|Exposes fixed/direct and Optuna training implementations through one result contract|
|`isolation_forest/training/fixed_training.py`|Direct training or predefined-candidate tuning|
|`isolation_forest/training/optuna_training.py`|Optuna hyperparameter optimization|
|`isolation_forest/testing.py`|Evaluate final Isolation Forest on untouched test data|

---

# 1. Purpose of Part D

Part D takes the **feature-engineered KPI dataset produced by Part C** and trains one anomaly-detection model **independently for every valid site series**.

It supports:

```text
XGBoost regression + residual thresholds
Isolation Forest anomaly detection
```

and three training strategies for each:

```text
Direct training
Fixed-candidate tuning
Optuna tuning
```

Part D is responsible for:

- validating the Part C model-input contract;
    
- skipping Part B-marked invalid site series;
    
- reserving the Part C-required history;
    
- planning chronological model splits;
    
- selecting the exact feature matrix;
    
- filtering model-eligible rows;
    
- training one model per site;
    
- tuning hyperparameters when requested;
    
- calibrating XGBoost anomaly thresholds;
    
- evaluating untouched test ranges;
    
- saving each model separately;
    
- persisting the complete training/inference contract.
    

---

# 2. External Project Dependencies

Part D ML directly uses three schema areas.

### Shared dataset schema

```text
DatasetColumnMapping
```

provides the physical:

- circle;
    
- cluster;
    
- site;
    
- timestamp;
    
- KPI value
    

column names.

### Part C feature schema

```text
ResolvedFeatureEngineeringConfig
```

provides:

- exact Part C feature columns;
    
- feature request → output-column grouping;
    
- `minimum_history_points`.
    

### Part D training schemas

Provide the XGBoost / Isolation Forest configuration, tuning mode, splits, model rules and thresholds.

Part D ML does **not directly run Part B or Part C processing**. It consumes the resulting Part C dataset and metadata already carried into it.

---

# 3. Main Part C → Part D Contract

The Part D runner receives:

```text
input_file
→ Part C feature-engineered CSV

dataset_columns
→ DatasetColumnMapping

feature_config
→ ResolvedFeatureEngineeringConfig

minimum_history_points
→ explicit value returned by Part C

training_config
→ XGBoostTrainingConfig
  or IsolationForestTrainingConfig
```

The runner verifies that the explicit history requirement equals:

```text
feature_config.minimum_history_points
```

before any splitting occurs.

This protects against training with a different warm-up/history interpretation than the one used to create the features.

---

# 4. One Model Per Site

Part D does **not** train one global model over every site.

For every usable:

```text
Circle + Cluster + Site
```

series:

```text
Site A → Model A
Site B → Model B
Site C → Model C
...
```

Each site receives:

- its own chronological splits;
    
- its own hyperparameter selection;
    
- its own final model;
    
- its own calibration settings where applicable;
    
- its own test summary;
    
- its own saved model file.
    

---

# 5. Overall Part D Architecture

```text
Part C engineered KPI CSV
        +
Resolved Part C feature contract
        +
Part D training config
            │
            ▼
────────────────────────────
runner.py
────────────────────────────
Validate history contract
Inspect kpi_usability
Separate valid / invalid sites
            │
            ▼
────────────────────────────
validation.py
────────────────────────────
Validate CSV
Resolve model feature contract
Resolve target / metadata roles
            │
            ▼
────────────────────────────
loader.py
────────────────────────────
Reserve Part C history
Plan chronological ranges/site
            │
            ▼
      Selected model?
       /           \
      /             \
 XGBoost        Isolation Forest
    │                 │
    ▼                 ▼
direct/fixed/     direct/fixed/
Optuna training  Optuna training
    │                 │
    ▼                 │
Residual             │
Calibration          │
    │                 │
    ▼                 ▼
Test             Test
    │                 │
    └───────┬─────────┘
            ▼
────────────────────────────
model_output.py
────────────────────────────
Save each site model
Write complete training package
            │
            ▼
PartDTrainingResult
```

---

# 6. `__init__.py`

The public Part D package intentionally exports only:

```text
PartDTrainingResult
SkippedSeries
run_training
```

The parent pipeline therefore does not need to know which internal function performs fixed vs Optuna training.

That dispatch remains owned by `runner.py`.

---

# 7. `runner.py`

`runner.py` is the authoritative Part D orchestration layer.

Its main entry point is:

```python
run_training(...)
```

It controls:

1. input validation;
    
2. model/config matching;
    
3. Part C history verification;
    
4. site usability inspection;
    
5. shared dataset validation;
    
6. split planning;
    
7. per-site model dispatch;
    
8. model saving;
    
9. aggregate artifact finalization.
    

It does **not** contain model mathematics itself.

---

# 8. Site Usability Is Checked Before Training

The runner chunk-reads only:

```text
circle
cluster
site
kpi_usability
kpi_invalid_reason
```

to classify the site's eligibility before expensive model execution.

It requires:

```text
kpi_usability ∈ {"valid", "invalid"}
```

and requires the value to remain consistent for every row of a site, including across CSV chunks.

---

# 9. Invalid Sites

For:

```text
kpi_usability = invalid
```

Part D:

- does not generate a split plan for the site;
    
- does not train a model;
    
- does not test it;
    
- records it as `SkippedSeries`;
    
- preserves its `kpi_invalid_reason` in run metadata.
    

If **all** sites are invalid, Part D fails because no model can be trained.

---

# 10. Valid Sites Are Strict

A site marked:

```text
kpi_usability = valid
```

is expected to successfully complete Part D.

If validation, splitting, training, calibration, testing or persistence fails for such a site:

```text
complete Part D run fails
```

The runner does not silently convert a failing valid site into a skipped site.

---

# 11. `SkippedSeries`

Records:

```text
identity
usability
invalid_reason
```

so deliberate Part B invalidity remains distinguishable from a Part D execution failure.

---

# 12. `PartDTrainingResult`

The final runner result contains:

```text
status
model_type

input_file
output_directory

minimum_history_points

total_series
valid_series
trained_series
skipped_invalid_series

skipped_series

validation_result
split_plan
output_paths
```

Successful execution returns:

```text
status = "completed"
```

---

# 13. `validation.py`

This module defines the exact bridge between the **Part C feature dataset** and the selected Part D model.

It determines:

```text
Which CSV columns must exist?
Which columns become X?
Is there a y?
Which features must be excluded?
Which statuses are trusted?
What row-count minimums apply?
```

It does not create training splits or fit models.

---

# 14. `TrainingValidationResult`

The validated contract contains:

```text
input_file
model_type

all_part_c_feature_columns
model_feature_columns
excluded_part_c_feature_columns

target_column

site_identity_columns
timestamp_column
status_column
usability_column
invalid_reason_column

minimum_history_points

trusted_statuses
require_complete_feature_rows
require_non_null_target

minimum_train_points
minimum_validation_points
minimum_calibration_points
minimum_test_points

total_rows
```

This becomes the shared input contract for the loader and model-specific stages.

---

# 15. CSV Header Validation

Before Pandas loads training data, `validation.py` reads the raw CSV header using Python's `csv` module.

This is deliberate because Pandas can automatically rename duplicate column headers.

Part D rejects:

- empty files;
    
- empty column names;
    
- duplicate physical column names.
    

---

# 16. Part C Feature-Contract Revalidation

Part D defensively verifies the supplied resolved Part C contract:

```text
feature_columns must not be empty
feature names must be unique

len(features)
=
len(feature_column_groups)

flatten(feature_column_groups)
=
feature_columns
```

Part D therefore does not blindly trust a malformed feature-contract object.

---

# 17. Memory-Bounded Dataset Validation

The full Part C dataset is not loaded at once merely for validation.

The current implementation scans in chunks of:

```text
250,000 rows
```

and validates:

- site identity;
    
- timestamps;
    
- feature types;
    
- target type when applicable;
    
- status values.
    

---

# 18. Numeric Integrity Rules

Model feature columns may contain:

```text
finite numeric values
NaN
```

because Part C warm-up rows can legitimately be incomplete.

However, Part D rejects:

```text
nonnumeric text
+∞
-∞
```

for model features and the XGBoost target.

The status column must exist for every row and contain integer-valued labels.

---

# 19. Why NaN Is Allowed During Initial Validation

At this early stage, Part D does not require every row to be immediately model-ready.

Part C can legitimately produce warm-up NaNs such as:

```text
lag warm-up
rolling warm-up
seasonal-baseline warm-up
```

Actual train/validation/calibration/test stages later apply the configured complete-feature-row filter.

---

# 20. XGBoost Feature Resolution

For XGBoost:

```text
all Part C features
        │
        ▼
inspect Part C request types
        │
        ▼
exclude target-leaking families
        │
        ▼
model_feature_columns
```

Excluded request families are:

```text
current_value
difference
percentage_change
seasonal_difference
rolling_zscore
residual
```

The corresponding columns may remain physically present in the CSV but are not placed in `X`.

---

# 21. XGBoost Target

XGBoost receives exactly one `y`:

```text
DatasetColumnMapping.value_column
```

which is the physical KPI value.

Therefore:

```text
X = approved Part C features
y = KPI value
```

Metadata and source columns are explicitly prevented from accidentally entering `X`.

---

# 22. Isolation Forest Feature Resolution

For Isolation Forest:

```text
model_feature_columns
=
feature_config.feature_columns
```

No y target exists.

The original physical KPI value is not automatically added to X unless Part C deliberately produced a feature representing it, such as `current_value`.

---

# 23. Isolation Forest Direction Requirement

Isolation Forest itself detects unusual feature-space observations but does not inherently know:

```text
lower KPI anomaly
vs
upper KPI anomaly
```

For one-sided requests, Part D validation therefore requires Part C's:

```text
residual
```

feature.

For:

```text
threshold_direction = both
```

the residual is not required solely to decide whether the Isolation Forest marked a point anomalous.

---

# 24. Non-Feature Collision Protection

Part D verifies that columns designated as:

- target;
    
- identity;
    
- timestamp;
    
- status;
    
- usability;
    
- invalid reason
    

cannot also silently appear in the model's X matrix unless their role explicitly permits it.

This is another safeguard against metadata leakage.

---

# 25. `loader.py`

Despite its historical name, `loader.py` is primarily a **split planner**.

It does not:

- load the entire feature dataset;
    
- create `X_train`;
    
- create `y_train`;
    
- copy split dataframes;
    
- write split CSVs.
    

Instead, it scans only:

```text
site identity + timestamp
```

and creates lightweight chronological range descriptions.

---

# 26. `SeriesIdentity`

The site identity contract is:

```text
circle
cluster
site_name
```

and can be returned as a three-value tuple.

---

# 27. `SplitRange`

Every chronological range records:

```text
start_position
end_position

start_timestamp
end_timestamp

row_count
```

Positions are:

```text
zero-based positions inside one site's chronological series
```

not global CSV row numbers.

The positions and timestamps are both saved so later modules can reload exact ranges robustly.

---

# 28. `SeriesSplitPlan`

For one site:

```text
identity
total_points

history
train
validation | None
calibration | None
test
```

Whether validation/calibration exist depends on model and tuning mode.

---

# 29. `TrainingSplitPlan`

At complete-run level:

```text
input_file
model_type
hyperparameter_tuning_enabled

site_identity_columns
timestamp_column

minimum_history_points

post_history_percentages

series[]
```

The object contains **boundaries**, not training matrices.

---

# 30. History Is Reserved First

Every site is partitioned conceptually as:

```text
[first Part C minimum_history_points]
              │
              ▼
            HISTORY
              │
       remaining rows
              ▼
      Part D percentage splits
```

The history rows exist to support the Part C feature warm-up contract.

They are **not a Part D model training split**.

---

# 31. XGBoost Split Shape

### Tuning enabled

```text
History
→ Train
→ Validation
→ Calibration
→ Test
```

### Tuning disabled

```text
History
→ Train
→ Calibration
→ Test
```

---

# 32. Isolation Forest Split Shape

### Tuning enabled

```text
History
→ Train
→ Validation
→ Test
```

### Tuning disabled

```text
History
→ Train
→ Test
```

Isolation Forest has no calibration range.

---

# 33. Integer Split Allocation

Percentages cannot always convert into perfect integer row counts.

The loader avoids independently rounding each stage.

Instead it uses cumulative decimal boundaries with floor rounding and assigns the final stage all remaining rows.

Therefore:

```text
every post-history row is assigned exactly once
no row is duplicated
no row is lost through rounding
```

---

# 34. Raw Minimum-Row Check

Before expensive training, the loader performs an early check that each raw chronological range is at least large enough to _potentially_ meet the model minimum.

Important distinction:

```text
loader minimum check
= raw rows

model-stage minimum check
= usable rows after filtering
```

Passing the loader does not guarantee training succeeds.

---

# 35. Chronological Order Requirement

The loader requires every valid site's timestamps to be:

```text
strictly increasing
```

in physical CSV order.

This also prevents duplicate timestamps.

The check continues correctly across CSV chunks.

Part D does not silently sort a structurally unordered source and pretend the original split boundaries were safe.

---

# 36. Model Stages Load Only Their Own Ranges

After the split plan exists, model-specific modules scan the source CSV and select:

```text
exact site identity
+
exact planned timestamp range
```

They then compare the number of loaded raw rows to the `loader.py` plan.

If the count differs, execution fails.

This detects cases such as:

- source file changing after split planning;
    
- boundary mismatch;
    
- duplicate/missing rows.
    

---

# 37. XGBoost Training Branch

The XGBoost series flow is:

```text
split plan
    │
    ▼
Direct / Fixed / Optuna training
    │
    ▼
Final XGBRegressor
    │
    ▼
Residual calibration
    │
    ▼
Untouched test
    │
    ▼
Save model
```

The calibration and test stages are separate from the model-fit stage.

---

# 38. XGBoost Training Row Eligibility

For train rows, Part D requires:

```text
Current_Status_Label ∈ trusted_statuses
```

currently:

```text
{1, 3}
```

and, when configured:

```text
all model features non-null
target non-null
```

So XGBoost trains its regression target only on:

```text
trusted original values
safe fills
```

not outliers/risky unresolved statuses.

---

# 39. XGBoost X and y

The model matrices are built using:

```text
X
= validation_result.model_feature_columns
  in the exact validated order

y
= validation_result.target_column
```

The model implementation does not independently rediscover feature columns.

---

# 40. XGBoost Regression Diagnostics

During candidate/final-fit evaluation, it calculates:

```text
MAE
RMSE
median residual
mean residual
residual MAD
```

with:

```text
residual = actual - prediction
```

These are regression diagnostics, separate from the later anomaly-decision thresholds.

---

# 41. XGBoost Direct Training

When:

```text
hyperparameter_tuning_enabled = False
```

the fixed-training implementation:

1. resolves one complete hyperparameter configuration;
    
2. uses only trusted train rows;
    
3. has no validation range;
    
4. sets the final tree count from configured `max_estimators`;
    
5. fits the final model on train;
    
6. leaves calibration/test completely untouched.
    

---

# 42. XGBoost Fixed-Candidate Tuning

When:

```text
tuning_enabled = True
tuning_method = fixed
```

every candidate is fitted on the train split.

Each candidate uses the dedicated validation split for:

- early stopping;
    
- regression metrics;
    
- model selection.
    

Candidate results store success/failure independently.

---

# 43. XGBoost Early Stopping

Temporary candidate models receive:

```text
n_estimators = tuning.max_estimators
early_stopping_rounds = configured value
```

The selected tree count is:

```text
best_iteration + 1
```

If XGBoost exposes no best iteration, the implementation falls back to the configured maximum estimator count.

---

# 44. Fixed XGBoost Candidate Selection

Among successfully fitted candidates, Part D selects the minimum by:

```text
1. primary validation metric
2. secondary validation metric
3. candidate number
```

With defaults this corresponds to:

```text
lowest MAE
then lowest RMSE
then earliest candidate
```

If every candidate fails, training fails.

---

# 45. XGBoost Final Refit After Tuning

Once the winner has been selected:

```text
trusted train
+
trusted validation
        │
        ▼
final-fit dataset
```

The selected model is refitted using the selected tree count.

The dedicated:

```text
calibration
test
```

ranges remain unseen during fitting.

---

# 46. XGBoost `XGBoostTrainingResult`

Contains:

```text
identity
model

selected_hyperparameters
final_model_parameters

selected_candidate_number
best_tree_count

tuning_performed
tuning_summary

training_summary
usable_row_counts
```

The estimator remains in memory only long enough for runner-controlled calibration/testing/saving.

---

# 47. XGBoost Optuna Training

Optuna is used only when:

```text
tuning_enabled = True
tuning_method = optuna
```

The module deliberately reuses the fixed-training helpers for:

- range loading;
    
- row filtering;
    
- X/y construction;
    
- regression metrics;
    
- final model fitting.
    

This keeps fixed and Optuna training on the same data contract.

---

# 48. XGBoost Optuna Search

The study uses:

```text
TPESampler
configured sampler seed
n_jobs = 1
```

Sequential trials plus the fixed sampler seed are intended to keep equivalent searches reproducible.

---

# 49. XGBoost Optuna Trial Execution

For every trial:

```text
resolved Optuna parameter ranges
        ↓
generate complete hyperparameter set
        ↓
fit XGBoost on train
        ↓
validation-based early stopping
        ↓
calculate validation metrics
        ↓
record best tree count
```

Integer parameters use `suggest_int`; numeric parameters use `suggest_float`.

---

# 50. Failed XGBoost Optuna Trials

Trial exceptions are captured into trial metadata and Optuna is configured to continue the study.

Therefore:

```text
one failed trial ≠ complete tuning failure
```

But:

```text
zero completed valid trials
→ training failure
```

---

# 51. XGBoost Optuna Selection

The study minimizes the configured primary metric.

Completed trials are then deterministically ranked by:

```text
primary metric
secondary metric
trial number
```

The selected trial supplies both:

```text
selected_hyperparameters
best_tree_count
```

---

# 52. XGBoost Optuna Final Refit

After trial selection:

```text
trusted train
+
trusted validation
→ final refit
```

using:

- selected trial parameters;
    
- selected best tree count.
    

Calibration and test remain untouched.

---

# 53. Fixed and Optuna XGBoost Share One Result Contract

Both paths return:

```text
XGBoostTrainingResult
```

For fixed tuning:

```text
selected_candidate_number = candidate number
```

For Optuna:

```text
selected_candidate_number = None
selected_trial_number
→ recorded in training summary
```

This allows the runner and persistence layer to remain independent of tuning strategy.

---

# 54. `residual_calibration.py`

XGBoost training itself does **not** decide which residual values count as anomalies.

That responsibility belongs to the dedicated calibration stage.

Input:

```text
already-trained site model
+
dedicated calibration split
```

Output:

```text
per-site residual threshold(s)
```

---

# 55. Calibration Row Eligibility

Calibration uses the same core row trust rule as XGBoost training:

```text
status ∈ {1,3}
complete model features
non-null target
```

The module then enforces the configured minimum usable calibration rows.

---

# 56. XGBoost Residual Definition

```text
residual
=
actual KPI
-
predicted KPI
```

Therefore:

```text
negative residual
→ actual KPI below model expectation

positive residual
→ actual KPI above model expectation
```

---

# 57. Quantile Calibration

For configured:

```text
q = residual_quantile
```

upper threshold uses:

```text
quantile(q)
```

and lower threshold uses:

```text
quantile(1-q)
```

with NumPy quantile method:

```text
linear
```

Only the directionally required threshold(s) are generated.

---

# 58. XGBoost Anomaly Comparisons

The persisted comparison rules are inclusive:

```text
lower anomaly:
residual <= lower_threshold

upper anomaly:
residual >= upper_threshold
```

For `both`, either condition is sufficient.

---

# 59. XGBoost Calibration Summary

The calibration result records:

- raw and usable calibration rows;
    
- residual quantile;
    
- lower/upper quantiles;
    
- lower/upper thresholds;
    
- residual mean/median/std/MAD/min/max;
    
- calibration anomaly count/rate;
    
- calibration MAE/RMSE.
    

It also returns the exact `decision_settings` later reused during testing and inference.

---

# 60. XGBoost Testing

The test stage uses only the untouched test range.

It does not:

- retrain;
    
- refit;
    
- recalibrate thresholds.
    

It receives the already-calibrated `decision_settings`.

---

# 61. Critical XGBoost Test-Status Difference

Unlike training and calibration, final XGBoost test rows are **not filtered to trusted statuses `{1,3}`**.

This is intentional.

For example:

```text
status 2 outlier
```

remains available for final testing if its model features and target are usable.

---

# 62. XGBoost Test Eligibility

Test rows are filtered for:

```text
complete model features
non-null target
```

when those rules are enabled.

They are **not filtered based on trusted-status membership**.

The minimum usable test count is then enforced.

---

# 63. XGBoost Test Outputs

The test summary includes:

```text
MAE
RMSE

residual mean
residual median
residual std
residual MAD
residual min/max

anomaly count/rate
lower anomaly count
upper anomaly count

status distribution
```

---

# 64. XGBoost Test Is Not Labelled Classification Accuracy

The current Part D test module does **not** define:

```text
status 2 = ground-truth anomaly
```

and therefore does not calculate classification:

```text
accuracy
precision
recall
F1
```

It reports regression diagnostics, anomaly rates and status distributions without treating Part B status as a hard ground-truth anomaly label.

This is an important interpretation boundary for downstream reporting.

---

# 65. Isolation Forest Training Branch

The Isolation Forest site flow is simpler structurally:

```text
split plan
    │
    ▼
Direct / Fixed / Optuna training
    │
    ▼
Final IsolationForest
    │
    ▼
Untouched test
    │
    ▼
Save model
```

There is **no separate calibration stage**.

---

# 66. Isolation Forest Has No y

Every IF training stage checks that:

```text
validation_result.target_column is None
```

The matrix is simply:

```text
X = exact validated Part C feature columns
```

---

# 67. Trusted IF Training Rows

The training subset requires:

```text
complete model features
+
status ∈ {1,3}
```

Therefore the final IF model learns from:

```text
trusted originals
safe fills
```

rather than known preprocessing outliers/risky states.

---

# 68. Isolation Forest Direct Training

When tuning is disabled:

```text
trusted train
        ↓
resolve one hyperparameter set
        ↓
fit final Isolation Forest
```

There is:

- no validation split;
    
- no calibration split;
    
- no test exposure during fitting.
    

---

# 69. Isolation Forest Fixed Tuning

With fixed tuning:

```text
trusted train
    │
    ├─ Candidate 1
    ├─ Candidate 2
    ├─ Candidate 3
    └─ ...
          │
          ▼
validation evaluation
          │
          ▼
best score separation
```

Each candidate failure is recorded.

If all candidates fail, the site training fails.

---

# 70. Special Isolation Forest Validation Rule

The validation data used for **candidate selection** is intentionally prepared differently from training data.

Candidate evaluation uses:

```text
complete feature rows
```

but does **not** apply the trusted-status filter.

This allows anomalous behavior to remain visible while comparing unsupervised candidate models.

---

# 71. Isolation Forest Score Separation

For a candidate:

```text
model.predict(X_validation)
```

divides validation observations into:

```text
+1 = model inlier
-1 = model outlier
```

The selection metric is:

```text
mean(decision_function of model inliers)
-
mean(decision_function of model outliers)
```

Larger separation is better.

---

# 72. Undefined IF Candidate Scores

A candidate cannot receive `score_separation` when it labels:

```text
zero inliers
```

or:

```text
zero outliers
```

because one of the means would be undefined.

That candidate therefore fails evaluation.

---

# 73. Fixed IF Candidate Selection

Among successful candidates:

```text
largest score_separation wins
```

Tie-break:

```text
earlier candidate number wins
```

This is explicitly deterministic.

---

# 74. IF Validation Before Final Refit

After tuning selects a candidate, validation is filtered again:

```text
complete feature rows
+
trusted statuses {1,3}
```

Only that trusted validation subset joins training for the final fit.

Therefore:

```text
candidate evaluation
→ may observe anomalous validation rows

final estimator fitting
→ trusted validation rows only
```

---

# 75. Final Isolation Forest Refit

Tuning enabled:

```text
trusted train
+
trusted validation
→ final fit
```

Direct mode:

```text
trusted train
→ final fit
```

The test split is untouched in both cases.

---

# 76. Isolation Forest Decision Settings

Training produces and saves decision settings including:

```text
method = isolation_forest

model_prediction_rule:
predict == -1

decision_function_rule:
decision_function < 0 indicates model anomaly

model_offset
contamination

threshold_direction
direction_feature

lower rule:
<direction_feature> < 0

upper rule:
<direction_feature> > 0
```

The default direction feature comes from the schema's `residual` rule.

---

# 77. `IsolationForestTrainingResult`

Contains:

```text
identity
model

selected_hyperparameters
final_model_parameters

selected_candidate_number
tuning_performed
tuning_summary

decision_settings
training_summary
usable_row_counts
```

Both fixed and Optuna implementations share this same contract.

---

# 78. Isolation Forest Optuna

Optuna is used only for:

```text
tuning_enabled = True
tuning_method = optuna
```

It reuses fixed-training helpers for:

- loading;
    
- trusted training filtering;
    
- validation evaluation filtering;
    
- scoring;
    
- final refitting.
    

---

# 79. Isolation Forest Optuna Sampling

The resolved search space supports:

```text
integer → suggest_int
float → suggest_float
categorical → suggest_categorical
```

The study uses:

```text
TPESampler
configured sampler seed
n_jobs = 1
```

for reproducible sequential search.

---

# 80. Isolation Forest Optuna Objective

Every trial:

```text
fits on trusted train rows
```

and is evaluated on:

```text
complete-feature validation rows
without trusted-status filtering
```

Objective:

```text
maximize score_separation
```

---

# 81. Isolation Forest Optuna Selection

Among completed valid trials:

```text
highest score separation wins
```

Tie-break:

```text
earlier trial number wins
```

Failed trials can occur without terminating the whole study; the run fails only if no valid completed trial remains.

---

# 82. Isolation Forest Optuna Final Refit

After optimization:

```text
trusted train
+
trusted validation
→ final Isolation Forest
```

The final result retains:

```text
selected_candidate_number = None
selected_trial_number
→ training summary
```

and uses the same result and persistence contracts as fixed tuning.

---

# 83. Isolation Forest Testing

The final test stage loads only the planned untouched test range and verifies its raw row count against the loader plan.

Test rows are **not filtered by trusted status**.

---

# 84. Isolation Forest Test Eligibility

The test filter requires:

```text
complete model features
```

when configured.

It does not require:

```text
status ∈ {1,3}
```

so known/suspected anomalies remain available for evaluation.

---

# 85. Isolation Forest Raw Model Decision

The primary estimator anomaly definition is:

```text
model.predict(X) == -1
```

The module additionally obtains:

```text
decision_function(X)
score_samples(X)
```

and verifies those scores are finite.

---

# 86. Isolation Forest Direction Filtering

After the model identifies anomalies:

### Lower only

```text
model anomaly
AND
residual < 0
```

### Upper only

```text
model anomaly
AND
residual > 0
```

### Both

```text
all model anomalies
```

---

# 87. Zero Residual in One-Sided IF Decisions

The comparisons are strict:

```text
lower → residual < 0
upper → residual > 0
```

Therefore an IF-model anomaly whose residual is exactly:

```text
0
```

belongs to neither one-sided directional class.

---

# 88. Isolation Forest `both`

When:

```text
threshold_direction = both
```

the final anomaly mask is simply:

```text
model.predict(X) == -1
```

If the direction feature exists, the module additionally reports how many model anomalies have:

```text
negative residual
positive residual
```

but those subtype counts do not change the final anomaly decision.

---

# 89. Isolation Forest Test Summary

The saved test summary includes:

```text
model anomaly count/rate

final direction-filtered anomaly count/rate

lower anomaly count
upper anomaly count

model offset
contamination

decision score mean/median/std/min/max

score_samples mean/median/std/min/max

status counts
```

---

# 90. Isolation Forest Testing Is Also Not Labelled Accuracy

Like XGBoost, the current test module does not hardcode Part B status values as supervised ground truth.

Therefore it does not calculate:

```text
accuracy
precision
recall
F1
```

It reports model anomaly behavior and score statistics.

---

# 91. Training vs Validation vs Test Status Rules

This is one of the most important Part D distinctions.

|Stage|XGBoost|Isolation Forest|
|---|---|---|
|Train|trusted `{1,3}`|trusted `{1,3}`|
|Tuning validation|trusted `{1,3}`|complete rows, **no trusted-status filter**|
|Final refit validation|trusted `{1,3}`|trusted `{1,3}`|
|Calibration|trusted `{1,3}`|N/A|
|Final test|**no trusted-status filter**|**no trusted-status filter**|

This difference is intentional rather than inconsistent.

---

# 92. Minimum Rows Are Checked Twice

Part D protects model stages at two levels.

### Loader

Checks:

```text
raw chronological rows
```

### Model-specific stage

Checks:

```text
usable rows after
status / completeness / target filtering
```

So a series may pass split planning but still correctly fail training if too many rows are unusable.

---

# 93. `model_output.py`

This is the **single persistence boundary** for Part D.

The model-specific files do not write their models or JSON summaries themselves.

`runner.py` sends their results to `model_output.py`.

---

# 94. Staging Strategy

A run is first constructed inside:

```text
<output>/.training_build/
```

The final location is:

```text
<output>/training/
```

Existing final output or a stale staging directory is rejected rather than overwritten.

---

# 95. Failure Cleanup

If execution fails after staging begins:

```text
abort_model_output()
```

deletes only:

```text
.training_build
```

The incomplete package is therefore not published as a successful `training/` output.

---

# 96. Immediate Per-Site Model Saving

Once one site's:

```text
training
+
calibration where applicable
+
testing
```

is complete, its model is serialized immediately.

The runner then retains only lightweight result metadata and can release the estimator before moving to the next site.

This is specifically designed for runs containing many independent models.

---

# 97. Series Folder Key

Each site directory receives a collision-resistant key constructed from:

```text
sanitized circle
+
sanitized cluster
+
sanitized site
+
10-character SHA1 digest
```

The digest is calculated from:

```text
circle||cluster||site
```

This keeps folder names readable while reducing collision risk.

---

# 98. Model Serialization

### XGBoost

Saved using native XGBoost serialization:

```text
final_model.json
```

### Isolation Forest

Saved using joblib:

```text
final_model.joblib
```

---

# 99. Final Part D Output Structure

```text
<Part D output>/
└── training/
    │
    ├── model/
    │   ├── <site-series-key-A>/
    │   │   └── final_model.json      # XGBoost run
    │   │
    │   ├── <site-series-key-B>/
    │   │   └── final_model.json
    │   │
    │   └── ...
    │
    ├── split_plan.json
    ├── training_config.json
    ├── feature_contract.json
    ├── final_hyperparameters.json
    ├── training_summary.json
    ├── decision_settings.json
    ├── usable_row_counts.json
    └── metadata.json
```

For Isolation Forest, each per-site model file is instead:

```text
final_model.joblib
```

The original Part C CSV is **not copied into the training package**.

---

# 100. `split_plan.json`

Persists the exact chronological ranges used for every trained site:

```text
history
train
validation if present
calibration if present
test
```

including positions and timestamps.

This makes the original train/test chronology traceable without copying separate split datasets.

---

# 101. `training_config.json`

Stores the complete validated Part D model configuration used for the run.

This includes the relevant:

- model;
    
- direction;
    
- tuning mode;
    
- split;
    
- hyperparameter/tuning configuration.
    

---

# 102. `feature_contract.json`

Stores the exact validated model contract:

```text
all Part C feature columns
actual model X feature columns
excluded Part C feature columns
target column

site identity columns
timestamp column
status column
usability column
invalid-reason column

trusted statuses
complete-feature-row rule
non-null-target rule
minimum_history_points
```

This is particularly important because:

```text
Part C feature columns
≠ necessarily XGBoost model columns
```

---

# 103. `final_hyperparameters.json`

Stored per site and contains:

```text
selected_hyperparameters
final_model_parameters
```

The latter also includes fixed estimator settings and final runtime parameters such as the selected XGBoost tree count where applicable.

---

# 104. `training_summary.json`

Stored per site and aggregates:

```text
tuning_summary
training_summary
calibration_summary
testing_summary
```

For Isolation Forest:

```text
calibration_summary = null
```

because it has no separate calibration stage.

---

# 105. `decision_settings.json`

Stores the final anomaly-decision contract per site.

### XGBoost

Includes calibrated:

```text
residual threshold(s)
quantile(s)
threshold direction
comparison rules
```

### Isolation Forest

Includes:

```text
model anomaly rule
model offset
contamination
threshold direction
direction feature/rules
```

These settings are essential later for inference.

---

# 106. `usable_row_counts.json`

Records actual rows that survived the stage-specific model filters.

This is deliberately separate from raw split-plan row counts.

Examples can include:

### XGBoost

```text
train
validation
final_fit
calibration
test
```

### Isolation Forest tuning

```text
train
validation_evaluation
validation_trusted_refit
final_fit
test
```

---

# 107. `metadata.json`

Contains run traceability such as:

```text
model_type
saved_at_utc

source Part C dataset
source dataset filename

total source rows
split-plan series count
trained-series count

feature count
target column

tuning enabled
tuning method

series identity → model file mapping

library versions
```

Libraries recorded depend on the model:

```text
numpy
pandas
xgboost
```

or:

```text
numpy
pandas
scikit-learn
joblib
```

and Optuna is included when Optuna tuning was used.

---

# 108. Atomic Final Publication

Only after:

- every valid site succeeds;
    
- every model file exists;
    
- aggregate artifacts are successfully written
    

does:

```text
.training_build
```

get renamed to:

```text
training
```

This prevents a partially completed package from looking finalized.

---

# 109. Runner Model Dispatch

The parent pipeline does not choose implementation files itself.

Conceptually:

```text
model_type = xgboost
        │
        ├─ direct/fixed → XGB fixed_training.py
        └─ optuna       → XGB optuna_training.py

model_type = isolation_forest
        │
        ├─ direct/fixed → IF fixed_training.py
        └─ optuna       → IF optuna_training.py
```

The helper chooses Optuna only when:

```text
tuning enabled
AND
method == optuna
```

Otherwise the fixed/direct implementation is used.

---

# 110. Complete XGBoost Runtime Flow

```text
Part C engineered site series
        │
        ▼
Validate feature + target contract
        │
        ▼
Reserve Part C history
        │
        ▼
Chronological split
        │
        ├────────────────────────────┐
        │ TUNING OFF                 │
        │                            │
        │ Train                      │
        │ → direct final model       │
        │                            │
        └──────────────┬─────────────┘
                       │
        ┌──────────────┴─────────────┐
        │ TUNING ON                  │
        │                            │
        │ Train                      │
        │ → Fixed candidates         │
        │      OR                    │
        │ → Optuna trials            │
        │                            │
        │ Validation                 │
        │ → choose hyperparameters   │
        │ → determine tree count     │
        │                            │
        │ Train + Validation         │
        │ → final model refit        │
        └──────────────┬─────────────┘
                       ▼
                Calibration
                       │
          residual = actual - predicted
                       │
             residual quantile(s)
                       │
                       ▼
               decision settings
                       │
                       ▼
               untouched test
                       │
          apply existing thresholds
                       │
                       ▼
            save site XGB model
```

---

# 111. Complete Isolation Forest Runtime Flow

```text
Part C engineered site series
        │
        ▼
Validate feature contract
No y target
        │
        ▼
Reserve Part C history
        │
        ▼
Chronological split
        │
        ├─────────────────────────────┐
        │ TUNING OFF                  │
        │                             │
        │ trusted Train               │
        │ → final model               │
        └──────────────┬──────────────┘
                       │
        ┌──────────────┴──────────────┐
        │ TUNING ON                   │
        │                             │
        │ trusted Train               │
        │ → fixed candidates          │
        │        OR                   │
        │ → Optuna trials             │
        │                             │
        │ complete Validation rows    │
        │ → score_separation          │
        │ → choose best config        │
        │                             │
        │ trusted Validation rows     │
        │ + trusted Train             │
        │ → final refit               │
        └──────────────┬──────────────┘
                       ▼
              untouched Test
                       │
                predict == -1
                       │
             model anomaly mask
                       │
              direction filtering
              /        |        \
          lower      upper      both
                       │
                       ▼
             save site IF model
```

---

# 112. Part C vs Part D Responsibility Boundary

### Part C owns

```text
feature construction
feature naming
feature history requirement
feature-source logic
warm-up behavior
```

### Part D owns

```text
model feature eligibility
target selection
site training eligibility
history reservation for splitting
chronological train/test ranges
hyperparameter selection
model fitting
calibration
testing
model persistence
```

Part D does not regenerate features or alter the Part C feature dataset.

---

# 113. Part B vs Part D Responsibility Boundary

Part D consumes Part B-origin metadata carried through Part C, primarily:

```text
Current_Status_Label
kpi_usability
kpi_invalid_reason
```

But Part D does not:

- redetect outliers;
    
- refill missing data;
    
- reclassify site usability;
    
- change Part B statuses.
    

It uses those values strictly as training eligibility/provenance information.

---

# 114. Important Data-Safety Properties

The current implementation establishes several strong boundaries.

### History is reserved before model splits

Part C warm-up rows cannot accidentally become percentage-based model data.

### Chronology is preserved

No random train/test split is used.

### Validation is isolated

It is used only when tuning is active.

### XGBoost calibration is isolated

Calibration rows do not train the regression model.

### Test remains untouched

Neither model fits on test rows.

### XGBoost target leakage is explicitly filtered

Several Part C current-target-derived feature families are excluded from X.

### Invalid sites are not trained

But their skip reason remains traceable.

### Valid-site failure is not silently ignored

It fails the complete run.

### Model artifacts are not partially published

Staging is finalized only after success.

---

# 115. Responsibility Separation Between Shared Files

### `validation.py`

**Determine what the model is legally allowed to consume.**

### `loader.py`

**Determine exactly when each model stage occurs chronologically.**

### `runner.py`

**Determine which site/model/tuning path executes and in what order.**

### `model_output.py`

**Persist successful models and the complete training contract.**

This keeps validation, splitting, model mathematics, orchestration and persistence from collapsing into one file.

---

# 116. Responsibility Separation — XGBoost

### `training/fixed_training.py`

**Direct fitting or predefined candidate tuning.**

### `training/optuna_training.py`

**Optuna search while reusing the fixed data/model contract.**

### `residual_calibration.py`

**Convert regression residual distribution into anomaly thresholds.**

### `testing.py`

**Apply those already-calibrated thresholds to untouched test data.**

---

# 117. Responsibility Separation — Isolation Forest

### `training/fixed_training.py`

**Direct fitting or predefined-candidate unsupervised tuning.**

### `training/optuna_training.py`

**Optuna search using the same score-separation contract.**

### `testing.py`

**Apply the fitted estimator and requested KPI-direction rule to untouched test data.**

There is no separate calibration module because the Isolation Forest's own fitted contamination/offset provides its model anomaly boundary.

---

# 118. Final Part D Result

Part D ultimately transforms:

```text
Part C engineered KPI dataset
+
resolved feature contract
+
Part D model request
```

into:

```text
one trained model per valid site
+
exact chronological split plan
+
model feature contract
+
selected hyperparameters
+
training/tuning diagnostics
+
decision settings
+
test diagnostics
+
usable-row counts
+
run/model metadata
```

---

# 119. Final Summary

The Part D implementation is best understood as three layers.

```text
SHARED PART D INFRASTRUCTURE

validation.py
→ Validate Part C dataset and construct exact model X/y contract.

loader.py
→ Reserve Part C history and generate chronological boundaries.

runner.py
→ Skip invalid sites, dispatch model/tuning route, execute every
  valid site and coordinate persistence.

model_output.py
→ Save each site model immediately and finalize the reproducible
  training package.
```

```text
XGBOOST

fixed_training.py
→ Direct training or fixed candidate tuning with validation-based
  early stopping and final refit.

optuna_training.py
→ Optuna search with the same loading/filtering/model contract.

residual_calibration.py
→ Derive per-site lower/upper residual thresholds from dedicated
  calibration data.

testing.py
→ Apply saved residual thresholds to untouched test data.
```

```text
ISOLATION FOREST

fixed_training.py
→ Direct fitting or fixed candidate selection by score separation.

optuna_training.py
→ Optuna search maximizing the same score-separation objective.

testing.py
→ Apply model anomaly detection and then lower/upper/both residual
  direction filtering to untouched test rows.
```

The central architectural result is therefore:

```text
Part C feature-engineered, provenance-aware timeline
                    ↓
        Validate exact model contract
                    ↓
        Reserve required feature history
                    ↓
          Chronological model splits
                    ↓
       One independent model per site
                    ↓
      Direct / Fixed / Optuna training
                    ↓
     Model-specific anomaly decision
                    ↓
           Untouched final test
                    ↓
   Persist model + complete inference contract
```

Part D is therefore not merely a model-fitting function. It is the backend's **site-specific model training, selection, calibration, evaluation, and model-package creation layer**, while preserving strict chronological separation and the Part B/Part C provenance and feature contracts supplied by earlier stages.