# [[Part A Shared Dataset Schema — schema common.dataset.py]]
# [[Part B Preprocessing Schema — app.schemas.preprocessing]]
# Part B — Preprocessing ML Module Final Technical Report

**Module:** Part B — Preprocessing  
**Module Location:** `app/ml/preprocessing/`

### Files

|File|Main Responsibility|
|---|---|
|`timeline_correction.py`|Correct timeline, clean invalid values, create initial labels, and determine series usability|
|`outlier_labelling.py`|Detect and label KPI outliers|
|`missing_gap_analysis.py`|Freeze original missing gaps into preprocessing phases|
|`missing_value_phase_1.py`|Fill short gaps using bounded local anchors|
|`missing_value_phase_2.py`|Seasonal filling using recent same-type and last-week references|
|`missing_value_phase_3.py`|Broader historical seasonal-median filling|
|`missing_value_phase_4.py`|Optional two-pass Prophet filling|
|`runner.py`|Authoritative normal/training Part B orchestration|
|`runner_inference.py`|Inference-specific Part B orchestration with cached-usability enforcement|

The normal runner executes the complete Part B sequence for **one KPI result returned by Part A**.

---

# 1. Purpose of Part B

Part B converts the structural findings produced by Part A into an **actual corrected and preprocessing-ready KPI time series**.

Part A determines what is wrong with the data.

Part B performs the corresponding preprocessing operations:

- removes duplicate site-timestamp rows;
    
- inserts timestamps identified as missing;
    
- converts invalid KPI values to missing values;
    
- assigns immutable original-condition labels;
    
- calculates site-series usability;
    
- detects and labels outliers;
    
- classifies original missing gaps;
    
- fills missing values through ordered filling phases;
    
- distinguishes safe fills from leakage-risk fills;
    
- returns one final cleaned dataset for the KPI.
    

The Part B runner does not independently rediscover Part A files. It receives an exact `KPIEDARunResult` and uses the source, site-summary, and integrity paths carried in that result.

---

# 2. Project Components Used by Part B

Part B directly depends on a few project components outside its own package.

## Part A EDA

Part B uses:

```text
KPIEDARunResult
DataIntegrityResult
Part A Composite_ID definition
Part A gap details
Part A duplicate details
Part A per-series integrity summary
Part A site summary
```

The Part B runner validates that these artifacts all belong to the **same prepared KPI dataset** before preprocessing begins.

Part B also deliberately reuses Part A's:

```text
COMPOSITE_ID_COLUMN
COMPOSITE_ID_SEPARATOR
MISSING_ID_VALUE
```

so site identity remains consistent across the two modules.

---

## Shared Dataset Schema

Part B uses:

- `DatasetInputConfig`
    
- `DatasetColumnMapping`
    
- `BucketConfig`
    

primarily for:

- physical source-column mappings;
    
- site identity;
    
- KPI value/timestamp columns;
    
- resolved bucket information.
    

---

## Part B Schema

Part B consumes:

- `PreprocessingConfig`
    
- `ResolvedFrequencyConfig`
    

The normal runner resolves the preprocessing configuration against the Part A bucket **once**, then passes the same resolved configuration to every frequency-dependent stage.

---

## Core Exceptions / File Services

Part B uses the shared project's:

- validation/file-processing exceptions;
    
- CSV reading/writing;
    
- directory creation;
    
- filename sanitization.
    

Their internal implementation belongs to the separate Core/Services reports.

---

# 3. Overall Part B Processing Flow

```text
Part A KPIEDARunResult
        │
        ▼
Validate Part A handoff
        │
        ▼
Resolve PreprocessingConfig
against Part A BucketConfig
        │
        ▼
ResolvedFrequencyConfig
        │
        ▼
────────────────────────────
1. Timeline Correction
────────────────────────────
        │
        ▼
────────────────────────────
2. Outlier Labelling
────────────────────────────
        │
        ▼
────────────────────────────
3. Original Gap Analysis
────────────────────────────
        │
        ▼
────────────────────────────
4. Phase 1 Filling
────────────────────────────
        │
        ▼
────────────────────────────
5. Phase 2 Filling
────────────────────────────
        │
        ▼
────────────────────────────
6. Phase 3 Filling
────────────────────────────
        │
        ▼
      Phase 4 enabled?
       /          \
     Yes           No
      │             │
      ▼             │
────────────────    │
7. Prophet Phase 4 │
────────────────    │
      │             │
      └──────┬──────┘
             ▼
       Final Validation
             │
             ▼
     Final Cleaned Dataset
             │
             ▼
 PreprocessingRunnerResult
```

This sequence is fixed by the normal Part B runner.

---

# 4. Part B State-Label System

Part B uses two related label columns.

## `Original_Condition_Label`

Created during timeline correction and then treated as **immutable provenance**.

Possible values are:

|Label|Meaning|
|--:|---|
|`-2`|Timestamp inserted during timeline correction|
|`-1`|Original supplied value was invalid and converted to NaN|
|`0`|Original value was missing/blank|
|`1`|Original value was valid|

Once created, later stages must not modify this column.

---

## `Current_Status_Label`

Starts equal to `Original_Condition_Label`, but represents the **current working state**.

Later Part B stages can add:

|Label|Meaning|
|--:|---|
|`2`|Outlier|
|`3`|Safe fill|
|`4`|Leakage-risk/full-series Prophet fill|

Therefore:

```text
Original_Condition_Label
= What was this point originally?

Current_Status_Label
= What is this point now?
```

The runner finally verifies that `Original_Condition_Label` remained unchanged through the entire Part B chain.

---

# 5. `timeline_correction.py`

## Responsibility

This is the **first actual preprocessing stage**.

It performs:

1. Part A handoff validation;
    
2. duplicate correction;
    
3. source-value cleaning;
    
4. insertion of missing timestamps;
    
5. initial condition/status labelling;
    
6. expected-series-length validation;
    
7. missing-percentage calculation;
    
8. site-series usability classification.
    

It does **not** detect outliers or fill missing values.

---

# 6. Part A Inputs Used by Timeline Correction

Timeline correction consumes:

### Prepared KPI dataset

The normalized KPI-specific CSV produced by Part A.

### Site-analysis summary

Used as the authoritative site list.

### `series_summary.csv`

Used to verify expected series sizes and Part A integrity state.

### `gap_details.csv`

Used to determine exactly which missing site timestamps must be inserted.

### `duplicate_timestamp_details.csv`

Used to verify that Part A's duplicate findings still match the source.

The module therefore **uses Part A's findings rather than performing a second independent EDA pass**.

---

# 7. Strict Part A Handoff Validation

Before modification begins, Part B checks that required Part A artifacts exist and are mutually consistent.

It rejects cases where:

- the prepared KPI file is missing;
    
- the site summary is missing;
    
- required integrity outputs are missing;
    
- the Part A integrity result belongs to another source;
    
- the site-summary path does not match;
    
- Part A reported invalid timestamps;
    
- Part A reported rows outside its expected timeline;
    
- Part A reported off-grid timestamps that preprocessing cannot safely preserve.
    

## This protects Part B from applying one KPI's analysis results to another KPI dataset.

# 8. Duplicate Removal

Duplicate keys are based on:

```text
site identity
+
timestamp
```

Part B verifies Part A's duplicate report against the prepared KPI dataset.

The correction rule is:

```text
First physical row  → keep
Later duplicate rows → remove
```

The number of removed rows becomes:

```text
duplicate_rows_removed
```

in the final runner result.

---

# 9. Source KPI Value Cleaning

After duplicates are removed, Part B interprets the original KPI values.

### Missing or blank

Receives:

```text
Original_Condition_Label = 0
Current_Status_Label = 0
```

### Valid numeric value

Receives:

```text
Original_Condition_Label = 1
Current_Status_Label = 1
```

### Invalid supplied numeric value

The value is converted to `NaN` and receives:

```text
Original_Condition_Label = -1
Current_Status_Label = -1
```

Non-blank values that cannot be parsed as numeric are rejected rather than silently treated as missing.

---

# 10. Boundary Tolerance

The valid-value configuration can permit values slightly outside the physical bounds.

When clipping is enabled, a value inside the configured tolerance is clipped back to the nearest valid boundary before invalid-value classification.

Conceptually:

```text
lower_bound - tolerance
        │
        ├── slightly low → clip to lower_bound
        │
lower_bound
        │
     valid range
        │
upper_bound
        │
        ├── slightly high → clip to upper_bound
        │
upper_bound + tolerance
```

Values still outside the accepted range after tolerance handling become `NaN` and receive original label `-1`.

---

# 11. Missing Timestamp Insertion

Part B does not independently infer missing timestamps.

It reads the exact missing blocks already recorded in Part A's:

```text
gap_details.csv
```

and generates the corresponding site-specific timestamps.

Inserted rows receive:

```text
KPI value                  = NaN
Original_Condition_Label   = -2
Current_Status_Label       = -2
```

Site identity is populated from the authoritative site information.

## Other metadata is copied only when it can be safely treated as constant for the site; non-constant or unavailable optional metadata may remain missing.

# 12. Corrected Timeline Validation

After:

- duplicate removal;
    
- original-value labelling;
    
- timestamp insertion;
    

the module combines and orders all rows by:

```text
Part A site order
+
timestamp
```

It verifies that:

- no duplicate site-timestamp keys remain;
    
- every site contains exactly the expected timestamp count previously calculated by Part A.
    

If Part A expected 8,640 timestamps for a site, the corrected Part B series must contain exactly 8,640 rows.

---

# 13. Series Usability

Timeline correction calculates a missing percentage separately for each site.

Missing-origin labels are:

```text
{-2, -1, 0}
```

Therefore:

```text
missing_percentage =
(
    inserted timestamps
    + invalid original values
    + originally missing values
)
/
final expected rows
× 100
```

The default threshold is defined by the Part B schema.

A site is invalid only when:

```text
missing_percentage > maximum_missing_percentage
```

Equality remains valid.

---

# 14. Usability Columns

Timeline correction adds:

```text
missing_percentage
kpi_usability
kpi_invalid_reason
```

Possible usability values are:

```text
valid
invalid
```

For a site invalidated by the missing-percentage threshold:

```text
kpi_invalid_reason =
"missing_percentage_above_limit"
```

The decision is repeated consistently across every row belonging to the site.

---

# 15. Timeline-Corrected Dataset Columns

The output retains the original physical source columns and adds:

```text
Original_Condition_Label
Current_Status_Label
missing_percentage
kpi_usability
kpi_invalid_reason
```

At this point:

```text
Current_Status_Label == Original_Condition_Label
```

because outlier detection and filling have not yet occurred.

---

# 16. `outlier_labelling.py`

## Responsibility

This stage receives the fully corrected timeline and applies exactly **one selected outlier detector** to each usable site series.

Supported methods:

```text
global_iqr
one_day_centered_iqr
user_bounds
```

Supported directions:

```text
lower_only
upper_only
both
```

Detected outliers change only:

```text
Current_Status_Label: 1 → 2
```

The KPI value itself and `Original_Condition_Label` remain unchanged.

---

# 17. Outlier Eligibility

Outlier reference/evaluation data comes only from originally valid observations:

```text
Original_Condition_Label == 1
finite KPI value
```

Invalid site series are skipped.

Rows originally representing:

```text
-2
-1
0
```

are not detector references.

This means missing values or timeline insertions do not distort outlier thresholds.

---

# 18. Global IQR

For each site independently:

```text
Q1 = 25th percentile
Q3 = 75th percentile
IQR = Q3 - Q1
```

then:

```text
Lower Threshold = Q1 - multiplier × IQR
Upper Threshold = Q3 + multiplier × IQR
```

The module requires at least:

```text
4 original-valid reference points
```

before global IQR can be applied.

The selected direction determines whether lower, upper, or both thresholds are active.

---

# 19. One-Day Centered IQR

The centred-IQR method calculates local rolling IQR thresholds around each target.

Its resolved window size and minimum valid-point requirement come from:

```text
ResolvedFrequencyConfig
```

Unlike the later missing-value filling stages, this detector is a **batch centred detector** and may use values both before and after the target timestamp.

Therefore this method is appropriate for offline/batch preprocessing, not as a past-only inference principle by itself.

---

# 20. User-Bounds Detection

When `user_bounds` is selected, the configured threshold is applied directly.

Depending on direction:

```text
lower_only → value < lower threshold
upper_only → value > upper threshold
both       → either condition
```

Threshold comparisons are strict, so a value exactly equal to the configured threshold is not classified as an outlier.

The detector uses only originally valid finite points.

---

# 21. Outlier Output

For each site, the stage summary can record:

- selected method;
    
- selected direction;
    
- usability;
    
- reference points;
    
- evaluated points;
    
- unevaluated valid points;
    
- lower outliers;
    
- upper outliers;
    
- total outliers;
    
- IQR statistics where applicable;
    
- threshold ranges;
    
- detector status.
    

The stage performs a final invariant check confirming that **only `Current_Status_Label` changed**.

---

# 22. `missing_gap_analysis.py`

## Responsibility

This stage freezes the **original missing structure** before any filling begins.

It adds:

```text
Original_Gap_Phase
```

based exclusively on:

```text
Original_Condition_Label
```

Original missing rows are:

```text
-2
-1
0
```

Outliers are **not missing gaps**, because an outlier remains:

```text
Original_Condition_Label = 1
Current_Status_Label = 2
```

---

# 23. Why Gap Classification Is Immutable

Suppose an original gap contains four missing points.

Later Phase 2 might successfully fill three of those points.

The gap must still remain historically:

```text
original gap size = 4
```

Otherwise later retry logic could incorrectly reinterpret the remaining one unresolved point as a new one-point Phase 1 gap.

For this reason:

```text
Original_Gap_Phase
```

is created once and not recalculated after filling.

---

# 24. Gap Phase Values

The stage stores:

|Value|Meaning|
|--:|---|
|`1`|Phase 1|
|`2`|Phase 2|
|`3`|Phase 3|
|`4`|Phase 4 Pass 1|
|`5`|Phase 4 Pass 2|

Non-original-missing rows receive a nullable blank phase.

The actual ranges come from the already resolved `GapProfileConfig`, allowing the same algorithm to support:

- built-in 5-minute ranges;
    
- built-in 15-minute ranges;
    
- validated custom ranges.
    

---

# 25. Gap Analysis Does Not Skip Invalid Sites

An important distinction is:

```text
Gap classification → all site series
Filling            → usable site series only
```

`missing_gap_analysis.py` still classifies original gaps belonging to invalid site series.

This preserves a complete historical description of the input dataset.

The later filling stages decide whether those gaps are eligible for correction.

---

# 26. Gap Analysis Validation

Before classifying gaps, the module verifies:

- required columns;
    
- timestamps;
    
- original/current labels;
    
- legal label transitions;
    
- value-label consistency;
    
- site usability consistency;
    
- absence of duplicate site-timestamp keys;
    
- complete spacing at the resolved bucket interval.
    

Therefore this stage also acts as a structural checkpoint confirming that timeline correction and outlier labelling produced the expected state.

---

# 27. Missing Gap Summary

The stage produces one record per continuous original gap containing information such as:

```text
Composite_ID
Gap Number
Gap Start
Gap End
Gap Size
Assigned Phase
```

It additionally tracks aggregate:

- total gaps;
    
- total original missing points;
    
- gaps per phase;
    
- missing points per phase.
    

---

# 28. Shared Trust Rule Used by Filling Stages

Across the safe missing-value filling stages, a reference is generally trusted only when:

```text
Current_Status_Label in {1, 3}
finite KPI value
value inside configured valid range
same site series
```

Therefore:

```text
1 = trusted original observation
3 = trusted safe fill
```

while these are not trusted references:

```text
2  = outlier
4  = leakage-risk fill
0  = unresolved original missing
-1 = unresolved invalid
-2 = unresolved inserted timestamp
```

This rule prevents outliers, unresolved points, and leakage-risk predictions from contaminating later safe fills.

---

# 29. `missing_value_phase_1.py`

## Responsibility

Phase 1 targets original gaps classified as:

```text
Original_Gap_Phase == 1
```

It fills complete gaps using nearby trusted anchors.

Invalid site series are skipped.

---

# 30. Phase 1 Filling Ladder

For each complete Phase 1 gap:

### Method 1 — Immediate linear interpolation

```text
phase1_linear_interpolation
```

If trusted values immediately surround the gap, Part B linearly interpolates every missing point between them.

---

### Method 2 — Two-sided weighted anchors

```text
phase1_neighbor_weighted
```

If immediate interpolation is unavailable, it searches for trusted anchors on both sides.

Both must satisfy:

- maximum search distance;
    
- stricter two-sided distance;
    
- configured distance-balance ratio.
    

Each target is weighted according to its real distance from both anchors.

---

### Method 3 — One-sided anchor

If two-sided filling cannot be accepted:

```text
phase1_neighbor_before_only
```

or:

```text
phase1_neighbor_after_only
```

uses the closer trusted anchor for the entire gap.

A distance tie favors the previous anchor.

---

### Failure

The complete gap remains unresolved so later phases can retry it.

---

# 31. Phase 1 Search Barriers

The bounded local search may pass an outlier (`2`), but the outlier itself can never act as the anchor.

Hard barriers include:

```text
-2
-1
0
4
missing values
unexpected states
```

Earlier successful Phase 1 fills labelled `3` may be reused as trusted anchors for later Phase 1 gaps.

---

# 32. Phase 1 Successful Fill

Successful filling modifies only:

```text
KPI value
Current_Status_Label → 3
Fill_Method
```

It never changes:

```text
Original_Condition_Label
Original_Gap_Phase
```

Generated values are validated against the configured physical range and may be clipped when configured.

---

# 33. Phase 1 Statistics

Phase 1 tracks:

- eligible gaps;
    
- eligible points;
    
- filled gaps;
    
- filled points;
    
- unresolved gaps;
    
- unresolved points;
    
- linear fills;
    
- weighted fills;
    
- before-only fills;
    
- after-only fills;
    
- processed sites;
    
- skipped unusable sites.
    

---

# 34. `missing_value_phase_2.py`

## Responsibility

Phase 2 handles:

### Primary targets

```text
Original_Gap_Phase == 2
```

### Retry targets

Unresolved:

```text
Original_Gap_Phase == 1
```

Points already safely filled by Phase 1 remain status `3` and are not overwritten.

---

# 35. Phase 2 Seasonal References

For each unresolved target timestamp `T`, Phase 2 attempts to obtain two types of historical references.

## Recent same-type reference

Searches backward for the nearest earlier day with the same broad day type:

```text
weekday → previous weekday-type day
weekend → previous weekend-type day
```

up to the configured lookback limit.

---

## Last-week reference

Uses:

```text
T - configured last-week lookback days
```

normally preserving the same time of day.

---

## Neighbor fallback

Around either seasonal timestamp, Phase 2 can inspect:

```text
reference - configured offset
reference + configured offset
```

If both are trusted, their mean is used.

If only one is trusted, that value is used.

---

# 36. Phase 2 Filling Ladder

The exact ordered ladder is:

```text
1. recent exact + last-week exact
2. recent neighbours + last-week exact
3. recent exact + last-week neighbours
4. recent neighbours + last-week neighbours
5. recent exact only
6. last-week exact only
7. recent neighbours only
8. last-week neighbours only
9. failure
```

When both recent and last-week references participate, their contribution follows the configured Phase 2 weights.

Successful fills are past-only and receive:

```text
Current_Status_Label = 3
```

Phase 2 never creates label `4`.

---

# 37. Phase 2 Can Reuse Earlier Safe Fills

Trusted references can include:

- original label-1 observations;
    
- Phase 1 safe fills;
    
- earlier Phase 2 safe fills.
    

This lets safe information progressively improve later filling opportunities without allowing risky information back into the reference pool.

---

# 38. Phase 2 Gap Outcomes

Unlike Phase 1, Phase 2 operates at the unresolved-point level and therefore a target gap can become:

```text
completely filled
partially filled
still unresolved
```

The stage separately tracks:

- primary gaps/points;
    
- Phase 1 retry gaps/points;
    
- already resolved Phase 1 points;
    
- filled points;
    
- unresolved points;
    
- skipped unusable points;
    
- counts for all eight methods.
    

---

# 39. `missing_value_phase_3.py`

## Responsibility

Phase 3 broadens the historical search.

### Primary targets

```text
Original_Gap_Phase == 3
```

### Retry targets

Unresolved points from:

```text
Original_Gap_Phase == 1 or 2
```

Already resolved safe points are not overwritten.

---

# 40. Phase 3 Filling Ladder

For every unresolved target:

### Level 1 — Same-type seasonal median

Collect trusted values in the configured narrow window around previous matching weekday/weekend days.

A configured minimum number of clean values is required.

Method:

```text
phase3_same_type_median_level_1
```

---

### Level 2 — Wider same-type seasonal median

If Level 1 fails, use the wider configured window around those same-type days.

Method:

```text
phase3_same_type_median_level_2
```

---

### Level 3 — Same-type exact-time median

Use trusted exact-time values from earlier same-type days.

Method:

```text
phase3_same_type_exact_median
```

---

### Level 4 — Previous-day-any-type median

Walk backward by calendar day and use the first earlier day containing enough trusted values in the Level 1 window.

Method:

```text
phase3_previous_day_any_type_median
```

---

### Failure

Leave the point unresolved for Phase 4.

---

# 41. Phase 3 Safety

Every Phase 3 historical reference occurs **before the target timestamp**.

Therefore successful Phase 3 fills receive:

```text
Current_Status_Label = 3
```

and never:

```text
4
```

Safe fills from:

- Phase 1;
    
- Phase 2;
    
- earlier Phase 3 operations
    

can be reused as references.

---

# 42. Phase 3 Statistics

The stage tracks:

- primary Phase 3 gaps/points;
    
- retry gaps/points from Phases 1 and 2;
    
- earlier points already safely resolved;
    
- eligible points;
    
- filled points;
    
- unresolved points;
    
- complete/partial/unresolved gaps;
    
- skipped unusable points;
    
- method counts for each Phase 3 level.
    

---

# 43. `missing_value_phase_4.py`

## Responsibility

Phase 4 is the final optional filling stage and uses Prophet.

Unlike Phases 1–3, it explicitly distinguishes:

```text
safe past-only prediction
```

from:

```text
full-series leakage-risk prediction
```

This distinction is recorded through both `Current_Status_Label` and `Fill_Method`.

---

# 44. Phase 4 Pass 1

Pass 1 targets:

### Primary

```text
Original_Gap_Phase == 4
```

### Retry

Remaining unresolved points from original:

```text
Phase 1
Phase 2
Phase 3
```

---

# 45. Phase 4 Pass 2

Pass 2 primarily processes:

```text
Original_Gap_Phase == 5
```

A fresh fixed training snapshot is created at the beginning of Pass 2.

Therefore safe Pass 1 fills can become part of Pass 2's trusted information, while leakage-risk Pass 1 fills cannot.

---

# 46. Fixed Training Snapshot Rule

At the beginning of each Prophet pass:

```text
training snapshot is frozen
```

Consequently:

```text
fills produced earlier in the same pass
        ↓
cannot train later models in that same pass
```

This avoids within-pass recursive model contamination.

Between passes:

```text
Pass 1 status-3 fills → available to Pass 2
Pass 1 status-4 fills → excluded
```

---

# 47. Prophet Mode 1 — Past-Only Safe Model

For each target gap, Part B first attempts a model trained strictly from trusted history **before the original gap start**.

Successful predictions receive:

```text
Current_Status_Label = 3
```

and methods such as:

```text
phase4_pass1_prophet_forward_safe
phase4_pass2_prophet_forward_safe
```

This is treated as the safe Prophet route.

---

# 48. Prophet Mode 2 — Full-Series Fallback

If enabled and the safe model cannot resolve the target, Phase 4 may use a cached full-series Prophet model.

Because this model can contain information from after the target gap, successful predictions receive:

```text
Current_Status_Label = 4
```

with methods such as:

```text
phase4_pass1_prophet_full_series_leakage
phase4_pass2_prophet_full_series_leakage
```

This explicitly preserves the distinction between safe and leakage-risk fills rather than treating them identically.

---

# 49. Prophet Training Trust Rules

Prophet training rows must have:

```text
Current_Status_Label in {1, 3}
finite KPI value
value within configured valid range
```

Excluded training rows include:

```text
2  outliers
4  leakage-risk fills
-2 unresolved insertions
-1 unresolved invalid values
0  unresolved missing values
```

Therefore a full-series leakage fill is never recycled into another Prophet training set.

---

# 50. Prophet Dependency Behaviour

`prophet` is imported lazily.

Therefore:

```text
Phase 4 disabled
        ↓
backend can operate without importing Prophet
```

If Phase 4 is enabled but Prophet is unavailable, Part B raises a file-processing error indicating the optional package is required.

---

# 51. Phase 4 Disabled Behaviour

The runner checks:

```text
preprocessing_config.phase_4.enabled
```

If `False`:

- Phase 4 is not called;
    
- no Phase 4 summary is created;
    
- the Phase 3 dataframe becomes the final Part B dataframe;
    
- Phase 4 safe/leakage counts remain zero.
    

The Phase 4 module itself also rejects accidental direct execution while disabled.

---

# 52. Dataset Fields Added Across Part B

By the end of Part B, the final dataset carries the original dataset fields plus the preprocessing state columns:

```text
Original_Condition_Label
Current_Status_Label
missing_percentage
kpi_usability
kpi_invalid_reason
Original_Gap_Phase
Fill_Method
```

Their roles are:

|Column|Responsibility|
|---|---|
|`Original_Condition_Label`|Immutable original state|
|`Current_Status_Label`|Current state after outlier/filling stages|
|`missing_percentage`|Original missing/invalid/inserted percentage for site|
|`kpi_usability`|Site-level valid/invalid decision|
|`kpi_invalid_reason`|Reason for invalidity|
|`Original_Gap_Phase`|Immutable original gap classification|
|`Fill_Method`|Provenance of successful missing-value fill|

---

# 53. Complete Current-Status Meaning at Part B Output

The final `Current_Status_Label` contract is:

```text
-2 → inserted timestamp still unresolved
-1 → invalid original value still unresolved
 0 → original missing value still unresolved
 1 → trusted original valid value
 2 → detected outlier
 3 → safely filled value
 4 → leakage-risk/full-series Prophet fill
```

This status system allows later stages to distinguish not simply whether a numeric value exists, but **how trustworthy that value is and where it came from**.

---

# 54. `runner.py`

## Responsibility

`runner.py` is the authoritative orchestration layer for normal/training preprocessing.

It receives:

```text
KPIEDARunResult
DatasetInputConfig
PreprocessingConfig
BucketConfig
output directory
logger
```

and returns:

```text
PreprocessingRunnerResult
```

for one KPI.

---

# 55. Runner's Part A Handoff

`validate_part_a_handoff()` confirms:

```text
prepared_dataset.file_path
site_analysis.summary_file
data_integrity.source_file
data_integrity.site_summary_file
```

all describe the same KPI run.

The runner does **not** search directories for files based on assumed naming conventions.

---

# 56. Runner Frequency Resolution

The runner calls:

```text
preprocessing_config.resolve_for_bucket(bucket)
```

once.

That produces:

```text
ResolvedFrequencyConfig
```

which is reused by:

- outlier detection;
    
- gap analysis;
    
- Phase 1;
    
- Phase 2;
    
- Phase 3;
    
- Phase 4.
    

This ensures all stages interpret time-based configuration identically.

---

# 57. In-Memory Stage Chain

After timeline correction produces its dataset, the main runner carries later stage outputs in memory:

```text
timeline dataframe
      ↓
OutlierLabellingData.dataframe
      ↓
MissingGapAnalysisData.dataframe
      ↓
Phase1FillingData.dataframe
      ↓
Phase2FillingData.dataframe
      ↓
Phase3FillingData.dataframe
      ↓
Phase4FillingData.dataframe
```

The runner itself decides which summaries and checkpoints need to be persisted.

This reduces unnecessary dependence between stages on externally rediscovering files.

---

# 58. Output Policy

The runner always saves:

```text
final cleaned dataset
all applicable stage summaries
```

Intermediate full dataset checkpoints are saved only when:

```text
save_intermediate_outputs = True
```

Temporary timeline-correction files used internally by the runner are stored in a short-lived `TemporaryDirectory` and removed automatically.

---

# 59. Part B Output Structure

For a workflow-created KPI Part B directory:

```text
<KPI preprocessing directory>/
│
├── <KPI>_final_cleaned.csv
│
├── summaries/
│   ├── 01_outlier_summary.csv
│   ├── 02_original_gap_summary.csv
│   ├── 03_phase_1_summary.csv
│   ├── 04_phase_2_summary.csv
│   ├── 05_phase_3_summary.csv
│   └── 06_phase_4_summary.csv   # only when Phase 4 enabled
│
└── intermediate/                # only when requested
    ├── 01_timeline_corrected.csv
    ├── 02_outlier_labelled.csv
    ├── 03_original_gap_classified.csv
    ├── 04_phase_1_filled.csv
    ├── 05_phase_2_filled.csv
    └── 06_phase_3_filled.csv
```

The final cleaned dataset and summaries are stable runner-owned outputs.

---

# 60. Final Runner Validation

Before the final dataset is written, `validate_final_runner_output()` verifies cross-stage invariants.

Most importantly:

### Row count cannot change after timeline correction

```text
timeline-corrected row count
=
final Part B row count
```

Filling stages therefore modify values/state but cannot arbitrarily add or remove rows.

### Original labels must remain immutable

```text
Original_Condition_Label at timeline stage
=
Original_Condition_Label at final stage
```

### Phase 4 disabled means no label 4

If Prophet is disabled:

```text
Current_Status_Label == 4
```

must not exist.

---

# 61. Final Unresolved Count

The runner defines final unresolved points as rows whose current status remains:

```text
{-2, -1, 0}
```

This count can include unresolved points belonging to unusable site series because those sites are deliberately skipped by filling.

---

# 62. `PreprocessingRunnerResult`

The structured result exposes both file locations and headline processing statistics.

Important paths include:

```text
final_dataset_file
outlier_summary_file
gap_summary_file
phase_1_summary_file
phase_2_summary_file
phase_3_summary_file
phase_4_summary_file
optional intermediate checkpoints
```

Important statistics include:

```text
input/final rows
duplicates removed
timestamps inserted
invalid values converted
valid/invalid series
outliers flagged
original gaps
original missing points
Phase 1 fills
Phase 2 fills
Phase 3 fills
Phase 4 safe fills
Phase 4 leakage fills
final unresolved points
method counts
Prophet pass statistics
```

---

# 63. Normal Part B vs Inference Part B

Part B has **two runners**, but not two separate preprocessing implementations.

```text
runner.py
→ normal/training preprocessing

runner_inference.py
→ inference preprocessing
```

The inference runner deliberately reuses the same:

- timeline correction;
    
- outlier labelling;
    
- gap analysis;
    
- Phase 1;
    
- Phase 2;
    
- Phase 3;
    
- Phase 4;
    
- final result type.
    

The normal `runner.py` remains authoritative for training.

---

# 64. Why Inference Needs a Separate Runner

Timeline correction calculates site usability from the data window currently being processed.

During training, that is appropriate.

During inference, however, the runtime working window may be considerably shorter.

A site that was historically considered:

```text
valid
```

could appear:

```text
invalid
```

merely because the short inference window has a temporarily high missing percentage.

The inference runner prevents that classification drift for previously known sites.

---

# 65. Inference Cached-Usability Rule

After normal timeline correction:

```text
timeline correction
        │
        ▼
fresh missing_percentage
fresh provisional usability
```

the inference runner consults the saved processed cache.

For each site already known in that cache, it restores the cached:

```text
kpi_usability
kpi_invalid_reason
```

**before outlier detection and filling begin.**

---

# 66. What Inference Does Not Restore

The inference runner deliberately leaves:

```text
missing_percentage
```

as the newly calculated runtime value.

Therefore:

```text
missing_percentage
→ diagnostic for the current inference window

kpi_usability
→ authoritative historical decision for cached sites
```

This lets the system observe that the current window is sparse without changing the training-established usability classification.

---

# 67. Cached and Uncached Inference Sites

For a site present in the processed cache:

```text
cached usability + reason
→ authoritative
```

For a runtime site absent from the cache:

```text
timeline correction's provisional runtime usability
→ retained
```

The inference runner also validates that cached site identities, usability values, and reasons are internally consistent before enforcement.

---

# 68. Inference Processing After Enforcement

After cached usability has been applied, inference runs the **same remaining Part B stages**:

```text
Outlier Labelling
        ↓
Missing Gap Analysis
        ↓
Phase 1
        ↓
Phase 2
        ↓
Phase 3
        ↓
Optional Phase 4
        ↓
Final Validation
        ↓
PreprocessingRunnerResult
```

Thus the inference-specific difference is deliberately narrow rather than maintaining a second independent preprocessing implementation.

---

# 69. Important Data-Safety Principles

The completed Part B implementation enforces several important principles.

### Original provenance is immutable

The original condition of every point is retained even after filling.

### Outliers remain observable

Outlier values are labelled rather than overwritten during outlier detection.

### Gap size is frozen before filling

Later fills cannot change which original gap class the point belonged to.

### Safe and risky fills are distinguishable

```text
3 = safe
4 = leakage-risk
```

### Risky fills never become trusted references

Status `4` is excluded from later training/reference pools.

### Invalid sites are preserved

They are generally skipped rather than deleted.

### Timeline shape stabilizes early

After timeline correction, later Part B stages preserve row count and row order.

---

# 70. Responsibility Separation Between Files

The module's internal responsibility split is:

### `timeline_correction.py`

**Turn Part A findings into a corrected, labelled timeline.**

### `outlier_labelling.py`

**Identify suspicious original-valid KPI observations without changing their values.**

### `missing_gap_analysis.py`

**Freeze every original missing gap into its configured processing phase.**

### `missing_value_phase_1.py`

**Attempt local short-gap repair.**

### `missing_value_phase_2.py`

**Use recent/weekly past seasonal references and retry failed Phase 1 points.**

### `missing_value_phase_3.py`

**Use broader multi-day seasonal history and retry earlier unresolved points.**

### `missing_value_phase_4.py`

**Use Prophet for remaining configured targets while separating safe and leakage-risk predictions.**

### `runner.py`

**Control the authoritative normal/training stage order, outputs and final result.**

### `runner_inference.py`

**Reuse the same Part B stages while enforcing cached historical site usability for inference.**

---

# 71. Complete Part A → Part B Handoff

```text
PART A
│
├── Prepared KPI CSV
├── Site summary
├── Series integrity summary
├── Gap details
├── Duplicate details
├── DataIntegrityResult
└── KPIEDARunResult
        │
        ▼
────────────────────────────────
PART B TIMELINE CORRECTION
────────────────────────────────
Validate Part A artifacts
Remove duplicates
Clean invalid values
Insert missing timestamps
Create original/current labels
Calculate missing percentage
Mark usable/unusable sites
        │
        ▼
────────────────────────────────
OUTLIER LABELLING
────────────────────────────────
Valid original point
      │
      ├─ normal  → status 1
      └─ outlier → status 2
        │
        ▼
────────────────────────────────
ORIGINAL GAP CLASSIFICATION
────────────────────────────────
Original {-2,-1,0} gaps
        │
        ├─ Phase 1
        ├─ Phase 2
        ├─ Phase 3
        ├─ Phase 4 Pass 1
        └─ Phase 4 Pass 2
        │
        ▼
────────────────────────────────
PHASE 1
────────────────────────────────
Local anchor methods
Success → status 3
Failure → unresolved
        │
        ▼
────────────────────────────────
PHASE 2
────────────────────────────────
Seasonal recent/week references
+ retry unresolved Phase 1
Success → status 3
        │
        ▼
────────────────────────────────
PHASE 3
────────────────────────────────
Broader seasonal medians
+ retry unresolved Phase 1/2
Success → status 3
        │
        ▼
────────────────────────────────
PHASE 4 — OPTIONAL
────────────────────────────────
Pass 1 + Pass 2

Past-only Prophet
→ status 3

Full-series fallback
→ status 4
        │
        ▼
────────────────────────────────
FINAL VALIDATION
────────────────────────────────
Preserve row count
Preserve original labels
Check leakage-state legality
        │
        ▼
<KPI>_final_cleaned.csv
        │
        ▼
PreprocessingRunnerResult
```

---

# 72. Part B → Later Pipeline Boundary

The central Part B product is:

```text
PreprocessingRunnerResult.final_dataset_file
```

This is the stable cleaned dataset passed onward to the next ML stage.

It contains:

- corrected timestamp rows;
    
- cleaned invalid values;
    
- outlier information;
    
- missing-value fills;
    
- original provenance;
    
- current status;
    
- usability;
    
- gap classification;
    
- fill provenance.
    

Part B therefore does considerably more than simply produce a numeric filled series: it preserves **how each final observation should be interpreted**.

---

# 73. Final Summary

Part B is the backend's **data correction and missing-value reconstruction layer**.

Its complete responsibility can be summarized as:

```text
timeline_correction.py
→ Apply Part A findings, correct timeline structure, clean invalid
  observations, establish immutable labels and site usability.

outlier_labelling.py
→ Detect lower/upper/both-side outliers using the selected detector and
  change only the current state to label 2.

missing_gap_analysis.py
→ Freeze every original missing gap into Phase 1, 2, 3, 4 Pass 1,
  or 4 Pass 2.

missing_value_phase_1.py
→ Fill short gaps using bounded local anchors.

missing_value_phase_2.py
→ Fill using recent same-type and last-week seasonal history and retry
  unresolved Phase 1 points.

missing_value_phase_3.py
→ Use broader multi-day seasonal medians and retry unresolved earlier
  phases.

missing_value_phase_4.py
→ Optionally use two-pass Prophet filling, explicitly separating
  past-only safe fills from full-series leakage-risk fills.

runner.py
→ Orchestrate the authoritative normal/training Part B pipeline and
  produce PreprocessingRunnerResult.

runner_inference.py
→ Reuse the same Part B processing chain while restoring cached
  historical site usability before inference filling begins.
```

The core architectural result of Part B is therefore:

```text
Raw per-KPI timeline identified by Part A
                ↓
Structurally corrected timeline
                ↓
Original-condition provenance
                ↓
Outlier state
                ↓
Immutable original-gap classification
                ↓
Ordered safe filling attempts
                ↓
Optional explicitly-labelled leakage fallback
                ↓
Final cleaned, provenance-aware KPI dataset
```

This provides later ML stages with both the **processed KPI values** and the **metadata required to distinguish original, anomalous, safely reconstructed, risky, unresolved, and unusable data**.