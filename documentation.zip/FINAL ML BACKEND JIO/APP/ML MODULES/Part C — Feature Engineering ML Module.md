# [[Part C Feature Engineering Schema — app.schemas.feature_engineering]]
# [[Part A Shared Dataset Schema — schema common.dataset.py]]
# Part C — Feature Engineering ML Module Final Technical Report

**Module Location:** `app/ml/feature_engineering/`

### Files

|File|Main Responsibility|
|---|---|
|`__init__.py`|Public Part C orchestration interface|
|`common.py`|Shared column, site-grouping, source-bundle, and feature-attachment helpers|
|`feature_validation.py`|Validate Part B input and final Part C output|
|`source_preparation.py`|Prepare `raw_value`, temporary `corrected_history`, and referenced-point cleaning|
|`value_features.py`|Generate `current_value`|
|`lag_features.py`|Generate exact point-based lag features|
|`comparison_features.py`|Generate difference, percentage-change, and seasonal-difference features|
|`rolling_features.py`|Generate rolling statistics, z-score, EWMA, and rolling slope|
|`time_features.py`|Generate time-of-day bucket and cyclical features|
|`calendar_features.py`|Generate weekday/weekend and day-cycle features|
|`baseline_features.py`|Generate leakage-safe weighted seasonal baseline|
|`residual_features.py`|Generate baseline + residual|
|`runner.py`|Orchestrate complete Part C execution for one preprocessed KPI|

---

# 1. Purpose of Part C

Part C converts the **final preprocessed KPI dataset returned by Part B** into a feature-engineered dataset suitable for downstream models.

Its responsibilities are:

- validate the exact Part B handoff;
    
- resolve feature configuration for the actual dataset bucket;
    
- process each site independently;
    
- preserve Part B rows and provenance;
    
- prepare reusable feature value sources;
    
- generate the requested feature families;
    
- enforce past-only calculations where required;
    
- retain invalid sites but skip feature generation for them;
    
- allow valid sites with insufficient history to produce natural warm-up `NaN`s;
    
- validate the completed feature matrix;
    
- save the feature-engineered dataset and site-level reporting.
    

Part C **does not redo Part A EDA or Part B preprocessing**.

---

# 2. External Project Dependencies

Part C directly uses several project-level contracts.

## Part B

The runner receives:

```text
PreprocessingRunnerResult
```

and takes the exact:

```text
final_dataset_file
```

as its source.

It does not search directories or reconstruct Part B filenames.

---

## Shared Dataset Schema

Part C uses:

```text
DatasetInputConfig
BucketConfig
```

to determine:

- site identity columns;
    
- timestamp column;
    
- KPI value column;
    
- dataset bucket.
    

---

## Part C Schema

The ML module consumes:

```text
FeatureEngineeringConfig
ResolvedFeatureEngineeringConfig
FeatureRequest models
```

The schema decides **what to generate**; the ML module calculates it.

---

## Core / Services

The runner uses shared:

- custom exceptions;
    
- directory creation;
    
- CSV reading/writing;
    
- filename sanitization.
    

Those internals remain part of the separate Core/Service reports.

---

# 3. Overall Part C Flow

```text
PreprocessingRunnerResult
        │
        ▼
Validate Part B handoff
        │
        ▼
Resolve physical dataset columns
        │
        ▼
FeatureEngineeringConfig
        +
BucketConfig
        │
        ▼
ResolvedFeatureEngineeringConfig
        │
        ▼
Read Part B final dataset
        │
        ▼
Normalize + validate input
        │
        ▼
Group by site
        │
        ├── invalid site
        │      ↓
        │   retain rows
        │   feature columns = NaN
        │
        └── valid site
               │
               ▼
       Prepare feature sources
               │
               ├── raw_value
               └── corrected_history if needed
               │
               ▼
       Dispatch feature requests
               │
               ├── value
               ├── lag
               ├── comparison
               ├── rolling
               ├── time
               ├── calendar
               ├── baseline
               └── residual
               │
               ▼
        Site feature matrix
               │
               ▼
Combine all site features
        │
        ▼
Final cross-validation
        │
        ▼
<KPI>_feature_engineered.csv
        │
        ├── site summary
        └── optional corrected-history audit
        │
        ▼
FeatureEngineeringRunnerResult
```

---

# 4. `__init__.py`

The package-level interface exposes only:

```text
FeatureEngineeringRunnerResult
FeatureEngineeringSiteRunSummary
run_feature_engineering_pipeline
```

Feature generators themselves remain internal implementation modules.

This keeps workflows/API orchestration dependent on the runner interface rather than individual feature-calculation files.

---

# 5. `common.py`

## Responsibility

`common.py` provides reusable Part C infrastructure without deciding which features are requested.

Its main runtime models are:

```text
FeatureInputColumns
SiteGroup
FeatureSourceBundle
```

---

# 6. `FeatureInputColumns`

This reduces the larger shared dataset configuration into only the physical columns Part C needs:

```text
site_identity_columns
timestamp_column
value_column
```

It is created using:

```text
resolve_feature_input_columns()
```

from `DatasetInputConfig`.

This means Part C never hardcodes telecom column names.

---

# 7. Site Grouping

`iter_site_groups()` groups the KPI dataframe using the configured site identity columns.

For every site it returns:

```text
SiteGroup
├── key
├── composite_id
└── dataframe
```

Each site's dataframe is stably sorted chronologically using:

```text
mergesort
```

while preserving its row index.

The helper itself does **not skip invalid sites**; that decision belongs to validation/runner logic.

---

# 8. Site Identity in Part C

Part C builds a readable composite identifier from the configured site grouping key.

The helper uses:

```text
" | "
```

as the separator.

Its default missing token is:

```text
<MISSING_ID>
```

This identifier is mainly used for runtime grouping/reporting rather than being inserted as a permanent feature column.

---

# 9. `FeatureSourceBundle`

For value-based features, the site can expose:

```text
raw_value
corrected_history
```

`raw_value` always exists.

`corrected_history` exists only when the resolved feature configuration requires it.

The bundle guarantees that both sources, when present, have:

- identical row count;
    
- identical index alignment.
    

Feature modules explicitly request one of these sources rather than silently switching between them.

---

# 10. Safe Feature Attachment

`common.py` also validates generated feature outputs before they are appended.

It requires:

- Series/DataFrame output;
    
- non-empty feature columns;
    
- valid nonblank column names;
    
- no duplicate generated names;
    
- exact row-count preservation;
    
- exact index preservation;
    
- no overwrite of an existing column.
    

Therefore Part C does not silently replace a Part B column or an earlier feature.

---

# 11. `feature_validation.py`

## Responsibility

This file validates:

1. the Part B dataset before feature generation;
    
2. site-level feature readiness;
    
3. the final feature-engineered dataframe.
    

It does not calculate features or repair data.

---

# 12. Part C Representation Normalization

Part C may normalize dataframe representation after CSV loading:

### Timestamp

Converted using:

```text
pd.to_datetime(...)
```

### KPI value

Converted to numeric `float64`.

### Status

Converted to an integer-compatible nullable representation.

This is **dtype normalization only**.

It does not:

- insert timestamps;
    
- remove duplicates;
    
- fill values;
    
- alter labels;
    
- correct site identities;
    
- repair irregular timelines.
    

---

# 13. Required Part B State

At minimum, Part C requires:

```text
configured site identity columns
configured timestamp
configured KPI value
kpi_usability
```

If the selected feature contract needs Part B statuses, it additionally requires:

```text
Current_Status_Label
```

The requirement is dynamic because timestamp-only features may not need statuses at all.

---

# 14. Supported Part B Status Labels

When the current-status column is present, Part C accepts:

```text
-2
-1
 0
 1
 2
 3
 4
```

consistent with the Part B contract.

It validates that:

```text
statuses 1,2,3,4 → KPI value must be present
statuses -2,-1,0 → KPI value must be missing
```

So Part C checks that Part B's value/status contract has not become inconsistent.

---

# 15. Site Usability Handling

Allowed values are:

```text
valid
invalid
```

and each site must contain one consistent usability value.

### Valid site

Part C may generate features.

### Invalid site

Part C:

- keeps all rows in the output;
    
- skips all feature calculations;
    
- leaves all requested feature columns as `NaN`.
    

---

# 16. Timeline Validation Applies to Valid Sites

For every **valid** site Part C verifies:

- timestamps are unique;
    
- timestamps are in chronological order after grouping;
    
- every consecutive timestamp difference equals the resolved dataset bucket.
    

For example, with a 15-minute bucket:

```text
t[n] - t[n-1] = 15 minutes
```

must hold throughout the valid site series.

Part C rejects irregular valid-site timelines rather than repairing them.

---

# 17. Invalid Sites Are Not Repaired or Fully Timeline-Validated

A site marked:

```text
kpi_usability = invalid
```

is returned as non-processable before the valid-site timeline checks run.

This is deliberate: invalid sites are already excluded from feature generation, but their rows remain part of the output dataset.

---

# 18. Insufficient History Is Not an Error

The resolved Part C schema provides:

```text
minimum_history_points
```

For each valid site Part C calculates:

```text
has_sufficient_history
```

but a site below that threshold is **still processed**.

Therefore:

```text
valid + insufficient history
        ↓
feature generators still run
        ↓
unavailable early features naturally remain NaN
```

This distinguishes:

```text
invalid data
```

from:

```text
valid data that has not accumulated enough history yet
```

---

# 19. Validation Results

Per-site validation returns:

```text
SiteFeatureValidationResult
```

containing:

- composite ID;
    
- row count;
    
- usability;
    
- minimum history requirement;
    
- history sufficiency;
    
- whether features can be generated;
    
- skip reason;
    
- minimum timestamp;
    
- maximum timestamp.
    

Dataset-level validation returns:

```text
FeatureDatasetValidationResult
```

with totals for:

- rows;
    
- sites;
    
- valid sites;
    
- invalid sites;
    
- processable sites;
    
- history-sufficient sites;
    
- insufficient-history sites.
    

---

# 20. Final Output Validation

After all features are generated, `validate_generated_feature_dataframe()` verifies:

- total row count is unchanged;
    
- no duplicate columns exist;
    
- every requested feature column exists;
    
- generated features are numeric or `NaN`;
    
- no `+inf` or `-inf` exists;
    
- invalid-site feature cells remain `NaN`.
    

If:

```text
retain_original_columns = True
```

it additionally verifies that all original Part B columns remain exactly unchanged in value, ignoring only dtype normalization differences.

---

# 21. `source_preparation.py`

## Responsibility

This module prepares the temporary value sources used by feature generators.

Supported modes are:

```text
1. raw_value
2. raw_value + referenced-point local median cleaning
3. corrected_history
```

It does not append any feature columns and never modifies the original Part B KPI column.

---

# 22. `raw_value`

The raw source is simply the Part B KPI value normalized to `float64`.

It can contain:

```text
finite numeric values
NaN
```

but infinity is rejected.

No filling, clipping, or outlier replacement occurs when creating `raw_value`.

---

# 23. Temporary `corrected_history`

Corrected history exists only when at least one requested feature selects:

```text
source = corrected_history
```

The runner prepares it **once per valid site**, then shares it across all features that require it.

---

# 24. Corrected-History Algorithm

`prepare_corrected_history()` performs:

```text
raw values
    │
    ▼
mask configured bad statuses
    │
    ├── default bad status = 2
    │
    ▼
optionally mask existing NaNs
    │
    ▼
clean raw source
    │
    ▼
shift(1)
    │
    ▼
past-only trailing median
    │
    ▼
replace unavailable targets
    │
    ▼
optional forward fill of remaining targets
    │
    ▼
corrected_history
```

The key leakage-safety rule is:

```text
clean_raw_source.shift(1)
```

before the rolling median.

Therefore the current row never contributes to its own trailing-median replacement.

---

# 25. Corrected History Does Not Modify Part B

The corrected history is a temporary Part C `Series`.

The original:

```text
Part B KPI value column
Current_Status_Label
```

remain unchanged.

This allows different features to choose either:

```text
raw_value
```

or:

```text
corrected_history
```

within the same run.

---

# 26. Important Default Status Behaviour

With the current schema defaults, corrected history masks:

```text
status 2
```

and missing values.

It does **not automatically mask status 4**.

Therefore a finite Part B value carrying:

```text
Current_Status_Label = 4
```

remains available in corrected history unless configuration explicitly includes `4` among the bad statuses.

This is the actual current implementation contract.

---

# 27. Corrected-History Audit

`CorrectedHistoryResult` records masks for:

```text
unavailable_mask
trailing_median_replaced_mask
forward_filled_mask
unresolved_mask
```

and exposes counts for each.

These counts later appear in the per-site Part C summary and, when enabled, the corrected-history audit CSV.

---

# 28. Local Median Referenced-Point Cleaning

Local median cleaning is different from corrected history.

It operates on a **specific historical reference**, such as:

```text
t - lag
```

rather than building a replacement series for the entire timeline.

When enabled:

1. obtain the referenced raw value;
    
2. inspect its referenced status;
    
3. if the reference is unacceptable or missing, obtain a local-median candidate;
    
4. replace it when that candidate exists;
    
5. otherwise follow the configured fallback:
    
    - `nan`; or
        
    - `keep_source`.
        

---

# 29. Local Median Candidate Values

Candidates are calculated only from raw values whose statuses belong to:

```text
accepted_statuses
```

Under the current defaults this includes:

```text
{1, 3, 4}
```

while status `2` is a default bad status.

So, unlike the seasonal baseline defaults, local-median source cleaning can currently use status-4 values by default.

---

# 30. Adaptive Leakage-Safe Local Windows

Lag-based feature modules do not blindly use a centered median.

For:

```text
lag = L
half-window = h
```

they calculate:

```text
safe_right_points = min(h, L - 1)
```

Thus the referenced-point candidate window is:

```text
[reference - h, ..., reference + safe_right_points]
```

and can never reach the current row `t` or any future row.

Small lags therefore use an asymmetric median window; larger lags can use the full centered window when safe.

---

# 31. `PreparedFeatureSources`

For each valid site, `prepare_feature_sources()` returns:

```text
PreparedFeatureSources
├── bundle
│   ├── raw_value
│   └── corrected_history | None
├── statuses | None
└── corrected_history_result | None
```

Statuses are loaded only when the resolved configuration actually requires them.

---

# 32. `value_features.py`

## `current_value`

This is the simplest value feature.

Formula:

```text
current_value(t) = raw Part B KPI value(t)
```

It always uses:

```text
raw_value
```

and does not use:

- corrected history;
    
- local median cleaning;
    
- shifting;
    
- clipping;
    
- filling.
    

Outliers and missing values remain exactly as Part B supplied them.

---

# 33. `lag_features.py`

## Responsibility

Generates exact point-based lags:

```text
lag_n(t) = selected_source(t - n)
```

Examples:

```text
lag_1
lag_96
lag_672
```

for requests containing those lags.

---

# 34. Lag Sources

Lag requests may use:

```text
raw_value
corrected_history
```

If local median cleaning is enabled:

```text
source must be raw_value
```

The cleaning applies only to the **referenced historical point**, not the current row.

---

# 35. Lag Warm-Up

For lag `L`, the first:

```text
L rows
```

cannot have an exact earlier reference.

Therefore they remain:

```text
NaN
```

The generator explicitly validates that the lag warm-up region has not accidentally been populated.

---

# 36. `comparison_features.py`

This module supports:

```text
difference
percentage_change
seasonal_difference
```

All are based on an exact historical lag reference.

---

# 37. Difference

Formula:

```text
difference_L(t)
=
source(t) - source(t-L)
```

The selected current source remains unmodified.

If local cleaning is active, it is applied only to:

```text
source(t-L)
```

not to `source(t)`.

---

# 38. Seasonal Difference

Mathematically:

```text
seasonal_difference_L(t)
=
source(t) - source(t-L)
```

It intentionally uses the same formula as ordinary difference.

The separate feature type exists so that schema configuration, UI, and later model reporting can distinguish an intentionally seasonal lag from a general movement feature.

---

# 39. Percentage Change

Formula:

```text
percentage_change_L(t)
=
(source(t) - source(t-L))
/
source(t-L)
```

This is a decimal ratio, not a percentage multiplied by 100.

If the historical denominator equals zero:

```text
result = NaN
```

Any unexpected infinity is also converted to `NaN`.

---

# 40. Comparison Warm-Up

As with lag features, the first `L` rows for a lag `L` remain `NaN`.

The module validates this explicitly for every generated comparison column.

---

# 41. `rolling_features.py`

Supports four related request families:

```text
rolling
rolling_zscore
ewma
rolling_slope
```

The central safety rule is:

```text
historical_source = selected_source.shift(1)
```

So the current row does not enter its own historical rolling feature.

---

# 42. Standard Rolling Statistics

Supported statistics are:

```text
mean
median
mad
std
min
max
range
iqr
```

For each requested window `W`, the generator calculates the statistic on the **previous values only**.

Example:

```text
rolling_median_4(t)
```

uses earlier observations, not the current value at `t`.

---

# 43. Rolling MAD

MAD is calculated as:

```text
median(
    abs(values - median(values))
)
```

using the finite observations available in the rolling window.

---

# 44. Rolling Standard Deviation

The request controls:

```text
std_ddof = 0 or 1
```

allowing population or sample standard deviation.

---

# 45. Rolling Range and IQR

Range:

```text
rolling_max - rolling_min
```

IQR:

```text
Q3 - Q1
```

over the historical window.

---

# 46. Rolling Z-Score

Formula:

```text
rolling_zscore_W(t)
=
(
    source(t)
    - mean(previous W observations)
)
/
std(previous W observations)
```

The current value is used only as the numerator's current observation.

Mean and standard deviation remain past-only.

If historical standard deviation is zero:

```text
result = NaN
```

---

# 47. EWMA

EWMA uses:

```text
selected_source.shift(1)
```

followed by:

```text
ewm(
    span = configured span,
    adjust = False,
    min_periods = 1
)
```

The first row is therefore `NaN`.

Unlike a fixed rolling window, `span` controls exponential decay rather than limiting the history to exactly `span` observations.

---

# 48. Rolling Slope

For each historical window, the module fits an ordinary least-squares line and returns the slope in:

```text
KPI units per timeline point
```

Missing values can be ignored, but their original timeline positions are retained instead of compressing the x-axis.

At least two finite observations are required for a slope.

---

# 49. `time_features.py`

Time features depend only on the timestamp column.

They do not use:

- KPI values;
    
- statuses;
    
- corrected history;
    
- source cleaning.
    

Two families are supported:

```text
time_bucket
time_cyclic
```

---

# 50. Time Bucket

Formula:

```text
time_bucket_Nm
=
floor(minutes_since_midnight / N)
```

Numbering begins at zero from midnight.

For 30-minute buckets:

```text
00:00 → 0
00:30 → 1
01:00 → 2
...
23:30 → 47
```

Every requested feature bucket must divide 1,440 minutes exactly.

---

# 51. Time Cyclic Features

Part C calculates:

```text
angle =
2π × minutes_since_midnight / 1440
```

then:

```text
sin_tod = sin(angle)
cos_tod = cos(angle)
```

The cyclical encoding therefore wraps naturally across midnight.

---

# 52. `calendar_features.py`

Calendar features also depend only on timestamps.

Supported features:

```text
is_weekend
day_of_week
day_sin
day_cos
```

---

# 53. Weekend and Day-of-Week

Pandas weekday convention is used:

```text
Monday    = 0
Tuesday   = 1
...
Sunday    = 6
```

`is_weekend` becomes:

```text
0 → Monday-Friday
1 → Saturday-Sunday
```

---

# 54. Cyclical Day Encoding

The weekday angle is:

```text
2π × day_of_week / 7
```

then:

```text
day_sin = sin(angle)
day_cos = cos(angle)
```

This represents weekday position cyclically rather than treating Sunday and Monday as numerically far apart.

---

# 55. `baseline_features.py`

## Responsibility

Generates the supported:

```text
weighted_seasonal
```

baseline.

The baseline is designed to use historical seasonal patterns while remaining past-only for the current feature row.

---

# 56. Baseline Warm-Up

No baseline is generated during the configured minimum history period:

```text
minimum_history_days × points_per_day
```

Those rows remain `NaN`.

With the current default baseline:

```text
minimum_history_days = 7
```

---

# 57. Baseline Fallback Ladder

For a target timestamp `t`, the baseline attempts:

### 1. Recent same-type anchor

Search earlier days at the same time of day, requiring the same broad day type:

```text
weekday ↔ weekday
weekend ↔ weekend
```

within the configured recent fallback horizon.

### 2. Weekly anchor

Search exact:

```text
t - 7 days
t - 14 days
t - 21 days
...
```

up to the configured number of weeks.

### 3. Weighted combination

If both exist:

```text
baseline
=
recent_weight × recent
+
weekly_weight × weekly
```

### 4. Single available anchor

If only recent or only weekly exists, use that value directly.

### 5. Slot fallback

If neither exists, use a median of recent accepted historical values from the same or tolerated time-of-day slot.

### 6. No available reference

Return:

```text
NaN
```

---

# 58. Default Baseline Anchor Statuses

Baseline anchors are filtered using:

```text
anchor_statuses
```

with current defaults:

```text
{1, 3}
```

Therefore the default seasonal baseline excludes:

```text
2 → outlier
4 → leakage-risk Part B fill
```

This is stricter than the default corrected-history/local-median source rules.

---

# 59. Robust Baseline Local Anchors

If:

```text
anchor_window_each_side_points > 0
```

a historical anchor can be represented by a median of accepted observations around the anchor.

However the right side is dynamically restricted so it can never include:

```text
current row
future row
```

for the feature being generated.

---

# 60. Slot Fallback Avoids Same-Day Leakage

The baseline keeps slot history from **earlier calendar days**.

Positions from the current day are staged and only become eligible after a date transition.

Therefore an earlier observation from the same calendar day does not accidentally become a slot-fallback reference when the algorithm intends prior-day seasonal history.

---

# 61. Baseline Output

Standalone baseline generation returns exactly:

```text
baseline
```

as a `float64` feature column.

The generator preserves:

- row count;
    
- index;
    
- source data.
    

Infinity is rejected.

---

# 62. `residual_features.py`

A residual is defined as:

```text
residual(t)
=
selected_current_source(t)
-
baseline(t)
```

---

# 63. Independent Residual Sources

Residual configuration has two independent source choices:

```text
request.source
```

for the current value and:

```text
request.baseline.source
```

for historical baseline anchors.

Therefore a configuration can, for example, use:

```text
current source  = raw_value
baseline source = corrected_history
```

if allowed by the schema configuration.

---

# 64. Residual Reuses Baseline Logic

`residual_features.py` does **not** implement a second seasonal algorithm.

It directly calls:

```text
generate_weighted_seasonal_baseline()
```

from `baseline_features.py`.

This keeps baseline behaviour identical between:

```text
standalone baseline
```

and:

```text
residual
```

---

# 65. Residual Output

The current schema requires residual generation to return:

```text
baseline
residual
```

in that order.

If either current value or baseline is unavailable, the residual naturally becomes `NaN`.

Unexpected arithmetic infinity is converted to `NaN`.

---

# 66. `runner.py`

## Responsibility

The runner is the orchestration layer.

It does not contain feature formulas.

Its job is to:

- validate the Part B handoff;
    
- resolve Part C configuration;
    
- load and validate data;
    
- iterate sites;
    
- prepare shared sources;
    
- dispatch requests;
    
- assemble outputs;
    
- write final artifacts;
    
- return structured results.
    

---

# 67. Exact Part B Handoff

`validate_preprocessing_handoff()` requires a genuine:

```text
PreprocessingRunnerResult
```

and then resolves:

```text
preprocessing_result.final_dataset_file
```

That exact file must exist.

No directory scanning or filename reconstruction is performed.

---

# 68. Bucket Consistency Check

Part C resolves its feature configuration using the supplied `BucketConfig`.

It then compares:

```text
Part B resolved_frequency.bucket_minutes
```

against:

```text
Part C resolved_config.bucket_minutes
```

If they differ, the runner fails with a bucket mismatch instead of generating features against a different timeline interpretation.

---

# 69. Part B Row-Count Handoff Check

After reading the Part B final CSV, the runner compares its actual row count with:

```text
preprocessing_result.final_rows
```

when available.

If the file and result object disagree, Part C rejects the handoff.

---

# 70. Internal Unique Row Index

After validation, Part C saves the original dataframe index, then temporarily replaces it with a unique:

```text
RangeIndex
```

named conceptually:

```text
_feature_row_id
```

This gives the runner a safe unique row identity while combining features from multiple independently grouped sites.

Before the final output is returned, the original external index is restored.

---

# 71. Feature Matrix Initialization

The runner creates a complete feature matrix with:

```text
rows = all Part B rows
columns = resolved requested feature columns
initial value = NaN
```

Therefore invalid sites naturally remain all-`NaN` unless explicitly populated—which the runner prevents.

---

# 72. Per-Site Processing

For every site:

```text
site validation
      │
      ├── can_generate_features = False
      │        ↓
      │     skip site
      │     preserve rows
      │
      └── can_generate_features = True
               │
               ▼
        prepare_feature_sources()
               │
               ▼
        generate requested features
               │
               ▼
        insert into master matrix
```

---

# 73. Feature Request Dispatch

The runner maps request classes to modules:

```text
CurrentValueFeatureRequest
→ value_features.py

LagFeatureRequest
→ lag_features.py

Difference / PercentageChange / SeasonalDifference
→ comparison_features.py

Rolling / RollingZScore / EWMA / RollingSlope
→ rolling_features.py

TimeBucket / TimeCyclic
→ time_features.py

Calendar
→ calendar_features.py

Baseline
→ baseline_features.py

Residual
→ residual_features.py
```

---

# 74. Schema Owns Output Names

Individual generators produce canonical names.

The runner checks each result against:

```text
get_feature_columns(request)
```

from the schema.

Only after this check does it rename repeated requests into the resolved schema-owned names such as:

```text
lag_1
lag_1_s2
```

This prevents calculation modules from independently inventing output naming rules.

---

# 75. Request Order Is Preserved

The runner iterates:

```text
resolved_config.features
```

and:

```text
resolved_config.feature_column_groups
```

in parallel.

Therefore final feature columns follow the deterministic order already established by the schema.

The runner verifies that the completed site feature sequence exactly matches:

```text
resolved_config.feature_columns
```

---

# 76. Failure Handling Per Site

If one feature generator fails for a valid site, the runner raises a structured:

```text
InputValidationError
```

including:

- site;
    
- feature type;
    
- underlying reason.
    

It does not silently skip an individual broken feature and continue with a partially different feature contract.

---

# 77. Final Dataset Composition

When:

```text
retain_original_columns = True
```

the intended final structure is:

```text
all original Part B columns
+
all Part C feature columns
```

When disabled, Part C can produce a feature-only dataset while preserving source row/index alignment required by final validation.

---

# 78. Output Files

For each KPI Part C directory, the runner creates:

```text
<KPI Part C directory>/
│
├── <KPI>_feature_engineered.csv
│
├── summaries/
│   └── 01_feature_engineering_site_summary.csv
│
└── intermediate/                       # optional
    └── 01_corrected_history_audit.csv  # when applicable
```

The intermediate directory is created only when:

```text
save_intermediate_outputs = True
```

---

# 79. Corrected-History Audit File

When intermediate outputs are enabled and corrected history is used, the audit contains site/timestamp information together with:

```text
raw_value
corrected_history
corrected_history_unavailable
corrected_history_trailing_median_replaced
corrected_history_forward_filled
corrected_history_unresolved
```

This makes the temporary Part C correction process inspectable without modifying the Part B dataset.

---

# 80. Site Summary

Each site's `FeatureEngineeringSiteRunSummary` contains:

```text
composite_id
row_count
usability

minimum_history_points
has_sufficient_history

can_generate_features
skip_reason

generated_feature_columns
populated_feature_cells
missing_feature_cells

corrected_history_unavailable_points
corrected_history_trailing_median_replacements
corrected_history_forward_fills
corrected_history_unresolved_points

minimum_timestamp
maximum_timestamp
```

---

# 81. Feature Cell Statistics

For each processed site the runner calculates:

```text
populated_feature_cells
missing_feature_cells
```

Missing cells can legitimately include:

- lag warm-up;
    
- rolling warm-up;
    
- baseline warm-up;
    
- unavailable historical references;
    
- unresolved corrected history.
    

For invalid sites:

```text
populated_feature_cells = 0
```

and:

```text
missing_feature_cells
=
site rows × requested feature columns
```

---

# 82. `FeatureEngineeringRunnerResult`

The final structured result contains:

### Paths

```text
source_file
output_directory
summary_directory
intermediate_directory
final_dataset_file
site_summary_file
corrected_history_audit_file
```

### Configuration

```text
resolved_config
feature_columns
validation_result
```

### Totals

```text
total_rows
total_sites
processed_sites
skipped_invalid_sites
insufficient_history_sites
populated_feature_cells
missing_feature_cells
```

### Site-level results

```text
site_summaries
```

---

# 83. Core Leakage-Safety Principles

Part C contains several independent leakage protections.

## Rolling features

```text
source.shift(1)
```

before rolling calculations.

## Corrected history

```text
clean source.shift(1)
```

before trailing-median replacement.

## Lag local median

Right-side candidate window is truncated so it remains before `t`.

## Baseline recent/weekly anchors

Only earlier timestamps are searched.

## Baseline local anchor median

Right side is capped before the current target.

## Slot fallback

Uses earlier calendar days only.

These safeguards are implemented inside the relevant feature/source modules rather than relying on the runner to enforce one generic rule.

---

# 84. Responsibility Boundaries

## `common.py`

Shared runtime utilities and safe feature attachment.

## `feature_validation.py`

Validate Part B input and final Part C output.

## `source_preparation.py`

Prepare temporary feature sources.

## `value_features.py`

Direct current value.

## `lag_features.py`

Exact historical lag features.

## `comparison_features.py`

Lag-based differences and percentage changes.

## `rolling_features.py`

Past-only rolling statistics/trends.

## `time_features.py`

Time-of-day features.

## `calendar_features.py`

Day/calendar features.

## `baseline_features.py`

Seasonal expected-value baseline.

## `residual_features.py`

Current value minus seasonal baseline.

## `runner.py`

Join all of the above into one validated per-KPI Part C execution.

---

# 85. Part B → Part C Responsibility Boundary

The distinction between Parts B and C is strict.

### Part B owns

```text
timeline correction
missing-value filling
outlier labels
site usability
Current_Status_Label
final preprocessed KPI values
```

### Part C owns

```text
temporary feature-specific value sources
historical lags
rolling features
comparison features
time/calendar features
seasonal baseline
residual
final feature matrix
```

Part C may create `corrected_history`, but this is **not a new Part B cleaning pass**.

It exists only as a temporary feature source and never overwrites Part B's KPI values.

---

# 86. Part C Does Not Drop Invalid Sites

This is important for later pipeline alignment.

Part C's output still contains rows belonging to:

```text
kpi_usability = invalid
```

but all requested Part C features for those rows stay:

```text
NaN
```

Therefore row/site preservation is separate from feature eligibility.

---

# 87. Part C Does Not Drop Warm-Up Rows

Likewise, early rows without sufficient lag/rolling/seasonal history remain in the dataset.

Examples:

```text
lag_96
→ first 96 rows NaN

rolling_median_4
→ initial history-dependent rows may be NaN

7-day seasonal baseline
→ baseline warm-up region NaN
```

Later training modules must therefore decide how to construct their model-ready history/training rows from the generated feature matrix.

Part C itself preserves those rows.

---

# 88. Complete Part C Flow by File

```text
runner.py
│
├── validate Part B handoff
│
├── resolve Part C schema
│
│
├── feature_validation.py
│   ├── normalize CSV representation
│   ├── validate Part B statuses/usability
│   ├── validate valid-site timelines
│   └── report history sufficiency
│
├── common.py
│   └── group each site chronologically
│
├── source_preparation.py
│   ├── raw_value
│   ├── corrected_history if needed
│   └── status/reference-cleaning support
│
├── for every feature request:
│   │
│   ├── value_features.py
│   ├── lag_features.py
│   ├── comparison_features.py
│   ├── rolling_features.py
│   ├── time_features.py
│   ├── calendar_features.py
│   ├── baseline_features.py
│   └── residual_features.py
│
├── common.py
│   └── validate + attach feature outputs
│
├── feature_validation.py
│   └── final cross-dataset validation
│
└── save:
    ├── feature-engineered dataset
    ├── site summary
    └── optional corrected-history audit
```

---

# 89. Final Architectural Summary

Part C can be summarized as:

```text
feature_validation.py
→ Ensure the Part B dataset is suitable for feature generation without
  repairing it.

common.py
→ Resolve dataset columns, group sites, manage aligned source/output data,
  and safely attach feature columns.

source_preparation.py
→ Build raw_value and optional past-only corrected_history and provide
  referenced-point cleaning support.

value_features.py
→ Copy the current Part B KPI value.

lag_features.py
→ Generate exact point-based historical lags with optional leakage-safe
  referenced-point local cleaning.

comparison_features.py
→ Generate difference, percentage-change, and seasonal-difference features.

rolling_features.py
→ Generate past-only rolling statistics, z-scores, EWMA, and trend slopes.

time_features.py
→ Generate configurable time-of-day bucket and cyclical features.

calendar_features.py
→ Generate weekend, weekday, and weekday-cycle features.

baseline_features.py
→ Generate a past-only weighted seasonal expected-value baseline.

residual_features.py
→ Generate the seasonal baseline and current-minus-baseline residual.

runner.py
→ Orchestrate the complete Part C chain for one Part B KPI result,
  preserve invalid/warm-up rows, validate the final feature contract,
  and return FeatureEngineeringRunnerResult.
```

The module's central architectural transformation is therefore:

```text
Part B provenance-aware KPI timeline
                │
                ▼
Validate but do not repair
                │
                ▼
Prepare feature-specific historical sources
                │
                ▼
Generate leakage-aware model features independently per site
                │
                ▼
Preserve original rows + provenance
                │
                ▼
Feature-engineered KPI dataset
```

The final product is not simply a reduced training matrix. It is a **row-preserving, provenance-preserving feature dataset** in which invalid sites and insufficient-history/warm-up rows remain visible, while the generated features obey the schema-defined source, naming, history, and leakage-safety contracts.