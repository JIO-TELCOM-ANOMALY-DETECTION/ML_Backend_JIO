# [[Part E Inference Schema — app.schemas.inference]]
# [[Part A Shared Dataset Schema — schema common.dataset.py]]
# [[Part B Preprocessing Schema — app.schemas.preprocessing]]
# [[Part C — Feature Engineering ML Module]]
# Part E — Pure Inference ML Module Final Technical Report

**Module Location:** `app/ml/inference/`

## Files

|File|Responsibility|
|---|---|
|`__init__.py`|Public Part E inference interface|
|`loader.py`|Load saved inference contract, resolve model artifacts, deserialize exactly one model on demand|
|`validation.py`|Validate inference-time Part C outputs against saved Part D model contracts|
|`runner.py`|Top-level pure-inference orchestration, staging, history commit and result publication|

### History subsystem — `app/ml/inference/history/`

|File|Responsibility|
|---|---|
|`__init__.py`|Public history interface|
|`loader.py`|Load incoming data, raw cache, processed caches, and reconstruction-only older raw slice|
|`validation.py`|Decide inference window, gap validity, cache readiness, overlap/late-data classification and normal vs reconstruction mode|
|`preparation.py`|Build temporary raw A/B input and correct per-KPI Part C handoffs|
|`runner.py`|Orchestrate history processing through existing Parts A → B → C without committing history|
|`updater.py`|Persist full histories and rebuild rolling caches only after successful model inference|

### Model-specific inference

|File|Responsibility|
|---|---|
|`xgboost/__init__.py`|XGBoost inference public interface|
|`xgboost/inference.py`|Pure one-site XGBoost prediction + saved residual-threshold application|
|`isolation_forest/__init__.py`|Isolation Forest inference public interface|
|`isolation_forest/inference.py`|Pure one-site IF scoring + saved directional rule application|

---

# 1. Purpose of Part E

Part E executes **already-trained Part D models on new raw telecom data** while reproducing the exact Part A/B/C processing contract used during training.

The complete responsibility is:

```text
new raw inference data
+
saved training-run contract
+
saved history/cache
+
saved Part D models
        │
        ▼
rebuild correct A → B → C context
        │
        ▼
validate current features against saved models
        │
        ▼
score one saved site model at a time
        │
        ▼
persist inference results
        │
        ▼
commit new history/cache state
```

Part E does **not retrain or retune models**.

---

# 2. Main Runtime Input

The parent ML runner receives:

```text
InferenceRequest
+
run_directory
```

where the request contains:

```text
run_id
input_file
inference_days
```

The service layer is responsible for:

```text
run_id → run_directory
```

before the ML runner starts.

Part E itself does not query the run database.

---

# 3. Core Saved Dependencies

The Part E runtime uses the saved inference contract to recover:

- saved dataset mapping and bucket;
    
- saved effective Part B config and resolved frequency;
    
- saved effective Part C config and resolved feature contract;
    
- history/cache policy;
    
- persistent storage paths;
    
- trained KPI set;
    
- site → model mapping;
    
- exact model feature order;
    
- XGBoost target and calibrated thresholds;
    
- Isolation Forest decision settings.
    

Part E therefore executes the trained run's frozen contract rather than current defaults.

---

# 4. Overall Architecture

```text
InferenceRequest + run_directory
              │
              ▼
──────────────────────────────
loader.py
──────────────────────────────
Load inference_config.json
Resolve storage/model paths
Build lightweight model plan
              │
              ▼
──────────────────────────────
history/
──────────────────────────────
incoming raw + saved caches
        │
        ▼
history validation
        │
   ┌────┴─────┐
   │          │
 normal   reconstruction
   │          │
   └────┬─────┘
        ▼
existing Part A
        ▼
inference-specific Part B
        ▼
prepare Part C handoff
        ▼
existing Part C
              │
              ▼
──────────────────────────────
validation.py
──────────────────────────────
Current Part C
       ↕
Saved model contracts
              │
              ▼
 ready saved series only
              │
              ▼
      ONE SITE AT A TIME
         /           \
        ▼             ▼
    XGBoost        Isolation
    inference       Forest
        \             /
         └─────┬─────┘
               ▼
       stage row outputs
               ▼
       write manifest
               ▼
       commit history
               ▼
       publish result dir
```

---

# 5. Critical Memory Design

Part E deliberately avoids:

```text
load all site data
+
load all models
+
score everything in memory
```

Instead it follows:

```text
lightweight metadata for all sites
+
ONE site's dataframe
+
ONE estimator
```

The loader builds model paths/contracts for every site but **does not deserialize the estimators**.

Immediately before scoring a site:

1. its Part C rows are loaded;
    
2. its model is loaded;
    
3. inference runs;
    
4. its output CSV is staged;
    
5. dataframe/model/result are released;
    
6. next site begins.
    

---

# 6. `__init__.py`

The public parent interface exports:

```text
InferenceRunnerResult
InferenceSeriesOutput
SkippedInferenceSeries
run_inference_pipeline
```

Internal loader/history/model-specific functions therefore do not need to be coordinated by an external caller.

---

# 7. `loader.py`

`loader.py` is the **saved-artifact loading boundary**.

Its responsibilities are:

```text
request + run_directory
        │
        ▼
load/validate saved inference contract
        │
        ▼
resolve saved model paths
        │
        ▼
construct lightweight model plan
```

It does not:

- execute A/B/C;
    
- validate history semantics;
    
- perform model predictions;
    
- apply anomaly decisions;
    
- save inference outputs;
    
- commit history.
    

---

# 8. `InferenceSeriesArtifact`

One saved site model is represented by:

```text
model_type
kpi_name
series_key
identity

model_file

model_feature_columns
target_column

decision_settings
```

No estimator is present.

---

# 9. `InferenceKPIArtifactPlan`

Stores one KPI's:

```text
model_type
kpi_name
model_feature_columns
target_column
series[]
```

and provides lookup by:

```text
series_key
```

or stable:

```text
(circle, cluster, site)
```

identity.

---

# 10. `InferenceModelLoadPlan`

Contains the complete saved-run model mapping:

```text
run_directory
model_type
kpis[]
```

and exposes:

```text
total_series
get_kpi()
iter_series()
```

Again, this plan contains **zero loaded estimators**.

---

# 11. Model KPI Set Validation

When building the load plan, Part E requires the model-specific saved mapping to contain exactly:

```text
SavedDatasetContract.kpi_names
```

for both XGBoost and Isolation Forest.

An extra or missing KPI invalidates the artifact plan.

---

# 12. Model File Resolution

Each saved model path is resolved underneath the run root with run-directory escape protection.

Expected suffix:

```text
XGBoost
→ .json

Isolation Forest
→ .joblib
```

A suffix inconsistent with the model type is rejected.

---

# 13. On-Demand Model Loading

Only:

```text
load_series_model(...)
```

deserializes an estimator.

Immediately before loading, the model file is rechecked because it could theoretically have disappeared between earlier validation and execution.

### XGBoost

Creates:

```text
XGBRegressor()
```

then loads the native saved JSON model.

### Isolation Forest

Loads the saved `.joblib` estimator.

The loader also validates the expected inference methods on the resulting estimator.

---

# 14. History Subsystem Purpose

The history subsystem solves the central inference problem:

> A model may only score new rows correctly if Parts B and C receive enough older context to recreate the exact features expected by training.

Part E therefore does not send the isolated new X-day CSV directly into the model.

It constructs a history-aware working pipeline.

---

# 15. `history/__init__.py`

The public history interface exposes primarily:

```text
HistoryRunContext
HistoryRunnerResult

run_history_pipeline
commit_history_pipeline
```

plus history validation/commit result types.

---

# 16. `HistoryRunContext`

The parent runner constructs:

```text
incoming_file
inference_days

dataset
preprocessing
feature_engineering
history
storage

working_directory
enforce_cached_usability = True
```

The context therefore contains only resolved saved contracts and current runtime paths.

---

# 17. Cached Usability Is Authoritative

The parent explicitly creates the history context with:

```text
enforce_cached_usability = True
```

Part B is then executed through:

```text
run_preprocessing_pipeline_for_inference(...)
```

using the saved processed cache.

The reason is important:

```text
short inference working window
        │
        ✗
must not recalculate a site's long-term
training usability from only that short window
```

The saved/cached usability decision remains authoritative while Part B still recalculates the runtime missing-state information needed for the new data.

---

# 18. History Context Validation

Before processing, the history runner checks:

- `inference_days >= 1`;
    
- cached-usability enforcement is enabled;
    
- processed history paths exactly match trained KPIs;
    
- processed cache paths exactly match trained KPIs;
    
- Part B and Part C saved bucket resolutions match;
    
- Part B and Part C points-per-day values match.
    

---

# 19. `history/loader.py`

Normal inference loads only:

```text
new incoming raw file
raw Z-day cache
processed Z-day cache for each trained KPI
```

It deliberately does **not normally load**:

```text
full raw history
full processed history
```

This keeps ordinary inference bounded to maintained caches.

---

# 20. `HistoryLoadResult`

Contains:

```text
incoming_file
incoming_dataframe

raw_cache_file
raw_cache_dataframe

processed_caches[]
```

Each processed cache stores:

```text
kpi_name
source_file
dataframe
```

---

# 21. Reconstruction-Only Full-History Access

If late data triggers reconstruction, the loader may call:

```text
load_reconstruction_raw_history_slice(...)
```

This is the only special history path that accesses full raw history before commit.

It retrieves:

```text
[current raw-cache start - cache_days,
 current raw-cache start)
```

from the full raw history.

So reconstruction obtains **one older cache-sized source slice**, rather than loading the entire historical dataset into memory.

---

# 22. Reconstruction History Sufficiency

The full raw history must extend far enough back to supply that requested older reconstruction interval.

If it does not, reconstruction fails.

This prevents rebuilding a historical range with insufficient context.

---

# 23. `history/validation.py`

This file is the **history decision layer**.

It decides:

```text
What is new?
What is overlap?
What is genuine late data?
What should be ignored?
How large is the bridge gap?
Is the rolling cache sufficient?
Normal or reconstruction?
```

It does not modify any persistent files.

---

# 24. Stable History Keys

Two identities are used.

### Series

```text
KPI
circle
cluster
site
```

### Row

```text
KPI
circle
cluster
site
timestamp
```

This lets Part E distinguish a site-series from a specific historical observation.

---

# 25. Structural History Validation

The history validator checks such conditions as:

- input/cache dataframes are nonempty;
    
- required physical columns exist;
    
- site/KPI identities are usable;
    
- timestamps parse correctly;
    
- only trained KPIs are accepted;
    
- finalized processed caches contain valid site/timestamp structure.
    

The processed history cache is treated as the definition of what has already been finalized.

---

# 26. Timestamp Comparison

Part E performs history comparison internally using UTC-aware Pandas timestamps.

When temporary data is later passed back to existing A/B/C, preparation converts timestamps back into UTC-naive values because those earlier modules, including Prophet, use the existing timezone-naive contract.

---

# 27. Duplicate Policy

Incoming raw data and raw-cache historical keys follow the existing:

```text
keep first
```

policy.

Duplicate counts are recorded in `HistoryValidationResult`.

Part E therefore does not introduce a different duplicate-selection rule.

---

# 28. Genuine Source-Value Validation

When deciding whether an incoming historical value qualifies as genuine late real data, Part E uses the saved Part B physical-value policy:

```text
lower_bound
upper_bound
boundary_tolerance
clip_values_within_tolerance
```

Nonblank nonnumeric KPI values are rejected.

Missing/invalid values do not qualify as genuine late replacements.

---

# 29. Incoming Row Classification

Every incoming row is classified relative to finalized processed history.

There are four major historical/forward cases.

---

# 30. Forward New Data

When:

```text
timestamp > finalized processed end
```

the row becomes a potential:

```text
forward_new_key
```

This is the data eligible for the requested inference period.

---

# 31. Existing Accepted Historical Real Value

If an overlapping timestamp already has an accepted genuine raw value:

```text
old genuine raw exists
+
new overlapping upload
        │
        ▼
existing_real_overlap
```

The original accepted source observation remains authoritative.

The new upload **does not overwrite it**.

---

# 32. Genuine In-Cache Late Data

If the historical timestamp lies inside the maintained processed cache and the old raw position was:

```text
missing / unavailable / invalid
```

while the incoming value is now a valid genuine source value:

```text
late_arrival_key
```

is generated.

This triggers reconstruction.

If:

```text
late_data_reconstruction_enabled = False
```

the run fails instead.

---

# 33. Historical Data Older Than the Maintained Cache

Current code behavior is:

```text
incoming historical row
timestamp < processed-cache start
        │
        ▼
ignored_historical_key
```

It does **not reject the entire forward inference call**.

This is important: data outside the maintained reconstruction window is simply ignored for this invocation while valid forward inference may continue.

---

# 34. Invalid Historical Overlap

An overlapping historical row that still fails to provide an acceptable real value is also classified as:

```text
ignored_historical_key
```

rather than used to rewrite history.

---

# 35. Forward Data Is Mandatory

Part E requires at least some data beyond finalized processed history.

If no forward timestamps exist:

```text
NO_FORWARD_INFERENCE_DATA
```

is raised.

Therefore a pure inference call cannot consist only of late historical corrections.

---

# 36. Requested Inference Window

Once forward rows are identified:

```text
new_period_start
=
earliest accepted forward timestamp

new_period_end_exclusive
=
new_period_start + inference_days
```

Only rows satisfying:

```text
timestamp < new_period_end_exclusive
```

are accepted for this invocation.

---

# 37. Extra Future Rows

If the incoming raw file contains valid rows beyond the requested X-day period:

```text
they are ignored for this call
```

They are:

- not passed into A/B/C;
    
- not scored;
    
- not committed to full raw history;
    
- not committed to processed history;
    
- not added to rolling caches.
    

This is the behavior of the **current code**.

---

# 38. Bridge Gap Validation

For every finalized KPI/site series, Part E calculates the bridge between its previous processed end and:

```text
new_period_start
```

Results include:

```text
gap_points
gap_days
gap_ratio
```

where:

```text
gap_ratio =
gap_points /
(gap_points + expected incoming points)
```

---

# 39. Gap Limits

Each site/KPI series must satisfy both:

```text
gap_days <= max_gap_days
```

and:

```text
gap_ratio <= max_gap_ratio
```

The check is performed independently per series, so a lagging site cannot be hidden by another site with a newer final timestamp.

---

# 40. Cache Readiness

The history validator checks sufficient source context before allowing inference.

It evaluates both:

### Raw cache

Must cover the raw history required to rerun A/B.

### Processed cache

Must provide sufficient finalized processed context for Part C.

This distinguishes:

```text
Part C minimum history
```

from:

```text
Part C maximum historical lookback + 1
```

rather than assuming they are always equal.

---

# 41. `HistoryValidationResult`

Stores:

```text
mode

bucket_minutes
points_per_day
inference_days

previous_history_end
new_period_start
new_period_end_exclusive

gap_points
gap_days
gap_ratio
series_gaps

incoming_duplicate_rows
raw_cache_duplicate_rows

forward_new_keys
existing_real_overlap_keys
late_arrival_keys
ignored_historical_keys

earliest_late_timestamp

series_readiness
```

Mode is:

```text
normal
```

when there is no genuine supported late data, otherwise:

```text
reconstruction
```

---

# 42. `history/preparation.py`

After history decisions have been made, `preparation.py` builds temporary data.

It does **not decide** whether reconstruction is needed.

That decision already came from validation.

---

# 43. `RawHistoryPreparationResult`

Stores:

```text
mode

working_raw_file
working_raw_dataframe

expected_timeline_start
expected_timeline_end

reconstruction_trigger_timestamp
reconstruction_replace_start

accepted_forward_raw_rows
accepted_late_raw_rows

retained_raw_history_rows
accepted_forward_rows
accepted_late_rows
ignored_incoming_rows
```

The accepted raw rows are later also needed during persistent history commit.

---

# 44. Normal Raw Working Dataset

Normal mode uses the current raw Z-cache as historical source context plus accepted forward rows.

Conceptually:

```text
required retained raw cache
+
accepted requested-window forward rows
        │
        ▼
temporary raw working file
        │
        ▼
Part A → Part B
```

Only enough historical context needed by the saved contract is retained.

---

# 45. Reconstruction Raw Working Dataset

If genuine late data exists:

```text
older reconstruction raw slice
+
current raw cache
+
accepted late replacements
+
accepted requested-window forward rows
        │
        ▼
extended temporary raw dataset
```

The older slice comes from full raw history and covers one additional `cache_days` interval before the current cache.

---

# 46. Late Row Replacement in Temporary Raw Data

During reconstruction, if a late key already has a raw-cache placeholder/invalid row, preparation removes that old occurrence and uses the accepted incoming real observation.

Already accepted genuine raw observations were filtered earlier and cannot be replaced through this mechanism.

---

# 47. Runtime A/B/C Timestamp Contract

Before the prepared raw dataframe enters Parts A/B/C:

```text
internal UTC-aware timestamp
        │
        ▼
convert to UTC
        │
        ▼
remove timezone
```

This creates the existing timezone-naive timestamp representation expected by A/B/C.

---

# 48. Runtime Part A Config

The history runner builds a fresh:

```text
DatasetInputConfig
```

using the saved:

- physical column mapping;
    
- bucket;
    
- KPI contract;
    

but points it at the temporary working raw file.

The old training dates are not reused.

Instead an exact inference runtime `date_range` is constructed from preparation's:

```text
expected_timeline_start
expected_timeline_end
```

---

# 49. Why Runtime Date Range Is Explicit

The explicit timeline allows Part A to construct all expected buckets through the requested X-day end even if raw observations are absent near the end of the input.

So:

```text
missing source row near requested end
```

does not shorten the requested inference timeline.

---

# 50. Part A Execution

The history runner calls the normal:

```text
run_eda_pipeline(...)
```

with the runtime dataset config.

Afterward it requires:

```text
runtime Part A bucket
=
saved training bucket
```

If that changes, inference fails.

---

# 51. Part B Execution

For each KPI, Part E calls:

```text
run_preprocessing_pipeline_for_inference(...)
```

using:

- actual Part A KPI result;
    
- saved Part B config;
    
- saved bucket;
    
- saved processed cache;
    
- cached-usability enforcement.
    

After execution:

```text
runtime resolved_frequency
=
saved ResolvedFrequencyConfig
```

must hold.

---

# 52. Part B Is Reused, Not Reimplemented

Part E does not contain its own second preprocessing algorithm.

It deliberately runs the existing Part B implementation through the inference-specific runner wrapper.

This preserves the saved preprocessing behavior while adding cached-usability enforcement.

---

# 53. Preparing Part C — Normal KPI

For a KPI that has no genuine late-data reconstruction:

Part E takes the newly regenerated Part B dataset and keeps only:

```text
timestamp > previous_history_end
```

as the newly processed tail.

Then Part C receives:

```text
old finalized processed Z-cache
+
new regenerated Part B tail
```

The old processed history is therefore **not unnecessarily regenerated/replaced** during normal inference.

---

# 54. Normal Processed Update

The portion later committed to persistent processed history is only:

```text
new regenerated Part B tail
```

with:

```text
processed_update_start
processed_update_end
```

saved for the updater.

---

# 55. Preparing Part C — Reconstruction KPI

For an affected KPI with genuine late data:

Part E does **not** concatenate stale processed-cache rows back into the reconstructed region.

The regenerated Part B output is handed directly into Part C.

The persistent replacement range begins from the **current processed-cache boundary**, not merely the exact late timestamp.

---

# 56. Reconstruction Replacement Boundary

Current code determines:

```text
reconstruction_update_start
=
minimum timestamp of existing processed Z-cache
```

and keeps regenerated rows from that point onward as the persistent processed update.

The older extra raw-history slice is therefore **context for regeneration**, not an instruction to replace older full processed history outside the current cache boundary.

---

# 57. Per-KPI Reconstruction Nuance

`HistoryValidationResult.mode` becomes `reconstruction` if **any** supported late data exists.

However, `prepare_part_c_inputs()` determines reconstruction at the KPI level:

```text
KPI has late timestamps
→ reconstruction Part C path

KPI has no late timestamps
→ normal Part C path
```

So an inference invocation may globally be reconstruction mode while unaffected KPIs still use the normal processed-cache + new-tail Part C handoff.

---

# 58. `PreparedKPIForPartC`

For each KPI it records:

```text
kpi_name
mode

part_c_preprocessing_result
part_c_input_file

processed_update_dataframe
processed_update_start
processed_update_end

old_processed_rows_retained_for_part_c
regenerated_rows_used_for_part_c
```

This object serves **both**:

1. the Part C runner;
    
2. the history updater after model success.
    

---

# 59. Part C Execution

The history runner calls the normal:

```text
run_feature_engineering_pipeline(...)
```

using:

- prepared Part B handoff;
    
- runtime dataset mapping;
    
- exact saved Part C config;
    
- exact saved bucket.
    

Afterward:

```text
runtime resolved_config
=
saved ResolvedFeatureEngineeringConfig
```

is mandatory.

---

# 60. `HistoryRunnerResult`

The non-persistent result contains:

```text
context

loaded
validation
raw_preparation

runtime_dataset_config

eda_result
preprocessing_results

part_c_preparation
feature_results
```

The parent model-inference layer primarily consumes:

```text
feature_results
```

which are genuine `FeatureEngineeringRunnerResult` objects produced by the normal Part C runner.

---

# 61. Critical Persistence Rule

`run_history_pipeline()` does **not change persistent history**.

At this stage:

```text
A succeeded
B succeeded
C succeeded
```

but model inference may still fail.

Therefore:

```text
A/B/C success
≠
history commit
```

Permanent history is intentionally left untouched until saved-model inference finishes successfully.

---

# 62. Parent `validation.py`

After Part C completes, parent inference validation checks:

```text
actual current Part C output
        +
saved Part D model contract
        │
        ▼
safe model inference handoff
```

It does not recalculate feature engineering or load models.

---

# 63. Two-Level Validation Design

Part E validation has two stages.

### Stage 1 — lightweight all-site validation

```text
validate_inference_handoff(...)
```

### Stage 2 — one-site dataframe loading

```text
load_and_validate_series_data(...)
```

This is another key memory-control mechanism.

---

# 64. `InferenceSeriesValidationPlan`

For one saved site model:

```text
artifact
feature_file

site_row_count
site_usability

minimum_timestamp
maximum_timestamp

ready_for_model_inference
skip_reason
```

No estimator or full feature dataframe is stored.

---

# 65. `InferenceKPIValidationPlan`

Contains:

```text
kpi_name
feature_result
feature_file

model_feature_columns
target_column

series[]
unmodelled_part_c_series[]
```

---

# 66. `InferenceValidationResult`

Aggregates:

```text
model_type

kpis[]

total_saved_series
ready_saved_series
skipped_saved_series
unmodelled_part_c_series
```

and exposes:

```text
iter_ready_series()
```

which is what the parent runner actually scores.

---

# 67. KPI Handoff Validation

The current Part C result KPI set must exactly match:

```text
saved.dataset.kpi_names
```

The model load-plan type must also match the saved model type.

---

# 68. Exact Part C Contract Recheck

For every KPI, validation reconfirms that:

```text
feature_result.resolved_config
=
saved Part C resolved config
```

and:

```text
feature_result.feature_columns
=
saved Part C feature columns
```

before pairing the data with the model.

---

# 69. Required Feature Header

The current Part C CSV must include:

```text
circle
cluster
site
timestamp
kpi_usability
saved model features
```

plus:

### XGBoost

```text
saved target column
```

### One-sided Isolation Forest

the direction feature, when needed.

---

# 70. Exact Model Feature Order

Part E does not merely check that the model feature names exist.

They must also appear in the current Part C output preserving the exact saved order used by training.

This prevents changing the meaning of estimator input columns during inference.

---

# 71. Saved Model File Validation

Before any estimators are deserialized, validation confirms that all saved model files:

- exist;
    
- are nonempty;
    
- have the correct extension for the model type.
    

This is done during lightweight all-site handoff validation.

---

# 72. Current Site Mapping

Each saved model identity must still exist in the current Part C output.

If a saved model has **no matching site data**, inference fails.

---

# 73. Current Site Usability

If the saved site exists but current Part C says:

```text
kpi_usability = valid
```

then:

```text
ready_for_model_inference = True
```

If:

```text
kpi_usability = invalid
```

the saved model is deliberately skipped for this invocation.

This is **not treated as model execution failure**.

---

# 74. `SkippedInferenceSeries`

The parent runner records:

```text
kpi_name
series_key
identity
reason
```

for saved models skipped due to current invalid usability.

---

# 75. Unmodelled Current Part C Sites

A site can appear in current Part C output without having a saved Part D model.

This is not automatically an error because Part D may intentionally have skipped that site during training when it was invalid.

Such sites are recorded as:

```text
UnmodelledPartCSeries
```

rather than scored.

---

# 76. One-Site Data Loading

Immediately before one model is loaded:

```text
load_and_validate_series_data(...)
```

chunk-reads only the required columns and filters to exactly one saved site identity.

Chunk size is:

```text
100,000 rows
```

for this one-site loading stage.

---

# 77. One-Site Structural Validation

The selected data is:

- timestamp parsed;
    
- chronologically sorted;
    
- duplicate timestamps rejected;
    
- model features converted to numeric;
    
- XGBoost target converted to numeric;
    
- standalone IF direction feature converted when needed.
    

The final dataframe retains only what model inference needs.

---

# 78. `ValidatedSeriesData`

Contains:

```text
series_plan
dataframe

model_feature_columns
target_column
direction_feature

scorable_mask

total_rows
scorable_rows
unscorable_rows

minimum_timestamp
maximum_timestamp
```

---

# 79. Model-Aware Scorable Rule

### Isolation Forest

A row is initially scorable when:

```text
all saved model feature values are finite
```

### XGBoost

A row is scorable when:

```text
all saved model features finite
AND
actual target finite
```

because pure XGBoost anomaly detection still needs:

```text
residual = actual - prediction
```

---

# 80. Historical Rows vs Output Rows

Part C's site dataframe may include older historical rows because they were required to create current features.

The model-specific inference modules output only:

```text
[inference_start, inference_end_exclusive)
```

Rows before `inference_start` are context only and are not returned as current inference results.

---

# 81. XGBoost Inference Branch

File:

```text
app/ml/inference/xgboost/inference.py
```

The runtime behavior mirrors Part D final testing but removes all:

- train splitting;
    
- fitting;
    
- tuning;
    
- calibration;
    
- evaluation-stage logic.
    

---

# 82. XGBoost Input Validation

It requires:

```text
loaded artifact model_type = xgboost
validated data model_type = xgboost
```

and the loaded model artifact must exactly match the artifact associated with the validated site data.

It also requires:

- nonempty feature set;
    
- correct target;
    
- exact feature order;
    
- valid XGBoost decision settings;
    
- estimator with `predict()`.
    

---

# 83. XGBoost Requested Window

Only:

```text
timestamp >= inference_start
AND
timestamp < inference_end_exclusive
```

is selected.

If no rows exist in that interval, the site inference fails.

---

# 84. XGBoost Final Scorable Mask

Inside the requested window, Part E again defensively requires:

```text
upstream scorable
AND
all model features finite
AND
target finite
```

Unscorable rows remain in the output instead of disappearing.

---

# 85. XGBoost Prediction

For scorable rows:

```text
X = saved ordered feature columns

prediction = saved_model.predict(X)

actual = target_column
```

The prediction must have the same shape as the target and all predictions must be finite.

---

# 86. XGBoost Residual

Exact Part D semantics are retained:

```text
residual
=
actual - prediction
```

No new threshold calibration is performed.

---

# 87. Saved XGBoost Decision

### `lower_only`

```text
residual <= saved lower_threshold
```

### `upper_only`

```text
residual >= saved upper_threshold
```

### `both`

```text
lower condition
OR
upper condition
```

The thresholds come directly from the saved Part D contract.

---

# 88. XGBoost Row Output

Every requested-window row appears in the output with:

```text
kpi_name
series_key
circle
cluster
site_name
timestamp

scorable

actual
prediction
residual

lower_anomaly
upper_anomaly
is_anomaly
```

For unscorable rows, model-derived fields remain `NaN`/nullable rather than the row being removed.

---

# 89. `XGBoostSeriesInferenceResult`

Contains:

```text
kpi_name
series_key
identity

inference_start
inference_end_exclusive

total_window_rows
scorable_rows
unscorable_rows

anomaly_count
anomaly_rate

lower_anomaly_count
upper_anomaly_count

threshold_direction
lower_threshold
upper_threshold

output
```

Anomaly rate is based on:

```text
anomaly_count / scorable_rows
```

and is `0.0` if there are zero scorable rows.

---

# 90. Isolation Forest Inference Branch

File:

```text
app/ml/inference/isolation_forest/inference.py
```

It mirrors Part D final testing semantics without training/tuning behavior.

---

# 91. Isolation Forest Input Validation

Requires:

- loaded artifact model type = IF;
    
- validated data model type = IF;
    
- same saved artifact;
    
- no target column;
    
- nonempty exact saved feature list;
    
- valid saved IF decision settings;
    
- one-sided direction feature agreement;
    
- estimator methods:
    

```text
predict()
decision_function()
score_samples()
```

---

# 92. Isolation Forest Scorable Rule

Requested-window rows are scorable when:

```text
upstream scorable
AND
all model features finite
```

No target is required.

---

# 93. Isolation Forest Model Execution

For scorable rows:

```text
predicted_labels = model.predict(X)

decision_scores =
model.decision_function(X)

raw_scores =
model.score_samples(X)
```

All score shapes must match.

Decision/raw scores must be finite.

Predicted labels are restricted to:

```text
{-1, +1}
```

---

# 94. Isolation Forest Model Anomaly

The saved fundamental model decision remains:

```text
model_anomaly
=
predict(X) == -1
```

`decision_function < 0` is stored/reported consistently, but it does not replace the explicit saved prediction rule.

---

# 95. Isolation Forest Lower Direction

For:

```text
lower_only
```

final anomaly is:

```text
model anomaly
AND
direction_feature < 0
```

---

# 96. Isolation Forest Upper Direction

For:

```text
upper_only
```

final anomaly is:

```text
model anomaly
AND
direction_feature > 0
```

---

# 97. Isolation Forest Both

For:

```text
both
```

every model anomaly is retained:

```text
final anomaly
=
model anomaly
```

If the direction feature exists in the model feature matrix, lower/upper subtype counts are also calculated.

Otherwise those direction subtype counts are unavailable, without affecting final anomaly status.

---

# 98. Isolation Forest Zero Direction Value

The one-sided comparisons remain strict:

```text
lower: value < 0
upper: value > 0
```

Therefore a model anomaly whose direction value is exactly zero belongs to neither one-sided direction.

---

# 99. Isolation Forest Row Output

Requested-window output contains:

```text
kpi_name
series_key
circle
cluster
site_name
timestamp

scorable

model_prediction
decision_score
score_samples
model_anomaly

direction_value

lower_anomaly
upper_anomaly
is_anomaly
```

Unscorable rows remain represented.

---

# 100. `IsolationForestSeriesInferenceResult`

Contains:

```text
kpi_name
series_key
identity

inference_start
inference_end_exclusive

total_window_rows
scorable_rows
unscorable_rows

model_anomaly_count
model_anomaly_rate

anomaly_count
anomaly_rate

lower_anomaly_count
upper_anomaly_count
direction_counts_available

threshold_direction
direction_feature
model_offset
contamination

output
```

---

# 101. Parent `runner.py`

The main public entry point is:

```text
run_inference_pipeline(...)
```

It coordinates:

```text
load
→ history
→ validation
→ model execution
→ output staging
→ history commit
→ publication
```

but leaves detailed calculations inside their specialized modules.

---

# 102. Invocation ID

Every inference execution receives a unique identifier constructed from:

```text
sanitized run_id
+
UTC timestamp
+
8-character UUID fragment
```

This is used for:

- working directory;
    
- staging output directory;
    
- final inference-result directory.
    

---

# 103. Temporary Directories

The runner creates:

### Working A/B/C area

```text
<run_directory>/.inference_work/<invocation_id>/
```

### Staged inference result

```text
<inference_results_directory>/
.staging_<invocation_id>/
```

### Final published result

```text
<inference_results_directory>/
<invocation_id>/
```

---

# 104. Parent History Context

The runner converts the loaded saved contract into `HistoryRunContext`, explicitly enforcing:

```text
cached usability = True
```

and then calls:

```text
run_history_pipeline(...)
```

---

# 105. Inference Window Comes From History Validation

The parent does not independently invent the final time interval.

It uses:

```text
history_result.validation.new_period_start

history_result.validation.new_period_end_exclusive
```

for every site model.

Thus history acceptance, A/B/C processing and model output all share the same requested runtime period.

---

# 106. Current Part C → Model Validation

The parent calls:

```text
validate_inference_handoff(
    load_result,
    history_result.feature_results,
)
```

before loading any estimator.

Saved invalid-current sites become skipped entries.

Ready saved sites become the iterable model execution plan.

---

# 107. One-Series Parent Execution

For each ready site:

```text
load_and_validate_series_data()
        ↓
load_series_model()
        ↓
model-specific inference()
        ↓
save site's row output CSV
        ↓
retain lightweight summary only
        ↓
delete result/data/model
```

This is the core Part E memory lifecycle.

---

# 108. Per-Site Output Filename

Output names contain sanitized:

```text
KPI
circle
cluster
site
series key
```

plus a deterministic sequence index within the invocation.

Each is saved as a CSV in staging.

---

# 109. `InferenceSeriesOutput`

The lightweight persisted summary contains:

```text
model_type

kpi_name
series_key
identity

result_file

total_window_rows
scorable_rows
unscorable_rows

anomaly_count
anomaly_rate

model_anomaly_count
lower_anomaly_count
upper_anomaly_count
```

For XGBoost:

```text
model_anomaly_count = None
```

because XGBoost has no separate pre-direction model-anomaly concept.

---

# 110. Row Outputs Are Not Accumulated

After a site's CSV is written:

```text
result.output
```

is deliberately not retained.

The result is deleted and garbage collection is requested before continuing.

This prevents many site-level result dataframes accumulating in memory.

---

# 111. Staged Manifest Before History Commit

Once **every ready model site has completed and every output CSV exists in staging**, Part E writes:

```text
manifest.json
```

with:

```text
history_committed = false
```

At this exact point:

```text
all inference output has succeeded
BUT
persistent history is still unchanged
```

---

# 112. Manifest Contents

The manifest contains run-level information such as:

```text
schema_version
run_id
invocation_id
model_type
input_file
inference_days

inference_start
inference_end_exclusive

history_committed

total_saved_series
completed_series
skipped_saved_series
unmodelled_part_c_series

outputs[]
skipped_series[]
```

Each output records the result filename and major scorable/anomaly counts.

---

# 113. History Commit Timing

Only after:

```text
all ready site inference succeeded
+
all row-level output CSVs were staged
+
initial manifest was written
```

does the parent call:

```text
commit_history_pipeline(history_result)
```

This is the central state-safety guarantee of Part E.

---

# 114. `history/updater.py`

This is the **only history subsystem file allowed to mutate persistent history/cache state**.

It receives already-decided/prepared update objects.

It does not decide:

- what counts as late data;
    
- whether reconstruction is required;
    
- which A/B/C configuration to run.
    

---

# 115. Raw History — Normal Mode

Normal mode appends:

```text
accepted forward genuine raw observations
```

to full raw history.

Existing accepted historical source values are never silently overwritten.

---

# 116. Raw History — Reconstruction Mode

Reconstruction incorporates:

```text
accepted genuine late observation(s)
+
accepted forward observations
```

The late real value replaces the corresponding previously unavailable raw key.

This replacement was already explicitly approved by history validation.

---

# 117. Processed History — Normal Mode

Normal processed history is append-only.

The update is the:

```text
new regenerated Part B tail
```

prepared earlier.

Overlap with previously finalized processed rows is rejected.

---

# 118. Processed History — Reconstruction Mode

For affected series, the updater removes existing processed rows inside the prepared:

```text
processed_update_start
→ processed_update_end
```

range and replaces them with the regenerated Part B update.

Current preparation makes that range begin at the processed Z-cache boundary.

---

# 119. Full Histories Are Loaded at Commit Time

Normal inference avoids loading full histories during preprocessing.

The updater loads the persistent full raw/processed histories only when a successful invocation is ready to commit its new state.

This keeps deep persistent state access off the ordinary preparation path.

---

# 120. Common Finalized End

Before committing, all KPI processed updates must end at the same timestamp.

Otherwise Part E refuses to advance history because raw/processed caches could no longer share one coherent finalized boundary.

---

# 121. Cache Cutoff

Once:

```text
finalized_end
```

is known:

```text
cache_cutoff =
finalized_end
- cache_days
+ one bucket
```

The updater rebuilds:

```text
raw cache
processed cache for every KPI
```

from the newly updated full histories.

---

# 122. Why Caches Are Rebuilt

Part E does not simply append independently to existing cache files.

It derives them from finalized full history over the configured window.

This keeps:

```text
full history
rolling cache
```

synchronized after both:

- normal append;
    
- reconstruction replacement.
    

---

# 123. Commit Path Validation

Persistent targets must be unique across:

```text
raw full history
raw cache
all processed histories
all processed caches
```

and the KPI mappings must exactly match trained KPIs.

A single file cannot accidentally serve two incompatible persistent roles.

---

# 124. Rollback-Protected History Commit

The updater uses a multi-file staging strategy.

For every target:

1. serialize candidate data to a sibling pending file;
    
2. create backups of existing targets;
    
3. replace targets;
    
4. if replacement fails, restore already-replaced targets from backups;
    
5. clean staging/backup files.
    

This is not a database transaction, but it is explicitly designed to avoid leaving raw/processed/cache files intentionally half-updated.

---

# 125. `HistoryCommitResult`

Returns:

```text
raw_history_file
raw_cache_file

raw_history_rows
raw_cache_rows

finalized_end
cache_cutoff

kpis[]
```

Each KPI receives:

```text
KPIHistoryCommitResult
```

with:

```text
kpi_name
mode

processed_history_file
processed_cache_file

processed_history_rows
processed_cache_rows

update_start
update_end
```

---

# 126. Manifest Is Updated After Commit

When history commit succeeds:

```text
history_committed = True
```

and the **staged manifest is rewritten** to reflect that state.

Only after this does Part E attempt final result publication.

---

# 127. Final Output Publication

The completed staging directory is renamed to:

```text
<inference_results_directory>/<invocation_id>
```

This publishes:

```text
manifest.json
+
one result CSV per completed saved site
```

as one result directory.

---

# 128. Important Commit vs Publication Ordering

Current implementation order is:

```text
1. score all models
2. stage all result CSVs
3. write manifest: history_committed=false
4. COMMIT persistent history
5. rewrite manifest: history_committed=true
6. publish staging directory
```

This means history is protected against **model/staging failures**, but publication occurs **after** history commit.

---

# 129. Publication Failure After History Commit

This is explicitly handled differently.

If publication fails **after history has committed**:

```text
persistent history cannot safely be rolled back by parent runner
```

Therefore Part E retains the staged completed outputs for recovery rather than deleting them.

This is an important operational boundary.

---

# 130. Failure Before History Commit

If a failure occurs before successful history commit:

```text
history_committed = False
```

and staging output is removed.

Because `run_history_pipeline()` itself never persisted history, persistent history remains unchanged.

---

# 131. Working-Directory Cleanup

Regardless of success/failure, the temporary:

```text
.inference_work/<invocation_id>
```

directory is removed in the runner's `finally` block.

The history processing work products can always be regenerated and are not part of the published inference result.

---

# 132. `InferenceRunnerResult`

Successful final result contains:

```text
run_id
model_type
invocation_id

inference_start
inference_end_exclusive

output_directory
manifest_file

total_saved_series
completed_series
skipped_series_count
unmodelled_part_c_series

outputs
skipped_series

history_commit
```

---

# 133. Complete Normal Inference Flow

```text
NEW RAW INPUT
     │
     ▼
load saved contract + artifact plan
     │
     ▼
load raw Z-cache
load per-KPI processed Z-caches
     │
     ▼
history validation
     │
     ├─ classify overlaps
     ├─ identify requested forward rows
     ├─ ignore data beyond requested end
     ├─ ignore unsupported old historical data
     ├─ check gaps
     └─ verify cache readiness
     │
     ▼
mode = normal
     │
     ▼
retained raw history + accepted forward raw
     │
     ▼
Part A
     │
     ▼
Part B with cached usability
     │
     ▼
keep NEW Part B tail only
     │
     ▼
old finalized processed cache
+
new processed tail
     │
     ▼
Part C
     │
     ▼
validate Part C against saved model
     │
     ▼
one valid saved site at a time
     │
     ▼
load data + model
     │
     ▼
XGB / IF inference
     │
     ▼
stage site result
     │
     ▼
all sites successful
     │
     ▼
stage manifest
     │
     ▼
append raw history
append processed tail
rebuild caches
     │
     ▼
publish inference result
```

---

# 134. Complete Reconstruction Flow

```text
NEW RAW INPUT
     │
     ▼
history validation
     │
     ├─ valid forward data
     │
     └─ genuine in-cache late data detected
                │
                ▼
      mode = reconstruction
                │
                ▼
load older raw-history slice
[current cache start - cache_days,
 current cache start)
                │
                ▼
older raw
+
current raw cache
+
accepted late replacement
+
accepted requested forward rows
                │
                ▼
             Part A
                │
                ▼
 Part B with cached usability
                │
                ▼
for affected KPI:
regenerated Part B range directly → Part C

for unaffected KPI:
old processed cache + new tail → Part C
                │
                ▼
current Part C/model validation
                │
                ▼
one site/model at a time
                │
                ▼
saved-model inference
                │
                ▼
all outputs staged
                │
                ▼
persistent commit:
  raw late replacement + forward rows

  affected processed range replaced
  from current processed-cache boundary

  unaffected processed history appended

  all Z-day caches rebuilt
                │
                ▼
publish result
```

---

# 135. Part A/B/C Responsibility Boundary

Part E **uses** Parts A, B and C but does not redefine their internal algorithms.

### Part E owns

```text
how much history to supply
which rows are accepted
normal vs reconstruction
which temporary files A/B/C receive
cached usability enforcement
saved-config equality checks
```

### Parts A/B/C still own

```text
EDA/timeline preparation
preprocessing/filling/outlier logic
feature calculation
```

Therefore this Part E report does not duplicate their internal implementation details.

---

# 136. Part D Responsibility Boundary

Part E consumes Part D artifacts but does not:

```text
train
tune
calibrate
split train/test
select hyperparameters
```

It receives only the saved runtime model contract.

### XGBoost

```text
saved model
+
saved feature order
+
target
+
saved residual thresholds
```

### Isolation Forest

```text
saved model
+
saved feature order
+
saved IF decision settings
```

---

# 137. Main State-Safety Properties

The current Part E implementation provides several important protections.

### Saved training contracts are reused

Runtime A/B/C must resolve identically to training.

### Only requested forward data advances history

Extra future rows remain untouched for later calls.

### Existing genuine historical observations are immutable

Overlapping uploads cannot silently replace them.

### Supported genuine late data triggers reconstruction

Only previously unavailable historical source positions can be replaced.

### Historical data older than maintained reconstruction cache is ignored

It does not break otherwise valid forward inference.

### Per-series gap checks

One lagging site cannot hide behind the rest.

### Current invalid sites are skipped

Models are not run when current Part C marks the site invalid.

### Exact model feature order is preserved

No estimator input-column guessing.

### Saved thresholds are not recalibrated

Pure inference remains consistent with Part D.

### One site/model at a time

Memory usage is bounded.

### History does not move before model success

A/B/C alone cannot advance persistent state.

### History files commit together with rollback protection

Persistent raw/processed/cache state is designed to stay coherent.

---

# 138. Responsibility Separation

## Parent `loader.py`

**Which saved run/model artifacts exist and where?**

## `history/loader.py`

**Which current cache/raw data must be loaded?**

## `history/validation.py`

**What does the incoming data mean relative to finalized history?**

## `history/preparation.py`

**What temporary datasets should A/B/C receive?**

## `history/runner.py`

**Execute the saved A → B → C contract without persisting state.**

## Parent `validation.py`

**Can current Part C outputs safely enter the saved models?**

## `xgboost/inference.py`

**Apply saved XGBoost model + saved residual thresholds.**

## `isolation_forest/inference.py`

**Apply saved IF model + saved directional decision semantics.**

## `history/updater.py`

**Persist successful history/cache changes.**

## Parent `runner.py`

**Coordinate the entire transaction-like inference lifecycle.**

---

# 139. Final Summary

Part E is not simply:

```text
load model → predict
```

It is a complete **stateful pure-inference layer**.

```text
loader.py
→ Reconstructs the saved run/model artifact plan without loading every model.

history/
→ Maintains the historical context required to recreate training-time
  preprocessing/features.
→ Distinguishes normal forward inference from supported late-data
  reconstruction.
→ Does not mutate persistent state until model inference succeeds.

validation.py
→ Validates the actual current Part C outputs against exact saved Part D
  model contracts and determines which saved sites are currently runnable.

xgboost/inference.py
→ Predicts KPI values and applies the exact saved Part D residual thresholds.

isolation_forest/inference.py
→ Reuses predict == -1 and applies the saved lower/upper/both direction rule.

runner.py
→ Executes one site at a time, stages all outputs, commits history only
  after successful model execution, and publishes the completed inference run.
```

The final architectural flow is:

```text
Saved A/B/C/D training state
            +
       new raw data
            │
            ▼
      history-aware A/B/C
            │
            ▼
exact current feature contract
            │
            ▼
saved site-specific model
            │
            ▼
saved anomaly decision
            │
            ▼
row-level inference results
            │
            ▼
successful history/cache advancement
```

So Part E provides the production bridge from a **frozen trained run** to repeated future anomaly inference while preserving model consistency, historical continuity, late-data handling, bounded memory usage, and controlled persistent-state advancement.