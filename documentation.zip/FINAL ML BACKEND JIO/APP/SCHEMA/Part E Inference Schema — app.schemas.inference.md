# Part E Inference Schema — Final Technical Report

**Schema Package:** `app/schemas/inference/`

### Files

|File|Responsibility|
|---|---|
|`request.py`|Runtime inference request, frozen A/B/C/history/storage contracts, canonical `inference_config.json`, cross-contract validation and safe path resolution|
|`xgboost.py`|Saved XGBoost model-input and residual-decision contract|
|`isolation_forest.py`|Saved Isolation Forest model-input and directional-decision contract|

The schema package is designed around one central idea:

```text
Completed A/B/C/D training run
        │
        ▼
freeze everything needed for future inference
        │
        ▼
inference_config.json
        │
        ▼
small runtime request:
run_id + input_file + inference_days
```

Future inference therefore does **not reconstruct behavior from current defaults**. It uses the effective and resolved contracts saved by the completed training run.

---

# 1. Purpose

Part E schema defines the contract required to execute **already-trained models** safely in the future.

It answers:

- which completed training run is being used;
    
- which raw input file should be inferred;
    
- how many new days are requested;
    
- what dataset mapping/bucket was used during training;
    
- what exact Part B preprocessing configuration was used;
    
- what exact Part C feature-engineering configuration was used;
    
- how much history/cache must be retained;
    
- where persistent history/cache/model artifacts live;
    
- which trained model belongs to each KPI/site;
    
- which model feature columns must be supplied;
    
- which saved anomaly-decision rules must be applied.
    

It does **not**:

- run Part A/B/C;
    
- detect late data;
    
- combine history dataframes;
    
- deserialize models;
    
- execute predictions;
    
- update persistent history;
    
- save inference result CSVs.
    

Those are Part E ML responsibilities.

---

# 2. Overall Schema Architecture

```text
app/schemas/inference/
│
├── request.py
│     │
│     ├── InferenceRequest
│     ├── SavedDatasetContract
│     ├── SavedPreprocessingContract
│     ├── SavedFeatureEngineeringContract
│     ├── SavedHistoryContract
│     ├── SavedStorageContract
│     ├── SavedInferenceContract
│     ├── ResolvedStoragePaths
│     ├── ResolvedInferenceRequest
│     └── load_saved_inference_request()
│
├── xgboost.py
│     └── saved XGBoost inference contract
│
└── isolation_forest.py
      └── saved Isolation Forest inference contract
```

The model-specific section inside `SavedInferenceContract` is a discriminated union:

```text
model_type = "xgboost"
    → XGBoostInferenceConfig

model_type = "isolation_forest"
    → IsolationForestInferenceConfig
```

---

# 3. Direct Schema Dependencies

Unlike Part D's schema, Part E intentionally depends on earlier-stage schema contracts because inference must reproduce the training-time A/B/C behavior.

`request.py` imports:

### Common dataset schema

```text
BucketConfig
DatasetColumnMapping
DatasetInputConfig
ExpectedTimelineConfig
```

### Part B schema

```text
PreprocessingConfig
ResolvedFrequencyConfig
```

### Part C schema

```text
FeatureEngineeringConfig
ResolvedFeatureEngineeringConfig
```

### Model-specific Part E schemas

```text
XGBoostInferenceConfig
IsolationForestInferenceConfig
```

Both model-specific inference schema files also reuse:

```text
OutlierDirection
```

from preprocessing for:

```text
lower_only
upper_only
both
```

---

# 4. Two Different Types of Configuration

Part E separates two very different things.

## Runtime request

Small and user/request specific:

```text
run_id
input_file
inference_days
```

## Saved training-run contract

Large and frozen:

```text
dataset contract
Part B contract
Part C contract
history/cache contract
storage paths
model feature contract
per-site model files
per-site anomaly decision settings
```

This means the user does **not** submit new preprocessing, feature-engineering, threshold, or model settings for normal inference.

---

# 5. `InferenceRequest`

The runtime request contains only:

|Field|Meaning|
|---|---|
|`run_id`|Unique completed training-run identifier|
|`input_file`|New raw input file|
|`inference_days`|Number of requested new inference days|

`extra="forbid"` is enabled.

### `run_id`

Must:

- be nonblank;
    
- start with an alphanumeric character;
    
- thereafter contain only alphanumeric characters, `.`, `_`, or `-`.
    

### `input_file`

Converted to an expanded `Path`.

The schema does **not require the file to exist yet** during simple request parsing.

### `inference_days`

Must satisfy:

```text
inference_days >= 1
```

---

# 6. Database Boundary

The schema does **not** look up:

```text
run_id → run directory
```

itself.

The intended flow is:

```text
InferenceRequest.run_id
        │
        ▼
database / service layer
        │
        ▼
resolved run_directory
        │
        ▼
load_saved_inference_request(...)
```

So database responsibility remains outside `app/schemas/inference/`.

---

# 7. `SavedDatasetContract`

This freezes the Part A/shared dataset contract required for inference.

Fields:

```text
columns
bucket
kpi_names
single_kpi_name
```

### `columns`

Exact saved:

```text
DatasetColumnMapping
```

so inference keeps the same logical → physical column mapping used during training.

### `bucket`

Exact saved:

```text
BucketConfig
```

### `kpi_names`

Contains all KPIs for which the completed run has trained models.

Rules:

- at least one KPI;
    
- names stripped;
    
- no blanks;
    
- no duplicates.
    

### `single_kpi_name`

Optional.

If present:

```text
len(kpi_names) must equal 1
AND
kpi_names[0] == single_kpi_name
```

---

# 8. Runtime Dataset Config Reconstruction

`SavedDatasetContract` provides:

```python
build_runtime_dataset_config(...)
```

It rebuilds a `DatasetInputConfig` using the saved:

```text
columns
bucket
single_kpi_name
```

but substitutes the new working inference input file.

The training-time date boundaries are deliberately **not reused**.

Its default runtime timeline is initially:

```text
global_min_max
```

The Part E history runner can later replace that with the exact current inference range.

---

# 9. `SavedPreprocessingContract`

This freezes **both**:

```text
config
resolved
```

where:

```text
config   = PreprocessingConfig
resolved = ResolvedFrequencyConfig
```

This distinction is important.

The config preserves what Part B was asked to do.

The resolved object preserves what those settings became after applying the saved bucket.

Part E later checks that the two still reproduce one another exactly.

---

# 10. `SavedFeatureEngineeringContract`

Similarly stores:

```text
config
resolved
```

where:

```text
config   = FeatureEngineeringConfig
resolved = ResolvedFeatureEngineeringConfig
```

Therefore Part E freezes:

- requested Part C feature configuration;
    
- exact resolved feature columns;
    
- bucket resolution;
    
- points per day;
    
- minimum history;
    
- maximum historical lookback;
    
- all other resolved Part C behavior.
    

---

# 11. Why Both Config and Resolved Objects Are Saved

The saved object is not trusted merely because it contains a plausible resolved structure.

Part E re-runs:

```text
saved Part B config
        +
saved bucket
        ↓
resolve_for_bucket()
```

and requires the result to equal the saved Part B resolved object.

It does the same for Part C.

So:

```text
saved effective config
        │
        ▼
must deterministically reproduce
        │
        ▼
saved resolved contract
```

This protects future inference from inconsistent or corrupted saved contracts.

---

# 12. `SavedHistoryContract`

This freezes the history/cache policy required to reproduce A/B/C safely during inference.

Fields:

```text
part_b_required_history_points
part_b_required_history_days

part_c_required_history_points
part_c_maximum_lookback_points

final_required_history_points
final_required_history_days

cache_days

max_gap_days
max_gap_ratio

late_data_reconstruction_enabled
```

---

# 13. Part B History Requirement

The contract stores both:

```text
part_b_required_history_points
part_b_required_history_days
```

Both must be positive.

The point requirement represents the Part B numerical-history requirement.

The day requirement preserves longer calendar-based lookbacks required by preprocessing logic.

---

# 14. Part C History Requirement

Stores:

```text
part_c_required_history_points
part_c_maximum_lookback_points
```

with:

```text
part_c_required_history_points > 0
part_c_maximum_lookback_points >= 0
```

These correspond directly to the resolved Part C contract:

```text
minimum_history_points
maximum_lookback_points
```

and are later required to match those exact saved values.

---

# 15. Final Required History

Part E computes/fixes a final history requirement that must cover all earlier requirements.

The schema enforces:

```text
final_required_history_points
>= max(
    part_b_required_history_points,
    part_c_required_history_points,
    part_c_maximum_lookback_points + 1
)
```

Therefore Part E cannot save a history requirement shorter than what Part B or Part C actually needs.

---

# 16. Final Required History Days

The schema also requires:

```text
final_required_history_days
>= part_b_required_history_days
```

Part C's point-based requirements are separately converted to day coverage when possible and checked in the complete saved contract.

---

# 17. Rolling Cache Contract

`cache_days` is the maintained Z-day rolling cache used by normal inference.

The important relationship is:

```text
cache_days
>= final_required_history_days + max_gap_days
```

This means the normal cache is deliberately large enough to hold:

```text
required model/preprocessing context
+
permitted gap bridge
```

without relying on full historical files during normal inference.

---

# 18. Gap Policy

### `max_gap_days`

```text
>= 0
```

Represents the allowed bridge between stored history and new incoming data in day terms.

### `max_gap_ratio`

```text
0.0 <= max_gap_ratio <= 1.0
```

The saved schema describes runtime `gap_ratio` as:

```text
missing bridge points
/
(missing bridge points + expected incoming points)
```

The actual gap calculation belongs to the Part E ML history validator.

---

# 19. Late Reconstruction Switch

```text
late_data_reconstruction_enabled: bool = True
```

is persisted in the history contract.

The schema only stores the permission/policy.

It does **not detect late data or reconstruct history itself**.

---

# 20. Part B Day-Lookback Consistency

The complete saved contract calculates the minimum Part B day history from the enabled preprocessing settings, including:

```text
Phase 2 recent-same-type lookback
Phase 2 last-week lookback
Phase 3 maximum lookback
Phase 4 minimum history days, if enabled
```

and requires:

```text
part_b_required_history_days
```

to cover the largest enabled lookback.

---

# 21. Prophet History Consistency

If saved Part B:

```text
phase_4.enabled = True
```

then the resolved preprocessing contract must contain:

```text
prophet_minimum_history_points
```

and Part E requires:

```text
part_b_required_history_points
>= prophet_minimum_history_points
```

So the saved inference history contract cannot under-provision Prophet relative to the preprocessing configuration that training actually used.

---

# 22. Part C Day Coverage

When the dataset bucket divides a full day cleanly, the schema derives:

```text
points_per_day = 1440 / bucket_minutes
```

and computes day coverage for:

```text
minimum_history_points
```

and:

```text
maximum_lookback_points + 1
```

Then:

```text
final_required_history_days
```

must cover the larger of those Part C requirements.

---

# 23. `SavedStorageContract`

This stores portable **run-relative** locations for Part E persistent state.

Fields:

```text
raw_history_file
raw_cache_file

processed_history_by_kpi
processed_cache_by_kpi

inference_results_directory
```

---

# 24. Full History vs Cache

The contract distinguishes:

### Raw

```text
raw_history_file
raw_cache_file
```

### Per-KPI processed

```text
processed_history_by_kpi[kpi]
processed_cache_by_kpi[kpi]
```

This is deliberate because normal inference can use rolling caches, while reconstruction may need deeper full-history access.

The schema itself only defines the storage contract; usage belongs to the Part E ML history subsystem.

---

# 25. Portable Relative-Path Validation

Saved paths must be portable and relative to the saved-run root.

The normalizer rejects:

```text
blank paths
Windows "\" separators
absolute POSIX paths
absolute Windows paths
".."
"."
```

Saved paths therefore look conceptually like:

```text
history/raw_history.csv
history/raw_cache.csv
training/model/site_x/final_model.json
```

rather than machine-specific absolute paths.

---

# 26. Storage KPI Mapping

`processed_history_by_kpi` and `processed_cache_by_kpi` must:

- contain nonblank KPI keys;
    
- contain exactly the same KPI-key set.
    

Then `SavedInferenceContract` further requires those mappings to contain exactly the saved training KPI set.

---

# 27. `SavedInferenceContract`

This is the canonical persisted:

```text
inference_config.json
```

contract.

Fields:

```text
schema_version
run_id
created_at_utc
model_type

dataset
preprocessing
feature_engineering
history
storage
model
```

---

# 28. Schema Version

Current version is fixed as:

```text
schema_version = "1.0"
```

No other version is accepted by this schema.

---

# 29. Saved Run ID

`run_id` follows the same identifier pattern as the runtime request:

```text
[A-Za-z0-9][A-Za-z0-9._-]*
```

It acts as the identity binding between the database/service lookup and the saved inference contract.

---

# 30. Creation Timestamp

```text
created_at_utc
```

must be timezone-aware.

A naive `datetime` is rejected.

The field name says UTC, while the validator specifically enforces timezone awareness.

---

# 31. Model Discriminator

Top-level:

```text
model_type
```

may only be:

```text
xgboost
isolation_forest
```

The `model` field is a discriminated union over the model-specific contracts.

The complete saved contract additionally requires:

```text
self.model.model_type == self.model_type
```

---

# 32. Saved Bucket Revalidation

The saved dataset bucket is converted to whole minutes.

Supported units include:

```text
minute / minutes / min / mins
hour / hours / hr / hrs
day / days
second / seconds
```

Seconds must resolve exactly to whole minutes.

Unsupported bucket units or nonpositive resulting durations are rejected.

---

# 33. Part B Re-resolution

Part E executes conceptually:

```text
saved preprocessing.config
        │
        + saved dataset.bucket
        ▼
resolve_for_bucket()
        │
        ▼
must exactly equal
saved preprocessing.resolved
```

A mismatch invalidates the entire saved inference contract.

---

# 34. Part C Re-resolution

Likewise:

```text
saved feature_engineering.config
        │
        + saved dataset.bucket
        ▼
resolve_for_bucket()
        │
        ▼
must exactly equal
saved feature_engineering.resolved
```

This is the primary mechanism ensuring inference recreates the **same Part C contract as training**.

---

# 35. Bucket Consistency Across A/B/C

The saved contract requires:

```text
Part A/shared dataset bucket
=
Part B resolved bucket_minutes
=
Part C resolved bucket_minutes
```

where applicable.

If the bucket divides 1440 minutes, the expected points per day are also derived and checked against the saved Part B/Part C resolved contracts.

---

# 36. Exact Part C History Match

The schema explicitly requires:

```text
history.part_c_required_history_points
=
feature_engineering.resolved.minimum_history_points
```

and:

```text
history.part_c_maximum_lookback_points
=
feature_engineering.resolved.maximum_lookback_points
```

These are not approximate values.

---

# 37. Exact KPI Set Across Contracts

Let:

```text
expected KPIs
=
dataset.kpi_names
```

Then the saved contract requires exactly the same KPI set in:

```text
storage.processed_history_by_kpi
storage.processed_cache_by_kpi
model.kpis
```

No trained KPI may be silently missing from Part E, and an extra unknown KPI cannot be added to the saved inference contract.

---

# 38. XGBoost Saved Inference Schema

File:

```text
app/schemas/inference/xgboost.py
```

Structure:

```text
XGBoostInferenceConfig
    │
    ├── threshold_direction
    │
    └── kpis
          │
          └── XGBoostKPIInferenceConfig
                  │
                  ├── model_feature_columns
                  ├── target_column
                  └── series
                        │
                        └── XGBoostSeriesInferenceConfig
                                ├── identity
                                ├── model_file
                                └── decision_settings
```

---

# 39. `XGBoostSeriesIdentity`

Stores:

```text
circle
cluster
site_name
```

All are nonblank strings.

The object is:

```text
extra = forbid
frozen = True
str_strip_whitespace = True
```

and provides:

```python
as_tuple()
```

in the same logical identity order used by Part D.

---

# 40. `XGBoostDecisionSettings`

This freezes the exact residual-decision contract created by Part D.

Fixed semantics include:

```text
method = "residual_quantile"

residual_definition =
"actual_minus_prediction"

quantile_method = "linear"
```

and the saved:

```text
threshold_direction
residual_quantile
lower_quantile
upper_quantile
lower_threshold
upper_threshold
lower_comparison
upper_comparison
```

---

# 41. XGBoost Residual Quantile

Constraint:

```text
0.5 < residual_quantile < 1.0
```

Expected tails are:

```text
lower_quantile = 1 - residual_quantile
upper_quantile = residual_quantile
```

The schema checks them with absolute tolerance:

```text
1e-12
```

---

# 42. XGBoost `lower_only`

Requires all lower-side components:

```text
lower_quantile
lower_threshold
lower_comparison =
"residual <= lower_threshold"
```

and forbids all upper-side decision fields.

So an `lower_only` saved contract cannot accidentally carry an unused/stale upper threshold.

---

# 43. XGBoost `upper_only`

Requires:

```text
upper_quantile
upper_threshold
upper_comparison =
"residual >= upper_threshold"
```

and forbids lower-side fields.

---

# 44. XGBoost `both`

Requires both lower and upper contracts.

Additionally, if both thresholds exist:

```text
lower_threshold <= upper_threshold
```

must hold.

---

# 45. Thresholds Are Frozen, Not Recomputed

The inference schema stores the **actual thresholds produced during Part D calibration**.

Therefore future inference is intended to perform:

```text
new residual
        │
        ▼
compare against saved threshold
```

not:

```text
new inference data
        │
        ▼
recalculate a new residual quantile
```

That distinction is fundamental to pure inference.

---

# 46. `XGBoostSeriesInferenceConfig`

For each saved site model:

```text
identity
model_file
decision_settings
```

`model_file` must be a portable run-relative path.

The schema does not deserialize or check model internals.

---

# 47. `XGBoostKPIInferenceConfig`

Per KPI:

```text
model_feature_columns
target_column
series
```

### Feature columns

Must:

- contain at least one feature;
    
- be stripped;
    
- contain no blanks;
    
- contain no duplicates.
    

### Target column

Must be a nonblank string.

### Series mapping

Must:

- contain at least one saved series;
    
- contain no blank series keys;
    
- not map the same site identity more than once within that KPI.
    

---

# 48. XGBoost Feature Contract vs Part C

At the top-level saved-contract validation:

```text
XGBoost model_feature_columns
```

must be a subset of:

```text
saved Part C feature_columns
```

and must preserve the relative Part C order.

This matches Part D's behavior where XGBoost may exclude target-leaking Part C feature families.

Therefore XGBoost does **not necessarily use every Part C feature**.

---

# 49. XGBoost Target Contract

For every KPI:

```text
XGBoost target_column
=
dataset.columns.value_column
```

The inference contract therefore preserves the exact KPI source value used to compute:

```text
residual = actual - prediction
```

---

# 50. `XGBoostInferenceConfig`

Run-level XGBoost contract:

```text
model_type = "xgboost"
threshold_direction
kpis
```

Every series' saved decision direction must equal the run-level `threshold_direction`.

So one saved XGBoost run cannot quietly mix:

```text
site A = lower_only
site B = both
```

under the same contract.

---

# 51. Unique XGBoost Model Files

Across the whole saved XGBoost inference contract, each series must reference a unique:

```text
model_file
```

A second KPI/site cannot reuse the same saved model path.

This is checked across KPI boundaries, not merely within a single KPI.

---

# 52. Isolation Forest Saved Inference Schema

File:

```text
app/schemas/inference/isolation_forest.py
```

Structure:

```text
IsolationForestInferenceConfig
    │
    ├── threshold_direction
    │
    └── kpis
          │
          └── IsolationForestKPIInferenceConfig
                  │
                  ├── model_feature_columns
                  └── series
                        │
                        └── IsolationForestSeriesInferenceConfig
                                ├── identity
                                ├── model_file
                                └── decision_settings
```

---

# 53. `IsolationForestSeriesIdentity`

Same stable identity contract as XGBoost:

```text
circle
cluster
site_name
```

and exposes:

```python
as_tuple()
```

---

# 54. `IsolationForestDecisionSettings`

This stores the exact final Part D decision semantics.

Fixed fields:

```text
method = "isolation_forest"

model_prediction_rule =
"predict == -1"

decision_function_rule =
"decision_function < 0 indicates model anomaly"
```

It additionally stores:

```text
model_offset
contamination
threshold_direction
direction_feature
lower_direction_rule
upper_direction_rule
```

---

# 55. Isolation Forest Contamination

May be:

```text
"auto"
```

or numeric:

```text
0 < contamination <= 0.5
```

Anything else is rejected.

---

# 56. Isolation Forest Direction Rules Are Self-Consistent

Given:

```text
direction_feature = residual
```

the schema requires:

```text
lower_direction_rule = "residual < 0"
upper_direction_rule = "residual > 0"
```

More generally, the strings must exactly match the actual saved `direction_feature`.

Thus a contract cannot say:

```text
direction_feature = residual
lower_direction_rule = some_other_feature < 0
```

---

# 57. `IsolationForestSeriesInferenceConfig`

Per modelled site:

```text
identity
model_file
decision_settings
```

Again, `model_file` must remain portable and run-relative.

---

# 58. `IsolationForestKPIInferenceConfig`

Contains:

```text
model_feature_columns
series
```

There is deliberately **no y target**.

Feature names:

- nonempty;
    
- no blank names;
    
- unique.
    

Series:

- at least one;
    
- no blank keys;
    
- duplicate site identities forbidden.
    

---

# 59. One-Sided Isolation Forest Requirement

For:

```text
lower_only
upper_only
```

the saved:

```text
direction_feature
```

must exist in:

```text
model_feature_columns
```

because runtime anomaly direction depends on its sign.

---

# 60. Isolation Forest `both`

For:

```text
threshold_direction = both
```

the direction feature is not required **solely for anomaly filtering**.

The trained Isolation Forest anomaly decision itself is sufficient:

```text
predict == -1
```

If the direction feature is available, runtime can still report lower/upper subtype counts.

---

# 61. Isolation Forest Feature Contract vs Part C

Unlike XGBoost, the complete saved-contract validator requires:

```text
IsolationForest model_feature_columns
=
exact saved Part C feature_columns
```

including order.

So:

```text
XGBoost
→ ordered subset of Part C features

Isolation Forest
→ exact Part C feature contract
```

This reflects the actual Part D model-input policy.

---

# 62. `IsolationForestInferenceConfig`

Contains:

```text
model_type = "isolation_forest"
threshold_direction
kpis
```

All per-series decision settings must use the same run-level direction.

---

# 63. Unique Isolation Forest Model Files

Like XGBoost, each saved IF series must own a unique:

```text
model_file
```

across the complete run contract.

A duplicate model path assigned to different saved series is rejected.

---

# 64. XGBoost vs Isolation Forest Saved Contract

|Contract|XGBoost|Isolation Forest|
|---|---|---|
|Model file per site|Yes|Yes|
|Stable circle/cluster/site identity|Yes|Yes|
|Exact model feature order|Yes|Yes|
|Feature relation to Part C|Ordered subset|Exact full contract|
|y target|Saved KPI value column|None|
|Saved decision mechanism|Residual quantile thresholds|`predict == -1`|
|Lower/upper semantics|Residual threshold tails|Direction-feature sign|
|Saved model offset|No requirement|Yes|
|Saved contamination|No|Yes|
|Threshold recalculation during inference|No|N/A|
|One-sided direction feature|Not separate|Required|
|Unique model path per site|Yes|Yes|

---

# 65. `ResolvedStoragePaths`

The persisted storage schema holds **relative** paths.

Once the caller provides the real saved-run directory, the schema helper converts them into:

```text
ResolvedStoragePaths
```

containing absolute resolved paths for:

```text
raw_history_file
raw_cache_file

processed_history_by_kpi
processed_cache_by_kpi

inference_results_directory
```

---

# 66. Saved-Run Escape Protection

Resolution follows:

```text
run root
+
validated relative path
        │
        ▼
.resolve()
        │
        ▼
must still be beneath run root
```

If the result escapes the run root, validation fails.

This supplements the earlier rejection of absolute paths and `..`.

---

# 67. `ResolvedInferenceRequest`

This is the final schema-level object passed toward the ML inference layer.

It contains:

```text
request
run_directory
config_file
saved
storage
```

where:

```text
request
→ runtime InferenceRequest

saved
→ fully validated SavedInferenceContract

storage
→ absolute safely resolved common storage paths
```

---

# 68. `load_saved_inference_request()`

This helper belongs to the schema file and performs the saved-contract loading boundary.

Flow:

```text
InferenceRequest
+
caller-resolved run_directory
        │
        ▼
resolve inference_config.json safely
        │
        ▼
read JSON
        │
        ▼
SavedInferenceContract.model_validate()
        │
        ▼
verify saved.run_id == request.run_id
        │
        ▼
resolve common storage paths under run root
        │
        ▼
ResolvedInferenceRequest
```

---

# 69. Default Saved Config Filename

The canonical filename is:

```text
inference_config.json
```

through:

```text
INFERENCE_CONFIG_FILE_NAME
```

The helper can technically receive another config filename, but it is still required to be a safe run-relative path.

---

# 70. What This Helper Does Not Validate

`load_saved_inference_request()` validates:

- config-file existence;
    
- valid JSON;
    
- schema structure;
    
- run-ID match;
    
- safe path resolution.
    

It intentionally does **not validate the existence/content of every**:

```text
raw history file
processed history file
cache file
model file
```

Those are runtime data/artifact responsibilities of the Part E ML layer.

---

# 71. Important Cross-Stage Principle

Part E does not simply store:

```text
"we used Part B"
"we used Part C"
```

It stores the **actual effective and resolved contracts**.

Conceptually:

```text
Training
────────────────────────────

Dataset mapping/bucket
      ↓
Part B config → resolved B
      ↓
Part C config → resolved C
      ↓
Part D model + decisions
      ↓
history/cache requirements
      ↓
inference_config.json


Future inference
────────────────────────────

load inference_config.json
      ↓
validate it still reproduces B/C
      ↓
use saved A/B/C/model contracts
```

---

# 72. Important Model Principle

Part E does not save Part D's complete **training configuration** as its runtime model contract.

It saves only what is required to execute the trained model.

Therefore the Part E model schemas deliberately do **not contain**:

```text
train/validation/calibration/test percentages
fixed tuning candidates
Optuna search spaces
Optuna trial counts
early stopping controls
training minimum-point requirements
```

Those are training concerns whose job is already finished.

Instead Part E saves:

```text
model file
model input feature contract
target if required
final decision settings
```

---

# 73. Important History Principle

The saved history contract must cover **both**:

```text
exact point requirements
```

and:

```text
calendar-span requirements
```

because Parts B and C do not express every historical dependency in the same unit.

This is why Part E stores both:

```text
*_history_points
*_history_days
```

instead of reducing everything to one percentage or one arbitrary cache size.

---

# 74. Important Cache Principle

The schema formalizes:

```text
cache_days
>= required history days + permitted gap days
```

This is the structural reason normal inference can remain primarily cache-based.

Full history is preserved separately for scenarios such as reconstruction, but the schema does not implement when/how it is read.

---

# 75. Important Path Principle

Every saved path in `inference_config.json` is intended to be portable relative to its run folder.

Therefore the run directory can conceptually move:

```text
Server A:
/data/runs/run_123/

Server B:
/mnt/model_runs/run_123/
```

while internal saved paths remain:

```text
history/raw_cache.csv
training/model/.../final_model.json
```

No machine-specific root is frozen into the schema.

---

# 76. Important Part C → Model Contract

Part E explicitly connects the model artifact back to the exact saved Part C feature contract.

### XGBoost

```text
Part C feature_columns
        │
        ▼
ordered subset
        │
        ▼
saved XGB model_feature_columns
```

because Part D may have excluded target-derived features.

### Isolation Forest

```text
Part C feature_columns
        │
        ▼
exact equality
        │
        ▼
saved IF model_feature_columns
```

This prevents inference from feeding a trained estimator a feature matrix inferred from arbitrary CSV columns.

---

# 77. Schema Responsibility Boundary

The Part E schema answers:

```text
Which trained run is requested?

What A/B/C configuration belongs to that run?

Can those saved configurations reproduce their resolved contracts?

What history/cache capacity does inference require?

Where are persistent inference artifacts located?

Which KPIs have trained models?

Which model belongs to each site?

What exact feature matrix does each model expect?

Does XGBoost use the correct target?

What thresholds/rules were finalized during Part D?

Are all model paths portable and uniquely assigned?

Is the complete saved run internally consistent?
```

It does **not answer**:

```text
Is incoming history continuous?

Is an incoming historical value late data?

Should reconstruction run?

Which raw/cache rows should be joined?

Which current sites remain usable?

Which rows have complete features?

Can the model file actually be deserialized?

What prediction does the model produce?

Which inference rows are anomalous?

When should history be committed?
```

Those belong to `app/ml/inference/`.

---

# 78. Final Part E Schema Flow

```text
                  TRAINING COMPLETES
                         │
                         ▼
             freeze dataset contract
                         │
             freeze Part B config/resolved
                         │
             freeze Part C config/resolved
                         │
             calculate history contract
                         │
             save storage contract
                         │
             collect Part D model files
             + final decision settings
                         │
                         ▼
               SavedInferenceContract
                         │
                         ▼
                inference_config.json


                  FUTURE INFERENCE
                         │
                         ▼
                 InferenceRequest
       run_id + input_file + inference_days
                         │
                         ▼
               external run-ID lookup
                         │
                         ▼
                   run_directory
                         │
                         ▼
        load_saved_inference_request()
                         │
             ┌───────────┴───────────┐
             │                       │
             ▼                       ▼
      validate frozen A/B/C    validate model
      + history/storage        specific contract
             │                       │
             └───────────┬───────────┘
                         ▼
              resolve safe run paths
                         │
                         ▼
              ResolvedInferenceRequest
                         │
                         ▼
                  Part E ML
```

---

# 79. Final Summary

The Part E schema package is a **frozen bridge between training and all future pure-inference executions**.

```text
request.py
→ Defines the small runtime request and the canonical saved-run contract.
→ Saves the exact dataset, preprocessing, feature-engineering, history and
  storage information needed later.
→ Re-resolves Parts B/C to prove their saved resolved contracts are
  reproducible.
→ Validates cross-stage KPI, bucket, history and feature relationships.
→ Safely resolves portable run-relative paths.

xgboost.py
→ Stores each site's XGBoost model path, exact ordered model features,
  target column and final Part-D residual thresholds.
→ Enforces lower/upper/both threshold semantics exactly.
→ Never stores or reruns training/tuning logic.

isolation_forest.py
→ Stores each site's Isolation Forest model path, exact feature matrix,
  contamination/model-offset contract and final directional rules.
→ Preserves predict == -1 as the model anomaly rule.
→ Requires the saved direction feature for one-sided inference.
```

The key architectural principle is:

```text
Training determines behavior once
            ↓
Part E freezes that behavior
            ↓
Future inference reuses it exactly
```

rather than allowing future changes to Part A/B/C defaults, Part D tuning settings, or anomaly thresholds to silently alter how an already-trained model is executed.