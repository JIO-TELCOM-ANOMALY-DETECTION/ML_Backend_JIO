# Part B Preprocessing Schema — Final Technical Report

**Schema Package Location:** `app/schemas/preprocessing/`

### Files

|File|Responsibility|
|---|---|
|`__init__.py`|Public exports for the preprocessing schema package|
|`defaults.py`|Central data-only default values|
|`preprocessing.py`|Pydantic models, validation, gap profiles, and bucket-dependent configuration resolution|

---

# 1. Purpose

The Part B preprocessing schema defines **how preprocessing should be configured** after Part A has already established the dataset structure and resolved the dataset bucket.

It covers configuration for:

- timeline correction;
    
- duplicate handling;
    
- off-grid timestamp handling;
    
- valid KPI-value bounds;
    
- site-series usability;
    
- outlier detection;
    
- missing-gap classification;
    
- Phase 1 filling;
    
- Phase 2 filling;
    
- Phase 3 filling;
    
- optional Phase 4 Prophet filling;
    
- frequency-dependent parameter conversion;
    
- optional intermediate-output saving.
    

The schema does **not perform preprocessing itself**.

It describes and validates the settings that the Part B ML module later consumes.

---

# 2. Project Dependency Used by This Schema

The only external project schema directly required here is:

**`app.schemas.common.dataset.BucketConfig`**

from the shared dataset schema documented separately.

Part B receives the bucket that was resolved during dataset preparation and uses it to convert settings expressed in minutes into actual point counts.

Conceptually:

```text
Shared BucketConfig
        │
        ▼
PreprocessingConfig.resolve_for_bucket()
        │
        ▼
ResolvedFrequencyConfig
```

This allows the same preprocessing configuration to adapt to different dataset frequencies without the ML stages independently performing their own conversions.

---

# 3. Package Structure

The schema package is organized as:

```text
app/schemas/preprocessing/
│
├── __init__.py
│
├── defaults.py
│
└── preprocessing.py
```

The separation has a specific purpose.

### `defaults.py`

Contains data values only.

It intentionally does **not import Pydantic models from `preprocessing.py`**, avoiding circular dependencies.

### `preprocessing.py`

Imports those defaults and applies:

- types;
    
- Pydantic constraints;
    
- cross-field validation;
    
- bucket-dependent resolution.
    

### `__init__.py`

Re-exports the public schema API so other backend modules can continue importing from:

```text
app.schemas.preprocessing
```

## without needing to know which internal file contains each model.

# 4. Main Schema Structure

The top-level configuration is:

```text
PreprocessingConfig
│
├── TimelineCorrectionConfig
├── ValidValueConfig
├── SeriesUsabilityConfig
├── OutlierConfig
├── GapProfileConfig | None
│   ├── Phase 1 range
│   ├── Phase 2 range
│   ├── Phase 3 range
│   ├── Phase 4 Pass 1 range
│   └── Phase 4 Pass 2 range
├── Phase1Config
├── Phase2Config
├── Phase3Config
├── Phase4ProphetConfig
└── save_intermediate_outputs
```

After the actual bucket is known:

```text
PreprocessingConfig
        +
BucketConfig
        │
        ▼
resolve_for_bucket()
        │
        ▼
ResolvedFrequencyConfig
```

---

# 5. Public Type Aliases

Three restricted type aliases are defined.

## `OutlierMethod`

Allowed values:

```text
global_iqr
one_day_centered_iqr
user_bounds
```

Only one detector is selected for a preprocessing run.

---

## `OutlierDirection`

Allowed values:

```text
lower_only
upper_only
both
```

This controls which side of the selected detector's threshold is considered anomalous.

---

## `SeasonalityMode`

Allowed Prophet modes:

```text
additive
multiplicative
```

---

# 6. `TimelineCorrectionConfig`

## Responsibility

Defines the fixed policies used during Part B timeline correction.

Fields:

|Field|Default|Allowed|
|---|---|---|
|`duplicate_timestamp_strategy`|`keep_first`|only `keep_first`|
|`off_grid_timestamp_strategy`|`reject`|only `reject`|

Therefore these are represented as configuration fields, but the current schema intentionally exposes only one supported policy for each.

### Duplicate Strategy

For duplicate site-timestamp rows:

```text
First physical row → retained
Later duplicate rows → removed
```

### Off-grid Strategy

A timestamp that does not belong to the resolved bucket grid is:

```text
rejected
```

rather than silently moved or rounded.

---

# 7. `ValidValueConfig`

## Responsibility

Defines the physical KPI-value range and how values close to its boundaries are treated.

### Defaults

|Field|Default|
|---|--:|
|`lower_bound`|`0.0`|
|`upper_bound`|`100.0`|
|`boundary_tolerance`|`0.001`|
|`clip_values_within_tolerance`|`True`|
|`clip_generated_values`|`True`|

---

## Boundary Behaviour

The configured range is inclusive:

```text
lower_bound <= valid value <= upper_bound
```

`boundary_tolerance` permits slightly out-of-range source values to be clipped back to the nearest boundary when:

```text
clip_values_within_tolerance = True
```

Generated filling values and Prophet predictions can similarly be constrained to the valid range through:

```text
clip_generated_values = True
```

---

## Validation

The schema requires:

```text
upper_bound > lower_bound
```

It also prevents tolerance regions from becoming so large that the lower and upper tolerance zones overlap:

```text
2 × boundary_tolerance < value span
```

---

# 8. `SeriesUsabilityConfig`

## Responsibility

Defines when an entire site-level KPI series is considered unusable for filling.

### Field

```text
maximum_missing_percentage
```

Default:

```text
20.0%
```

Allowed range:

```text
0% to 100%
```

A series becomes invalid only when its calculated original missing percentage is:

```text
> maximum_missing_percentage
```

Equality remains valid.

The percentage is based on rows with immutable original labels:

```text
-2
-1
0
```

The actual meaning and creation of those labels belongs to the Part B ML module; this schema only defines the threshold.

---

# 9. `OutlierConfig`

## Responsibility

Defines one selected outlier detector and all method-specific settings.

### Core Fields

|Field|Purpose|
|---|---|
|`method`|Select detector|
|`direction`|Lower, upper, or both sides|
|`iqr_multiplier`|IQR threshold multiplier|
|`user_lower_bound`|Manual lower threshold|
|`user_upper_bound`|Manual upper threshold|
|`centered_window_minutes`|Centred-IQR window duration|
|`centered_min_valid_minutes`|Minimum reference duration|

The `method` field has **no default** and must therefore be explicitly selected.

The default direction is:

```text
lower_only
```

---

# 10. Global IQR Configuration

When:

```text
method = global_iqr
```

the schema:

- rejects user bounds;
    
- rejects centred-window settings;
    
- uses `iqr_multiplier = 1.5` when it was omitted.
    

Therefore the default conceptual configuration is:

```text
method = global_iqr
direction = lower_only
iqr_multiplier = 1.5
```

The actual quartiles and thresholds are calculated later by the ML module.

---

# 11. One-Day Centred IQR Configuration

When:

```text
method = one_day_centered_iqr
```

the schema supplies defaults of:

```text
iqr_multiplier = 1.5
centered_window_minutes = 1440
centered_min_valid_minutes = 720
```

The configured minimum valid duration cannot exceed the configured window duration.

These minute-based values are not directly passed to the detector as point counts.

They are converted later by:

```text
resolve_for_bucket()
```

---

# 12. User-Bounds Configuration

When:

```text
method = user_bounds
```

IQR-specific fields are not permitted.

Requirements depend on direction.

### Lower only

Requires:

```text
user_lower_bound
```

and rejects `user_upper_bound`.

### Upper only

Requires:

```text
user_upper_bound
```

and rejects `user_lower_bound`.

### Both

Requires:

```text
user_lower_bound
user_upper_bound
```

with:

```text
user_lower_bound < user_upper_bound
```

The top-level `PreprocessingConfig` later performs an additional cross-section check to ensure these user thresholds lie inside the configured physical KPI range.

---

# 13. `GapRangeConfig`

## Responsibility

Represents one inclusive original missing-gap size range.

Fields:

```text
minimum_points
maximum_points
```

`minimum_points` must be at least `1`.

`maximum_points` may be:

- another positive integer; or
    
- `None`, meaning no upper limit.
    

When supplied:

```text
maximum_points >= minimum_points
```

---

# 14. `GapProfileConfig`

## Responsibility

Defines the complete mapping from original missing-gap size to preprocessing phase.

It contains exactly five ranges:

```text
phase_1
phase_2
phase_3
phase_4_pass_1
phase_4_pass_2
```

Each is a `GapRangeConfig`.

---

## Complete-Profile Validation

The profile must cover **every possible positive gap size exactly once**.

Therefore:

1. Phase 1 must begin at `1`.
    
2. Every following range must begin immediately after the previous range.
    
3. Ranges cannot overlap.
    
4. Ranges cannot leave holes.
    
5. Only Phase 4 Pass 2 may be open-ended.
    
6. Phase 4 Pass 2 must be open-ended.
    

Conceptually:

```text
1 ────────────────► ∞
│
├─ Phase 1
├─ Phase 2
├─ Phase 3
├─ Phase 4 Pass 1
└─ Phase 4 Pass 2 ──► open ended
```

This guarantees that every original missing gap receives one unambiguous phase classification.

---

# 15. Built-In 5-Minute Gap Profile

For 5-minute data, the built-in profile is:

|Processing Phase|Gap Size|
|---|--:|
|Phase 1|1–3 points|
|Phase 2|4–12 points|
|Phase 3|13–72 points|
|Phase 4 Pass 1|73–288 points|
|Phase 4 Pass 2|289+ points|

The helper:

```text
build_5_minute_gap_profile()
```

## constructs this as a validated `GapProfileConfig`.

# 16. Built-In 15-Minute Gap Profile

For 15-minute data:

|Processing Phase|Gap Size|
|---|--:|
|Phase 1|1 point|
|Phase 2|2–4 points|
|Phase 3|5–24 points|
|Phase 4 Pass 1|25–96 points|
|Phase 4 Pass 2|97+ points|

This is created by:

```text
build_15_minute_gap_profile()
```

---

# 17. Custom Gap Profiles

`PreprocessingConfig.gap_profile` is optional.

When omitted:

```text
5-minute bucket
    → built-in 5-minute profile

15-minute bucket
    → built-in 15-minute profile
```

For another supported bucket duration:

```text
custom complete gap_profile required
```

The custom profile still has to satisfy all `GapProfileConfig` continuity and non-overlap rules.

---

# 18. `Phase1Config`

## Responsibility

Defines the bounded local-anchor search settings used by Phase 1.

### Defaults

```text
maximum_anchor_search_minutes = 60
maximum_two_sided_distance_minutes = 30
maximum_anchor_distance_ratio = 2.0
```

---

## Meaning

### `maximum_anchor_search_minutes`

Maximum distance Part B may search for a trusted local anchor.

### `maximum_two_sided_distance_minutes`

Stricter maximum distance used when considering anchors on both sides.

### `maximum_anchor_distance_ratio`

Limits how unbalanced the two anchor distances may be.

Default:

```text
farther distance / nearer distance <= 2.0
```

---

## Validation

The stricter two-sided search cannot exceed the overall search:

```text
maximum_two_sided_distance_minutes
<=
maximum_anchor_search_minutes
```

---

# 19. `Phase2Config`

## Responsibility

Defines settings for recent same-type and last-week seasonal references.

### Defaults

|Setting|Default|
|---|--:|
|`recent_same_type_lookback_days`|14|
|`last_week_lookback_days`|7|
|`recent_weight`|0.8|
|`last_week_weight`|0.2|
|`neighbor_offset_minutes`|`None`|

---

## Weight Validation

The two weights must form one complete mixture:

```text
recent_weight + last_week_weight = 1.0
```

within a very small floating-point tolerance.

Each individual weight is restricted to:

```text
0.0 – 1.0
```

---

## Neighbor Offset

When:

```text
neighbor_offset_minutes = None
```

the bucket resolver interprets the neighbor offset as **exactly one bucket step**.

Therefore the default automatically adapts to dataset frequency.

---

# 20. `Phase3Config`

## Responsibility

Defines the multi-day seasonal-median reference settings.

### Defaults

```text
maximum_same_type_days = 4
maximum_lookback_days = 30

level_1_window_minutes = 15
level_2_window_minutes = 30

level_1_min_clean_values = None
level_2_min_clean_values = 2
level_4_min_clean_values = 2
```

---

# 21. Phase 3 Validation

The relaxed Level 2 window cannot be narrower than Level 1:

```text
level_2_window_minutes
>=
level_1_window_minutes
```

The overall lookback must also be large enough to locate the requested number of same-type days:

```text
maximum_lookback_days
>=
maximum_same_type_days
```

---

# 22. Frequency-Specific Phase 3 Defaults

`level_1_min_clean_values` is deliberately optional because its default depends on the actual bucket.

Built-in values are:

```text
5-minute bucket  → 5 clean values
15-minute bucket → 3 clean values
```

For another bucket duration, if the user does not provide this setting explicitly, bucket resolution fails.

## This prevents the schema from guessing an appropriate reference requirement for frequencies that do not have an established default.

# 23. `Phase4ProphetConfig`

## Responsibility

Defines whether Phase 4 runs and configures the two-pass Prophet filling stage.

### Operational Defaults

```text
enabled = True
allow_full_series_fallback = True
minimum_history_days = 14
minimum_history_points = None
```

When `minimum_history_points` is `None`, the actual observation-count requirement is derived from:

```text
minimum_history_days
×
points_per_day
```

after bucket resolution.

---

# 24. Prophet Model Defaults

|Parameter|Default|
|---|--:|
|`changepoint_prior_scale`|`0.3`|
|`seasonality_prior_scale`|`20.0`|
|`seasonality_mode`|`additive`|
|`daily_seasonality`|`True`|
|`weekly_seasonality`|`True`|
|`yearly_seasonality`|`False`|
|`interval_width`|`0.95`|
|`noise_scale`|`1.0`|
|`random_seed`|`42`|

---

# 25. Prophet Field Constraints

The schema validates:

```text
minimum_history_days > 0
minimum_history_points > 0, when supplied

changepoint_prior_scale > 0
seasonality_prior_scale > 0

0 < interval_width < 1

noise_scale >= 0
random_seed >= 0
```

`seasonality_mode` is restricted to:

```text
additive
multiplicative
```

---

# 26. `ResolvedFrequencyConfig`

## Responsibility

This model does **not represent raw user configuration**.

Instead, it stores the finalized frequency-specific point counts produced after `PreprocessingConfig` is combined with the resolved `BucketConfig`.

It is configured as:

```text
extra = "forbid"
frozen = True
```

so after creation it acts as an immutable resolved contract for the ML stages.

---

# 27. Resolved Fields

`ResolvedFrequencyConfig` contains:

```text
bucket_minutes
gap_profile

centered_window_points
centered_min_valid_points

phase_1_maximum_anchor_search_points
phase_1_maximum_two_sided_distance_points

phase_2_neighbor_offset_points

phase_3_level_1_half_window_points
phase_3_level_2_half_window_points
phase_3_level_1_min_clean_values

points_per_day
prophet_minimum_history_points
```

Some fields remain `None` when the corresponding feature is not required.

For example, centred-IQR point settings remain `None` when a different outlier method is selected.

---

# 28. `PreprocessingConfig`

## Responsibility

This is the **top-level Part B preprocessing schema**.

Its fields are:

|Field|Type|
|---|---|
|`timeline_correction`|`TimelineCorrectionConfig`|
|`valid_values`|`ValidValueConfig`|
|`series_usability`|`SeriesUsabilityConfig`|
|`outlier`|`OutlierConfig`|
|`gap_profile`|`GapProfileConfig \| None`|
|`phase_1`|`Phase1Config`|
|`phase_2`|`Phase2Config`|
|`phase_3`|`Phase3Config`|
|`phase_4`|`Phase4ProphetConfig`|
|`save_intermediate_outputs`|`bool`|

Most sections have defaults.

The important exception is:

```text
outlier
```

which must be explicitly supplied because the schema does not automatically decide which outlier-detection method the run should use.

---

# 29. Cross-Section Validation

`PreprocessingConfig.validate_cross_section_settings()` connects two otherwise separate schema sections:

```text
ValidValueConfig
        +
OutlierConfig
```

When `user_bounds` is selected, any supplied user outlier threshold must lie inside the configured valid KPI range.

Therefore:

```text
valid lower
    <= user lower threshold
    <= valid upper
```

and similarly for the upper threshold.

This prevents an outlier threshold from contradicting the physical valid-value definition.

---

# 30. Intermediate Output Control

### `save_intermediate_outputs`

Default:

```text
False
```

This configuration controls whether Part B should preserve selected intermediate processing datasets in addition to its final output.

The schema merely records this preference.

The runner determines which actual checkpoint files are written.

---

# 31. Bucket-Dependent Resolution

One of the most important responsibilities of this schema package is:

### `PreprocessingConfig.resolve_for_bucket()`

Many user-facing settings are easier to understand in:

```text
minutes
days
```

while the actual ML algorithms operate on:

```text
number of timeline points
```

The schema resolves this difference once.

Example for a 15-minute dataset:

```text
60-minute anchor search
        │
        ▼
60 / 15
        │
        ▼
4 points
```

The runner can then give every Part B stage the exact same resolved values.

---

# 32. Bucket Normalization

The resolver first converts `BucketConfig` into whole minutes.

Supported bucket units are:

```text
seconds
minutes
hours
days
```

including singular versions.

Seconds must convert exactly into whole minutes.

Unsupported units are rejected.

The resolved bucket must be positive and the current schema requires it to fit a whole-number observation structure within a 1,440-minute day.

---

# 33. Minute-to-Point Conversion

The helper concept is:

```text
points = configured_minutes / bucket_minutes
```

The conversion must be exact.

For example:

```text
30 minutes / 15-minute bucket = 2 points
```

is valid.

But a setting such as:

```text
20 minutes / 15-minute bucket
```

cannot produce an exact whole number of timeline steps and is rejected.

This prevents algorithms from receiving silently rounded frequency settings.

---

# 34. Centred-IQR Resolution

Only when:

```text
method = one_day_centered_iqr
```

does the resolver create:

```text
centered_window_points
centered_min_valid_points
```

For the default 15-minute configuration:

```text
centered_window_minutes = 1440
1440 / 15 = 96 intervals

resolved rolling window = 96 + centre point
                        = 97 points
```

The default valid-reference requirement:

```text
720 / 15 = 48 points
```

The extra `+1` on the rolling window reflects that the resolved centred window includes the target/centre point itself.

---

# 35. Phase 1 Resolution

Minute settings are converted into:

```text
phase_1_maximum_anchor_search_points
phase_1_maximum_two_sided_distance_points
```

For the default 15-minute bucket:

```text
60 minutes → 4 points
30 minutes → 2 points
```

The distance ratio remains a normal configuration value because it does not depend on frequency.

---

# 36. Phase 2 Resolution

If:

```text
neighbor_offset_minutes = None
```

then:

```text
neighbor offset = one bucket
```

Therefore:

```text
15-minute dataset → 1 point
5-minute dataset  → 1 point
```

If a user supplies an explicit minute offset, it must divide exactly by the bucket duration.

---

# 37. Phase 3 Resolution

The schema converts the Phase 3 half-window durations into:

```text
phase_3_level_1_half_window_points
phase_3_level_2_half_window_points
```

It then resolves the Level 1 minimum clean-value requirement.

Finally, it calculates the **maximum possible reference pool sizes** and checks that configured requirements are physically achievable.

It validates:

- Level 1 minimum against the Level 1 pool;
    
- Level 2 minimum against the Level 2 pool;
    
- Level 4 minimum against the Level 4 reference window.
    

Therefore an impossible configuration is rejected before the ML filling stage begins.

---

# 38. Points Per Day

When the bucket permits complete-day resolution:

```text
points_per_day = 1440 / bucket_minutes
```

Examples:

```text
5-minute bucket  → 288 points/day
15-minute bucket → 96 points/day
```

This value supports day-based preprocessing behaviour, particularly Prophet history requirements.

---

# 39. Prophet History Resolution

When Phase 4 is enabled:

### User explicitly supplies `minimum_history_points`

That value is used.

### User leaves it as `None`

The schema derives:

```text
minimum_history_days
×
points_per_day
```

With defaults and a 15-minute bucket:

```text
14 days × 96 points/day
= 1344 minimum history points
```

For 5-minute data:

```text
14 × 288
= 4032 points
```

If Phase 4 is disabled, Prophet-specific resolved history can remain `None`.

---

# 40. Default Configuration Source

All default values live centrally in:

**`app/schemas/preprocessing/defaults.py`**

rather than being duplicated throughout the Pydantic models.

Major default groups are:

```text
Timeline policies
Valid-value rules
Series usability
Outlier settings
5/15-minute gap profiles
Phase 1
Phase 2
Phase 3
Phase 4 / Prophet
Output behaviour
```

Only names beginning with:

```text
DEFAULT_
```

are publicly exported by that module.

---

# 41. Public Package API

`__init__.py` re-exports:

```text
OutlierMethod
OutlierDirection
SeasonalityMode

GapProfileConfig
GapRangeConfig

OutlierConfig
Phase1Config
Phase2Config
Phase3Config
Phase4ProphetConfig

PreprocessingConfig
ResolvedFrequencyConfig

SeriesUsabilityConfig
TimelineCorrectionConfig
ValidValueConfig

build_5_minute_gap_profile
build_15_minute_gap_profile
```

This means processing code can use:

```text
from app.schemas.preprocessing import ...
```

without importing from the internal `preprocessing.py` file directly.

The package was explicitly structured to preserve existing imports after changing preprocessing from a single schema module into a package.

---

# 42. Responsibility Boundary

The Part B schema package does **not**:

- remove duplicate timestamps;
    
- insert missing timestamp rows;
    
- assign condition/status labels;
    
- calculate missing percentages;
    
- detect outliers;
    
- classify actual dataset gaps;
    
- interpolate values;
    
- calculate seasonal medians;
    
- fit Prophet models;
    
- generate cleaned datasets;
    
- write stage summaries.
    

Those operations belong to the Part B ML preprocessing module.

The schema instead answers:

```text
What strategies are allowed?
What parameter values are valid?
What defaults should be used?
What gap ranges belong to each phase?
How should frequency-dependent durations become point counts?
```

---

# 43. Relationship With the Shared Dataset Schema

The separation between the two schema areas is important.

### Shared Dataset Schema

Defines:

```text
Where is the dataset?
Which physical columns mean what?
What KPI/bucket information exists?
What expected timeline mode is being used?
```

### Part B Preprocessing Schema

Defines:

```text
How should that already-understood dataset be cleaned?
How are outliers configured?
What constitutes an unusable series?
Which gap belongs to which filling phase?
How should each filling phase behave?
Should Prophet run?
```

The only direct bridge required for Part B frequency resolution is the resolved shared:

```text
BucketConfig
```

This keeps dataset interpretation separate from preprocessing behaviour.

---

# 44. Overall Configuration Flow

```text
API / Pipeline Configuration
          │
          ▼
PreprocessingConfig
          │
          ├── TimelineCorrectionConfig
          ├── ValidValueConfig
          ├── SeriesUsabilityConfig
          ├── OutlierConfig
          ├── GapProfileConfig
          ├── Phase1Config
          ├── Phase2Config
          ├── Phase3Config
          └── Phase4ProphetConfig
          │
          ▼
Pydantic validation
          │
          ▼
Validated Part B Configuration
          │
          │      Part A resolved BucketConfig
          │                │
          └────────┬───────┘
                   ▼
         resolve_for_bucket()
                   │
                   ▼
         ResolvedFrequencyConfig
                   │
                   ▼
       Part B Processing Runner
                   │
                   ▼
       Individual ML Stages
```

---

# 45. Key Architectural Role

The most important architectural purpose of this schema is to provide **one validated source of truth for preprocessing behaviour**.

Without it, individual Part B files could independently decide:

```text
what counts as a valid KPI value
what missing percentage is acceptable
which outlier algorithm to use
how long an anchor search should be
which gap belongs to which phase
how many historical points Prophet requires
how minute settings convert to dataset points
```

Instead:

```text
PreprocessingConfig
```

contains the user-level configuration, while:

```text
ResolvedFrequencyConfig
```

contains the dataset-frequency-specific version that every ML stage receives.

That separation avoids repeatedly interpreting bucket-dependent settings throughout the Part B implementation.

---

# 46. Final Summary

The Part B preprocessing schema package has three clearly separated responsibilities:

```text
defaults.py
→ Stores centralized data-only default values without depending on
  Pydantic schema classes.

preprocessing.py
→ Defines all Part B Pydantic models, validation rules, built-in gap
  profiles and frequency-resolution logic.

__init__.py
→ Exposes the package's stable public schema interface.
```

At the model level:

```text
TimelineCorrectionConfig
→ Duplicate and off-grid policies.

ValidValueConfig
→ Physical KPI range and clipping behaviour.

SeriesUsabilityConfig
→ Maximum original missing percentage allowed for a usable series.

OutlierConfig
→ Detector, direction and detector-specific settings.

GapRangeConfig / GapProfileConfig
→ Complete mapping from original gap sizes to filling phases.

Phase1Config
→ Local anchor-search settings.

Phase2Config
→ Recent/last-week seasonal settings.

Phase3Config
→ Multi-day seasonal reference settings.

Phase4ProphetConfig
→ Optional Prophet filling and model controls.

PreprocessingConfig
→ Complete user-facing Part B configuration.

ResolvedFrequencyConfig
→ Immutable point-based settings after the Part A bucket is known.
```

Together, these schemas form the **configuration contract between the pipeline request and the Part B preprocessing implementation**, while keeping the actual data transformations inside the ML module.