# Shared Dataset Schema — Final Technical Report

**File Name:** `dataset.py`  
**File Location:** `app/schemas/common/dataset.py`

## 1. Purpose

`dataset.py` defines the **shared dataset input contract** used across the ML backend.

It does not belong specifically to Part A. Its schemas are designed to be reused by:

- Part A — EDA
    
- Part B — Preprocessing
    
- Part C — Feature Engineering
    
- Part D — Training
    
- Part E — Inference
    

Its responsibility is to describe **what information a dataset request contains and how that information must be validated before the ML modules use it**. It does not read, modify, split, or analyse CSV data itself.

---

# 2. Internal Project Dependencies

**None.**

This schema file does not import any other `app.*` project module.

This is useful because the common dataset schema remains independent from:

- ML implementation modules
    
- file services
    
- backend core utilities
    
- API routes
    
- individual pipeline stages
    

Other modules depend on this schema rather than this schema depending on them.

---

# 3. Main External Packages Used

### Pydantic

The schema layer is built using Pydantic:

- `BaseModel`
    
- `Field`
    
- `ConfigDict`
    
- `field_validator`
    
- `model_validator`
    

Pydantic provides:

- request-data parsing;
    
- type validation;
    
- default values;
    
- field constraints;
    
- rejection of unknown fields;
    
- cross-field validation.
    

### Python Standard Library

The file also uses:

- `datetime` — explicit timeline boundaries;
    
- `Path` — input CSV locations;
    
- `Literal` — restricts timeline mode to supported values.
    

---

# 4. Schema Structure

The file defines four main Pydantic models:

```text
DatasetInputConfig
│
├── DatasetColumnMapping
│
├── BucketConfig | None
│
├── single_kpi_name | None
│
└── ExpectedTimelineConfig
```

`DatasetInputConfig` is therefore the **top-level shared dataset configuration**, while the remaining schemas represent individual parts of that configuration.

---

# 5. `DatasetColumnMapping`

## Responsibility

Defines which **physical CSV columns** correspond to the logical fields expected by the backend.

This prevents the ML code from being permanently tied to one exact CSV naming convention.

For example, the backend logically requires a timestamp field, but the source dataset does not necessarily have to call it `time`; another physical column can be mapped to that role.

---

## Default Column Mapping

|Logical Meaning|Default CSV Column|
|---|---|
|Circle|`Jio_Circles`|
|Cluster|`Jio_Cluster`|
|Site Name|`AMF_Site_Name`|
|Timestamp|`time`|
|KPI Value|`computedValue`|
|KPI Name|`kpiName`|
|Server Type|`JIO_AMF_Server_Type`|
|Consequent Value|`consequentValue`|
|Bucket Type|`bucketType`|
|Bucket Size|`bucketSize`|

These defaults match the current Jio AMF dataset structure.

---

## Configuration Rules

The model uses:

```text
extra = "forbid"
str_strip_whitespace = True
```

Therefore:

- unexpected configuration fields are rejected;
    
- surrounding whitespace is removed from string values.
    

Every configured column name must also contain at least one character.

---

## Duplicate Mapping Validation

`validate_unique_column_mappings()`

ensures that two logical fields cannot point to the same physical CSV column.

For example, this is invalid:

```text
timestamp_column = "time"
value_column     = "time"
```

because the backend would no longer be able to distinguish timestamp data from KPI values.

The validation covers **all configured column mappings**.

---

## Helper Methods

### `get_base_required_columns()`

Returns the five columns fundamentally required for the dataset:

```text
circle
cluster
site name
timestamp
value
```

Using the default mapping:

```text
Jio_Circles
Jio_Cluster
AMF_Site_Name
time
computedValue
```

KPI and bucket columns are deliberately excluded because equivalent information may instead come from the request.

---

### `get_site_identity_columns()`

Returns:

```text
circle
cluster
site name
```

These three fields define one unique telecom site for the backend.

With the default configuration:

```text
Jio_Circles + Jio_Cluster + AMF_Site_Name
```

This common definition can therefore be reused consistently throughout the later ML modules.

---

### `get_optional_analysis_columns()`

Returns:

```text
server type
consequent value
```

These fields can be used for additional analysis but are not fundamental dataset requirements.

Their absence should therefore not automatically make a dataset unusable.

---

### `get_bucket_columns()`

Returns the configured:

```text
bucketType
bucketSize
```

columns.

These become mandatory from the CSV only when the caller has not supplied equivalent bucket information through the request.

---

# 6. `BucketConfig`

## Responsibility

Represents request-level information describing the expected time interval between observations.

It contains:

### `bucket_type`

A non-empty string describing the time unit.

Examples conceptually include:

```text
Minutes
Hours
Days
```

### `bucket_size`

A positive integer representing the number of those units between observations.

For example:

```text
bucket_type = "Minutes"
bucket_size = 15
```

represents a 15-minute dataset interval.

---

## Important Design Rule

`BucketConfig` is **optional inside `DatasetInputConfig`**.

Therefore bucket information may come from either:

```text
API/request configuration
```

or

```text
CSV columns
```

The schema itself records the requested value; later dataset-preparation logic determines how request and CSV bucket information are resolved together.

---

# 7. `ExpectedTimelineConfig`

## Responsibility

Defines how later timestamp-integrity analysis determines the timeline that the dataset is expected to cover.

Exactly three modes are supported:

```text
date_range
num_days
global_min_max
```

The default is:

```text
global_min_max
```

---

# 8. Timeline Modes

## A. `date_range`

The caller explicitly supplies:

```text
expected_start
expected_end
```

Example conceptually:

```text
expected_start = 2026-01-01 00:00
expected_end   = 2026-01-31 23:45
```

Validation requires:

- both boundaries must exist;
    
- `expected_end` must be later than `expected_start`;
    
- `num_days` must not also be supplied.
    

---

## B. `num_days`

The caller supplies:

```text
num_days
```

as a positive integer.

Later processing uses the earliest valid timestamp in each prepared KPI dataset as the beginning of the expected period.

When this mode is selected:

- `num_days` is mandatory;
    
- `expected_start` is forbidden;
    
- `expected_end` is forbidden.
    

---

## C. `global_min_max`

No additional timeline values are supplied.

Later integrity analysis derives the boundaries from:

```text
minimum valid timestamp
        ↓
maximum valid timestamp
```

found in the prepared KPI dataset.

This is the **default timeline mode**.

When selected, the request cannot additionally contain:

- `expected_start`
    
- `expected_end`
    
- `num_days`
    

This ensures that only one timeline definition acts as the source of truth.

---

# 9. `DatasetInputConfig`

## Responsibility

`DatasetInputConfig` is the main shared request-level dataset schema.

It combines all information necessary to identify and interpret the source dataset before the later ML stages process it.

It contains:

|Field|Type|Purpose|
|---|---|---|
|`input_file`|`Path`|Source CSV location|
|`columns`|`DatasetColumnMapping`|Physical CSV column mappings|
|`bucket`|`BucketConfig \| None`|Optional request-level bucket definition|
|`single_kpi_name`|`str \| None`|Declares a single KPI when necessary|
|`expected_timeline`|`ExpectedTimelineConfig`|Defines integrity-analysis timeline|

---

# 10. Input File Handling

### `input_file`

Stores the source CSV path as a Python `Path`.

The validator:

```text
normalise_input_file()
```

converts string/path-compatible input to a `Path` and expands the user-home marker:

```text
~
```

if present.

For example:

```text
~/datasets/input.csv
```

is normalized to a Path representation.

### Important Boundary

The schema **does not check**:

- whether the file exists;
    
- whether it is actually a file;
    
- its extension;
    
- its size;
    
- whether it can be read.
    

Those responsibilities are intentionally left to the file-service/dataset-processing layer.

This keeps schema validation separate from filesystem validation.

---

# 11. Single-KPI Handling

### `single_kpi_name`

Allows the caller to explicitly state that the complete input dataset represents one KPI.

This becomes important when the source CSV does not contain a KPI-name column.

Two possibilities therefore exist:

### KPI provided by CSV

```text
kpiName column exists
```

or

### KPI provided by request

```text
single_kpi_name = "..."
```

The schema records this choice while the actual KPI resolution and dataset splitting occur later during dataset preparation.

---

# 12. Dynamic Required-Column Logic

One important feature of the schema is that the required CSV columns depend on what information has already been supplied through the request.

### `get_required_source_columns()`

Starts with the five mandatory base fields:

```text
circle
cluster
site
timestamp
value
```

Then:

```text
IF single_kpi_name is absent
    require KPI-name column

IF bucket config is absent
    require bucketType
    require bucketSize
```

Therefore the dataset contract is **context-dependent rather than forcing redundant information into every CSV**.

---

# 13. Requirement Helper Methods

### `requires_kpi_column()`

Returns:

```text
True
```

when `single_kpi_name` was not supplied.

Meaning the CSV itself must provide KPI identity.

Returns:

```text
False
```

when the request explicitly declares a single KPI.

---

### `requires_bucket_columns()`

Returns:

```text
True
```

when no request-level `BucketConfig` exists.

The CSV must then provide bucket information.

Returns:

```text
False
```

when the request already supplies the bucket configuration.

---

# 14. Overall Validation Flow

The schema performs validation approximately as follows:

```text
Incoming Dataset Configuration
        │
        ▼
DatasetInputConfig
        │
        ├── Normalize input_file → Path
        │
        ├── DatasetColumnMapping
        │       ├── validate names
        │       └── reject duplicate mappings
        │
        ├── BucketConfig
        │       ├── non-empty type
        │       └── bucket_size > 0
        │
        ├── Optional single_kpi_name
        │
        └── ExpectedTimelineConfig
                │
                └── validate selected timeline mode
        │
        ▼
Validated Shared Dataset Configuration
        │
        ▼
Consumed by downstream ML modules
```

---

# 15. Schema Responsibility Boundary

A major architectural point is what this file **does not do**.

`dataset.py` does **not**:

- open the CSV;
    
- validate actual CSV contents;
    
- check whether filesystem paths exist;
    
- split multi-KPI datasets;
    
- resolve conflicting bucket values from the CSV;
    
- perform EDA;
    
- identify sites;
    
- analyse timestamps;
    
- clean values;
    
- generate features;
    
- train models;
    
- perform inference.
    

Instead, it defines the **validated configuration contract that those later stages receive**.

---

# 16. How Part A Uses This Shared Schema

Although the schema is shared across the backend, Part A directly relies on three of its models.

### `DatasetInputConfig`

Acts as the main input configuration passed into the Part A runner and dataset-preparation stage.

### `DatasetColumnMapping`

Provides Part A with the physical names of:

- site identity columns;
    
- timestamp column;
    
- value column;
    
- KPI column;
    
- server column;
    
- bucket columns.
    

This allows Part A logic to work with custom column names without changing its implementation.

### `BucketConfig`

Carries the resolved/requested bucket definition that Part A ultimately converts into the expected timestamp frequency.

`ExpectedTimelineConfig`, contained inside `DatasetInputConfig`, supplies Part A's choice between:

```text
date_range
num_days
global_min_max
```

for data-integrity analysis.

---

# 17. Key Architectural Role

The main architectural purpose of `dataset.py` is to create **one reusable dataset contract between the external request and every ML stage**.

Instead of each module independently deciding:

```text
Which column is the timestamp?
Which fields identify a site?
Where does KPI identity come from?
What bucket interval should be expected?
What time range should be analysed?
```

those decisions are represented once in the shared schema and then passed downstream.

This gives the ML backend a consistent interpretation of the same dataset across Parts A–E while still allowing different physical dataset structures through configurable column mappings.

---

## Final Summary

`app/schemas/common/dataset.py` is the common dataset-contract layer of the ML backend.

Its four models divide responsibilities clearly:

```text
DatasetColumnMapping
→ Defines what each physical CSV column means.

BucketConfig
→ Defines the dataset's requested time bucket.

ExpectedTimelineConfig
→ Defines how expected timeline boundaries are selected.

DatasetInputConfig
→ Combines the source path and all shared dataset configuration into
  the top-level validated input contract.
```

The file performs **configuration-level validation only**. Actual file validation, CSV inspection, data preparation, EDA, preprocessing, training, and inference remain responsibilities of the modules that consume this shared schema.