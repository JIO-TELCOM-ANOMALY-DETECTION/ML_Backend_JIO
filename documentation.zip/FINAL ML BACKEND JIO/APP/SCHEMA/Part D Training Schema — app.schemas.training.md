# Part D Training Schema — Final Technical Report 

**Schema Package:** `app/schemas/training/`

### Files

|File|Responsibility|
|---|---|
|`common.py`|Configuration shared by all Part D model types|
|`xgboost/defaults.py`|Data-only XGBoost estimator defaults, hyperparameters, tuning spaces, split defaults and validation rules|
|`xgboost/xgboost.py`|XGBoost Pydantic request models and direct/fixed/Optuna resolution|
|`isolation_forest/defaults.py`|Data-only Isolation Forest defaults, tuning spaces, split defaults and validation rules|
|`isolation_forest/isolation_forest.py`|Isolation Forest Pydantic request models and direct/fixed/Optuna resolution|

---

# 1. Purpose

The Part D schema defines the complete **model-training configuration contract** used after Part C has produced an engineered feature dataset.

It controls:

- selected model type;
    
- anomaly direction;
    
- whether hyperparameter tuning occurs;
    
- fixed-candidate vs Optuna tuning;
    
- direct-training hyperparameters;
    
- fixed candidate lists;
    
- Optuna search spaces;
    
- Optuna execution controls;
    
- chronological post-history splits;
    
- model-specific tuning-selection metrics;
    
- XGBoost residual calibration;
    
- model-specific feature/target rules;
    
- trusted training statuses;
    
- minimum usable row requirements.
    

The schema **does not**:

- read Part C datasets;
    
- create train/validation/calibration/test dataframe splits;
    
- fit models;
    
- perform Optuna studies;
    
- calculate XGBoost residual thresholds;
    
- calculate Isolation Forest scores;
    
- test models;
    
- save model artifacts.
    

Those operations belong to `app/ml/training/`.

---

# 2. Schema Architecture

```text
app/schemas/training/
│
├── common.py
│
├── xgboost/
│   ├── defaults.py
│   └── xgboost.py
│
└── isolation_forest/
    ├── defaults.py
    └── isolation_forest.py
```

The design separates:

```text
shared model-independent controls
                ↓
          common.py

model-specific data defaults
                ↓
          defaults.py

model-specific Pydantic validation
and runtime configuration resolution
                ↓
   xgboost.py / isolation_forest.py
```

---

# 3. Direct Project Dependencies

## Direct dependency on Part B schema

`common.py` imports:

```python
from app.schemas.preprocessing import OutlierDirection
```

Therefore Part D reuses the existing direction contract:

```text
lower_only
upper_only
both
```

instead of defining another incompatible direction type.

## No direct Part C or common-dataset import in these schema files

The current Part D schema package itself does **not directly import**:

```text
DatasetColumnMapping
ResolvedFeatureEngineeringConfig
```

Those are consumed by the **Part D ML validation/runner**, not by these five schema files.

The model-specific schema nevertheless defines internal rules describing how those later contracts must be interpreted.

---

# 4. `common.py`

## Main Types

```python
TrainingModelType = Literal[
    "xgboost",
    "isolation_forest",
]
```

and:

```python
HyperparameterTuningMethod = Literal[
    "fixed",
    "optuna",
]
```

---

# 5. `CommonTrainingConfig`

This is the base configuration inherited by both model-specific schemas.

Fields:

|Field|Meaning|
|---|---|
|`model_type`|Selected Part D algorithm|
|`threshold_direction`|Lower, upper or both anomaly directions|
|`hyperparameter_tuning_enabled`|Direct training vs hyperparameter tuning|
|`hyperparameter_tuning_method`|`fixed` or `optuna` when tuning is enabled|

`extra="forbid"` is enabled.

The tuning method defaults to:

```text
fixed
```

but it is ignored when:

```text
hyperparameter_tuning_enabled = False
```

---

# 6. Three Effective Training Strategies

Although the schema has a tuning boolean and tuning-method field, there are effectively three execution strategies:

```text
1. Direct training
   hyperparameter_tuning_enabled = False

2. Fixed-candidate tuning
   hyperparameter_tuning_enabled = True
   hyperparameter_tuning_method = "fixed"

3. Optuna tuning
   hyperparameter_tuning_enabled = True
   hyperparameter_tuning_method = "optuna"
```

Both XGBoost and Isolation Forest support all three.

---

# 7. Six Hyperparameter Input Modes

For each model the schema supports six user/default combinations.

### Direct training

```text
1. tuning OFF + user hyperparameters
2. tuning OFF + no hyperparameters
   → internal single default
```

### Fixed tuning

```text
3. tuning ON + method=fixed + user candidate list
4. tuning ON + method=fixed + no candidate list
   → internal default candidates
```

### Optuna tuning

```text
5. tuning ON + method=optuna + user search space
6. tuning ON + method=optuna + no search space
   → internal default Optuna search space
```

The current model schemas explicitly enforce these mutually exclusive modes.

---

# 8. History Is Not a Part D Split Percentage

A central architecture rule for **both models** is:

```text
Part C minimum_history_points
        │
        ▼
reserved first
        │
        ▼
remaining rows only
        │
        ▼
Part D percentage splits
```

Part D does not configure history as, for example, `10%`.

Instead, it expects the ML layer to reserve the exact:

```text
ResolvedFeatureEngineeringConfig.minimum_history_points
```

from Part C before applying model-specific percentages.

---

# 9. XGBoost Schema

Files:

```text
app/schemas/training/xgboost/defaults.py
app/schemas/training/xgboost/xgboost.py
```

XGBoost is treated as a **regression model whose prediction residual is later converted into an anomaly decision**.

---

# 10. Fixed XGBoost Estimator Parameters

These are fixed internal estimator settings:

```python
{
    "objective": "reg:squarederror",
    "tree_method": "hist",
    "eval_metric": "mae",
    "random_state": 42,
    "n_jobs": -1,
    "verbosity": 0,
}
```

They are **not** part of the user-configurable hyperparameter set.

---

# 11. XGBoost User-Configurable Hyperparameters

The complete configurable set is:

|Hyperparameter|Default|
|---|--:|
|`learning_rate`|`0.05`|
|`max_depth`|`3`|
|`min_child_weight`|`5`|
|`subsample`|`0.80`|
|`colsample_bytree`|`0.80`|
|`reg_alpha`|`0.0`|
|`reg_lambda`|`1.0`|
|`gamma`|`0.0`|

A user-supplied direct configuration or fixed candidate must provide **all eight keys**.

Partial dictionaries are rejected.

Unexpected hyperparameters are also rejected.

---

# 12. XGBoost Hyperparameter Validation

Rules include:

```text
learning_rate > 0

max_depth
→ integer
→ >= 0

min_child_weight >= 0

0 < subsample <= 1

0 < colsample_bytree <= 1

reg_alpha >= 0

reg_lambda >= 0

gamma >= 0
```

Boolean values are explicitly rejected where an integer/numeric value is expected.

---

# 13. XGBoost Default Fixed Candidates

The default fixed search contains four complete configurations.

They primarily vary:

- depth;
    
- learning rate;
    
- minimum child weight;
    
- row/column sampling;
    
- regularization.
    

Examples include:

```text
Candidate 1
learning_rate = 0.05
max_depth = 3
min_child_weight = 5
subsample = 0.80
colsample_bytree = 0.80
reg_alpha = 0
reg_lambda = 1
gamma = 0
```

and alternatives using:

```text
max_depth = 5
```

or stronger regularization / different learning rates.

Every candidate follows exactly the same complete eight-parameter contract.

---

# 14. XGBoost Optuna Range Model

## `XGBoostOptunaParameterRange`

Each Optuna-controlled parameter contains:

```text
low
high
log
```

The model is:

```text
extra = forbid
frozen = True
strict = True
```

Rules include:

```text
low < high
```

and when:

```text
log = True
```

then:

```text
low > 0
```

Integer XGBoost parameters require integer boundaries.

Parameter sampling type is not supplied by the user; it is derived from `XGBOOST_HYPERPARAMETER_RULES`.

---

# 15. Complete XGBoost Optuna Search Contract

Like direct/fixed configurations, a custom XGBoost Optuna search space is **all-or-none**.

If supplied, it must define ranges for all eight configurable hyperparameters.

Missing or unexpected parameter names cause validation failure.

---

# 16. Default XGBoost Optuna Search Space

|Parameter|Default search|
|---|---|
|`learning_rate`|`0.01–0.20`, log|
|`max_depth`|`2–10`|
|`min_child_weight`|`1–20`|
|`subsample`|`0.50–1.00`|
|`colsample_bytree`|`0.50–1.00`|
|`reg_alpha`|`0–5`|
|`reg_lambda`|`0–10`|
|`gamma`|`0–5`|

---

# 17. `XGBoostOptunaConfig`

Optuna execution controls are separate from the search space.

Defaults:

```text
n_trials = 50
sampler_seed = 42
```

`n_trials` must be positive.

The sampler seed may also be `None`.

---

# 18. XGBoost Chronological Splits

## Tuning enabled

The order is:

```text
history
   ↓
train
   ↓
validation
   ↓
calibration
   ↓
test
```

Default percentages **after history**:

|Split|%|
|---|--:|
|Train|60|
|Validation|10|
|Calibration|15|
|Test|15|

---

# 19. XGBoost Split Rules With Tuning Enabled

A custom split must provide either:

```text
none of the four percentages
```

or:

```text
all four percentages
```

A partial custom split is rejected.

Validation must be positive.

All four percentages must sum to:

```text
100%
```

within `1e-9`.

---

# 20. XGBoost Direct-Training Split

When tuning is disabled there is no validation stage:

```text
history
   ↓
train
   ↓
calibration
   ↓
test
```

The default validation share is absorbed into training:

```text
60 + 10
=
70% train
```

so the effective default direct split is:

|Split|%|
|---|--:|
|Train|70|
|Calibration|15|
|Test|15|

---

# 21. Direct XGBoost Custom Split Validation

When tuning is disabled:

- a nonzero `validation_percentage` is rejected;
    
- `train_percentage`, `calibration_percentage`, and `test_percentage` must either all be supplied or all omitted;
    
- they must sum to 100.
    

The resolved config explicitly stores:

```text
validation_percentage = 0
uses_validation_split = False
```

---

# 22. `ResolvedXGBoostSplitConfig`

Stores finalized values:

```text
train_percentage
validation_percentage
calibration_percentage
test_percentage
uses_validation_split
```

It is:

```text
extra = forbid
frozen = True
```

and therefore serves as an immutable resolved split contract.

---

# 23. `XGBoostTuningConfig`

Controls candidate/trial evaluation for **both fixed and Optuna tuning**.

Defaults:

```text
primary_selection_metric = "mae"
secondary_selection_metric = "rmse"

max_estimators = 800
early_stopping_rounds = 40
```

---

# 24. XGBoost Selection Metrics

Allowed metrics are:

```text
mae
rmse
```

The strings are stripped and lowercased.

The primary and secondary metrics must be different.

Therefore the default ranking is:

```text
Primary   → MAE
Tie-break → RMSE
```

---

# 25. XGBoost Residual Calibration Schema

## `XGBoostCalibrationConfig`

Contains:

```text
residual_quantile
```

Default:

```text
0.99
```

Constraint:

```text
0.5 < residual_quantile < 1.0
```

---

# 26. XGBoost Threshold-Direction Interpretation

`residual_quantile` represents the **upper residual tail**.

For:

```text
residual_quantile = 0.99
```

the complementary lower quantile is:

```text
1 - 0.99 = 0.01
```

Therefore:

```text
lower_only
→ use lower 0.01 quantile

upper_only
→ use upper 0.99 quantile

both
→ use both
```

Actual residual calculation and threshold generation occur in the ML calibration module, not the schema.

---

# 27. XGBoost Dataset Validation Rules

## `XGBoostValidationRules`

These are internal model rules rather than ordinary user-facing training settings.

The rules specify that XGBoost is supervised/self-supervised regression:

```text
X = selected Part C engineered features

y = physical KPI value column
    from DatasetColumnMapping.value_column
```

Source/metadata columns retained by Part C are not automatically added to `X`.

---

# 28. XGBoost Feature Contract

Defaults:

```text
use_only_resolved_feature_columns = True
require_all_resolved_features = True
```

Therefore Part D starts from the exact feature contract resolved by Part C rather than inferring feature columns from every numeric CSV column.

---

# 29. XGBoost Target-Leakage Feature Exclusions

The following Part C feature families are excluded from XGBoost `X` because they directly contain the same current KPI used as `y`:

```text
current_value
difference
percentage_change
seasonal_difference
rolling_zscore
residual
```

These columns may still physically exist in the Part C CSV; Part D simply excludes their resolved output columns from model `X`.

This is a **model-specific XGBoost rule**, not a restriction on Part C generating those features.

---

# 30. XGBoost Column Roles

The schema defines logical roles for:

```text
model_features
target
site_identity
timestamp
status
usability
invalid_reason
```

Important rules are:

```text
model_features
→ Part C resolved feature columns

target
→ DatasetColumnMapping.value_column

site identity
→ circle + cluster + site

timestamp
→ configured dataset timestamp

status
→ Current_Status_Label

usability
→ kpi_usability

invalid reason
→ kpi_invalid_reason
```

Only model features can enter `X`.

Only the physical KPI value is `y`.

---

# 31. XGBoost Trusted Target Statuses

Default:

```text
{1, 3}
```

meaning:

```text
1 = original valid
3 = safe fill
```

These are the statuses considered trustworthy for regression target training/calibration logic.

Default requirements also specify:

```text
require_complete_feature_rows = True
require_non_null_target = True
```

---

# 32. XGBoost Minimum Usable Rows

Defaults:

|Stage|Minimum usable points|
|---|--:|
|Train|1,000|
|Validation|400|
|Calibration|400|
|Test|400|

These are model-stage requirements later enforced by the ML implementation after its appropriate row filtering.

---

# 33. `XGBoostTrainingConfig`

This is the complete model-specific Part D XGBoost request.

Major fields are:

```text
model_type = "xgboost"

threshold_direction
hyperparameter_tuning_enabled
hyperparameter_tuning_method

split

hyperparameters
hyperparameter_candidates

optuna_search_space
optuna

tuning
calibration
```

---

# 34. XGBoost Mode Exclusivity

The schema rejects contradictory combinations.

### Tuning OFF

Allowed:

```text
hyperparameters
```

Not allowed:

```text
hyperparameter_candidates
optuna_search_space
optuna
```

### Fixed tuning

Allowed:

```text
hyperparameter_candidates
```

Not allowed:

```text
hyperparameters
optuna_search_space
optuna
```

### Optuna tuning

Allowed:

```text
optuna_search_space
optuna
```

Not allowed:

```text
hyperparameters
hyperparameter_candidates
```

---

# 35. XGBoost Resolution Helpers

`XGBoostTrainingConfig` exposes:

```text
resolve_hyperparameters()
```

for direct mode,

```text
resolve_hyperparameter_candidates()
```

for fixed tuning,

```text
resolve_optuna_search_space()
resolve_optuna_config()
```

for Optuna,

plus:

```text
resolve_split()
get_validation_rules()
```

Each resolver checks that it is being called in the correct mode.

---

# 36. Isolation Forest Schema

Files:

```text
app/schemas/training/isolation_forest/defaults.py
app/schemas/training/isolation_forest/isolation_forest.py
```

Isolation Forest differs fundamentally from XGBoost:

```text
XGBoost
→ regression prediction
→ residual calibration

Isolation Forest
→ unsupervised anomaly estimator
→ contamination/model boundary
```

Isolation Forest therefore has **no y target and no separate calibration split**.

---

# 37. Fixed Isolation Forest Estimator Parameters

Internal fixed estimator settings are:

```python
{
    "n_jobs": -1,
    "random_state": 42,
    "verbose": 0,
    "warm_start": False,
}
```

These are not user-configurable hyperparameters.

---

# 38. Isolation Forest User Hyperparameters

Complete configurable set:

|Parameter|Default|
|---|---|
|`n_estimators`|`300`|
|`max_samples`|`"auto"`|
|`contamination`|`0.01`|
|`max_features`|`1.0`|
|`bootstrap`|`False`|

Every explicit direct configuration and every fixed candidate must supply all five keys.

---

# 39. Isolation Forest Parameter Validation

### `n_estimators`

```text
integer > 0
```

### `max_samples`

May be:

```text
"auto"
positive integer
float in (0, 1]
```

### `contamination`

May be:

```text
"auto"
float/numeric in (0, 0.5]
```

### `max_features`

May be:

```text
positive integer
float in (0, 1]
```

### `bootstrap`

Must be boolean.

---

# 40. Default Isolation Forest Fixed Candidates

Four complete candidates are provided.

They vary primarily:

- number of trees;
    
- sample fraction;
    
- feature fraction.
    

The default candidate list deliberately keeps:

```text
contamination = 0.01
```

across all candidates.

The source comments explain that automatically comparing substantially different contamination values is considered less reliable without labelled anomalies; users may still provide their own valid candidates.

---

# 41. Isolation Forest Optuna Parameter Model

## `IsolationForestOptunaParameterConfig`

Supported search types:

```text
int
float
categorical
```

This is more flexible than the XGBoost search model because Isolation Forest parameters can naturally contain:

```text
"auto"
booleans
mixed categorical choices
```

---

# 42. Isolation Forest Optuna Structural Validation

For:

```text
type = categorical
```

the schema requires:

```text
choices
```

and rejects:

```text
low
high
log=True
```

For `int`/`float` searches:

```text
low and high required
choices forbidden
low < high
```

Logarithmic ranges require:

```text
low > 0
```

JSON lists supplied for categorical choices are normalized to tuples.

---

# 43. Isolation Forest Parameter-Type Compatibility

The schema also validates search type against the underlying parameter.

For example:

```text
n_estimators
→ int or categorical

bootstrap
→ categorical only

contamination
→ float or categorical

max_samples
→ int / float / categorical

max_features
→ int / float / categorical
```

The sampled values must still satisfy the normal Isolation Forest parameter contract.

---

# 44. Complete Isolation Forest Optuna Contract

A user-supplied search space must contain a definition for **all five configurable parameters**.

Missing or unexpected parameters are rejected.

When omitted entirely, the schema resolves its internal default Optuna space.

---

# 45. Default Isolation Forest Optuna Search Space

Defaults include:

### `n_estimators`

```text
int 100–500
```

### `max_samples`

```text
categorical:
"auto", 0.70, 0.80, 0.90, 1.00
```

### `contamination`

```text
categorical:
0.01
```

### `max_features`

```text
float 0.50–1.00
```

### `bootstrap`

```text
False / True
```

Again, default Optuna intentionally keeps contamination fixed at 1%.

---

# 46. `IsolationForestOptunaConfig`

Defaults:

```text
n_trials = 50
sampler_seed = 42
```

`n_trials > 0`.

As with XGBoost, Optuna controls are separate from the hyperparameter search-space definition.

---

# 47. Isolation Forest Chronological Splits

## Tuning enabled

Sequence:

```text
history
   ↓
train
   ↓
validation
   ↓
test
```

Default percentages:

|Split|%|
|---|--:|
|Train|70|
|Validation|15|
|Test|15|

---

# 48. Isolation Forest Tuning Split Validation

When tuning is enabled:

- either all three percentages are omitted;
    
- or train/validation/test must all be supplied;
    
- validation must be positive;
    
- all percentages must total 100.
    

Resolved:

```text
uses_validation_split = True
```

---

# 49. Isolation Forest Direct Split

When tuning is disabled:

```text
history
   ↓
train
   ↓
test
```

Defaults:

```text
train = 85%
test  = 15%
```

There is no validation stage and no calibration stage.

---

# 50. Isolation Forest Direct Custom Split

With tuning disabled:

- `validation_percentage` must be omitted or exactly `0`;
    
- train and test must either both be supplied or both omitted;
    
- train + test must equal 100.
    

Resolved:

```text
validation_percentage = 0
uses_validation_split = False
```

---

# 51. `ResolvedIsolationForestSplitConfig`

Stores:

```text
train_percentage
validation_percentage
test_percentage
uses_validation_split
```

and is frozen after resolution.

---

# 52. `IsolationForestTuningConfig`

The tuning-selection metric is:

```text
score_separation
```

and this is currently the **only supported metric**.

It is shared by both:

```text
fixed candidate tuning
Optuna tuning
```

The actual calculation of score separation belongs to the ML training module.

---

# 53. Isolation Forest Dataset Validation Rules

## `IsolationForestValidationRules`

Isolation Forest is explicitly defined as unsupervised:

```text
X = Part C resolved features

y = none
```

The source KPI value is not automatically treated as:

```text
a target
or
a feature
```

If Part C intentionally generated `current_value`, however, that generated feature can enter `X` because it is part of the resolved Part C feature contract.

---

# 54. Isolation Forest Feature Contract

Defaults:

```text
use_only_resolved_feature_columns = True
require_all_resolved_features = True
```

Like XGBoost, retained Part B/source metadata cannot accidentally become model features simply because it is numeric.

---

# 55. Isolation Forest Column Roles

Roles include:

```text
model_features
dataset_value
site_identity
timestamp
status
usability
invalid_reason
```

There is explicitly:

```text
no required y target
```

Structural/status/usability fields remain non-feature metadata.

---

# 56. Isolation Forest Direction Feature

Isolation Forest's own anomaly score is **not inherently “upper KPI” or “lower KPI.”**

Therefore the schema defines:

```text
direction feature = residual
```

for one-sided requests.

The rule is:

```text
lower_only
→ residual feature required

upper_only
→ residual feature required

both
→ residual not required solely for direction filtering
```

The actual sign-based filtering occurs later in the ML model logic.

---

# 57. Isolation Forest Trusted Training Statuses

Default:

```text
{1, 3}
```

meaning:

```text
1 = original valid
3 = safe fill
```

The default also requires:

```text
complete feature rows = True
```

---

# 58. Isolation Forest Minimum Usable Rows

Defaults:

|Stage|Minimum points|
|---|--:|
|Train|1,000|
|Validation|400|
|Test|400|

There is no calibration minimum because Isolation Forest has no calibration split.

---

# 59. `IsolationForestTrainingConfig`

Complete request fields include:

```text
model_type = "isolation_forest"

threshold_direction
hyperparameter_tuning_enabled
hyperparameter_tuning_method

split

hyperparameters
hyperparameter_candidates

optuna_search_space
optuna

tuning
```

There is intentionally no XGBoost-style:

```text
calibration
```

field.

---

# 60. Isolation Forest Mode Exclusivity

### Direct

Allowed:

```text
hyperparameters
```

Rejected:

```text
hyperparameter_candidates
optuna_search_space
optuna
```

### Fixed tuning

Allowed:

```text
hyperparameter_candidates
```

Rejected:

```text
hyperparameters
optuna_search_space
optuna
```

### Optuna

Allowed:

```text
optuna_search_space
optuna
```

Rejected:

```text
hyperparameters
hyperparameter_candidates
```

---

# 61. Isolation Forest Resolution Helpers

The model provides:

```text
resolve_hyperparameters()
resolve_hyperparameter_candidates()

resolve_optuna_search_space()
resolve_optuna_config()

resolve_split()
get_validation_rules()
```

Each is callable only in its valid execution mode.

---

# 62. XGBoost vs Isolation Forest — Schema Comparison

|Contract|XGBoost|Isolation Forest|
|---|---|---|
|Learning type|Regression/self-supervised|Unsupervised anomaly model|
|Model input|Selected Part C features|All resolved Part C model features|
|y target|Physical KPI value|None|
|Trusted statuses|`{1,3}`|`{1,3}`|
|Tuning OFF|Train/Cal/Test|Train/Test|
|Tuning ON|Train/Val/Cal/Test|Train/Val/Test|
|Default tuning split|60/10/15/15|70/15/15|
|Default direct split|70/15/15|85/15|
|Fixed tuning|Yes|Yes|
|Optuna|Yes|Yes|
|Default Optuna trials|50|50|
|Calibration|Residual quantile|None|
|Anomaly boundary|Residual threshold|IF contamination/offset|
|Direction|Residual tail|Residual sign after IF anomaly|
|Min train|1000|1000|
|Min validation|400|400|
|Min calibration|400|—|
|Min test|400|400|

---

# 63. Shared Direct / Fixed / Optuna Flow

```text
CommonTrainingConfig
        │
        ├── model_type
        ├── threshold_direction
        ├── tuning_enabled
        └── tuning_method
               │
               ▼
        Model-specific schema
               │
       ┌───────┼────────┐
       │       │        │
       ▼       ▼        ▼
    DIRECT   FIXED    OPTUNA
       │       │        │
single/default │    search/default
hyperparams    │    search space
               │
          candidates/default
               │
       └───────┼────────┘
               ▼
         resolve_split()
               │
               ▼
     model validation rules
               │
               ▼
        Part D ML module
```

---

# 64. Relationship to Part C

The most important Part C → Part D schema concept is:

```text
minimum_history_points
```

Part D's model split percentages explicitly **exclude that reserved history**.

Part C also determines the feature contract that the Part D ML validation later checks.

However, those Part C objects are not imported directly into the model-specific schema files.

This keeps:

```text
training-request configuration
```

separate from:

```text
runtime dataset/feature validation
```

---

# 65. Relationship to Part B

Part D's direct schema-level dependency on Part B is intentionally small:

```text
OutlierDirection
```

This gives Part D the same vocabulary:

```text
lower_only
upper_only
both
```

The model-specific validation rules additionally refer to the stable Part B output columns:

```text
Current_Status_Label
kpi_usability
kpi_invalid_reason
```

but the actual physical validation of those columns occurs later in the Part D ML validation module.

---

# 66. `defaults.py` Responsibility

Both model defaults files intentionally contain **data only**.

They do not import the Pydantic schema classes.

This prevents circular dependencies:

```text
defaults.py
     ↓
model schema imports defaults

NOT

defaults.py ↔ model schema
```

The defaults therefore act as the centralized source of truth for:

- estimator constants;
    
- configurable parameter keys;
    
- validation metadata;
    
- single defaults;
    
- fixed candidates;
    
- Optuna spaces;
    
- split percentages;
    
- tuning controls;
    
- model validation policy;
    
- minimum row counts.
    

---

# 67. Important Configuration Principle — Complete Hyperparameter Sets

Both models deliberately use an **all-or-none contract**.

For direct training:

```text
complete user hyperparameter set
OR
internal complete default
```

For fixed tuning:

```text
complete candidate configurations
OR
internal complete candidates
```

For Optuna:

```text
complete search space
OR
internal complete search space
```

The schema does not merge a partial user dictionary into internal defaults.

This avoids ambiguous training configurations.

---

# 68. Important Configuration Principle — Split Resolution

The request-level split fields are optional.

The schema converts them into an explicit resolved contract depending on:

```text
hyperparameter_tuning_enabled
```

This prevents the ML loader from having to decide whether a validation split exists.

It receives resolved information such as:

```text
uses_validation_split = True/False
```

from the model schema.

---

# 69. Important Configuration Principle — Model-Specific Feature Policy

Part D does **not** use the naive rule:

```text
all numeric columns = model features
```

Instead, each model carries a schema-defined feature/column-role policy.

### XGBoost

```text
Part C resolved features
minus target-leaking feature families
```

### Isolation Forest

```text
Part C resolved features
```

with no automatically inferred KPI-value target or feature.

The actual enforcement occurs in `app/ml/training/validation.py`.

---

# 70. Schema Responsibility Boundary

The Part D schema answers:

```text
Which model should be trained?

Which anomaly direction is requested?

Should hyperparameters be direct, fixed-tuned, or Optuna-tuned?

What constitutes a valid complete hyperparameter configuration?

What default candidates/search space should be used?

What chronological percentages apply after Part C history?

Does this mode require validation?

What tuning metric should select the model?

How should XGBoost residual calibration be configured?

Which Part C features are allowed in model X?

Is there a y target?

Which Part B statuses are trusted?

How many usable rows are required?
```

It does **not answer**:

```text
Which rows actually satisfy these rules?
How many usable rows are present?
Where do exact split timestamps fall?
Which candidate/trial wins?
What are the calibrated thresholds?
Which test points are anomalous?
Where should the final model files be saved?
```

Those belong to the Part D ML implementation.

---

# 71. Final Configuration Flow

```text
API / Pipeline training request
              │
              ▼
      CommonTrainingConfig
              │
       model discriminator
        ┌─────┴─────┐
        │           │
        ▼           ▼
     XGBoost   Isolation Forest
        │           │
        ▼           ▼
  model-specific Pydantic validation
        │           │
        ├───────────┤
        │
        ▼
Resolve execution mode
        │
        ├── Direct
        ├── Fixed tuning
        └── Optuna tuning
        │
        ▼
Resolve hyperparameter contract
        │
        ▼
Resolve chronological split
        │
        ▼
Resolve internal validation rules
        │
        │  + Part C history/feature contract
        │  + DatasetColumnMapping
        │
        ▼
      Part D ML
```

---

# 72. Final Summary

The Part D schema package is organized around **one shared training contract and two strongly separated model contracts**.

```text
common.py
→ Defines model choice, anomaly direction, tuning switch and
  fixed-vs-Optuna tuning method.

xgboost/defaults.py
→ Stores XGBoost estimator constants, complete hyperparameter contract,
  fixed candidates, Optuna ranges, tuning defaults, split defaults,
  residual calibration default and dataset-validation policy.

xgboost/xgboost.py
→ Validates direct/fixed/Optuna XGBoost requests, resolves model splits,
  controls tuning/early stopping, defines residual calibration, and exposes
  fixed XGBoost feature/target validation rules.

isolation_forest/defaults.py
→ Stores Isolation Forest estimator constants, complete hyperparameter
  contract, candidates, Optuna definitions, tuning/split defaults,
  direction-feature policy and dataset-validation rules.

isolation_forest/isolation_forest.py
→ Validates direct/fixed/Optuna Isolation Forest requests, resolves
  train/validation/test percentages and exposes the unsupervised model
  validation/directional contract.
```

The key architectural distinction is:

```text
XGBoost
Part C history
→ regression train
→ optional validation tuning
→ residual calibration
→ test

Isolation Forest
Part C history
→ unsupervised train
→ optional validation tuning
→ test
```

while **both models support direct training, predefined fixed-candidate tuning, and Optuna search through the same high-level Part D configuration philosophy**.