# Part C Feature Engineering Schema — Final Technical Report

**Schema Package Location:** `app/schemas/feature_engineering/`

### Files

|File|Responsibility|
|---|---|
|`__init__.py`|Public exports for the Part C schema package|
|`defaults.py`|Shared feature defaults and algorithm-specific XGBoost / Isolation Forest default profiles|
|`feature_engineering.py`|Feature request schemas, source/cleaning configuration, output naming, validation, history calculation, and bucket-aware resolution|

---

# 1. Purpose

The Part C schema defines **which features should be generated and exactly how those feature requests must be configured before the Part C ML module runs**.

It controls:

- requested feature families;
    
- raw vs corrected-history source selection;
    
- local referenced-point cleaning;
    
- temporary corrected-history settings;
    
- lag/window/span values;
    
- rolling statistics;
    
- time and calendar features;
    
- weighted seasonal baseline configuration;
    
- residual configuration;
    
- XGBoost and Isolation Forest default profiles;
    
- deterministic output-column names;
    
- repeated-feature naming;
    
- bucket-dependent conversion;
    
- minimum history requirements;
    
- maximum historical lookback;
    
- whether Part B columns are retained;
    
- whether intermediate source-preparation outputs may be saved.
    

The schema **does not calculate the actual features or modify dataframes**. Those responsibilities belong to the Part C ML module.

---

# 2. Internal Project Dependency

The Part C schema directly depends on the shared:

`app.schemas.common.dataset.BucketConfig`

Part A resolves the actual dataset bucket, and Part C uses that bucket when:

- calculating `bucket_minutes`;
    
- calculating `points_per_day`;
    
- converting minute-based settings into exact point counts;
    
- constructing frequency-dependent default features;
    
- calculating history requirements.
    

Conceptually:

```text
BucketConfig from shared dataset contract
              │
              ▼
FeatureEngineeringConfig.resolve_for_bucket()
              │
              ▼
ResolvedFeatureEngineeringConfig
```

---

# 3. Package Organization

```text
app/schemas/feature_engineering/
│
├── __init__.py
├── defaults.py
└── feature_engineering.py
```

### `defaults.py`

Owns default feature profiles and default parameter values.

### `feature_engineering.py`

Owns the actual Pydantic feature-request models, validation and bucket-aware resolution.

### `__init__.py`

Provides the stable public import surface:

```python
from app.schemas.feature_engineering import ...
```

---

# 4. Main Configuration Structure

At the highest level:

```text
FeatureEngineeringConfig
│
├── features | None
├── default_profile
├── default_features
├── corrected_history
├── retain_original_columns
└── save_intermediate_outputs
```

The individual entries in `features` can represent:

```text
current_value
lag
rolling
time_bucket
time_cyclic
calendar
difference
percentage_change
seasonal_difference
rolling_zscore
ewma
rolling_slope
baseline
residual
```

These are combined into the discriminated `FeatureRequest` union using the request's `type` field.

---

# 5. Supported Feature Sources

The schema defines:

```text
FeatureSource =
    "raw_value"
    | "corrected_history"
```

### `raw_value`

Means the feature should use the Part B KPI value as its source.

### `corrected_history`

Means the feature should use Part C's temporary corrected-history series.

This source choice is explicit at the feature-request level rather than globally forcing every value-based feature to use the same source.

---

# 6. Corrected History Configuration

## `CorrectedHistoryConfig`

This defines the optional temporary cleaned history used only when at least one requested feature selects:

```text
source = "corrected_history"
```

Default settings are:

|Setting|Default|
|---|---|
|`bad_statuses`|`{2}`|
|`replace_missing_values`|`True`|
|`replacement_method`|`trailing_median`|
|`replacement_window_minutes`|`60`|
|`replacement_window_points`|`None`|
|`minimum_periods`|`1`|
|`forward_fill_remaining`|`True`|

The schema therefore treats status `2`—Part B outliers—as unavailable by default when constructing corrected history.

---

# 7. Corrected-History Window Rules

The replacement window may be represented in either:

```text
minutes
```

or:

```text
exact timeline points
```

but not both.

The schema requires **exactly one** of:

```text
replacement_window_minutes
replacement_window_points
```

If minute-based configuration is used, it is later converted according to the dataset bucket.

It also validates:

```text
minimum_periods <= resolved window points
```

and rejects a configuration that neither masks any statuses nor replaces missing values.

---

# 8. Local Median Cleaning

## `LocalMedianCleaningConfig`

This is a separate cleaning strategy used around a **referenced historical point**, such as a lag reference.

Defaults:

|Setting|Default|
|---|---|
|`enabled`|`False`|
|`method`|`local_median`|
|`bad_statuses`|`{2}`|
|`accepted_statuses`|`{1, 3, 4}`|
|`half_window_minutes`|`720`|
|`half_window_points`|`None`|
|`minimum_valid_points`|`1`|
|`unavailable_strategy`|`nan`|

So local cleaning is **opt-in**, not part of the default corrected-history approach.

---

# 9. Local Median Validation

When local cleaning is enabled:

- `bad_statuses` cannot be empty;
    
- `accepted_statuses` cannot be empty;
    
- the two sets cannot overlap;
    
- exactly one half-window representation must be supplied:
    
    - minutes; or
        
    - points;
        
- `minimum_valid_points` cannot exceed the complete configured local window.
    

The fallback when no median can be generated is restricted to:

```text
nan
keep_source
```

---

# 10. Important Source/Cleaning Separation

The schema deliberately treats:

```text
corrected_history
```

and:

```text
raw_value + local median cleaning
```

as **two separate approaches**.

Therefore configurations such as:

```text
source = "corrected_history"
point_cleaning.enabled = True
```

are rejected.

The same restriction also applies when a weighted seasonal baseline uses `corrected_history`: its local anchor-median window must be zero.

---

# 11. `CurrentValueFeatureRequest`

The simplest feature request is:

```text
type = "current_value"
```

It exposes no source choice and no cleaning configuration.

Its canonical output column is:

```text
current_value
```

The schema deliberately keeps this feature tied to the direct current-value concept.

---

# 12. `LagFeatureRequest`

Defines exact point-based lags.

Important fields:

```text
type = "lag"
lags
source
point_cleaning
```

Default source:

```text
corrected_history
```

Lag values must be:

- positive;
    
- unique;
    
- non-empty.
    

The list is normalized into ascending order.

Example:

```text
lags = [1, 96, 672]
```

produces canonical names:

```text
lag_1
lag_96
lag_672
```

---

# 13. Rolling Statistics

## `RollingFeatureRequest`

Supports:

```text
mean
median
mad
std
min
max
range
iqr
```

Fields include:

```text
statistics
windows
source
minimum_periods
std_ddof
```

Default source:

```text
corrected_history
```

Default:

```text
std_ddof = 1
```

which represents sample standard deviation.

Windows must be unique positive point counts.

If `minimum_periods` is supplied:

```text
minimum_periods <= smallest selected window
```

---

# 14. Rolling Output Naming

For:

```text
statistics = ["median", "mad"]
windows = [4]
```

the canonical columns are:

```text
rolling_median_4
rolling_mad_4
```

For multiple windows, output naming is deterministic using:

```text
rolling_<statistic>_<window>
```

---

# 15. Time Bucket Features

## `TimeBucketFeatureRequest`

Contains:

```text
type = "time_bucket"
bucket_minutes = [...]
```

Every configured bucket must:

- be positive;
    
- be unique;
    
- divide `1,440` minutes exactly.
    

Example:

```text
bucket_minutes = [30]
```

produces:

```text
time_bucket_30m
```

---

# 16. Cyclical Time Features

## `TimeCyclicFeatureRequest`

Allowed values are:

```text
sin_tod
cos_tod
```

Requests must contain at least one feature and cannot contain duplicates.

The output columns use those names directly.

---

# 17. Calendar Features

## `CalendarFeatureRequest`

Allowed values:

```text
is_weekend
day_of_week
day_sin
day_cos
```

Again:

- at least one feature is required;
    
- duplicates are rejected.
    

The requested names directly become output column names.

---

# 18. Lag-Based Comparison Requests

Three feature types share the same core configuration:

```text
DifferenceFeatureRequest
PercentageChangeFeatureRequest
SeasonalDifferenceFeatureRequest
```

They all contain:

```text
lags
source
point_cleaning
```

with default:

```text
source = "corrected_history"
```

Local median cleaning can only be enabled when the source is `raw_value`.

---

# 19. Difference Feature

Request:

```text
type = "difference"
```

Canonical output:

```text
difference_<lag>
```

Example:

```text
difference_1
difference_96
```

---

# 20. Percentage Change

Request:

```text
type = "percentage_change"
```

Output:

```text
percentage_change_<lag>
```

Its only supported zero-denominator behaviour is:

```text
zero_denominator_strategy = "nan"
```

so infinity is not part of the defined feature contract.

---

# 21. Seasonal Difference

Request:

```text
type = "seasonal_difference"
```

uses user-provided exact lag points but is intentionally distinguished from ordinary `difference`.

Canonical naming:

```text
seasonal_difference_<lag>
```

This allows configuration and later model reporting to distinguish general lag movement from explicitly seasonal comparisons.

---

# 22. Rolling Z-Score

## `RollingZScoreFeatureRequest`

Fields:

```text
windows
source
minimum_periods
std_ddof
zero_std_strategy
```

Defaults:

```text
source = "corrected_history"
std_ddof = 1
zero_std_strategy = "nan"
```

Windows must be positive and unique.

If supplied:

```text
minimum_periods <= smallest window
```

Output naming:

```text
rolling_zscore_<window>
```

---

# 23. EWMA

## `EWMAFeatureRequest`

Fields:

```text
spans
source
adjust
```

Defaults:

```text
source = "corrected_history"
adjust = False
```

Only recursive:

```text
adjust=False
```

is supported by the schema.

Spans must be positive and unique.

Output naming:

```text
ewma_<span>
```

---

# 24. Rolling Slope

## `RollingSlopeFeatureRequest`

Fields:

```text
windows
source
minimum_periods
```

Default source:

```text
corrected_history
```

Rules:

- each window must contain at least `2` points;
    
- `minimum_periods`, if supplied, must be at least `2`;
    
- it cannot exceed the smallest requested window.
    

Output naming:

```text
rolling_slope_<window>
```

---

# 25. Weighted Seasonal Baseline

## `WeightedSeasonalBaselineConfig`

The currently supported baseline method is:

```text
weighted_seasonal
```

Default configuration:

|Setting|Default|
|---|--:|
|`source`|`raw_value`|
|`anchor_statuses`|`{1, 3}`|
|`recent_fallback_days`|`14`|
|`weekly_fallback_weeks`|`3`|
|`recent_weight`|`0.8`|
|`weekly_weight`|`0.2`|
|`anchor_window_each_side_points`|`1`|
|`slot_fallback_points`|`10`|
|`slot_tolerance_minutes`|`None`|
|`minimum_history_days`|`7`|

---

# 26. Baseline Validation

The schema requires:

```text
anchor_statuses != empty
```

and:

```text
recent_weight + weekly_weight = 1.0
```

within a very small floating-point tolerance.

If:

```text
source = corrected_history
```

then:

```text
anchor_window_each_side_points = 0
```

because a positive anchor window represents another local-median cleaning operation.

---

# 27. Slot Tolerance Resolution

If:

```text
slot_tolerance_minutes = None
```

the schema resolves it to:

```text
one dataset bucket
```

on either side of the target time slot.

If explicitly supplied, the tolerance duration must convert exactly into timeline points for the resolved dataset bucket.

---

# 28. Standalone Baseline Request

## `BaselineFeatureRequest`

```text
type = "baseline"
baseline = WeightedSeasonalBaselineConfig(...)
```

Its output column is:

```text
baseline
```

---

# 29. Residual Request

## `ResidualFeatureRequest`

Contains:

```text
type = "residual"
source
baseline
include_baseline_column
```

Default current source:

```text
raw_value
```

The baseline has its own independent source.

Therefore these can be configured separately.

The schema currently requires:

```text
include_baseline_column = True
```

so a residual request always owns both canonical outputs:

```text
baseline
residual
```

---

# 30. Feature Request Union

All supported request models are combined into:

```text
FeatureRequest
```

using the discriminating field:

```text
type
```

For example:

```json
{
  "type": "lag",
  "lags": [1, 96]
}
```

is parsed as `LagFeatureRequest`, while:

```json
{
  "type": "rolling_zscore",
  "windows": [4]
}
```

is parsed as `RollingZScoreFeatureRequest`.

This gives the API one structured heterogeneous feature list while maintaining strict validation for each feature family.

---

# 31. Canonical Output Naming

The helper:

```text
get_feature_columns()
```

defines the authoritative canonical output names.

|Request|Canonical Output|
|---|---|
|current value|`current_value`|
|lag|`lag_<n>`|
|rolling|`rolling_<stat>_<window>`|
|time bucket|`time_bucket_<minutes>m`|
|time cyclic|requested names|
|calendar|requested names|
|difference|`difference_<lag>`|
|percentage change|`percentage_change_<lag>`|
|seasonal difference|`seasonal_difference_<lag>`|
|rolling z-score|`rolling_zscore_<window>`|
|EWMA|`ewma_<span>`|
|rolling slope|`rolling_slope_<window>`|
|baseline|`baseline`|
|residual|`baseline`, `residual`|

---

# 32. Repeated Feature Requests

The current schema deliberately allows some feature families to be requested more than once.

Repeatable families are:

```text
lag
rolling
difference
percentage_change
seasonal_difference
rolling_zscore
ewma
rolling_slope
```

If the same canonical output appears again within the **same repeatable family**, deterministic suffixes are applied:

```text
lag_1
lag_1_s2
lag_1_s3
```

The first occurrence keeps its canonical name.

---

# 33. Disallowed Output Collisions

Repetition is rejected when:

- the feature family is not repeatable;
    
- two different feature families attempt to own the same canonical name;
    
- a repeatable feature collides with a non-repeatable feature.
    

For example, because residual inherently outputs:

```text
baseline
residual
```

a separate baseline request producing `baseline` would create a disallowed collision.

This validation occurs before feature generation.

---

# 34. `FeatureEngineeringConfig`

This is the **top-level Part C request schema**.

Fields:

|Field|Purpose|
|---|---|
|`features`|Explicit requested feature list|
|`default_profile`|Algorithm profile used when `features` is omitted|
|`default_features`|Configuration of XGBoost/Isolation Forest defaults|
|`corrected_history`|Shared temporary-history configuration|
|`retain_original_columns`|Whether final output retains Part B columns|
|`save_intermediate_outputs`|Whether optional Part C audit outputs may be saved|

---

# 35. Custom Features vs Default Profile

### Explicit custom configuration

```text
features = [ ... ]
```

means:

> generate exactly these validated feature requests.

### No explicit features

```text
features = None
```

means:

> build the schema-owned default profile.

An explicit:

```text
features = []
```

is rejected.

The caller must omit the field to request defaults.

---

# 36. Default Profile Selection

Supported default profiles:

```text
xgboost
isolation_forest
```

The top-level default is:

```text
default_profile = "xgboost"
```

The profiles are stored in:

```text
DefaultFeatureProfilesConfig
├── xgboost
└── isolation_forest
```

---

# 37. Default XGBoost Feature Profile

The XGBoost default profile currently produces:

### Lags

Using:

```text
source = corrected_history
```

with:

```text
previous-point lag = 1
daily lag          = points_per_day
weekly lag         = points_per_day × 7
```

Local-median lag cleaning is disabled by default.

### Rolling

```text
source = corrected_history
statistics = median, mad
window = 60 minutes converted to points
```

### Time Bucket

```text
30-minute time bucket
```

### Calendar

```text
is_weekend
```

For a 15-minute dataset, this conceptually resolves to:

```text
lag_1
lag_96
lag_672
rolling_median_4
rolling_mad_4
time_bucket_30m
is_weekend
```

---

# 38. Default Isolation Forest Feature Profile

The Isolation Forest default profile produces:

### Current Value

```text
current_value
```

### Residual + Baseline

Current source:

```text
raw_value
```

with weighted-seasonal baseline using by default:

```text
baseline source = raw_value
anchor statuses = {1,3}
anchor local window = 1 point each side
```

### Rolling

```text
rolling median
60-minute window
source = corrected_history
```

### Daily Lag

```text
points_per_day
source = corrected_history
```

### Time Bucket

```text
30-minute bucket
```

### Time Cyclic

```text
sin_tod
cos_tod
```

### Calendar

```text
is_weekend
```

---

# 39. Default-Profile Separation

`defaults.py` deliberately creates **plain feature request payloads** rather than importing all request models from `feature_engineering.py`.

Those payloads are later parsed through the same `FeatureRequest` validation used for custom requests.

This avoids circular imports while ensuring default-generated requests and user-supplied requests ultimately obey the same feature contract.

---

# 40. Dataset Bucket Resolution

`FeatureEngineeringConfig.resolve_for_bucket()` converts the shared `BucketConfig` into minutes.

Supported Part C bucket units are:

```text
minute / minutes / min / mins
hour / hours / hr / hrs
day / days
```

Part C's schema does **not** currently support seconds.

The resolved bucket must divide:

```text
1,440 minutes
```

exactly.

Then:

```text
points_per_day = 1440 / bucket_minutes
```

For example:

```text
15-minute dataset → 96 points/day
5-minute dataset  → 288 points/day
```

---

# 41. Exact Duration Conversion

Whenever the schema converts minutes to points:

```text
points = duration_minutes / bucket_minutes
```

the division must be exact.

It does not silently round durations.

For example:

```text
60 minutes / 15 = 4 points
```

is valid.

A configured duration that cannot map exactly to the dataset grid is rejected.

---

# 42. History Requirements

The helper:

```text
get_request_history_requirements()
```

returns:

```text
(minimum_history_points, maximum_lookback_points)
```

for every requested feature.

This allows the Part C runner to understand how much history the selected feature set expects before generation begins.

---

# 43. History Rules by Feature

### Current / Time / Calendar

```text
minimum history = 1
maximum lookback = 0
```

### Lag / Difference / Percentage / Seasonal Difference

For maximum lag `L`:

```text
minimum history = L + 1
maximum lookback = L
```

### Rolling / Z-score / Slope

For maximum window `W`:

```text
minimum history = W + 1
maximum lookback = W
```

### EWMA

The schema uses:

```text
minimum history = 2
maximum practical lookback = maximum configured span
```

because the feature begins from previous history rather than the current point.

---

# 44. Baseline / Residual History

For weighted seasonal baseline and residual:

```text
minimum_history =
    minimum_history_days
    × points_per_day
```

The maximum seasonal search is:

```text
max(
    recent_fallback_days,
    weekly_fallback_weeks × 7
)
```

Therefore:

```text
maximum_lookback =
    maximum seasonal days × points_per_day
    + anchor_window_each_side_points
```

With the default baseline configuration, warm-up is:

```text
7 days
```

---

# 45. Adaptive Local-Median History Resolution

For lag-based local cleaning, the current schema accounts for leakage-safe asymmetric windows.

For:

```text
lag = L
nominal half-window = h
```

the maximum right side is:

```text
safe_right = min(h, L - 1)
```

The schema verifies that:

```text
minimum_valid_points
```

can actually be satisfied inside that reduced safe window.

It also increases the resolved history requirement to include the extra left-side window:

```text
minimum_history_points
≥ maximum_lag + h + 1
```

and:

```text
maximum_lookback_points
≥ maximum_lag + h
```

This is important because the schema's current revision explicitly aligns history calculation with the leakage-safe lag implementation.

---

# 46. Status-Column Requirement Resolution

Part C does not always require the Part B `Current_Status_Label`.

The resolved schema determines this dynamically.

The status column becomes required when, for example:

- `corrected_history` is used;
    
- local median cleaning is enabled;
    
- baseline is requested;
    
- residual/baseline anchor filtering is required.
    

Pure timestamp-derived features such as:

```text
time_bucket
time_cyclic
calendar
```

do not inherently require status information.

---

# 47. `ResolvedFeatureEngineeringConfig`

After bucket resolution, the runner receives an explicit runtime contract containing:

```text
bucket_minutes
points_per_day

corrected_history
corrected_history_window_points

features

feature_columns
feature_column_groups

minimum_history_points
maximum_lookback_points

uses_corrected_history
uses_local_median_cleaning
requires_status_column

retain_original_columns
save_intermediate_outputs
```

---

# 48. `feature_columns` vs `feature_column_groups`

### `feature_columns`

A flattened final sequence of every generated column.

Example:

```text
(
    "lag_1",
    "lag_96",
    "rolling_median_4",
    "is_weekend"
)
```

### `feature_column_groups`

Maintains which resolved columns belong to each original feature request.

Example:

```text
(
    ("lag_1", "lag_96"),
    ("rolling_median_4",),
    ("is_weekend",)
)
```

This becomes especially important when repeated requests are renamed with `_s2`, `_s3`, etc.

The resolved model validates that flattening `feature_column_groups` exactly reproduces `feature_columns`.

---

# 49. `retain_original_columns`

Default:

```text
True
```

This represents the intended output policy:

```text
Part B columns
+
Part C feature columns
```

If disabled, Part C may produce a feature-only output.

The schema controls the policy; enforcement belongs to the ML runner and validation module.

---

# 50. `save_intermediate_outputs`

Default:

```text
False
```

This allows Part C to optionally save source-preparation/audit outputs.

The schema only records this preference.

The Part C runner decides which files are actually written.

---

# 51. Overall Resolution Flow

```text
Incoming Part C Request
        │
        ▼
FeatureEngineeringConfig
        │
        ├── Explicit features?
        │      │
        │      ├─ Yes → validate custom FeatureRequests
        │      │
        │      └─ No  → select XGBoost / Isolation Forest default profile
        │
        ▼
Canonical feature requests
        │
        ▼
Validate output-name ownership/collisions
        │
        │      Part A BucketConfig
        │               │
        └───────┬───────┘
                ▼
        resolve_for_bucket()
                │
                ├── resolve bucket_minutes
                ├── calculate points_per_day
                ├── resolve minute windows
                ├── resolve default lags/windows
                ├── resolve local-median windows
                ├── resolve corrected-history needs
                ├── calculate history/lookback
                ├── determine status requirement
                └── finalize output names
                │
                ▼
ResolvedFeatureEngineeringConfig
                │
                ▼
        Part C ML Runner
```

---

# 52. Schema Responsibility Boundary

The Part C schema does **not**:

- read the Part B CSV;
    
- validate actual site timelines;
    
- group data by site;
    
- create corrected-history values;
    
- calculate local medians;
    
- calculate lags;
    
- calculate rolling statistics;
    
- calculate time/calendar features;
    
- generate seasonal baselines;
    
- calculate residual values;
    
- append feature columns;
    
- skip invalid sites;
    
- save datasets or summaries.
    

Those responsibilities belong to `app/ml/feature_engineering/`.

The schema instead answers:

```text
Which features are requested?
What source does each feature use?
What parameters are allowed?
What cleaning configuration is valid?
What should each output column be called?
How much historical data is required?
What defaults should each model receive?
How do minute-based settings map to the dataset frequency?
```

---

# 53. Relationship With Earlier Schema Layers

### Shared Dataset Schema

Defines:

```text
physical dataset columns
source file
KPI identity
resolved bucket
```

### Part B Preprocessing Schema

Defines:

```text
how the underlying KPI history is cleaned
```

### Part C Feature Engineering Schema

Defines:

```text
which model features are derived from that Part B history
and how those feature calculations are configured
```

The Part C schema therefore does not redefine Part B's missing-value or outlier strategy.

It consumes the resulting dataset and Part B status information where a requested feature needs it.

---

# 54. Public Package API

`__init__.py` exports the major schema classes and helper contracts, including:

- all feature request types;
    
- `FeatureEngineeringConfig`;
    
- `ResolvedFeatureEngineeringConfig`;
    
- `CorrectedHistoryConfig`;
    
- `LocalMedianCleaningConfig`;
    
- `WeightedSeasonalBaselineConfig`;
    
- XGBoost and Isolation Forest default profile classes;
    
- `FeatureSource`;
    
- allowed rolling/time/calendar types;
    
- `get_feature_columns`;
    
- `get_request_history_requirements`.
    

This makes:

```python
app.schemas.feature_engineering
```

the intended public schema interface rather than requiring external code to know the internal file layout.

---

# 55. Final Summary

The three schema files have clearly separated responsibilities:

```text
defaults.py
→ Owns shared Part C defaults and algorithm-specific XGBoost /
  Isolation Forest default feature profiles.

feature_engineering.py
→ Defines every feature request, source/cleaning configuration,
  validation rule, canonical output name, history requirement,
  repeated-feature naming rule and bucket-aware resolution.

__init__.py
→ Provides the stable public import interface.
```

The major schema objects can be summarized as:

```text
CorrectedHistoryConfig
→ Defines shared temporary past-history correction.

LocalMedianCleaningConfig
→ Defines optional cleaning of referenced raw historical points.

Individual FeatureRequest models
→ Define exactly which features should be generated.

WeightedSeasonalBaselineConfig
→ Defines seasonal baseline behaviour shared by baseline and residual.

FeatureEngineeringConfig
→ Represents the user-facing Part C request.

ResolvedFeatureEngineeringConfig
→ Represents the fully bucket-resolved runtime contract consumed by
  the Part C ML module.

DefaultFeatureProfilesConfig
→ Owns the separate XGBoost and Isolation Forest default feature sets.
```

The central architectural role of this package is therefore to create a **single validated feature contract between the API/workflow and Part C**, ensuring that feature choice, source selection, output naming, historical requirements and dataset-frequency interpretation are resolved **before feature calculations begin**.