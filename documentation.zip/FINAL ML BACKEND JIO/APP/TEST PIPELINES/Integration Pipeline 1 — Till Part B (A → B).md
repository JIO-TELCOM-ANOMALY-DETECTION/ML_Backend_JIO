# Historical Integration Pipeline 1 — Till Part B (A → B)

**Pipeline:** Part A EDA → Part B Preprocessing  
**Historical role:** First integration pipeline connecting the completed EDA and preprocessing modules through FastAPI.

---

# 1. Pipeline Purpose

This pipeline connects:

```text
Part A — EDA
      ↓
Part B — Preprocessing
```

Its purpose was to verify that:

- one API request could configure both stages;
    
- Part A could run against the source dataset;
    
- every KPI discovered/prepared by Part A could independently enter Part B;
    
- the exact Part A KPI result could be handed directly into Part B;
    
- Part A's resolved bucket could be reused by preprocessing;
    
- separate output directories could be maintained for EDA and preprocessing;
    
- structured Part B results could be converted into an inspectable HTTP response.
    

The workflow explicitly describes itself as a **temporary server-testing pipeline** rather than a production orchestrator.

It does **not** support:

```text
Part C — Feature Engineering
Part D — Training
Part E — Inference
model selection
Optuna
saved-model lifecycle
inference cache lifecycle
```

---

# 2. File Map

|File|Responsibility|Main functions/classes|Calls / Depends On|
|---|---|---|---|
|`test_pipeline.py`|Combined A+B request schema|`PipelineRunRequest`|`DatasetInputConfig`, `PreprocessingConfig`|
|`test_pipeline_routes.py`|FastAPI HTTP interface and response shaping|`run_test_pipeline()`, `build_pipeline_response()`|`PipelineRunRequest`, workflow|
|`test_pipeline_workflow.py`|Actual A→B integration orchestration|`run_test_pipeline_workflow()`, `KPIWorkflowResult`, `TestPipelineWorkflowResult`|Part A runner, Part B runner, file service|
|`test_main.py`|Temporary FastAPI application|`app`, `health_check()`|test router|

The schema contains no processing logic.

The route explicitly delegates execution to the workflow layer.

The workflow contains the actual integration logic.

---

# 3. Public API Contract

## Pipeline endpoint

```text
Method:
POST

Router path:
/test-pipeline/run

Application prefix:
/api/v1

Effective path:
POST /api/v1/test-pipeline/run

Request schema:
PipelineRunRequest

Workflow:
run_test_pipeline_workflow()

Success status:
HTTP 200

Success response:
Manually constructed JSON dictionary

Runtime failure:
HTTP 500
```

The router declares:

```text
/test-pipeline/run
```

while `test_main.py` registers that router with:

```text
prefix="/api/v1"
```

giving the final effective endpoint:

```text
POST /api/v1/test-pipeline/run
```

## Health endpoint

The temporary application additionally exposes:

```text
GET /health
```

returning:

```json
{
  "status": "healthy"
}
```

This endpoint is outside the `/api/v1` router prefix.

---

# 4. Complete Request / Configuration Structure

The complete integration request is:

```text
PipelineRunRequest
│
├── dataset
│   └── DatasetInputConfig
│
├── preprocessing
│   └── PreprocessingConfig
│
└── output_directory
    └── Path
```

## Dataset / shared configuration

`dataset` is the existing shared:

```text
DatasetInputConfig
```

It carries the configuration needed by Part A, including conceptually:

```text
input_file
column mappings
bucket configuration, when supplied
single KPI declaration, when supplied
expected timeline configuration
```

The shared schema is reused rather than redefined by the test pipeline.

---

## Part A configuration

There is **no separate `eda` configuration object** in this test request.

Part A receives:

```text
request.dataset
```

directly.

Therefore the shared dataset configuration effectively acts as the Part A request contract.

---

## Part B configuration

The complete existing:

```text
PreprocessingConfig
```

is exposed as:

```text
request.preprocessing
```

The integration schema does not duplicate Part B's internal fields.

This means configuration for:

```text
timeline correction
valid value handling
series usability
outlier detection
gap profile
Phase 1
Phase 2
Phase 3
Phase 4 / Prophet
intermediate output policy
```

## remains owned and validated by the Part B schema.

## Pipeline-level configuration

Only one true pipeline-level field exists:

```text
output_directory
```

It represents the root under which the workflow creates the A and B directory trees.

The schema converts it to:

```python
Path(value).expanduser()
```

but does not itself create or verify the directory.

---

## Request strictness

`PipelineRunRequest` uses:

```text
extra = "forbid"
```

so unknown top-level fields are rejected during Pydantic validation.

---

# 5. Exact Integration Execution Flow

The historical flow is:

```text
HTTP POST
/api/v1/test-pipeline/run
        │
        ▼
PipelineRunRequest validation
        │
        ▼
run_test_pipeline()
        │
        ▼
run_test_pipeline_workflow()
        │
        ▼
Resolve/create requested output root
        │
        ├── /eda
        └── /preprocessing
        │
        ▼
run_eda_pipeline()
        │
        ▼
EDARunnerResult
        │
        ├── preparation
        │     └── resolved BucketConfig
        │
        └── kpi_results[]
              │
              ▼
        For each KPIEDARunResult
              │
              ├── extract original KPI name
              ├── sanitise KPI name
              ├── create preprocessing/<KPI>/
              │
              ▼
       run_preprocessing_pipeline()
              │
              ▼
      PreprocessingRunnerResult
              │
              ▼
         KPIWorkflowResult
              │
              ▼
repeat for every KPI
              │
              ▼
TestPipelineWorkflowResult
              │
              ▼
build_pipeline_response()
              │
              ▼
HTTP 200 JSON response
```

---

## 5.1 Output-root creation

The workflow first resolves:

```python
request.output_directory
```

into an absolute path and ensures that it exists.

It then creates:

```text
<output_root>/eda
<output_root>/preprocessing
```

---

## 5.2 Part A execution

Part A is called exactly once:

```python
run_eda_pipeline(
    config=request.dataset,
    logger=logger,
    output_directory=eda_root,
)
```

Part A therefore receives:

```text
DatasetInputConfig
shared workflow logger
<output_root>/eda
```

and returns:

```text
EDARunnerResult
```

Part A itself may prepare one or many KPI datasets. Its `EDARunnerResult` contains:

```text
preparation
kpi_results[]
```

where each entry of `kpi_results` is a `KPIEDARunResult`.

---

## 5.3 KPI enumeration

The integration workflow does **not re-read the source to discover KPIs**.

Instead it iterates:

```python
eda_result.kpi_results
```

Therefore Part A is the authoritative source for downstream KPI enumeration.

---

## 5.4 KPI folder resolution

For each Part A KPI result:

```python
raw_kpi_name =
    kpi_result.prepared_dataset.kpi_name
```

The workflow then applies:

```python
sanitise_filename(raw_kpi_name)
```

If sanitization produces an empty string, it falls back to:

```text
kpi_<index>
```

The resulting Part B root is:

```text
<output_root>/
└── preprocessing/
    └── <safe_kpi_name>/
```

---

## 5.5 Exact Part A → Part B call

For each KPI, the workflow calls:

```text
run_preprocessing_pipeline()
```

with:

```text
kpi_result
    = exact KPIEDARunResult object

output_directory
    = preprocessing/<safe KPI>/

dataset_config
    = request.dataset

preprocessing_config
    = request.preprocessing

bucket
    = eda_result.preparation.bucket

logger
    = shared workflow logger
```

This is the central historical A→B contract.

---

## 5.6 What Part B receives from Part A

Part B receives the exact:

```text
KPIEDARunResult
```

Python object.

It does **not** receive merely a folder name and then rediscover the Part A outputs.

The current Part B implementation uses that object to validate and access the exact Part A prepared dataset and associated integrity/site-analysis artifacts.

Therefore the handoff is primarily:

```text
structured Python object
+
paths contained inside that object
```

rather than:

```text
"search this directory for the latest EDA files"
```

---

## 5.7 Bucket propagation

Part B does not independently choose the dataset bucket.

The workflow passes:

```python
eda_result.preparation.bucket
```

into Part B.

This is the bucket resolved by Part A's dataset preparation.

Part B then resolves its own frequency-dependent configuration against this bucket.

---

## 5.8 Part B result collection

Each Part B run returns:

```text
PreprocessingRunnerResult
```

The workflow stores this together with the original KPI name:

```text
KPIWorkflowResult
├── kpi_name
└── preprocessing_result
```

All KPI results are finally collected as a tuple inside:

```text
TestPipelineWorkflowResult
```

---

# 6. Stage-to-Stage Handoff Contract

|From|To|Information passed|Form|Purpose|
|---|---|---|---|---|
|API route|Workflow|Complete `PipelineRunRequest`|Python Pydantic object|Supplies validated dataset, Part B and output configuration|
|Workflow|Part A|`request.dataset`|`DatasetInputConfig` object|Configures source dataset and Part A interpretation|
|Part A|Workflow|`EDARunnerResult`|Python object|Exposes resolved preparation + every KPI result|
|Part A|Part B|exact `KPIEDARunResult`|Python object|Gives Part B the exact Part A dataset/artifacts for that KPI|
|Part A|Part B|`eda_result.preparation.bucket`|`BucketConfig` object|Gives Part B the authoritative resolved frequency|
|Pipeline request|Part B|`request.dataset`|`DatasetInputConfig`|Preserves physical column/site definitions|
|Pipeline request|Part B|`request.preprocessing`|`PreprocessingConfig`|Supplies the complete Part B behaviour|
|Workflow|Part B|KPI-specific output directory|`Path`|Defines where Part B runner writes that KPI's artifacts|
|Part B|Workflow|`PreprocessingRunnerResult`|Python object|Exposes output paths and processing statistics|
|Workflow|Route|`TestPipelineWorkflowResult`|Python dataclass|Gives HTTP layer structured results for response construction|

### Most important contract

```text
Part A
    ↓
KPIEDARunResult
    ↓
Part B
```

Part B consumes the **exact Part A result object** for the corresponding KPI.

That is a concrete integration rule demonstrated by this pipeline.

---

# 7. KPI / Site / Model Iteration Behaviour

## Multiple KPI support

Yes.

Part A can prepare multiple KPIs.

The workflow then performs:

```python
for kpi_result in eda_result.kpi_results:
```

so every KPI receives its own independent Part B runner invocation.

Conceptually:

```text
Source dataset
      ↓
Part A
      ↓
KPI A ──→ Part B A
KPI B ──→ Part B B
KPI C ──→ Part B C
```

---

## Where the KPI loop occurs

The KPI loop belongs to:

```text
test_pipeline_workflow.py
```

not to Part B.

Thus the integration workflow owns:

```text
one Part B run per Part A KPI
```

---

## Site iteration

The integration workflow contains **no site loop**.

Site-level processing remains inside the Part A and Part B module implementations.

Part B internally performs its own per-site validation, correction, outlier detection and filling according to its runner/stage logic.

Therefore:

```text
Workflow level:
KPI iteration

Module level:
site iteration
```

---

## Model iteration

None.

Pipeline 1 has no training stage.

Therefore there is no:

```text
XGBoost selection
Isolation Forest selection
model loop
fixed hyperparameter mode
Optuna mode
```

---

# 8. Folder and Artifact Structure

## Workflow-created directories

The workflow explicitly creates:

```text
<requested output root>/
├── eda/
└── preprocessing/
    ├── <sanitized KPI 1>/
    ├── <sanitized KPI 2>/
    └── ...
```

These are integration-workflow-owned folders.

---

## Part A-created structure

Inside:

```text
<output root>/eda/
```

the Part A runner creates its own structure, including:

```text
eda/
├── prepared_datasets/
│   ├── <KPI>.csv
│   └── ...
│
└── summaries/
    ├── <KPI>/
    │   ├── <KPI>_unique_site_row_counts.csv
    │   ├── summary.txt
    │   ├── series_summary.csv
    │   ├── gap_details.csv
    │   ├── global_missing_timestamps.csv
    │   └── duplicate_timestamp_details.csv
    └── ...
```

The test workflow does not individually create these inner Part A folders.

---

## Part B-created structure

For each KPI, the workflow supplies:

```text
preprocessing/<safe KPI>/
```

to the Part B runner.

The Part B runner then owns its internal artifacts, conceptually:

```text
preprocessing/
└── <safe KPI>/
    ├── <KPI>_final_cleaned.csv
    │
    ├── summaries/
    │   ├── 01_outlier_summary.csv
    │   ├── 02_original_gap_summary.csv
    │   ├── 03_phase_1_summary.csv
    │   ├── 04_phase_2_summary.csv
    │   ├── 05_phase_3_summary.csv
    │   └── 06_phase_4_summary.csv
    │       # when Phase 4 runs
    │
    └── intermediate/
        ├── 01_timeline_corrected.csv
        ├── 02_outlier_labelled.csv
        ├── 03_original_gap_classified.csv
        ├── 04_phase_1_filled.csv
        ├── 05_phase_2_filled.csv
        └── 06_phase_3_filled.csv
```

The intermediate checkpoints exist only when configured.

---

## Run/session naming

The integration workflow does **not** generate:

```text
run ID
session ID
UUID
timestamped run folder
```

The caller supplies the complete root:

```text
output_directory
```

and the workflow directly creates:

```text
eda/
preprocessing/
```

beneath it.  
Therefore run isolation depends on the caller choosing a unique output root.

---

# 9. Validation and Error Handling

## 9.1 Route / schema validation

FastAPI first parses the JSON body into:

```text
PipelineRunRequest
```

The request schema validates:

```text
dataset → DatasetInputConfig
preprocessing → PreprocessingConfig
output_directory → Path
no unknown top-level fields
```

Invalid Pydantic request bodies fail before the route workflow executes.

Under normal FastAPI behaviour these request-validation failures produce:

```text
HTTP 422
```

rather than entering the route's `try/except`.

---

## 9.2 Workflow-level validation

The workflow itself performs little domain validation.

Its direct responsibilities are mainly:

```text
resolve/create output directories
sanitize KPI directory names
fallback if sanitized KPI name is empty
```

It then relies on the modules for data and handoff validation.

---

## 9.3 Part A module validation

Part A handles validation including:

```text
source-file usability
required columns
KPI identity
bucket resolution
timeline configuration
timestamp integrity
```

Fatal errors propagate upward.

---

## 9.4 Part B module validation

Part B validates the exact Part A handoff and ensures that the files/result metadata correspond to the same KPI run.

It also resolves and validates preprocessing behaviour against the supplied bucket.

---

## 9.5 Cross-stage validation

The strongest cross-stage validation occurs inside Part B.

Part B receives:

```text
KPIEDARunResult
```

and validates its referenced Part A artifacts rather than trusting only filenames supplied by the test workflow.

The workflow also passes the resolved:

```text
eda_result.preparation.bucket
```

rather than the unresolved request bucket.

---

## 9.6 Runtime exception handling

The route wraps the entire workflow in:

```python
except Exception
```

Any exception that reaches the route becomes:

```text
HTTP 500
```

with:

```json
{
  "detail": {
    "status": "failed",
    "error_type": "<Python exception class>",
    "message": "<str(error)>"
  }
}
```

This means runtime:

```text
InputValidationError
FileProcessingError
unexpected exceptions
```

are not assigned different HTTP status codes by this route.

---

## 9.7 Failure scope

There is no per-KPI `try/except` in the workflow.

Therefore:

```text
KPI A preprocessing succeeds
KPI B preprocessing fails
        ↓
complete workflow raises
        ↓
API returns HTTP 500
```

The workflow does not continue with KPI C after the exception.

Previously written artifacts are not explicitly rolled back.

---

# 10. Response Contract

The route does **not simply serialize the complete runner result objects**.

Instead:

```text
build_pipeline_response()
```

constructs a selected JSON representation.

---

## Top-level response

```text
status
output_directory
kpi_count
eda_outputs
kpi_results
```

### `status`

Always:

```text
completed
```

on successful completion.

---

## `eda_outputs`

Contains:

```text
output_directory
prepared_datasets_directory
summaries_directory
source_file
total_input_rows
prepared_kpi_count
was_split
```

The route therefore exposes only selected headline Part A information.

It does **not** expose the complete per-KPI `KPIEDARunResult` contents through this HTTP response.

---

## `kpi_results[]`

Each KPI contains:

```text
kpi_name
source_file
output_directory
final_dataset_file
summary_files
intermediate_files
statistics
method_counts
```

---

## `summary_files`

```text
outlier
original_gaps
phase_1
phase_2
phase_3
phase_4
```

`phase_4` may be:

```text
null
```

---

## `intermediate_files`

```text
timeline_corrected
outlier_labelled
gap_classified
phase_1_filled
phase_2_filled
phase_3_filled
```

Any checkpoint that was not written becomes:

```text
null
```

---

## `statistics`

The response exposes:

```text
total_input_rows
final_rows
duplicate_rows_removed
inserted_timestamp_rows
invalid_rows_converted
valid_series
invalid_series
outliers_flagged
original_gaps
original_missing_points
phase_1_filled_points
phase_2_filled_points
phase_3_filled_points
phase_4_safe_filled_points
phase_4_leakage_filled_points
unresolved_points
```

---

## `method_counts`

Contains:

```text
phase_2
phase_3
phase_4_pass_1
phase_4_pass_2
```

These values are copied directly from the `PreprocessingRunnerResult`.

---

# 11. Responsibilities of the Test Workflow Itself

The integration workflow performs several tasks that are outside Parts A and B.

## 1. Root directory ownership

It creates:

```text
output root
eda root
preprocessing root
```

---

## 2. Stage sequencing

It decides:

```text
Part A must finish first
        ↓
then Part B runs
```

---

## 3. KPI iteration

It decides that:

```text
every Part A KPI result
        ↓
receives exactly one Part B run
```

---

## 4. KPI output naming

It extracts and sanitizes the KPI name before deciding the Part B output folder.

---

## 5. Handoff assembly

It combines:

```text
KPIEDARunResult
DatasetInputConfig
PreprocessingConfig
resolved BucketConfig
output directory
logger
```

into the Part B invocation.

---

## 6. Workflow result aggregation

It builds:

```text
TestPipelineWorkflowResult
```

containing:

```text
root
complete EDARunnerResult
all KPI Part B results
```

---

## Route-owned integration logic

The HTTP route separately owns:

```text
runner-result → API-response mapping
optional Path → JSON string conversion
runtime exception → HTTP 500 conversion
```

This response-shaping logic is not inside Parts A or B.

---

# 12. Test-Only Behaviour

Several behaviours clearly reflect this pipeline's temporary testing role.

## Temporary endpoint

```text
/test-pipeline/run
```

The source comments explicitly identify it as a temporary testing endpoint.

---

## Temporary FastAPI application

The application description states:

```text
Temporary FastAPI server for testing Part A EDA
and Part B preprocessing.
```

with version:

```text
0.1.0
```

---

## Caller-controlled filesystem output root

The API request directly accepts:

```text
output_directory
```

as a filesystem path.

The test workflow then writes directly below that path.

This is highly convenient for integration testing but should not automatically be interpreted as a production API requirement.

---

## No run/session object

There is no persistent run-management abstraction.

No:

```text
run ID
session state
database run record
job status object
```

exists in these files.

---

## Filesystem paths exposed directly

The HTTP response includes physical paths to:

```text
source
output directories
final CSVs
summary files
intermediate files
```

This is useful during backend testing and debugging.

---

## Global logging setup

`test_main.py` configures global logging through:

```python
logging.basicConfig(...)
```

This is appropriate for the isolated test application but is not an integration requirement of Parts A/B.

---

## No explicit server-launch command

`test_main.py` creates:

```text
app = FastAPI(...)
```

but does not contain an explicit:

```python
uvicorn.run(...)
```

Therefore the exact command/process used to launch this server is:

```text
UNKNOWN / NOT CONFIRMED from these files.
```

The likely external Uvicorn launch mechanism is outside this pipeline code.

---

# 13. Integration Rules Learned From This Pipeline

The following rules are directly supported by the code.

## Rule 1 — Part A runs once for the incoming dataset

The workflow calls:

```text
run_eda_pipeline()
```

once before entering the KPI loop.

---

## Rule 2 — Part A determines the downstream KPI set

The workflow processes:

```text
eda_result.kpi_results
```

rather than performing a second KPI discovery operation.

---

## Rule 3 — Each KPI receives an independent Part B run

```text
one KPIEDARunResult
        ↓
one run_preprocessing_pipeline()
```

---

## Rule 4 — Part B receives the exact Part A KPI result object

The workflow passes:

```text
kpi_result=kpi_result
```

directly.

There is no integration-layer directory scan to reconstruct the Part A handoff.

---

## Rule 5 — The resolved Part A bucket is propagated downstream

Part B receives:

```text
eda_result.preparation.bucket
```

which becomes the common frequency basis for Part B resolution.

---

## Rule 6 — Shared dataset configuration is reused across stages

Both Part A and Part B receive:

```text
request.dataset
```

This keeps physical column and site identity interpretation consistent.

---

## Rule 7 — Module runners are the integration boundaries

The test workflow calls:

```text
run_eda_pipeline()
run_preprocessing_pipeline()
```

It does not call individual EDA/preprocessing internal stage functions.

---

## Rule 8 — Site iteration remains inside modules

The integration workflow handles KPI-level sequencing while Part A/B remain responsible for their own site-level behaviour.

---

## Rule 9 — Workflow owns high-level folder hierarchy

The integration layer creates:

```text
eda/
preprocessing/<KPI>/
```

while each module runner creates its internal artifacts.

---

## Rule 10 — API responses are constructed from structured runner results

The route does not reopen CSV summaries to create its response.

It reads fields from:

```text
EDARunnerResult
PreprocessingRunnerResult
```

---

# 14. Limitations of This Pipeline Version

This is intentionally only an:

```text
A → B
```

integration.

It lacks:

```text
Part C feature generation
Part D training
Part E inference
model artifacts
training metrics
model selection
Optuna tuning
training-run linkage
inference caches
scheduled inference
```

It also does not demonstrate:

- independent invocation of A and B through separate production endpoints;
    
- resuming from a previously completed Part A run;
    
- persistent run status;
    
- partial-success semantics;
    
- concurrency/run isolation;
    
- job scheduling.
    

Those questions must be evaluated from later pipeline versions and eventual production design.

---

# 15. Conflicts or Questionable Behaviour

|Issue|Severity|Evidence|Possible impact|
|---|---|---|---|
|All workflow/runtime exceptions become HTTP 500|**Important**|Route catches `Exception` generically|Input/data validation failures raised after request parsing are indistinguishable at HTTP level from internal server bugs|
|No per-KPI failure isolation|**Important**|KPI loop has no local exception handling|One failing KPI stops the complete request even if previous KPIs succeeded|
|No generated run/session ID|**Historical/Test-only**|Workflow writes directly under caller's `output_directory`|Repeated or concurrent runs using the same root may interact with existing files|
|Output root is directly caller-controlled|**Historical/Test-only**|`output_directory` comes from request|Convenient for tests but exposes server filesystem layout/control if carried directly into production|
|Sanitized KPI folder names are not collision-checked|**Important / Potential bug**|`sanitise_filename()` result is used directly; only empty names get fallback|Two different KPI names that sanitize to the same string could share one preprocessing directory|
|Raw exception message is returned|**Important**|`"message": str(error)`|Internal filesystem/configuration details can appear in API responses|
|No explicit API response model|**Minor**|Route returns `dict[str, Any]`|Response shape is manually maintained rather than schema-enforced|
|Long pipeline executes synchronously inside request lifecycle|**Historical/Test-only**|Normal synchronous route directly runs full A→B workflow|Long-running processing occupies the request worker until completion|
|No rollback of previously created artifacts|**Historical/Test-only**|Workflow writes progressively and propagates exceptions|Failed multi-KPI runs may leave valid outputs from earlier stages/KPIs on disk|
|Output-directory normalization occurs in both schema and workflow|**Minor**|Schema calls `expanduser`; workflow again calls `expanduser().resolve()`|Harmless duplication; indicates test-layer convenience rather than a clean ownership boundary|
|Detailed Part A KPI results are not returned over HTTP|**Minor / Historical**|`build_pipeline_response()` exposes only aggregate EDA paths/metadata|Internal workflow has richer EDA information than the API response exposes|

These issues should be preserved for comparison against Pipelines 2–5 rather than resolved from this historical version alone.

---

# 16. Compact Pipeline Contract

```text
Pipeline:
Part A EDA → Part B Preprocessing

Endpoint:
POST /api/v1/test-pipeline/run

Input:
PipelineRunRequest
├── dataset: DatasetInputConfig
├── preprocessing: PreprocessingConfig
└── output_directory: Path

Stages:
1. Part A EDA once
2. Part B preprocessing once per Part A KPI

Primary workflow:
run_test_pipeline_workflow()

Stage handoffs:
API → Workflow:
    PipelineRunRequest

Workflow → A:
    DatasetInputConfig
    EDA output directory
    logger

A → Workflow:
    EDARunnerResult

A → B:
    exact KPIEDARunResult
    Part A resolved BucketConfig

Request → B:
    DatasetInputConfig
    PreprocessingConfig

Workflow → B:
    KPI-specific output directory
    logger

B → Workflow:
    PreprocessingRunnerResult

Output:
HTTP JSON containing:
- overall completion status
- EDA output paths / basic preparation statistics
- one Part B result block per KPI
- final cleaned dataset paths
- summary/intermediate paths
- preprocessing statistics
- filling-method counts

Folder root:
Caller-supplied output_directory

Workflow-created folders:
<root>/eda/
<root>/preprocessing/<sanitized KPI>/

Important validation:
- FastAPI/Pydantic request validation
- DatasetInputConfig validation
- PreprocessingConfig validation
- Part A runtime/file validation
- Part B validation of exact Part A handoff
- Part B bucket/frequency resolution

Important errors:
Pydantic request errors:
    normal FastAPI request-validation response

Workflow/module runtime errors:
    HTTP 500
    {
      status: failed,
      error_type: ...,
      message: ...
    }

Failure scope:
One stage/KPI failure aborts the overall request.

Test-only logic:
- /test-pipeline endpoint
- temporary FastAPI app
- direct filesystem output path in request
- physical paths returned to caller
- no persistent run/session layer
- synchronous end-to-end execution

Key integration lessons:
1. Run Part A once per input dataset.
2. Use Part A's returned KPI list as the downstream KPI authority.
3. Run Part B independently for every KPI.
4. Pass the exact KPIEDARunResult object from A to B.
5. Pass Part A's resolved bucket into B.
6. Reuse the same DatasetInputConfig across A and B.
7. Keep module runners as integration boundaries.
8. Keep site-level processing inside the ML modules.
9. Let the integration workflow own high-level stage/KPI folders.
10. Construct API results from structured runner objects rather than rediscovering output files.
```

---

# Final Historical Interpretation

Pipeline 1 established the first clear integration boundary for the backend:

```text
External request
      ↓
Dataset + preprocessing configuration
      ↓
Part A runner
      ↓
EDARunnerResult
      ↓
KPIEDARunResult × N
      ↓
Part B runner × N
      ↓
PreprocessingRunnerResult × N
      ↓
Aggregated HTTP response
```

Its most important architectural contribution is the demonstrated **result-object handoff**:

```text
KPIEDARunResult
```

is passed directly from Part A into Part B, while the exact resolved Part A bucket and the shared dataset configuration are propagated alongside it.

The integration workflow therefore coordinates **stage order, KPI fan-out, output-root hierarchy and result aggregation**, while the actual site-level EDA/preprocessing behaviour remains inside Parts A and B.

This establishes the baseline against which the later A→B→C, training and inference integration pipelines should be compared.