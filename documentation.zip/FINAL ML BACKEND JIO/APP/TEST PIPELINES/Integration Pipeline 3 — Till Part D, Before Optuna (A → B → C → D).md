# Historical Integration Pipeline 3 — Till Part D, Before Optuna (A → B → C → D)

**Pipeline:** Part A EDA → Part B Preprocessing → Part C Feature Engineering → Part D Training  
**Historical role:** Third integration pipeline, extending the established A→B→C chain by adding model training before the later Optuna-enabled Part D revision.

---

# 1. Pipeline Purpose

This pipeline connects:

```text
Part A — EDA
      ↓
Part B — Preprocessing
      ↓
Part C — Feature Engineering
      ↓
Part D — Training
```

It was intended to prove that:

- the existing A→B→C integration remained reusable;
    
- one request could select a Part D model type and its training configuration;
    
- Part C could automatically use a feature profile appropriate for the selected model when custom features were omitted;
    
- the exact Part C feature-engineered dataset could become the Part D training input;
    
- the exact resolved Part C feature contract could be passed into training;
    
- Part C's calculated minimum-history requirement could control Part D's chronological splitting;
    
- one selected model type could be trained independently for every valid site series of each KPI;
    
- model files and training-support artifacts could be persisted and exposed through the API.
    

The workflow explicitly says that Part D receives the exact Part C engineered dataset and resolved feature contract, then trains the single model selected by the request independently for valid site series.

This is the **pre-Optuna historical pipeline**. No Optuna-specific integration branch, tuning mode, study configuration, or search-space handling exists in these four pipeline files.

---

# 2. File Map

|File|Responsibility|Main functions/classes|Calls / Depends On|
|---|---|---|---|
|`test_pipeline_till_part_d.py`|Combined A+B+C+D request contract|`PipelineRunRequest`, `TrainingConfig`|Shared dataset, preprocessing, feature-engineering, XGBoost and Isolation Forest training schemas|
|`test_pipeline_routes_till_part_d.py`|HTTP interface + A/B/C/D response construction|`run_test_pipeline()`, `build_pipeline_response()`, `build_training_response()`, `split_range_to_response()`|Workflow, `SplitRange`|
|`test_pipeline_workflow_till_part_d.py`|Actual A→B→C→D orchestration|`run_test_pipeline_workflow()`, `KPIWorkflowResult`, `TestPipelineWorkflowResult`|A/B/C/D runners and file service|
|`test_main_till_part_d.py`|Temporary FastAPI application|`app`, `health_check()`|Part D test router|

The request schema combines existing stage schemas and contains no execution logic.

The route delegates all execution to the workflow.

The workflow contains the actual cross-stage integration logic.

---

# 3. Public API Contract

## Pipeline endpoint

```text
Method:
POST

Router path:
/test-pipeline/run

Application prefix:
/api/v1

Effective endpoint:
POST /api/v1/test-pipeline/run

Request schema:
PipelineRunRequest

Workflow:
run_test_pipeline_workflow()

Success:
HTTP 200

Runtime failure:
HTTP 500
```

The route remains:

```text
/test-pipeline/run
```

and the temporary app registers it under:

```text
/api/v1
```

so the effective endpoint is:

```text
POST /api/v1/test-pipeline/run
```

## Health endpoint

```text
GET /health
```

returns:

```json
{
  "status": "healthy"
}
```

---

# 4. Complete Request / Configuration Structure

The combined request is:

```text
PipelineRunRequest
│
├── dataset
│   └── DatasetInputConfig
│
├── preprocessing
│   └── PreprocessingConfig
│
├── feature_engineering
│   └── FeatureEngineeringConfig | None
│
├── training
│   └── TrainingConfig
│       ├── XGBoostTrainingConfig
│       └── IsolationForestTrainingConfig
│
└── output_directory
    └── Path
```

---

## Dataset / shared config

```text
dataset: DatasetInputConfig
```

remains the common dataset interpretation passed through the pipeline.

It supplies the source path and shared physical dataset contract.

---

## Part A config

There is still no separate EDA-specific request block.

Part A receives:

```text
request.dataset
```

directly.

---

## Part B config

```text
preprocessing: PreprocessingConfig
```

is required and passed unchanged to Part B.

The integration workflow does not duplicate Part B configuration rules.

---

## Part C config

```text
feature_engineering:
FeatureEngineeringConfig | None
```

is optional.

This differs importantly from Pipeline 2.

Pipeline 2 used a default factory immediately at schema parsing.

Pipeline 3 instead allows:

```text
feature_engineering = None
```

and lets the **workflow resolve the default profile based on the Part D model**.

The workflow performs:

```text
IF custom Part C config exists:
    use it

ELSE:
    FeatureEngineeringConfig(
        default_profile=request.training.model_type
    )
```

Therefore:

```text
XGBoost training
    ↓
default XGBoost Part C feature profile

Isolation Forest training
    ↓
default Isolation Forest Part C feature profile
```

This prevents an Isolation Forest request from accidentally receiving the XGBoost default feature set, and vice versa.

---

## Part D config

The pipeline adds the required:

```text
training: TrainingConfig
```

where:

```text
TrainingConfig =
    XGBoostTrainingConfig
    |
    IsolationForestTrainingConfig
```

using:

```text
model_type
```

as the discriminating field.

Therefore one request selects exactly **one training model family**.

Conceptually:

```text
training.model_type = xgboost
        ↓
XGBoostTrainingConfig

training.model_type = isolation_forest
        ↓
IsolationForestTrainingConfig
```

The pipeline does not independently parse or transform model-specific parameters.

The validated training object is passed directly into Part D.

---

## Pre-Optuna status

These four files expose model-specific training schemas but contain **no explicit Optuna selection or search configuration at the pipeline level**.

Therefore this version demonstrates the pre-Optuna integration contract:

```text
selected model type
+
validated Part D training configuration
        ↓
run_training()
```

The later Optuna pipeline must be compared separately rather than assuming this request already behaves identically.

---

## Pipeline-level config

```text
output_directory
```

remains the only explicit integration-level storage configuration.

The workflow creates four stage roots below it:

```text
eda/
preprocessing/
feature_engineering/
part_d/
```

---

## Top-level request validation

`PipelineRunRequest` again uses:

```text
extra = "forbid"
```

and normalizes `output_directory` to a `Path`.

---

# 5. Exact Integration Execution Flow

```text
POST /api/v1/test-pipeline/run
        │
        ▼
PipelineRunRequest
        │
        ├── DatasetInputConfig
        ├── PreprocessingConfig
        ├── optional FeatureEngineeringConfig
        ├── model-specific TrainingConfig
        └── output_directory
        │
        ▼
run_test_pipeline_workflow()
        │
        ▼
Create:
├── eda/
├── preprocessing/
├── feature_engineering/
└── part_d/
        │
        ▼
Resolve Part C feature config
        │
        ├── custom supplied → use it
        │
        └── omitted → profile = training.model_type
        │
        ▼
Part A once
        │
        ▼
EDARunnerResult
        │
        ▼
for each KPIEDARunResult
        │
        ▼
Part B
        │
        ▼
PreprocessingRunnerResult
        │
        ▼
Part C
        │
        ▼
FeatureEngineeringRunnerResult
        │
        ├── final_dataset_file
        ├── resolved_config
        └── resolved_config.minimum_history_points
        │
        ▼
Part D run_training()
        │
        ▼
PartDTrainingResult
        │
        ▼
KPIWorkflowResult
        │
        ▼
next KPI
        │
        ▼
TestPipelineWorkflowResult
        │
        ▼
build_pipeline_response()
        │
        ▼
HTTP 200
```

---

## 5.1 Output roots

The workflow creates:

```text
<output_root>/
├── eda/
├── preprocessing/
├── feature_engineering/
└── part_d/
```

The workflow comments explicitly explain that `part_d/` is a parent boundary because Part D's own output layer creates its final `training/` directory inside the path passed to `run_training()`.

---

## 5.2 Feature-profile resolution

Before Part A runs, the workflow calculates one:

```text
feature_config
```

for the complete request:

```python
request.feature_engineering
```

when supplied, otherwise:

```python
FeatureEngineeringConfig(
    default_profile=request.training.model_type
)
```

That same Part C configuration is reused for every KPI in the request.

---

## 5.3 Part A execution

Part A still runs once:

```python
run_eda_pipeline(
    config=request.dataset,
    logger=logger,
    output_directory=eda_root,
)
```

and returns:

```text
EDARunnerResult
```

Part A remains the source for:

```text
resolved BucketConfig
KPI list
KPIEDARunResult objects
```

---

## 5.4 KPI iteration

The workflow loops:

```text
eda_result.kpi_results
```

Therefore Part A continues to define the downstream KPI set.

---

## 5.5 Part A → Part B

For each KPI, Part B receives:

```text
exact KPIEDARunResult
DatasetInputConfig
PreprocessingConfig
Part A resolved BucketConfig
KPI-specific preprocessing output directory
logger
```

This remains unchanged from Pipelines 1 and 2.

---

## 5.6 Part B → Part C

Part C receives:

```text
exact PreprocessingRunnerResult
DatasetInputConfig
resolved workflow FeatureEngineeringConfig
same Part A BucketConfig
KPI-specific feature-engineering directory
logger
```

Again, the complete result object is handed over rather than having the workflow rediscover Part B artifacts manually.

---

## 5.7 Part C → Part D — critical new handoff

This is the main new integration boundary.

Part D is called as:

```text
run_training(
    model_type=...,
    input_file=...,
    output_directory=...,
    dataset_columns=...,
    feature_config=...,
    minimum_history_points=...,
    training_config=...,
    metadata=...
)
```

The exact arguments are:

### Model dispatch

```text
model_type =
request.training.model_type
```

This selects either:

```text
xgboost
```

or:

```text
isolation_forest
```

---

### Training input file

```text
input_file =
feature_engineering_result.final_dataset_file
```

Unlike A→B and B→C, Part D does **not receive the complete `FeatureEngineeringRunnerResult` object**.

It receives the persisted final Part C dataset path extracted by the integration workflow.

This is an important change in handoff form.

```text
Part C
    ↓
FeatureEngineeringRunnerResult
    ↓ workflow extracts
final_dataset_file
    ↓
Part D
```

---

### Dataset-column contract

Part D receives:

```text
dataset_columns =
request.dataset.columns
```

Therefore it receives the shared physical-column mapping rather than reconstructing the site/timestamp/value columns from the file.

---

### Feature contract

Part D receives:

```text
feature_config =
feature_engineering_result.resolved_config
```

This is the **resolved Part C runtime feature contract**, not merely the original user request.

Therefore Part D knows exactly which feature columns Part C actually generated.

---

### Minimum-history requirement

Part D receives:

```text
minimum_history_points =
feature_engineering_result
    .resolved_config
    .minimum_history_points
```

This explicitly propagates the history requirement calculated by Part C into Part D.

The fixed Part D runner records this value as part of its result/metadata.

---

### Training configuration

Part D receives:

```text
training_config =
request.training
```

This is the exact validated model-specific configuration selected by the request.

---

### Parent-pipeline metadata

The workflow additionally provides:

```text
metadata = {
    "kpi_name": raw_kpi_name,
    "part_c_output_directory": ...,
    "part_c_final_dataset": ...
}
```

This creates explicit training provenance linking the Part D run back to:

```text
KPI identity
Part C output directory
Part C final dataset
```

The Part D runner preserves supplied parent metadata in its model-output metadata.

---

## 5.8 Part D result

`run_training()` returns:

```text
PartDTrainingResult
```

which includes at least:

```text
status
model_type
input_file
output_directory
minimum_history_points

total_series
valid_series
trained_series
skipped_invalid_series
skipped_series

validation_result
split_plan
output_paths
```

The fixed runner returns this structured result after finalizing model outputs.

---

# 6. Stage-to-Stage Handoff Contract

|From|To|Information Passed|Form|Purpose|
|---|---|---|---|---|
|API|Workflow|Entire request|`PipelineRunRequest`|Combined A/B/C/D configuration|
|Workflow|A|dataset config|`DatasetInputConfig`|Source + shared dataset interpretation|
|A|Workflow|complete A result|`EDARunnerResult`|Resolved bucket + KPI results|
|A|B|exact KPI result|`KPIEDARunResult`|Exact Part A artifacts for one KPI|
|A|B|resolved bucket|`BucketConfig`|Frequency source|
|Request|B|preprocessing config|`PreprocessingConfig`|B behaviour|
|B|Workflow|complete B result|`PreprocessingRunnerResult`|Exact B output|
|B|C|complete B result|`PreprocessingRunnerResult`|C resolves exact B final file|
|Request/workflow|C|Part C config|`FeatureEngineeringConfig`|Custom or model-matched defaults|
|A|C|resolved bucket|`BucketConfig`|Feature frequency resolution|
|C|Workflow|complete C result|`FeatureEngineeringRunnerResult`|Supplies dataset + resolved feature contract|
|C|D|final engineered dataset|`Path`|Physical training dataset|
|C|D|resolved feature contract|`ResolvedFeatureEngineeringConfig`|Exact generated-feature definition|
|C|D|minimum history|`int`|Controls Part D history reservation/splitting|
|Request|D|dataset column map|`DatasetColumnMapping`|Identifies site/timestamp/value fields|
|Request|D|training config|model-specific Pydantic object|Controls training|
|Request|D|model type|string discriminator|Dispatches model runner|
|Workflow|D|KPI/Part C provenance|metadata dictionary|Links model run to upstream Part C|
|D|Workflow|complete training result|`PartDTrainingResult`|Training status, split information and model outputs|
|Workflow|Route|aggregated result|`TestPipelineWorkflowResult`|API response construction|

---

# 7. KPI / Site / Model Iteration Behaviour

## KPI loop

The processing sequence remains KPI-major:

```text
Part A once
      ↓
KPI 1: B → C → D
KPI 2: B → C → D
KPI 3: B → C → D
...
```

The workflow does **not** run:

```text
all B
then all C
then all D
```

---

## Site loops in A/B/C

The parent integration workflow still does not process sites directly.

Part A, B and C retain their site-level responsibilities.

---

## Site loop in Part D

The workflow itself also does not loop over sites for training.

Instead the call:

```text
run_training(...)
```

handles site-series iteration internally.

The workflow documentation states that Part D trains the selected model independently for every valid site series inside the KPI.

The Part D result exposes:

```text
total_series
valid_series
trained_series
skipped_invalid_series
skipped_series
```

confirming that valid/invalid series handling belongs inside Part D.

---

## Invalid-site behaviour

Part D records skipped invalid series including:

```text
circle
cluster
site_name
usability
invalid_reason
```

in the API response.

The test workflow itself does not make the skip decision.

---

## Model selection

One request chooses **one model type**:

```text
XGBoost
OR
Isolation Forest
```

via:

```text
training.model_type
```

That single selected model type is used for every KPI in the request.

Therefore the pipeline does **not** do:

```text
KPI
 ├── XGBoost
 └── Isolation Forest
```

in one request.

Instead:

```text
Request model = XGBoost
    ↓
every KPI/site uses XGBoost

OR

Request model = Isolation Forest
    ↓
every KPI/site uses Isolation Forest
```

---

## Pre-Optuna iteration

There is no parent-workflow Optuna trial loop.

Hyperparameter/model execution remains entirely inside Part D.

The pipeline simply calls:

```text
run_training()
```

once per KPI.

---

# 8. Folder and Artifact Structure

## Workflow-created root

```text
<output_root>/
├── eda/
├── preprocessing/
├── feature_engineering/
└── part_d/
```

---

## KPI structure

Conceptually:

```text
<output_root>/
│
├── eda/
│   ├── prepared_datasets/
│   └── summaries/
│
├── preprocessing/
│   └── <KPI>/
│       ├── final cleaned dataset
│       ├── summaries/
│       └── intermediate/      # optional
│
├── feature_engineering/
│   └── <KPI>/
│       ├── feature-engineered dataset
│       ├── summaries/
│       └── intermediate/      # optional
│
└── part_d/
    └── <KPI>/
        └── training/
            ├── model files
            ├── split plan
            ├── training config
            ├── feature contract
            ├── final hyperparameters
            ├── training summary
            ├── decision settings
            ├── usable row counts
            └── metadata
```

The workflow explicitly creates:

```text
part_d/<safe KPI>/
```

while Part D's output layer creates the inner:

```text
training/
```

directory.

---

## Part D model directory

The route exposes:

```text
training_directory
model_directory
model_files[]
```

therefore Part D owns a dedicated model-artifact location under its training output.

The exact filename of each trained model is returned through `model_files` rather than reconstructed by the integration workflow.

---

## Part D persisted support artifacts

The response exposes paths for:

```text
split_plan
training_config
feature_contract
final_hyperparameters
training_summary
decision_settings
usable_row_counts
metadata
```

This means filesystem state becomes a significantly larger part of the integration contract starting with Part D.

---

## Session/run naming

The parent pipeline still has no global:

```text
run_id
UUID
timestamped session directory
database run record
```

The root is caller-supplied.

Part D may internally manage its own output session while producing artifacts, but the parent integration workflow does not expose or create a common A→D run identifier.

---

# 9. Validation and Error Handling

## Route/schema validation

FastAPI/Pydantic validates:

```text
DatasetInputConfig
PreprocessingConfig
optional FeatureEngineeringConfig
discriminated TrainingConfig
output_directory
```

before workflow execution.

The `model_type` discriminator ensures that the supplied Part D payload is interpreted as the matching training schema.

---

## Workflow-level validation

The workflow mainly resolves:

```text
directories
safe KPI names
Part C default profile based on model type
```

It does not duplicate model-level validation.

---

## Module validation

Validation remains layered:

```text
Part A
    ↓
dataset / timeline validation

Part B
    ↓
Part A handoff + preprocessing validation

Part C
    ↓
Part B handoff + feature validation

Part D
    ↓
training-dataset validation
feature eligibility
site validity
split feasibility
model-specific training validation
```

---

## Cross-stage C→D validation data

The parent workflow gives Part D several authoritative upstream values:

```text
feature_engineering_result.final_dataset_file

feature_engineering_result.resolved_config

feature_engineering_result
    .resolved_config
    .minimum_history_points
```

Therefore Part D does not infer the Part C feature contract from column names alone.

---

## Part D validation response

The API exposes training validation information including:

```text
total_rows

all_part_c_feature_columns
model_feature_columns
excluded_part_c_feature_columns

target_column

site_identity_columns
timestamp_column
status_column
usability_column
invalid_reason_column

trusted_statuses

require_complete_feature_rows
require_non_null_target

minimum_train_points
minimum_validation_points
minimum_calibration_points
minimum_test_points
```

This makes the model's accepted feature/data contract inspectable through the test API.

---

## Chronological split validation

The API also exposes the Part D `split_plan`.

For every series it can include:

```text
history
train
validation
calibration
test
```

Each range reports:

```text
start_position
end_position
start_timestamp
end_timestamp
row_count
```

This demonstrates that chronological training partitioning is generated inside Part D rather than by the integration workflow.

---

## Route error handling

As before:

```python
except Exception
```

wraps the complete workflow.

Any runtime error reaching the route returns:

```text
HTTP 500
```

with:

```json
{
  "detail": {
    "status": "failed",
    "error_type": "...",
    "message": "..."
  }
}
```

---

## Failure scope

There is still no KPI-level exception isolation.

Example:

```text
KPI 1:
B → C → D succeeds

KPI 2:
B → C succeeds
D fails
       ↓
whole request fails
       ↓
KPI 3 never begins
```

Previously written artifacts are not rolled back by the parent workflow.

Part D itself has an internal abort path for its own output session if model-output finalization fails, but that does not rollback upstream A/B/C artifacts.

---

# 10. Response Contract

Pipeline 3 retains the existing A/B/C response information and adds:

```text
training
```

for each KPI.

---

## Top-level response

```text
status
output_directory
kpi_count
eda_outputs
kpi_results
```

---

## Existing Part B section

Remains at the KPI top level:

```text
source_file
output_directory
final_dataset_file
summary_files
intermediate_files
statistics
method_counts
```

---

## Existing Part C section

```text
feature_engineering
├── source_file
├── output_directory
├── final_dataset_file
├── summary_directory
├── site_summary_file
├── intermediate_directory
├── corrected_history_audit_file
├── feature_columns
├── minimum_history_points
└── statistics
```

Pipeline 3 newly exposes:

```text
minimum_history_points
```

inside the Part C response because this value is now directly relevant to Part D.

---

## Part D training response

```text
training
├── status
├── model_type
├── input_file
├── output_directory
├── minimum_history_points
├── series_statistics
├── skipped_series
├── validation
├── split_plan
└── output_files
```

---

## Training series statistics

```text
total_series
valid_series
trained_series
skipped_invalid_series
```

---

## Skipped-series details

Each skipped series reports:

```text
identity
├── circle
├── cluster
└── site_name

usability
invalid_reason
```

---

## Validation block

Contains the complete headline Part D input/feature validation contract described above.

---

## Split-plan block

```text
hyperparameter_tuning_enabled
minimum_history_points
post_history_percentages
series_count
series[]
```

The presence of:

```text
hyperparameter_tuning_enabled
```

is a property of the Part D split-plan result contract.

It should **not be interpreted as evidence that this integration pipeline already contains Optuna orchestration**.

This version's request/workflow files contain no Optuna-specific integration branch.

---

## Per-series splits

Each series exposes:

```text
identity
total_points

history
train
validation
calibration
test
```

with optional ranges represented as JSON-safe dictionaries.

---

## Output files

The response returns:

```text
training_directory
model_directory
model_files
split_plan
training_config
feature_contract
final_hyperparameters
training_summary
decision_settings
usable_row_counts
metadata
```

---

## Detailed metrics are not copied into HTTP response

The route explicitly states that complete split information and detailed model summaries are already persisted by Part D.

Therefore the HTTP response intentionally returns:

```text
headline training information
+
exact artifact paths
```

rather than copying every per-series model metric into the JSON response.

This is an important API vs filesystem responsibility boundary.

---

# 11. Responsibilities of the Test Workflow Itself

Pipeline 3 adds several orchestration responsibilities beyond those already present in Pipeline 2.

## Existing workflow responsibilities

Still owns:

```text
root directory creation
stage sequencing
KPI iteration
safe KPI directory naming
A→B handoff
B→C handoff
result aggregation
```

---

## New — model-specific Part C default selection

The workflow now connects Part D model selection backward into Part C configuration:

```text
training.model_type
        ↓
FeatureEngineeringConfig.default_profile
```

when the user did not provide a custom Part C config.

This logic exists outside the Part C and Part D runners.

---

## New — Part D root creation

The workflow creates:

```text
part_d/<KPI>/
```

as the parent location given to Part D.

---

## New — Part C result extraction for D

Unlike B→C, the workflow extracts specific fields from the Part C result:

```text
final_dataset_file
resolved_config
minimum_history_points
```

and passes them separately to Part D.

---

## New — model dispatch

The workflow passes:

```text
request.training.model_type
```

as the explicit Part D runner dispatch switch.

---

## New — upstream training metadata

The workflow constructs metadata linking D back to C:

```text
kpi_name
part_c_output_directory
part_c_final_dataset
```

---

## New — training result aggregation

`KPIWorkflowResult` now stores:

```text
preprocessing_result
feature_engineering_result
training_result
```

---

## Route-owned responsibilities

The route adds significant Part D presentation logic:

```text
SplitRange → JSON
PartDTrainingResult → compact API response
training validation summary
chronological split response
artifact-path response
```

This remains outside the ML module itself.

---

# 12. Test-Only Behaviour

## Temporary endpoint/server

The app explicitly remains a temporary server for testing A/B/C/D integration.

---

## Direct output path

The request continues to accept the server-side filesystem:

```text
output_directory
```

directly.

---

## Direct artifact paths in HTTP response

The response exposes:

```text
model paths
training directories
config JSON paths
split-plan path
metadata path
summary paths
```

This is extremely useful for integration testing.

---

## Synchronous full training request

The route synchronously performs:

```text
EDA
+
preprocessing
+
feature engineering
+
training
```

before returning HTTP 200.

As the pipeline becomes more expensive, this becomes increasingly test-oriented.

---

## No persistent master run ID

There is still no top-level production-style run/session record connecting all A/B/C/D artifacts.

---

## Backward compatibility through omitted Part C config

A request can omit custom Part C settings and allow the workflow to construct model-matched defaults.

This is useful test/integration convenience.

---

## Global test logging

`logging.basicConfig()` remains in the temporary test application.

---

# 13. Integration Rules Learned From This Pipeline

## Confirmed Rule 1 — Part A remains single-run dataset authority

A runs once and determines all KPI branches.

---

## Confirmed Rule 2 — KPI processing remains workflow-owned

The parent workflow handles KPI fan-out.

---

## Confirmed Rule 3 — A→B still passes exact `KPIEDARunResult`

---

## Confirmed Rule 4 — B→C still passes exact `PreprocessingRunnerResult`

---

## New Rule 5 — C→D changes handoff form

Part D does **not** receive the full Part C result object.

Instead it receives selected authoritative fields:

```text
final_dataset_file
resolved_config
minimum_history_points
```

This is one of the most important architectural observations from Pipeline 3.

---

## New Rule 6 — Persisted Part C dataset becomes part of the D contract

Part D trains from:

```text
feature_engineering_result.final_dataset_file
```

Therefore the filesystem now becomes an explicit cross-stage integration dependency.

---

## New Rule 7 — Resolved Part C feature configuration is authoritative for D

Part D receives:

```text
feature_engineering_result.resolved_config
```

not the unresolved Part C request.

---

## New Rule 8 — Part C determines required training history

The calculated:

```text
minimum_history_points
```

is explicitly passed into D.

---

## New Rule 9 — Model choice can determine default Part C feature profile

If features are omitted:

```text
training.model_type
        ↓
Part C default profile
```

This connects model selection and feature-generation defaults at workflow level.

---

## New Rule 10 — One model family per pipeline request

The integration request does not train XGBoost and Isolation Forest together.

---

## New Rule 11 — Part D handles per-site model training

The parent workflow gives D the KPI dataset; D internally trains independent eligible series.

---

## New Rule 12 — Training provenance is explicitly persisted

The workflow sends upstream Part C information in metadata.

---

## New Rule 13 — Training produces both runtime result objects and persisted integration artifacts

Starting with Part D, downstream systems can depend not only on the result object but also on:

```text
serialized models
feature contract
training config
decision settings
metadata
split plan
hyperparameter record
training summary
```

---

## Confirmed Rule 14 — Module runners remain stage boundaries

The parent workflow calls only:

```text
run_eda_pipeline()
run_preprocessing_pipeline()
run_feature_engineering_pipeline()
run_training()
```

---

# 14. Limitations of This Pipeline Version

This version completes:

```text
A → B → C → D
```

but is still the **pre-Optuna historical training integration**.

It does not demonstrate the later Optuna integration changes.

It also lacks:

```text
Part E inference
saved-model inference loading
cache/history lifecycle
late-data behaviour
scheduled inference
model-run selection for inference
persistent master run management
partial KPI success
asynchronous jobs
```

The next historical pipeline is still required to determine exactly what changed when Optuna was added.

---

# 15. Conflicts or Questionable Behaviour

|Issue|Severity|Evidence|Possible impact|
|---|---|---|---|
|All runtime failures still become HTTP 500|**Important**|Generic `except Exception` in route|Model/data/config errors are not separated from internal failures at HTTP level|
|One KPI failure still aborts all remaining KPIs|**Important**|Single sequential KPI loop|Expensive successful training for prior KPIs can coexist with an overall failed request|
|No master run/session ID|**Historical/Test-only**|Caller supplies output root directly|Weak cross-stage/run lifecycle identity|
|Direct caller-controlled filesystem root|**Historical/Test-only**|`output_directory` in API request|Useful for testing but not necessarily appropriate for production|
|Sanitized KPI collision protection is still not visible|**Important / Potential bug**|Same `safe_kpi_name` used across B/C/D|Distinct raw KPI names could theoretically share stage folders|
|Raw exception messages returned to API|**Important**|`message = str(error)`|Internal training/filesystem details can leak|
|Synchronous training inside HTTP request|**Historical/Test-only**|POST waits for full A→D chain|Training may be long-running|
|No rollback of A/B/C if D fails|**Historical/Test-only**|Parent workflow writes stage outputs progressively|Failed D run can leave upstream artifacts|
|C→D is filesystem-dependent while earlier handoffs are object-oriented|**Important architectural difference**|D receives `final_dataset_file` rather than full C result|Production orchestrator must preserve both object metadata and persisted artifact linkage|
|Route imports `SplitRange` directly from `app.ml.training.loader`|**Minor**|Route import statement|HTTP layer is coupled to a Part D internal split type rather than only a top-level result contract|
|Response hierarchy remains historically asymmetric|**Minor/Test-only**|B top-level, C nested, D nested|Reflects incremental test-pipeline evolution|
|`training.model_type` drives default C profile only when C config omitted|**Important**|Workflow resolution logic|User-supplied custom Part C features can differ from model defaults; Part D validation must determine suitability|
|One model type applies to every KPI|**Historical limitation**|Single `request.training` object|Different KPIs cannot select different model families in one request|
|`hyperparameter_tuning_enabled` exists in split response despite pre-Optuna pipeline|**Historical ambiguity**|Route exposes Part D split-plan field|Must not be mistaken for proof of Optuna integration; next pipeline must resolve the evolution|
|Part D detailed model summaries remain primarily filesystem artifacts|**Minor / Intentional**|Route intentionally returns headline data + paths|API alone does not contain all model metrics|

No historical conflict should be silently resolved yet.

---

# 16. Compact Pipeline Contract

```text
Pipeline:
Part A → Part B → Part C → Part D
Pre-Optuna historical training integration

Endpoint:
POST /api/v1/test-pipeline/run

Input:
PipelineRunRequest
├── dataset: DatasetInputConfig
├── preprocessing: PreprocessingConfig
├── feature_engineering: FeatureEngineeringConfig | None
├── training:
│   ├── XGBoostTrainingConfig
│   └── IsolationForestTrainingConfig
│   discriminated by model_type
└── output_directory: Path

Stages:
1. Part A once
2. For each Part A KPI:
   a. Part B
   b. Part C
   c. Part D

Primary workflow:
run_test_pipeline_workflow()

A → B:
exact KPIEDARunResult
+
DatasetInputConfig
+
PreprocessingConfig
+
Part A resolved BucketConfig

B → C:
exact PreprocessingRunnerResult
+
DatasetInputConfig
+
FeatureEngineeringConfig
+
same Part A BucketConfig

C → D:
feature_engineering_result.final_dataset_file
+
feature_engineering_result.resolved_config
+
resolved_config.minimum_history_points
+
request.dataset.columns
+
request.training
+
request.training.model_type
+
metadata linking KPI and Part C artifacts

Output:
HTTP JSON containing:
- Part A headline outputs
- Part B paths/statistics
- Part C paths/features/statistics
- Part C minimum history
- Part D status/model type
- trained/skipped series counts
- Part D validation contract
- chronological split plan
- model files
- persisted training artifact paths

Folder root:
caller-supplied output_directory

Workflow-created:
<root>/eda/
<root>/preprocessing/<KPI>/
<root>/feature_engineering/<KPI>/
<root>/part_d/<KPI>/

Part D-created inside supplied KPI D root:
training/
├── models
├── split plan
├── training config
├── feature contract
├── final hyperparameters
├── training summary
├── decision settings
├── usable row counts
└── metadata

Important validation:
- Pydantic request validation
- model_type discriminated training schema
- Part A dataset/integrity validation
- Part B exact A handoff validation
- Part C exact B handoff validation
- Part C bucket/feature validation
- Part D training dataset validation
- Part D feature selection validation
- valid/invalid series handling
- minimum split requirements
- chronological split creation

Important errors:
Schema errors:
    FastAPI request validation path

Runtime/module errors:
    HTTP 500
    {
      status: failed,
      error_type: ...,
      message: ...
    }

Failure scope:
Any A/B/C/D failure aborts the remaining overall request.

Model behaviour:
One selected model type per request.
Part D internally trains that model independently for valid site series.

Optuna:
No Optuna-specific integration branch is present in this historical version.

Test-only logic:
- temporary endpoint/server
- caller-supplied filesystem root
- synchronous A→D execution
- direct model/artifact paths in response
- no persistent master run
- no partial-success handling

Key integration lessons:
1. A→B and B→C result-object handoffs remain stable.
2. C→D introduces a persisted-file handoff.
3. Part D receives the exact C final dataset path.
4. Part D receives C's resolved feature contract, not the unresolved request.
5. Part C minimum history is explicitly propagated into training.
6. Dataset column mappings are explicitly propagated into D.
7. training.model_type is the Part D dispatch switch.
8. One model type applies across all KPIs in one request.
9. Omitted C config is resolved according to the selected D model type.
10. D owns per-site model iteration and invalid-site skipping.
11. Workflow attaches KPI/Part C provenance to training metadata.
12. Part D persists models plus the contracts needed to explain/reuse that training run.
13. Filesystem state becomes an explicit cross-stage contract starting with C→D.
14. Module runners remain the orchestration boundaries.
```

---

# Final Historical Interpretation

Pipeline 3 extends the stable earlier architecture:

```text
External request
      ↓
Part A once
      ↓
EDARunnerResult
      ↓
KPIEDARunResult
      ↓
Part B
      ↓
PreprocessingRunnerResult
      ↓
Part C
      ↓
FeatureEngineeringRunnerResult
      ↓
extract:
├── final_dataset_file
├── resolved feature config
└── minimum history
      ↓
Part D
      ↓
PartDTrainingResult
      +
saved model/training artifacts
```

The most important architectural change is that the handoff style changes at Part D.

Earlier:

```text
A → B
Python result object

B → C
Python result object
```

But:

```text
C → D
persisted feature-engineered CSV
+
resolved feature contract object
+
minimum-history value
+
dataset column contract
+
training config
+
upstream metadata
```

Thus Part D is the first stage where **persisted filesystem artifacts become a first-class cross-stage dependency**, while structured configuration/results still carry the semantic contract around those files.

The second major change is the coupling of model selection to default feature generation:

```text
training.model_type
        ↓
Part C default profile
```

when no custom Part C configuration is provided.

Finally, the workflow remains intentionally thin regarding actual training: it selects the model family and supplies the correct C outputs/contracts, while **Part D itself owns per-site validation, chronological splitting, model execution, model serialization and training artifact creation**.  
This gives the historical baseline that the next **A→B→C→D after Optuna** pipeline should be compared against.