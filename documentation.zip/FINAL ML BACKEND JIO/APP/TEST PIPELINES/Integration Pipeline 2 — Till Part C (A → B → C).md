# Historical Integration Pipeline 2 — Till Part C (A → B → C)

**Pipeline:** Part A EDA → Part B Preprocessing → Part C Feature Engineering  
**Historical role:** Second integration pipeline, extending the original A→B test pipeline by adding Part C while preserving the existing Part A/B behaviour.

---

# 1. Pipeline Purpose

This pipeline connects:

```text
Part A — EDA
      ↓
Part B — Preprocessing
      ↓
Part C — Feature Engineering
```

Its purpose was to verify that:

- the existing A→B integration still worked;
    
- one API request could now also configure Part C;
    
- Part A could run once for the source dataset;
    
- each KPI returned by Part A could independently run through B and then C;
    
- the exact `PreprocessingRunnerResult` returned by Part B could be passed directly to Part C;
    
- the same resolved dataset bucket could be propagated through B and C;
    
- Part C could create its own KPI-specific output tree;
    
- Part C feature columns and statistics could be included in the API response.
    

The workflow explicitly identifies itself as a **temporary server-testing integration**.

It does not yet support:

```text
Part D — Training
Part E — Inference
model selection
Optuna
saved models
training metrics
model/cache lifecycle
```

---

# 2. File Map

|File|Responsibility|Main functions/classes|Calls / Depends On|
|---|---|---|---|
|`test_pipeline_till_part_c.py`|Combined A+B+C request schema|`PipelineRunRequest`|`DatasetInputConfig`, `PreprocessingConfig`, `FeatureEngineeringConfig`|
|`test_pipeline_routes_till_part_c.py`|FastAPI HTTP interface and response shaping|`run_test_pipeline()`, `build_pipeline_response()`|request schema, workflow|
|`test_pipeline_workflow_till_part_c.py`|Actual A→B→C orchestration|`run_test_pipeline_workflow()`, `KPIWorkflowResult`, `TestPipelineWorkflowResult`|Part A runner, Part B runner, Part C runner|
|`test_main_till_part_c.py`|Temporary FastAPI application|`app`, `health_check()`|Part C test router|

The schema only combines existing schemas and contains no execution logic.

The route remains HTTP-only and delegates execution to the workflow.

The workflow owns the actual integration sequence.

---

# 3. Public API Contract

## Pipeline endpoint

```text
Method:
POST

Router path:
/test-pipeline/run

Application prefix:
/api/v1

Effective endpoint:
POST /api/v1/test-pipeline/run

Request schema:
PipelineRunRequest

Workflow:
run_test_pipeline_workflow()

Success:
HTTP 200

Failure:
HTTP 500 for workflow/runtime exceptions
```

The route still uses:

```text
/test-pipeline/run
```

and the temporary app registers it under:

```text
/api/v1
```

so the final endpoint remains:

```text
POST /api/v1/test-pipeline/run
```

## Health endpoint

The application also exposes:

```text
GET /health
```

returning:

```json
{
  "status": "healthy"
}
```

---

# 4. Complete Request / Configuration Structure

The request is now:

```text
PipelineRunRequest
│
├── dataset
│   └── DatasetInputConfig
│
├── preprocessing
│   └── PreprocessingConfig
│
├── feature_engineering
│   └── FeatureEngineeringConfig
│
└── output_directory
    └── Path
```

---

## Dataset / shared config

```text
dataset: DatasetInputConfig
```

remains the shared dataset contract used by all three stages.

It supplies:

```text
source file
column mappings
bucket information
KPI identity
expected timeline configuration
```

where applicable.

---

## Part A config

There is still no separate EDA-specific object.

Part A receives:

```text
request.dataset
```

directly.

---

## Part B config

```text
preprocessing: PreprocessingConfig
```

is passed unchanged into Part B.

The integration layer does not duplicate or reinterpret Part B settings.

---

## Part C config

Pipeline 2 adds:

```text
feature_engineering: FeatureEngineeringConfig
```

This exposes the complete Part C feature configuration.

Important behaviour:

```python
default_factory=FeatureEngineeringConfig
```

means that the entire field may be omitted.

If omitted:

```text
FeatureEngineeringConfig()
```

is created automatically.

The comments explicitly state that this exists so **older temporary A→B test requests can continue to work** while Part C uses its schema-owned default feature profile.

This is an important chronological compatibility change from Pipeline 1.

---

## Part C feature selection behaviour

At the integration layer:

```text
custom feature config supplied
        ↓
use request.feature_engineering

field omitted
        ↓
FeatureEngineeringConfig()
        ↓
schema-owned default profile
```

The actual feature profile resolution remains Part C schema behaviour, not workflow behaviour.

---

## Pipeline-level config

```text
output_directory
```

remains the only real pipeline-level configuration.

It becomes the root for:

```text
eda/
preprocessing/
feature_engineering/
```

---

## Request strictness

The top-level schema again uses:

```text
extra = "forbid"
```

so unrecognized request fields are rejected.

---

# 5. Exact Integration Execution Flow

```text
POST /api/v1/test-pipeline/run
        │
        ▼
PipelineRunRequest validation
        │
        ▼
run_test_pipeline()
        │
        ▼
run_test_pipeline_workflow()
        │
        ▼
Create / resolve output root
        │
        ├── eda/
        ├── preprocessing/
        └── feature_engineering/
        │
        ▼
run_eda_pipeline()
        │
        ▼
EDARunnerResult
        │
        ▼
For each KPIEDARunResult
        │
        ├── extract KPI name
        ├── sanitize KPI name
        │
        ▼
Create preprocessing/<KPI>/
        │
        ▼
run_preprocessing_pipeline()
        │
        ▼
PreprocessingRunnerResult
        │
        ▼
Create feature_engineering/<KPI>/
        │
        ▼
run_feature_engineering_pipeline()
        │
        ▼
FeatureEngineeringRunnerResult
        │
        ▼
KPIWorkflowResult
        │
        ▼
Repeat for all KPI results
        │
        ▼
TestPipelineWorkflowResult
        │
        ▼
build_pipeline_response()
        │
        ▼
HTTP 200 JSON
```

---

## 5.1 Root directory creation

The workflow creates:

```text
<output_root>/
├── eda/
├── preprocessing/
└── feature_engineering/
```

using `ensure_directory()`.

---

## 5.2 Part A execution

Part A is executed once:

```python
run_eda_pipeline(
    config=request.dataset,
    logger=logger,
    output_directory=eda_root,
)
```

It returns:

```text
EDARunnerResult
```

containing:

```text
preparation
kpi_results[]
```

---

## 5.3 KPI loop

The workflow iterates:

```python
eda_result.kpi_results
```

exactly as Pipeline 1 did.

Therefore Part A remains the authoritative source of downstream KPI enumeration.

---

## 5.4 KPI name handling

For every KPI:

```python
raw_kpi_name =
    kpi_result.prepared_dataset.kpi_name
```

then:

```python
safe_kpi_name =
    sanitise_filename(raw_kpi_name)
```

If empty:

```text
kpi_<index>
```

is used.

The same sanitized name is reused for both:

```text
preprocessing/<KPI>/
feature_engineering/<KPI>/
```

---

## 5.5 Part A → Part B

Part B receives:

```text
kpi_result
    = exact KPIEDARunResult

dataset_config
    = request.dataset

preprocessing_config
    = request.preprocessing

bucket
    = eda_result.preparation.bucket

output_directory
    = preprocessing/<safe KPI>/

logger
```

This handoff is unchanged from Pipeline 1.

---

## 5.6 Part B result

Part B returns:

```text
PreprocessingRunnerResult
```

The workflow retains this exact result object.

It is not serialized and then reloaded before Part C.

---

## 5.7 Part B → Part C

The workflow calls:

```python
run_feature_engineering_pipeline(
    preprocessing_result=preprocessing_result,
    output_directory=kpi_feature_engineering_output_directory,
    dataset_config=request.dataset,
    feature_config=request.feature_engineering,
    bucket=eda_result.preparation.bucket,
    logger=logger,
)
```

This establishes the historical B→C integration contract.

Part C receives:

```text
exact PreprocessingRunnerResult
DatasetInputConfig
FeatureEngineeringConfig
Part A resolved BucketConfig
KPI-specific output directory
shared logger
```

---

## 5.8 How Part C obtains the actual Part B dataset

The workflow itself does **not** extract:

```text
preprocessing_result.final_dataset_file
```

and manually pass the CSV path.

Instead it passes the complete:

```text
PreprocessingRunnerResult
```

into Part C.

Part C's own runner validates that handoff and resolves:

```text
preprocessing_result.final_dataset_file
```

as its source.

Therefore:

```text
Workflow
    ↓
passes exact Part B result object
    ↓
Part C runner
    ↓
extracts exact final Part B dataset path
```

This maintains module-runner ownership of handoff validation.

---

## 5.9 Bucket propagation

The same:

```text
eda_result.preparation.bucket
```

is passed to both:

```text
Part B
Part C
```

Part C then independently verifies that the bucket implied by Part B's resolved preprocessing result agrees with its own feature configuration resolution.

Thus the integration chain is:

```text
Part A resolves bucket
        ↓
workflow propagates same BucketConfig
        ↓
Part B resolves preprocessing frequency
        ↓
Part C resolves feature frequency
        ↓
Part C verifies consistency
```

---

## 5.10 Result aggregation

For each KPI the workflow stores:

```text
KPIWorkflowResult
├── kpi_name
├── preprocessing_result
└── feature_engineering_result
```

All KPI objects are collected into:

```text
TestPipelineWorkflowResult
├── output_directory
├── eda_result
└── kpi_results[]
```

---

# 6. Stage-to-Stage Handoff Contract

|From|To|Information passed|Form|Purpose|
|---|---|---|---|---|
|API|Workflow|Complete integration request|`PipelineRunRequest`|Provides validated A/B/C configuration|
|Workflow|Part A|`request.dataset`|`DatasetInputConfig`|Source interpretation + EDA configuration|
|Part A|Workflow|complete EDA result|`EDARunnerResult`|Provides resolved bucket + KPI results|
|Part A|Part B|exact KPI result|`KPIEDARunResult`|Gives B exact Part A artifacts|
|Part A|Part B|resolved bucket|`BucketConfig`|Frequency source of truth|
|Request|Part B|preprocessing settings|`PreprocessingConfig`|Controls B behaviour|
|Request|Part B|dataset settings|`DatasetInputConfig`|Preserves physical dataset mappings|
|Part B|Workflow|complete preprocessing result|`PreprocessingRunnerResult`|Exposes final Part B artifacts/state|
|Part B|Part C|exact preprocessing result|`PreprocessingRunnerResult`|Gives C exact Part B handoff|
|Request|Part C|feature settings|`FeatureEngineeringConfig`|Controls requested/default features|
|Request|Part C|dataset settings|`DatasetInputConfig`|Preserves physical columns/site identity|
|Part A|Part C|same resolved bucket|`BucketConfig`|Allows C to resolve frequency-dependent features|
|Part C|Workflow|complete feature result|`FeatureEngineeringRunnerResult`|Exposes final feature dataset + statistics|
|Workflow|Route|complete workflow result|`TestPipelineWorkflowResult`|Used to construct API JSON|

---

# 7. KPI / Site / Model Iteration Behaviour

## KPI behaviour

Part A runs once.

Then:

```text
for each Part A KPI
    ↓
run Part B
    ↓
run Part C
```

So each KPI has a fully independent downstream branch:

```text
KPI A
  ↓
B(A)
  ↓
C(A)

KPI B
  ↓
B(B)
  ↓
C(B)
```

---

## Where KPI iteration occurs

KPI iteration remains owned by the integration workflow.

---

## Site iteration

There is still no site loop in the integration workflow.

Site-level processing belongs inside the modules.

### Part B

Handles site-specific:

```text
timeline correction
usability
outlier detection
gap filling
```

### Part C

Handles site-specific:

```text
validation
feature source preparation
feature generation
invalid-site skipping
history sufficiency
```

Therefore:

```text
Integration workflow:
KPI-level fan-out

Part B/C runners:
site-level processing
```

---

## Invalid sites entering Part C

Part C does not remove invalid sites.

It preserves their rows but skips feature generation, leaving Part C feature cells `NaN`.

This behaviour remains inside Part C rather than the test workflow.

---

## Model iteration

None.

Pipeline 2 still has no Part D training stage.

Therefore there is no:

```text
model-type loop
XGBoost
Isolation Forest
Optuna
training configuration
```

---

# 8. Folder and Artifact Structure

## Workflow-owned root structure

```text
<output_root>/
├── eda/
├── preprocessing/
│   └── <safe KPI>/
└── feature_engineering/
    └── <safe KPI>/
```

---

## Part A internal structure

Part A internally creates:

```text
eda/
├── prepared_datasets/
└── summaries/
    └── <KPI>/
```

with its prepared KPI and integrity-analysis artifacts.

---

## Part B internal structure

For every KPI:

```text
preprocessing/<KPI>/
├── <KPI>_final_cleaned.csv
├── summaries/
└── intermediate/       # optional
```

Part B owns the detailed files inside its KPI output directory.

---

## Part C internal structure

For every KPI, the workflow supplies:

```text
feature_engineering/<KPI>/
```

Part C creates its runner-owned structure:

```text
feature_engineering/<KPI>/
├── <KPI>_feature_engineered.csv
│
├── summaries/
│   └── 01_feature_engineering_site_summary.csv
│
└── intermediate/                      # optional
    └── 01_corrected_history_audit.csv
```

The intermediate folder/file only exists when applicable.

---

## Run/session naming

No new run-management mechanism appears in Pipeline 2.

Still absent:

```text
run_id
session_id
UUID
timestamp-based run folder
database run record
```

The caller again supplies:

```text
output_directory
```

directly.

---

# 9. Validation and Error Handling

## 9.1 Pydantic / request validation

The request now validates:

```text
DatasetInputConfig
PreprocessingConfig
FeatureEngineeringConfig
output_directory
```

before entering workflow execution.

Unknown top-level fields remain forbidden.

Normal FastAPI body-validation failures occur before the route's workflow `try/except`.

---

## 9.2 Feature config compatibility

Because:

```text
feature_engineering
```

has a default factory, omission is not an error.

Instead:

```text
FeatureEngineeringConfig()
```

is used.

The feature schema then resolves its default profile.

---

## 9.3 Workflow-level validation

The workflow itself mainly performs:

```text
directory creation
KPI name sanitization
KPI fallback folder naming
```

Domain validation remains inside A/B/C.

---

## 9.4 Part A validation

Part A validates:

```text
dataset
columns
KPI identity
bucket
timeline/integrity assumptions
```

---

## 9.5 Part B validation

Part B validates the exact `KPIEDARunResult` and the Part A artifacts referenced by it.

---

## 9.6 Part C handoff validation

Part C receives a genuine:

```text
PreprocessingRunnerResult
```

and validates:

```text
preprocessing_result.final_dataset_file
```

rather than searching a preprocessing folder.

Part C also verifies:

- actual Part B file exists;
    
- row count agrees with the preprocessing result where available;
    
- Part B dataset is structurally valid for the requested features;
    
- Part B resolved bucket agrees with Part C's bucket interpretation.
    

This is a strong B→C cross-stage contract.

---

## 9.7 Feature-generation failure

If one feature generator fails for one processable site, Part C raises an error rather than silently dropping that feature.

The integration workflow does not intercept it locally.

---

## 9.8 Route exception handling

The route again catches:

```python
except Exception
```

and converts the failure to:

```text
HTTP 500
```

with:

```json
{
  "detail": {
    "status": "failed",
    "error_type": "<exception class>",
    "message": "<error string>"
  }
}
```

---

## 9.9 Failure scope

There is no per-stage or per-KPI recovery.

Example:

```text
KPI A:
A → B → C succeeds

KPI B:
B succeeds
C fails
      ↓
workflow raises immediately
      ↓
API returns HTTP 500
      ↓
later KPIs are not processed
```

Existing A/B/C artifacts already written are not rolled back.

---

# 10. Response Contract

The route preserves the original Part B response structure and adds Part C data under:

```text
feature_engineering
```

for every KPI.

This is explicitly stated in the response-builder comments.

---

## Top-level response

```text
status
output_directory
kpi_count
eda_outputs
kpi_results
```

This remains unchanged from Pipeline 1.

---

## Existing Part B fields retained

Each KPI still contains:

```text
kpi_name
source_file
output_directory
final_dataset_file
summary_files
intermediate_files
statistics
method_counts
```

These continue to refer to **Part B** at the top of the KPI block.

---

## New Part C block

Each KPI additionally contains:

```text
feature_engineering
```

with:

```text
source_file
output_directory
final_dataset_file
summary_directory
site_summary_file
intermediate_directory
corrected_history_audit_file
feature_columns
statistics
```

---

## Part C statistics returned

```text
total_rows
total_sites
processed_sites
skipped_invalid_sites
insufficient_history_sites
populated_feature_cells
missing_feature_cells
```

---

## Part C feature list

The API exposes:

```text
feature_columns
```

as a JSON list copied from:

```text
FeatureEngineeringRunnerResult.feature_columns
```

This makes the exact resolved feature contract visible in the test response.

---

## Part C optional files

These may be null:

```text
intermediate_directory
corrected_history_audit_file
```

The route converts optional path-like values using:

```text
optional_path_to_string()
```

---

## Response is selective, not complete serialization

The route does not return the complete:

```text
EDARunnerResult
PreprocessingRunnerResult
FeatureEngineeringRunnerResult
```

It manually selects the fields useful for integration testing.

---

# 11. Responsibilities of the Test Workflow Itself

Pipeline 2's workflow owns the following logic outside A/B/C.

## Run-root hierarchy

Creates:

```text
eda
preprocessing
feature_engineering
```

---

## Stage sequencing

Enforces:

```text
A
↓
B
↓
C
```

---

## KPI fan-out

Runs:

```text
B once per Part A KPI
C once immediately after that KPI's B
```

Note that processing is **KPI-major**, not stage-major.

The code does:

```text
KPI A: B → C
KPI B: B → C
KPI C: B → C
```

not:

```text
all B runs
then all C runs
```

This is an important exact execution-order detail.

---

## KPI folder naming

Sanitizes one KPI name and reuses it across B and C roots.

---

## Config propagation

Passes:

```text
DatasetInputConfig
PreprocessingConfig
FeatureEngineeringConfig
resolved Part A BucketConfig
```

to the appropriate runners.

---

## Result-object connection

Connects:

```text
KPIEDARunResult
        ↓
Part B
        ↓
PreprocessingRunnerResult
        ↓
Part C
```

without reconstructing these contracts from filesystem names.

---

## Workflow aggregation

Stores both B and C results inside:

```text
KPIWorkflowResult
```

---

## Route-level responsibilities

The route owns:

```text
JSON response shape
Path serialization
exception → HTTP 500 conversion
```

---

# 12. Test-Only Behaviour

The following are clearly tied to integration testing.

## `/test-pipeline/run`

Still a temporary test endpoint.

---

## Temporary application

`test_main_till_part_c.py` explicitly describes the application as temporary.

---

## Direct filesystem path in request

The caller still controls:

```text
output_directory
```

---

## Filesystem paths returned to caller

The response exposes direct locations for:

```text
Part A folders
Part B final/summary/checkpoint files
Part C final/summary/audit files
```

---

## Backward-compatible feature default

The default factory for Part C was specifically added so older temporary test requests could omit the new field.

That is useful historical compatibility logic, not automatically a production requirement.

---

## No run state persistence

Still absent:

```text
job record
run state
resume state
database mapping
persistent lifecycle
```

---

## Synchronous request execution

The entire A→B→C chain runs synchronously inside the API request.

---

## Test logging

The test app again configures:

```python
logging.basicConfig(...)
```

globally.

---

# 13. Integration Rules Learned From This Pipeline

Pipeline 2 confirms several Pipeline 1 rules and adds new ones.

## Confirmed Rule 1 — Part A still runs once

The pipeline does not rerun A for each KPI.

---

## Confirmed Rule 2 — Part A owns KPI discovery

Downstream processing iterates:

```text
eda_result.kpi_results
```

---

## Confirmed Rule 3 — Part B still receives exact `KPIEDARunResult`

This contract survives unchanged from Pipeline 1.

---

## New Rule 4 — Part C receives exact `PreprocessingRunnerResult`

The workflow passes:

```text
preprocessing_result
```

directly to Part C.

---

## New Rule 5 — Part C itself resolves the final Part B CSV

The workflow does not manually extract/reconstruct the Part B final dataset path.

That remains Part C runner responsibility.

---

## Confirmed Rule 6 — Shared dataset config propagates through stages

```text
request.dataset
```

is reused for:

```text
A
B
C
```

---

## Confirmed / Extended Rule 7 — One resolved bucket propagates downstream

```text
eda_result.preparation.bucket
```

is reused for both:

```text
B
C
```

---

## New Rule 8 — C validates bucket consistency against B

Part C does not blindly trust the supplied bucket; it compares its resolved bucket interpretation against the Part B result.

---

## Confirmed Rule 9 — KPI iteration remains in workflow

---

## Confirmed Rule 10 — Site iteration remains inside modules

---

## Confirmed Rule 11 — Module runners remain stage boundaries

The workflow calls:

```text
run_eda_pipeline()
run_preprocessing_pipeline()
run_feature_engineering_pipeline()
```

and never individual internal stage functions.

---

## New Rule 12 — Part C configuration can be omitted and schema defaults used

This was added specifically in this pipeline.

---

## New Rule 13 — Feature output contract is visible through `feature_columns`

The API response reports the exact resolved Part C output feature names.

---

## Rule 14 — Processing is KPI-major

For every KPI:

```text
B → C
```

completes before the next KPI begins.

---

# 14. Limitations of This Pipeline Version

This pipeline now proves:

```text
A → B → C
```

but still does not address:

```text
training
model selection
training artifacts
model metrics
fixed hyperparameters
Optuna
model persistence
inference
cache/history lifecycle
```

It also does not prove:

- independent production endpoints per stage;
    
- resume-from-Part-B behaviour;
    
- asynchronous job execution;
    
- partial-success handling;
    
- persistent run records;
    
- cross-run model linkage.
    

Those remain for later pipelines.

---

# 15. Conflicts or Questionable Behaviour

|Issue|Severity|Evidence|Possible impact|
|---|---|---|---|
|Generic runtime failures still become HTTP 500|**Important**|Route catches all `Exception`|User/data errors remain indistinguishable from internal bugs|
|No per-KPI recovery|**Important**|One sequential loop with no local exception handler|A Part C failure for one KPI aborts remaining KPIs|
|No per-stage recovery/resume|**Important / Historical**|B result is immediately followed by C|Successful Part B work can exist even though the overall request fails|
|Caller directly controls filesystem output root|**Historical/Test-only**|`output_directory` in request|Test convenience; weak production isolation if carried forward|
|No run/session ID|**Historical/Test-only**|No generated run identity|Same-root reruns/concurrency may interact with existing files|
|Sanitized KPI names still lack visible collision protection|**Important / Potential bug**|Same sanitized folder name is reused for B and C|Two distinct KPI names could potentially share directories|
|Raw exception strings returned|**Important**|`message: str(error)`|Internal details can leak to API caller|
|No response model|**Minor**|Returns `dict[str, Any]`|Manual contract can drift as later stages are added|
|Response hierarchy is asymmetric|**Minor / Historical**|B fields remain top-level in each KPI; C is nested|Reflects extension of the earlier A→B test contract rather than a stage-neutral response design|
|Backward-compatible omitted Part C config silently activates defaults|**Historical/Test-only / Important**|`default_factory=FeatureEngineeringConfig`|Old A→B-style request now performs Part C automatically with default features|
|Synchronous A→B→C execution|**Historical/Test-only**|Full workflow executes inside POST|Increasing runtime as stages are added|
|No rollback|**Historical/Test-only**|Artifacts are written stage-by-stage|Failed C can leave valid A/B artifacts on disk|

The backward-compatibility point is particularly worth retaining for the later synthesis: an older request that does not contain `feature_engineering` no longer means "run only A→B"; under this Pipeline 2 schema it means **run A→B→C using default Part C features**.

---

# 16. Compact Pipeline Contract

```text
Pipeline:
Part A → Part B → Part C

Endpoint:
POST /api/v1/test-pipeline/run

Input:
PipelineRunRequest
├── dataset: DatasetInputConfig
├── preprocessing: PreprocessingConfig
├── feature_engineering: FeatureEngineeringConfig
│   └── optional at request level via default factory
└── output_directory: Path

Stages:
1. Part A once
2. For each Part A KPI:
   a. Part B once
   b. Part C once

Primary workflow:
run_test_pipeline_workflow()

A → B:
exact KPIEDARunResult
+
DatasetInputConfig
+
PreprocessingConfig
+
Part A resolved BucketConfig

B → C:
exact PreprocessingRunnerResult
+
DatasetInputConfig
+
FeatureEngineeringConfig
+
same Part A resolved BucketConfig

Part C source dataset:
Part C runner extracts
preprocessing_result.final_dataset_file

Output:
HTTP JSON containing:
- EDA root/preparation information
- Part B paths/statistics/method counts
- Part C final dataset
- Part C summary/audit paths
- resolved feature_columns
- Part C site/feature statistics

Folder root:
caller-supplied output_directory

Workflow-created:
<root>/eda/
<root>/preprocessing/<KPI>/
<root>/feature_engineering/<KPI>/

Important validation:
- Pydantic request validation
- A dataset/runtime validation
- B exact Part A handoff validation
- B frequency resolution
- C exact Part B handoff validation
- C final-file existence/row validation
- C bucket consistency
- C feature contract/output validation

Important errors:
Request schema errors:
    FastAPI validation path

Workflow/module errors:
    HTTP 500
    {
      status: failed,
      error_type: ...,
      message: ...
    }

Failure scope:
Any A/B/C failure aborts the remaining complete request.

Test-only logic:
- temporary test endpoint
- temporary FastAPI server
- direct filesystem output root
- filesystem paths exposed in response
- synchronous execution
- backward compatibility through default Part C config
- no run/session persistence

Key integration lessons:
1. Part A remains single-run dataset/KPI authority.
2. B still receives exact KPIEDARunResult.
3. C receives exact PreprocessingRunnerResult.
4. C resolves the exact B final dataset from that result.
5. Shared DatasetInputConfig remains common across A/B/C.
6. The Part A resolved BucketConfig is propagated through B and C.
7. C performs its own cross-stage bucket consistency check.
8. Workflow owns KPI-level sequencing, not site-level processing.
9. Module runners remain the integration boundary.
10. Each KPI completes B→C before the next KPI begins.
11. Part C can use schema-owned defaults when its request block is omitted.
12. Structured runner objects, not directory rediscovery, remain the primary handoff mechanism.
```

---

# Final Historical Interpretation

Pipeline 2 extends the original integration cleanly:

```text
External request
      ↓
Dataset + B config + C config
      ↓
Part A once
      ↓
EDARunnerResult
      ↓
KPIEDARunResult × N
      ↓
For each KPI:
    Part B
      ↓
PreprocessingRunnerResult
      ↓
    Part C
      ↓
FeatureEngineeringRunnerResult
      ↓
aggregated response
```

The major architectural advancement over Pipeline 1 is the new direct handoff:

```text
PreprocessingRunnerResult
        ↓
Part C
```

Part C does not rediscover preprocessing artifacts from directories. It receives the exact Part B result, validates it, and uses the exact `final_dataset_file` carried by that result.

At the same time, Pipeline 2 confirms that the broader integration pattern remained stable:

```text
shared request config
+
module runner boundaries
+
structured result-object handoffs
+
workflow-owned KPI fan-out
+
module-owned site processing
+
workflow-owned high-level directories
```

This makes Pipeline 2 the first historical version demonstrating the complete **data-preparation chain A→B→C** before model training was introduced.