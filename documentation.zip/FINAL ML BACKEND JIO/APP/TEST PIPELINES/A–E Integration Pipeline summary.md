	# Final A–E Integration Pipeline Synthesis

## Historical Test Pipelines 1–5

This report combines the five tested historical integration pipelines into one final view of how requests, configuration, result objects, files, and persisted state moved through the ML backend.

The five pipelines form a clear chronological progression rather than five unrelated designs.

---

# 1. Evolution Across the Five Pipelines

|Version|Pipeline|Main addition|
|---|---|---|
|**1**|A → B|First multi-stage integration|
|**2**|A → B → C|Added Feature Engineering|
|**3**|A → B → C → D|Added model training|
|**4**|A → B → C → D|Added fixed/Optuna-capable Part D configuration|
|**5**|A → B → C → D → saved run → E|Added persistent training→inference lifecycle|

The progression is:

```text
Pipeline 1
A → B

Pipeline 2
A → B → C

Pipeline 3
A → B → C → D

Pipeline 4
A → B → C → D
              ├── fixed/direct
              └── Optuna

Pipeline 5
A → B → C → D
              ↓
        saved inference run
              ↓
       later Part E calls
```

The biggest structural change is therefore **not Optuna**.

It is Pipeline 5, where the backend changes from one synchronous processing chain into:

```text
TRAINING LIFECYCLE
        ↓
persistent saved run
        ↓
INFERENCE LIFECYCLE
```

---

# 2. Endpoint Evolution

## Pipelines 1–4

All use:

```text
POST /api/v1/test-pipeline/run
```

The endpoint path stays the same while the workflow behind it expands.

|Pipeline|Meaning of `/test-pipeline/run`|
|---|---|
|1|A → B|
|2|A → B → C|
|3|A → B → C → D|
|4|A → B → C → D with fixed/Optuna-capable training|

## Pipeline 5

Training still uses:

```text
POST /api/v1/test-pipeline/run
```

but now means:

```text
A → B → C → D
+
prepare persistent Part-E state
```

A new endpoint appears:

```text
POST /api/v1/test-inference/run
```

which performs only future inference against an already completed saved run.

All five temporary servers also expose:

```text
GET /health
```

---

# 3. Request Schema Evolution

The request schemas are **cumulative**, not fundamentally different.

## Pipeline 1

```text
dataset
preprocessing
output_directory
```

## Pipeline 2

```text
dataset
preprocessing
feature_engineering
output_directory
```

## Pipeline 3

```text
dataset
preprocessing
feature_engineering | None
training
output_directory
```

## Pipeline 4

Structurally similar to Pipeline 3, but the model training schemas now carry fixed/direct/Optuna-capable hyperparameter behaviour.

## Pipeline 5

```text
dataset
preprocessing
feature_engineering | None
training
output_directory
run_id | None
inference_bootstrap
```

and the separate inference request uses:

```text
run_id
input_file
inference_days

+ run_directory   # temporary test-only field
```

### Main conclusion

There is no evidence of five conflicting schema architectures.

Instead:

```text
shared schema contracts
        +
new stage-specific config as stages were added
```

---

# 4. Configuration Propagation Map

## Shared dataset configuration

The same:

```text
DatasetInputConfig
```

is the foundation of every training pipeline.

It provides the physical dataset contract such as:

```text
source file
column mappings
KPI identity
bucket information
expected timeline information
```

### Part A

Receives:

```text
DatasetInputConfig
```

directly.

There is no separate EDA integration config.

---

## Part B

Receives:

```text
KPIEDARunResult
DatasetInputConfig
PreprocessingConfig
resolved BucketConfig
```

---

## Part C

Receives:

```text
PreprocessingRunnerResult
DatasetInputConfig
FeatureEngineeringConfig
resolved BucketConfig
```

---

## Part D

Receives:

```text
model_type
Part C final dataset path
DatasetColumnMapping
Part C resolved feature contract
Part C minimum_history_points
TrainingConfig
metadata
```

---

## Part E

Does not depend on the current application defaults.

It consumes a frozen saved contract containing:

```text
Dataset contract
Part B original + resolved contract
Part C original + resolved contract
history contract
storage contract
model contract
```

written during training bootstrap.

---

# 5. Feature-Engineering Default Evolution

This is one genuine historical change.

## Pipeline 2

If `feature_engineering` is omitted:

```text
FeatureEngineeringConfig()
```

is created automatically by the request schema.

## Pipelines 3–5

The field becomes:

```text
FeatureEngineeringConfig | None
```

If omitted, the workflow creates:

```python
FeatureEngineeringConfig(
    default_profile=request.training.model_type
)
```

### Interpretation

Pipeline 2 had no model context yet.

Once Part D existed, the default Part C profile became explicitly linked to the model family.

Therefore the later behaviour is a logical evolution rather than a contradiction:

```text
No model exists yet
    → generic C default

Model exists
    → model-matched C default
```

---

# 6. Result-Object Propagation Map

|Result object|Produced by|Consumed by|Important fields used|
|---|---|---|---|
|`EDARunnerResult`|Part A|Workflow|`kpi_results`, resolved preparation/bucket|
|`KPIEDARunResult`|Part A|Part B|exact prepared KPI + Part A artifacts|
|`PreprocessingRunnerResult`|Part B|Part C / workflow / E bootstrap|`final_dataset_file`, resolved frequency, stats|
|`FeatureEngineeringRunnerResult`|Part C|Workflow / Part D|`final_dataset_file`, `resolved_config`, features|
|`PartDTrainingResult`|Part D|Workflow / bootstrap|validation, split plan, output paths|
|`InferenceRunnerResult`|Part E|API route|inference outputs + committed history state|

---

# 7. Stable A → B Handoff

This is consistent across all five pipelines.

```text
Part A
    ↓
EDARunnerResult
    ↓
workflow loops eda_result.kpi_results
    ↓
exact KPIEDARunResult
    ↓
Part B
```

Part B receives the actual Python object:

```text
KPIEDARunResult
```

rather than reconstructing Part A state from directory names.

### Stable rule

> **Part A determines the KPI list and Part B receives the exact Part A KPI result.**

---

# 8. Stable B → C Handoff

From Pipeline 2 onward:

```text
Part B
    ↓
PreprocessingRunnerResult
    ↓
Part C
```

The workflow passes the exact:

```text
PreprocessingRunnerResult
```

rather than extracting a filename and asking Part C to rediscover the rest.

Part C itself resolves:

```text
preprocessing_result.final_dataset_file
```

and validates the handoff.

### Stable rule

> **B→C remains a structured Python result-object handoff.**

---

# 9. C → D Is Different

This is the first point where the handoff style changes.

Part D does **not** receive:

```text
FeatureEngineeringRunnerResult
```

as one complete object.

The workflow extracts:

```text
feature_engineering_result.final_dataset_file
feature_engineering_result.resolved_config
feature_engineering_result.resolved_config.minimum_history_points
```

and also sends:

```text
request.dataset.columns
request.training
request.training.model_type
metadata
```

Therefore:

```text
A → B
object handoff

B → C
object handoff

C → D
persisted CSV
+
resolved contract/config objects
+
history requirement
```

### Important implication

The filesystem becomes an explicit cross-stage dependency starting at Part D.

---

# 10. Part C → Part D History Contract

Part D does not independently guess how much prior data must be reserved.

It receives:

```text
feature_engineering_result
    .resolved_config
    .minimum_history_points
```

from Part C.

Therefore:

```text
Part C determines feature-history requirement
             ↓
Part D uses that requirement in training preparation/splitting
```

This remains stable in Pipelines 3, 4 and 5.

---

# 11. Fixed vs Optuna Integration

Pipeline 4 shows that adding Optuna **did not change the orchestration architecture**.

Pipeline 3:

```text
C
↓
run_training(...)
```

Pipeline 4:

```text
C
↓
run_training(...)
```

The difference is inside:

```text
request.training
```

which now carries tuning state such as:

```text
hyperparameter_tuning_enabled
hyperparameter_tuning_method
model-specific tuning configuration
```

The workflow does not itself perform:

```text
Optuna trials
search-space generation
trial scoring
best-trial selection
```

Those remain inside Part D.

### Stable integration rule

> Fixed/direct and Optuna training should remain behind the same Part D runner boundary.

---

# 12. Model and KPI Iteration

## KPI loop

The workflow consistently performs:

```text
Part A once
      ↓
for each Part A KPI:
    downstream stages
```

From Pipeline 3 onward:

```text
KPI A: B → C → D
KPI B: B → C → D
KPI C: B → C → D
```

Processing is **KPI-major**, not:

```text
all B
all C
all D
```

---

## Site loops

The integration workflows do not manually loop over sites.

Site processing remains inside:

```text
Part A
Part B
Part C
Part D
Part E
```

as appropriate.

---

## Model selection

One training request selects:

```text
XGBoost
OR
Isolation Forest
```

The chosen model applies across every KPI in that request.

The historical pipelines do not demonstrate a request containing:

```text
KPI A → XGBoost
KPI B → Isolation Forest
```

simultaneously.

---

# 13. Filesystem Evolution

## Pipeline 1

Primarily:

```text
eda/
preprocessing/
```

## Pipeline 2

Adds:

```text
feature_engineering/
```

## Pipeline 3

Adds:

```text
part_d/
    <KPI>/
        training/
```

and now model/config/summary files become important cross-stage artifacts.

## Pipeline 5

Adds persistent runtime state:

```text
inference_config.json

inference_state/
├── history/
└── cache/

inference_results/
```

### Evolution

```text
filesystem = output location
        ↓
filesystem = training artifact contract
        ↓
filesystem = persistent inference runtime state
```

---

# 14. Part D Persisted Artifacts

Part D exposes paths for:

```text
model files
split plan
training config
feature contract
final hyperparameters
training summary
decision settings
usable row counts
metadata
```

These artifacts become especially important in Pipeline 5.

---

# 15. D → E Is a Persistent Contract, Not a Normal Stage Handoff

This is the largest change across the five pipelines.

There is no:

```text
PartDTrainingResult
        ↓
immediately call Part E
```

Instead:

```text
Part D results/artifacts
+
Part B contract
+
Part C contract
+
training raw data
+
processed history
        ↓
create saved inference state
        ↓
future Part E request
```

Pipeline 5 creates:

```text
inference_config.json
```

which freezes:

```text
dataset contract
preprocessing contract
feature-engineering contract
history contract
storage contract
model contract
```

### Stable lifecycle rule

> **Training and inference are separate request lifecycles connected by persistent saved state.**

---

# 16. History and Cache Contract

Pipeline 5 establishes four important forms of state:

```text
raw full history
raw rolling cache

processed full history per KPI
processed rolling cache per KPI
```

Initial raw history comes from:

```text
original training input CSV
```

Initial processed history comes from:

```text
Part B final cleaned KPI dataset
```

not the Part C feature-engineered dataset.

---

# 17. Required History Calculation

The bootstrap combines B and C requirements.

Conceptually:

```text
final_required_history_points =
max(
    Part B history requirement,
    Part C minimum_history_points,
    Part C maximum_lookback_points + 1
)
```

and:

```text
cache_days =
final_required_history_days
+
max_gap_days
```

### Rule

Part E history/cache size is not arbitrary.

It derives from the actual frozen preprocessing and feature-engineering contracts.

---

# 18. Model Contract for Inference

Pipeline 5 reloads finalized Part D artifacts from disk:

```text
metadata JSON
decision-settings JSON
```

It does not rely solely on the live `PartDTrainingResult`.

For each trained series it captures:

```text
identity
model file
decision settings
model feature columns
target column where applicable
```

The saved model paths are converted to paths relative to the run root.

### Rule

> D→E requires both runtime objects **and persisted finalized Part D artifacts**.

---

# 19. Inference Request Contract

The real Part E request is intentionally small:

```text
run_id
input_file
inference_days
```

Pipeline 5 temporarily adds:

```text
run_directory
```

only because no database/service yet resolves:

```text
run_id → run_directory
```

The test workflow strips `run_directory` before calling the real Part E runner.

### Production-oriented evidence

The intended abstraction is therefore:

```text
client provides run_id
        ↓
backend resolves saved run
        ↓
Part E receives run directory internally
```

---

# 20. Response Evolution

Responses also grow cumulatively.

## Pipeline 1

```text
EDA information
+
Part B paths/statistics
```

## Pipeline 2

Adds:

```text
feature_engineering
```

## Pipeline 3

Adds:

```text
training
```

including:

```text
validation
split plan
model paths
training artifact paths
```

## Pipeline 4

Adds explicit:

```text
hyperparameter_tuning
├── enabled
└── method
```

## Pipeline 5 training endpoint

Adds:

```text
saved_run
```

containing:

```text
run_id
run_directory
inference_config
history/cache paths
history contract
```

## Pipeline 5 inference endpoint

Returns:

```text
run_id
model_type
invocation_id
inference window
per-series outputs
skipped series
manifest
history commit
```

---

# 21. Error Handling — What Stayed the Same

Across all five versions, runtime handling remains very similar.

The route generally does:

```python
except Exception:
    raise HTTPException(500, ...)
```

Therefore runtime problems from:

```text
A
B
C
D
E/bootstrap
```

are broadly converted into HTTP 500 responses.

Pipeline 5 improves diagnostics slightly by adding:

```text
stage =
training_pipeline_or_inference_bootstrap
```

or:

```text
stage = inference
```

but does not identify A/B/C/D individually.

---

# 22. Failure Scope — Consistent Historical Behaviour

All training pipelines are effectively:

```text
fail fast
```

There is no per-KPI exception isolation.

Example:

```text
KPI 1 succeeds
KPI 2 succeeds
KPI 3 fails
        ↓
overall request fails
        ↓
KPI 4 never executes
```

Previously written files may remain on disk.

This behaviour is consistent enough to treat as a genuine historical integration pattern, although whether it should remain in production is still an open decision.

---

# 23. Logic Owned by Integration Workflows

Across the five pipelines, the workflows consistently own:

```text
stage sequencing
high-level stage directories
KPI fan-out
KPI folder sanitization
config propagation
cross-stage result wiring
result aggregation
```

Later versions additionally own:

```text
model-matched Part C default resolution
Part D provenance metadata
tuning provenance
saved-run ID
training→inference bootstrap
history/cache initialization
saved model contract construction
```

---

# 24. Logic Clearly Remaining Inside ML Modules

## Part A

```text
dataset preparation
KPI discovery
EDA/site/integrity processing
```

## Part B

```text
timeline correction
series usability
outlier handling
gap filling
```

## Part C

```text
feature preparation
feature generation
site handling
resolved feature/history contract
```

## Part D

```text
training input validation
chronological splitting
per-site training
fixed/Optuna execution
model serialization
metrics/artifact creation
```

## Part E

```text
saved-run loading
runtime A/B/C processing
saved model loading
inference
anomaly decisions
history/cache commit
```

The test workflow does **not** reimplement these module internals.

---

# 25. Stable Integration Rules Across All Versions

The strongest code-supported rules are:

1. **Use module runners as stage boundaries.**
    
2. **Run Part A once per incoming training dataset.**
    
3. **Part A's returned KPI list is the downstream KPI authority.**
    
4. **Run B/C/D per KPI.**
    
5. **Pass exact `KPIEDARunResult` from A to B.**
    
6. **Pass exact `PreprocessingRunnerResult` from B to C.**
    
7. **Propagate Part A's resolved bucket into B and C.**
    
8. **Reuse the shared `DatasetInputConfig` physical dataset contract.**
    
9. **Part C's resolved feature contract, not only the user's raw config, is authoritative for D.**
    
10. **Part C's minimum-history requirement must be propagated to D.**
    
11. **C→D uses a persisted Part C dataset plus explicit contract objects.**
    
12. **One Part D runner interface can support fixed/direct and Optuna modes.**
    
13. **Part D owns per-site training.**
    
14. **Model artifacts and associated metadata are required for later inference.**
    
15. **Training and inference should be separate lifecycles.**
    
16. **Part E should use frozen training-time B/C/model contracts.**
    
17. **Persistent inference state requires raw history and processed Part B history.**
    
18. **Rolling cache size derives from B/C history requirements plus allowed inference gap.**
    
19. **Saved model/storage paths should be run-relative.**
    
20. **Production inference should identify the saved run through `run_id`; physical `run_directory` is an internal/test concern.**
    

---

# 26. Conflict Register

|ID|Versions|Difference|Classification|
|---|---|---|---|
|**C-01**|P2 vs P3–P5|P2 automatically creates generic Part C defaults; later pipelines select defaults based on `training.model_type`|**Clearly superseded by model-aware behaviour**|
|**C-02**|P1–P4 vs P5|Earlier pipeline is one request lifecycle; P5 separates future inference into another endpoint|**Evolution, not conflict**|
|**C-03**|A→B/B→C vs C→D|Earlier handoffs use full Python result objects; D receives selected C fields + persisted file|**Intentional architectural difference**|
|**C-04**|P3 vs P4|Pre-Optuna vs tuning-capable training config|**Clearly superseded for current D**|
|**C-05**|All|Generic HTTP 500 runtime handling|**Needs production decision**|
|**C-06**|All|No per-KPI continuation after failure|**Needs production decision**|
|**C-07**|All|Caller controls output filesystem root|**Likely test-only**|
|**C-08**|All|Sanitized KPI names have no demonstrated collision handling|**Potential bug / needs decision**|
|**C-09**|P3–P5|One model configuration applies to every KPI in the request|**Needs production decision if per-KPI models are desired**|
|**C-10**|P5|All KPIs must have identical resolved B/C contracts for one saved run|**Current demonstrated Part-E constraint**|
|**C-11**|P5|Test inference supplies physical `run_directory`|**Clearly test-only; intended replacement is run lookup**|
|**C-12**|P5|Bootstrap workflow owns saved-run construction|**Needs ownership decision for production service layer**|
|**C-13**|P3–P5|HTTP route imports Part D internal `SplitRange` type|**Minor coupling**|
|**C-14**|All|Responses expose physical server paths|**Likely test-only**|

---

# 27. Test-Only Behaviour That Should Not Automatically Become Production Design

The pipelines prove integration correctness, but several behaviours exist specifically because these were test rigs:

```text
/test-* endpoint names
direct output_directory supplied by API caller
physical file paths returned in response
temporary FastAPI apps
global logging.basicConfig()
synchronous long-running training request
explicit run_directory in inference request
no database run registry
raw exception messages
```

These should be treated as evidence of **what was needed for testing**, not automatically as final public API design.

---

# 28. Production-Workflow Requirements Derived From Evidence

Without yet designing the final endpoint/database architecture, the historical pipelines prove that a production orchestrator will need to support at least:

### Training lifecycle

```text
validate combined request
        ↓
create one run context/root
        ↓
A once
        ↓
for each KPI:
    B
    ↓
    C
    ↓
    D
        ↓
collect completed artifacts
        ↓
finalize saved inference contract
```

### Run persistence

It must retain or make recoverable:

```text
run identity
dataset contract
B resolved config
C resolved config
training config
model type
model paths
model decision settings
history requirements
storage paths
```

### Inference lifecycle

```text
run_id
        ↓
resolve saved run
        ↓
production InferenceRequest
        ↓
Part E
```

No historical evidence requires the production HTTP endpoint itself to know physical filesystem paths.

---

# 29. Final A–E Integration Contract

## Part A

### Receives

```text
DatasetInputConfig
output directory
logger
```

### Produces

```text
EDARunnerResult
```

with:

```text
resolved bucket
KPIEDARunResult[]
```

### A → B

```text
exact KPIEDARunResult
+
DatasetInputConfig
+
PreprocessingConfig
+
resolved BucketConfig
```

---

# Part B

### Receives

```text
one KPIEDARunResult
dataset config
preprocessing config
resolved bucket
KPI output directory
```

### Produces

```text
PreprocessingRunnerResult
```

including:

```text
final cleaned dataset
resolved B frequency contract
statistics/artifact paths
```

### B → C

```text
exact PreprocessingRunnerResult
+
DatasetInputConfig
+
FeatureEngineeringConfig
+
resolved BucketConfig
```

---

# Part C

### Receives

```text
PreprocessingRunnerResult
dataset config
feature config
bucket
```

### Produces

```text
FeatureEngineeringRunnerResult
```

including:

```text
final_dataset_file
resolved_config
feature_columns
minimum_history_points
```

### C → D

```text
final_dataset_file
+
resolved_config
+
minimum_history_points
+
DatasetColumnMapping
+
TrainingConfig
+
model_type
+
metadata
```

---

# Part D

### Receives

```text
Part C final CSV
resolved feature contract
minimum history
dataset columns
model-specific TrainingConfig
```

### Produces

```text
PartDTrainingResult
+
persisted model/training artifacts
```

including:

```text
model files
metadata
decision settings
feature contract
training config
final hyperparameters
split plan
training summary
```

### D → E

Not a simple Python-object handoff.

Instead:

```text
D artifacts
+
B contract
+
C contract
+
dataset contract
+
history/cache state
        ↓
SavedInferenceContract
        ↓
inference_config.json
```

---

# Part E

### Receives

At public contract level:

```text
run_id
input_file
inference_days
```

Internally also requires the resolved saved run directory/state.

### Produces

```text
InferenceRunnerResult
```

including:

```text
invocation ID
inference window
per-series results
skipped series
manifest
history/cache commit
```

---

# 30. What the Integration Workflow Owns

Based strictly on the five tested pipelines:

```text
stage ordering
run-level context/folders
KPI fan-out
stage result wiring
resolved config propagation
training metadata linkage
saved-run finalization
training→inference contract persistence
run result aggregation
```

---

# 31. What the ML Modules Own

```text
A:
EDA and dataset preparation

B:
cleaning/preprocessing

C:
feature generation

D:
training/tuning/model serialization

E:
runtime preprocessing/features,
saved-model inference,
history/cache updates
```

The integration layer should coordinate these modules rather than reproduce their internal algorithms.

---

# 32. Final Overall Finding

Across all five tested pipelines there are **very few true contradictions**.

Most differences are chronological additions:

```text
add B
↓
add C
↓
add D
↓
add Optuna inside D
↓
add persistent inference lifecycle
```

The strongest stable pattern is:

```text
REQUEST CONFIGS
      ↓
workflow orchestration
      ↓
MODULE RUNNER
      ↓
structured result object
      ↓
next stage
```

until Part D, where persisted files become important:

```text
A → B
result object

B → C
result object

C → D
persisted dataset
+
resolved contract

D → E
persistent saved-run state
+
saved models
+
frozen contracts
+
history/cache
```

So the five successful pipelines provide a very strong baseline for the final workflow design:

> **Keep the existing module runners and proven stage contracts; preserve structured object handoffs where they already exist; explicitly manage the persisted artifact contracts introduced by training and inference; and treat the test-server conveniences separately from the actual ML integration rules.**