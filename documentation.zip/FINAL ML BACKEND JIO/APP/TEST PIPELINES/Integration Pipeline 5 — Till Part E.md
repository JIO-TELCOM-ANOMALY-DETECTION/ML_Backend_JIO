# Historical Integration Pipeline 5 — Till Part E

## A → B → C → D Training + Saved-Run Bootstrap → Part E Inference

**Pipeline:** Part A EDA → Part B Preprocessing → Part C Feature Engineering → Part D Training → saved inference state → Part E inference  
**Historical role:** Fifth and most mature test/integration pipeline. It preserves the A→D training workflow from Pipeline 4, then creates the persistent filesystem state required for future inference calls and exposes a second endpoint that invokes the real Part E inference runner.

---

# 1. Pipeline Purpose

Pipeline 5 actually demonstrates **two connected but independent request lifecycles**:

```text
TRAINING / BOOTSTRAP

Part A
  ↓
Part B
  ↓
Part C
  ↓
Part D
  ↓
Create saved Part-E run state
  ↓
inference_config.json + history/cache/model contracts
```

and later:

```text
INFERENCE

saved run_directory
+
production InferenceRequest
        ↓
run_inference_pipeline()
        ↓
Part E inference
        ↓
results + history/cache commit
```

The important point is that **Part E is not executed immediately as the next in-memory stage after Part D**. The training endpoint first produces a completed persistent saved run. A later inference request then reloads that state and executes the real Part E runner.

Pipeline 5 proves:

- A→B→C→D behaviour remains essentially unchanged from Pipeline 4;
    
- fixed/Optuna-capable training remains supported;
    
- training completion can be converted into a reusable inference contract;
    
- trained models are associated with exact dataset/B/C/history/storage contracts;
    
- raw and processed history/cache state is initialized after successful training;
    
- model paths and decision settings are extracted from finalized Part D artifacts;
    
- a `run_id` can identify the saved inference run;
    
- Part E can later execute from that saved state without retraining;
    
- the real production `InferenceRequest` can remain small while the test endpoint temporarily supplies a physical `run_directory`.
    

---

# 2. File Map

|File|Responsibility|Main functions/classes|Calls / Depends On|
|---|---|---|---|
|`test_pipeline_part_E.py`|A–D training request + temporary inference request schemas|`PipelineRunRequest`, `InferenceBootstrapConfig`, `TestInferenceRunRequest`, `TrainingConfig`|Dataset/B/C/D schemas + production `InferenceRequest`|
|`test_pipeline_routes_part_E.py`|Two FastAPI endpoints and response construction|`run_test_pipeline()`, `run_test_inference()`, `build_pipeline_response()`, `build_inference_response()`, `build_training_response()`|Training/bootstrap workflow + inference workflow|
|`test_pipeline_workflow_part_E.py`|A→D orchestration, saved-state bootstrap, and test inference bridge|`run_test_pipeline_workflow()`, `run_test_inference_workflow()`, `_bootstrap_inference_state()` plus helper functions|A/B/C/D/E runners, saved inference schemas, file service|
|`test_main_part_E.py`|Temporary A–E FastAPI server|`app`, `health_check()`|Part E test router|

---

# 3. Public API Contract

Pipeline 5 exposes **two POST endpoints**.

## 3.1 Training + saved-state bootstrap

```text
POST /api/v1/test-pipeline/run
```

Purpose:

```text
A → B → C → D
        ↓
create complete saved Part-E inference state
```

Request:

```text
PipelineRunRequest
```

Success:

```text
HTTP 200
```

Runtime failure:

```text
HTTP 500
```

with stage label:

```text
training_pipeline_or_inference_bootstrap
```

---

## 3.2 Pure Part E inference

```text
POST /api/v1/test-inference/run
```

Purpose:

```text
previous saved training run
        +
new raw inference input
        ↓
real Part-E inference runner
```

Request:

```text
TestInferenceRunRequest
```

Success:

```text
HTTP 200
```

Runtime failure:

```text
HTTP 500
```

with:

```text
stage = "inference"
```

---

## 3.3 Health endpoint

```text
GET /health
```

returns:

```json
{
  "status": "healthy"
}
```

The FastAPI application version becomes:

```text
0.2.0
```

and its description explicitly includes saved-model inference.

---

# 4. Complete Request / Configuration Structure

## 4.1 Training/bootstrap request

```text
PipelineRunRequest
│
├── dataset
│   └── DatasetInputConfig
│
├── preprocessing
│   └── PreprocessingConfig
│
├── feature_engineering
│   └── FeatureEngineeringConfig | None
│
├── training
│   └── TrainingConfig
│       ├── XGBoostTrainingConfig
│       └── IsolationForestTrainingConfig
│
├── output_directory
│   └── Path
│
├── run_id
│   └── str | None
│
└── inference_bootstrap
    └── InferenceBootstrapConfig
```

The original Part D request remains largely compatible; the new additions are:

```text
run_id
inference_bootstrap
```

---

## 4.2 `run_id`

Optional:

```text
run_id: str | None
```

Validation:

```text
minimum length = 1
pattern = ^[A-Za-z0-9][A-Za-z0-9._-]*$
```

When omitted, the workflow derives a deterministic temporary run ID from:

```text
output_directory.name
```

after sanitization.

---

## 4.3 `InferenceBootstrapConfig`

```text
max_gap_days: int = 0
max_gap_ratio: float = 0.0
late_data_reconstruction_enabled: bool = True
```

Constraints:

```text
max_gap_days >= 0
0 <= max_gap_ratio <= 1
```

The object is:

```text
extra = forbid
frozen = true
```

Defaults intentionally allow only a contiguous next inference period while allowing dedicated test cases to override gap limits.

---

## 4.4 Part C configuration

Same Pipeline 4 behaviour:

```text
custom feature_engineering supplied
    ↓
use it

omitted
    ↓
FeatureEngineeringConfig(
    default_profile=request.training.model_type
)
```

---

## 4.5 Training configuration

Still:

```text
XGBoostTrainingConfig
OR
IsolationForestTrainingConfig
```

selected by:

```text
model_type
```

and supporting the fixed/Optuna-capable Part D contract.

---

## 4.6 Pure inference request

`TestInferenceRunRequest` inherits the **real production**:

```text
InferenceRequest
```

so it contains:

```text
run_id
input_file
inference_days
```

and adds only:

```text
run_directory
```

The helper:

```text
to_inference_request()
```

removes the temporary filesystem field and reconstructs:

```text
InferenceRequest(
    run_id=...,
    input_file=...,
    inference_days=...
)
```

This is a very important integration boundary:

```text
test-only request
        ↓
strip temporary run_directory
        ↓
exact production Part-E request
```

---

# 5. Exact Integration Execution Flow

# 5.1 Training/bootstrap flow

```text
POST /api/v1/test-pipeline/run
        ↓
PipelineRunRequest
        ↓
resolve output root
        ↓
create:
├── eda/
├── preprocessing/
├── feature_engineering/
└── part_d/
        ↓
resolve Part C profile
        ↓
resolve tuning-method label
        ↓
Part A once
        ↓
EDARunnerResult
        ↓
for every KPI:
    Part B
        ↓
    PreprocessingRunnerResult
        ↓
    Part C
        ↓
    FeatureEngineeringRunnerResult
        ↓
    Part D
        ↓
    PartDTrainingResult
        ↓
all KPIs trained successfully
        ↓
_bootstrap_inference_state()
        ↓
Saved inference run
        ↓
TestPipelineWorkflowResult
        ↓
HTTP response
```

The bootstrap happens **only after all KPI training results have been successfully collected**.

---

# 5.2 A→B→C→D behaviour

The earlier contracts remain unchanged.

## A → B

```text
exact KPIEDARunResult
DatasetInputConfig
PreprocessingConfig
Part A resolved BucketConfig
```

## B → C

```text
exact PreprocessingRunnerResult
DatasetInputConfig
FeatureEngineeringConfig
same resolved BucketConfig
```

## C → D

```text
feature_engineering_result.final_dataset_file
feature_engineering_result.resolved_config
resolved_config.minimum_history_points
dataset.columns
training config
model type
training metadata
```

---

# 5.3 Beginning of the new D → E lifecycle

Unlike earlier stage handoffs, D→E is not simply:

```text
PartDTrainingResult → run_inference_pipeline()
```

Instead the workflow transforms the completed A/B/C/D outputs into a persistent:

```text
SavedInferenceContract
```

plus history/cache files.

The real lifecycle is therefore:

```text
Part D completed artifacts
+
Part B resolved contract
+
Part C resolved contract
+
original training dataset
+
Part B final datasets
+
history policy
        ↓
bootstrap saved inference state
        ↓
inference_config.json
+
history/cache folders
+
saved models
        ↓
future Part E invocation
```

---

# 6. Training → Saved Inference State Bootstrap

This is the largest new integration responsibility in Pipeline 5.

## 6.1 Prevent overwriting an existing saved contract

Before bootstrapping, the workflow checks whether:

```text
<run_root>/inference_config.json
```

already exists.

If it does:

```text
FileExistsError
```

is raised.

---

## 6.2 Resolve saved run ID

The workflow uses:

```text
request.run_id
```

when explicitly provided.

Otherwise it derives one from the output-root directory name.

Fallback if necessary:

```text
temporary_run
```

and ensures the ID begins with an alphanumeric character.

---

## 6.3 Require one consistent B/C contract across all KPIs

Before creating one saved inference run, the workflow verifies that every KPI has the same:

```text
PreprocessingRunnerResult.resolved_frequency
```

and same:

```text
FeatureEngineeringRunnerResult.resolved_config
```

If any KPI differs:

```text
ValueError
```

is raised.

This is a new cross-KPI rule:

> One saved inference run requires one shared resolved Part B contract and one shared resolved Part C contract.

---

# 7. History Requirement Calculation

The bootstrap computes a frozen:

```text
SavedHistoryContract
```

from both Part B and Part C requirements.

## 7.1 Part B history

The workflow finds the maximum relevant Part B lookback from settings such as:

```text
Phase 2 recent same-type lookback
Phase 2 last-week lookback
Phase 3 maximum lookback
Phase 4 minimum history days, if enabled
```

with a minimum of one day.

If Phase 4 is enabled, the resolved Prophet minimum-history requirement is also incorporated.

---

## 7.2 Part C history

It reads:

```text
resolved_c.minimum_history_points
resolved_c.maximum_lookback_points
resolved_c.points_per_day
```

---

## 7.3 Final required history

The final required point count is:

```text
max(
    Part B required history points,
    Part C minimum history points,
    Part C maximum lookback points + 1
)
```

This matches the final Part E saved-history contract.

---

## 7.4 Cache length

```text
cache_days =
    final_required_history_days
    +
    max_gap_days
```

Therefore the cache is deliberately larger than only the normal feature-history requirement when a permitted inference gap is configured.

---

# 8. Saved Folder and Artifact Structure

Pipeline 5 extends the A–D root with persistent inference state.

Conceptually:

```text
<run_root>/
│
├── eda/
│
├── preprocessing/
│   └── <KPI>/
│
├── feature_engineering/
│   └── <KPI>/
│
├── part_d/
│   └── <KPI>/
│       └── training/
│           ├── models/
│           ├── metadata
│           ├── decision settings
│           └── other Part D artifacts
│
├── inference_config.json
│
├── inference_state/
│   │
│   ├── history/
│   │   ├── raw_history.csv
│   │   └── processed/
│   │       ├── <KPI_A>.csv
│   │       ├── <KPI_B>.csv
│   │       └── ...
│   │
│   └── cache/
│       ├── raw_cache.csv
│       └── processed/
│           ├── <KPI_A>.csv
│           ├── <KPI_B>.csv
│           └── ...
│
└── inference_results/
```

The directory constants are explicitly defined by the workflow.

---

# 9. Initial Raw and Processed History

## 9.1 Raw full history

The workflow copies the **original source training CSV**:

```text
request.dataset.input_file
```

to:

```text
inference_state/history/raw_history.csv
```

This establishes raw training-time observations as the full raw-history base.

---

## 9.2 Raw cache

The workflow calculates the final timestamp in raw history and retains the last:

```text
history_contract.cache_days
```

worth of records.

That becomes:

```text
inference_state/cache/raw_cache.csv
```

Invalid timestamps while creating this initial cache are rejected.

An empty cache is also rejected.

---

## 9.3 Processed full history

For each KPI, the workflow copies:

```text
PreprocessingRunnerResult.final_dataset_file
```

to:

```text
inference_state/history/processed/<KPI>.csv
```

Therefore **Part B's final cleaned output**, not Part C's feature-engineered CSV, is the persistent processed-history base used by Part E.

This is a major D/E lifecycle observation.

---

## 9.4 Processed cache

For every KPI, the corresponding processed-history file is sliced to the last:

```text
cache_days
```

and written as:

```text
inference_state/cache/processed/<KPI>.csv
```

---

# 10. Saved Model Contract Construction

The bootstrap does not merely point Part E at the Part D training directory.

It reconstructs an explicit model-specific inference contract.

## 10.1 Part D artifacts read back from disk

For every KPI training result, the workflow reloads:

```text
training_result.output_paths.metadata_file
training_result.output_paths.decision_settings_file
```

as JSON.

This is a **persisted-file reload**, not only an in-memory result handoff.

---

## 10.2 Required consistency

The workflow requires:

```text
metadata["series_models"]
```

to exist and be non-empty.

It also requires that:

```text
series_models.keys()
==
decision_settings.keys()
```

Otherwise bootstrap fails.

---

## 10.3 Per-series information extracted

For each trained series it extracts:

```text
identity
model_file
decision_settings
```

and combines that with:

```text
model_feature_columns
target_column
```

from the Part D validation result.

---

## 10.4 Portable model paths

Saved model file paths are converted into paths relative to:

```text
run_root
```

rather than storing absolute machine paths.

The workflow explicitly uses POSIX separators for saved contract portability.

This is a strong current integration rule:

> Saved inference contracts reference models and storage paths relative to the saved run root.

---

# 11. XGBoost vs Isolation Forest Saved Contracts

## XGBoost

For each KPI:

```text
XGBoostKPIInferenceConfig
├── model_feature_columns
├── target_column
└── series
    └── XGBoostSeriesInferenceConfig
```

The workflow requires a non-null:

```text
target_column
```

for XGBoost.

---

## Isolation Forest

For each KPI:

```text
IsolationForestKPIInferenceConfig
├── model_feature_columns
└── series
    └── IsolationForestSeriesInferenceConfig
```

No target column is required.

---

## Shared model-level state

Both model contracts also preserve:

```text
threshold_direction
```

from the training request.

The outer saved contract is discriminated by:

```text
model_type
```

---

# 12. `inference_config.json` — Main Training → Inference Contract

The workflow creates:

```text
SavedInferenceContract
```

and writes it to:

```text
<run_root>/inference_config.json
```

It contains:

```text
run_id
created_at_utc
model_type

dataset contract
preprocessing contract
feature-engineering contract
history contract
storage contract
model contract
```

More specifically:

## Dataset

```text
DatasetColumnMapping
resolved BucketConfig
KPI names
single_kpi_name
```

## Part B

```text
original PreprocessingConfig
resolved preprocessing frequency contract
```

## Part C

```text
actual FeatureEngineeringConfig used
resolved Part C feature contract
```

## History

```text
Part B requirements
Part C requirements
final required history
cache days
gap policy
late-data reconstruction policy
```

## Storage

Run-relative paths to:

```text
raw full history
raw cache
processed history per KPI
processed cache per KPI
inference results directory
```

## Model

Model-specific:

```text
XGBoostInferenceConfig
OR
IsolationForestInferenceConfig
```

containing exact per-series saved-model information.

The final Part E documentation confirms this file is the frozen bridge between training and future inference calls.

---

# 13. Exact Inference Execution Flow

The second workflow is intentionally much thinner.

```text
POST /api/v1/test-inference/run
        ↓
TestInferenceRunRequest
        │
        ├── run_id
        ├── input_file
        ├── inference_days
        └── run_directory   # temporary only
        ↓
resolve run_directory
        ↓
verify directory exists
        ↓
verify inference_config.json exists
        ↓
request.to_inference_request()
        ↓
production InferenceRequest
        ↓
run_inference_pipeline(
    request=pure_request,
    run_directory=run_directory
)
        ↓
InferenceRunnerResult
        ↓
HTTP response
```

The Part E ML runner itself is explicitly left unchanged by this test rig.

---

# 14. What the Test Workflow Does NOT Do During Inference

The test inference workflow does **not**:

```text
load models itself
execute XGBoost predictions
execute Isolation Forest predictions
run Part A/B/C itself
select anomaly thresholds itself
update caches itself
commit history itself
```

It only verifies the saved-run directory, converts the temporary request to the production request, and delegates to:

```text
run_inference_pipeline()
```

The final Part E module remains responsible for the actual inference lifecycle.

---

# 15. Part E Runtime Behaviour Relevant to Integration

The following is module behaviour rather than test-workflow behaviour, but it is required to understand the endpoint contract.

The saved Part E configuration is authoritative; inference does not recalculate its training contract from whichever defaults the application happens to contain later.

Part E reuses:

```text
Part A directly
Part C directly
Part B stages through the inference-specific preprocessing runner
```

where inference-specific Part B restores the saved cached:

```text
kpi_usability
kpi_invalid_reason
```

before filling operations.

The module also enforces the saved Part B/C resolved contracts against runtime resolution.

---

# 16. Inference History / Cache Lifecycle

The mature Part E module uses:

```text
raw full history
raw rolling cache
per-KPI processed full history
per-KPI processed rolling cache
```

The important persistence rule is:

```text
run history reconstruction / A/B/C
        ↓
run saved-model inference
        ↓
ONLY IF inference succeeds
        ↓
commit history/cache state
```

Therefore:

```text
A/B/C success
≠
persistent history update
```

History updates occur only after successful model inference.

This is one of the most important integration guarantees in the entire A–E chain.

---

# 17. Late Data and Cache Behaviour

The saved contract includes:

```text
max_gap_days
max_gap_ratio
late_data_reconstruction_enabled
```

At runtime, the final Part E module distinguishes normal forward inference from late-data reconstruction.

A genuine late row inside the maintained processed cache can trigger reconstruction.

Late rows older than the maintained processed cache are ignored for the current inference operation rather than forcing reconstruction.

When reconstruction is required, Part E may temporarily load an additional older:

```text
cache_days
```

slice of full raw history for enough A/B/C context. That older extra context does not automatically widen the final persisted processed-history replacement range.

---

# 18. Inference Window Boundary

The production inference request supplies:

```text
inference_days
```

This defines the forward processing window.

The final Part E module processes, infers and commits only the requested window. Extra later valid rows present in the input file are not processed or committed during that invocation.

This behaviour belongs to Part E itself, not the temporary route.

---

# 19. KPI / Site / Model Iteration Behaviour

## Training

Same as Pipeline 4:

```text
Part A once

For every KPI:
    B
    ↓
    C
    ↓
    D
```

Part D internally handles site/model-series training.

---

## Bootstrap

After all training completes:

```text
all KPI results
    ↓
one saved inference run
```

The bootstrap loops over every KPI to create:

```text
processed history
processed cache
model contract
```

---

## Inference

Part E operates from the saved multi-KPI model contract.

The inference response includes:

```text
total_saved_series
completed_series
skipped_series
unmodelled_part_c_series
```

and per-series outputs.

---

## Model selection

Still exactly one saved model family for the run:

```text
XGBoost
OR
Isolation Forest
```

All saved KPI/series contracts belong to that model type.

---

# 20. Stage-to-Stage Handoff Contract

|From|To|Information passed|Form|Purpose|
|---|---|---|---|---|
|API|Training workflow|A–D config + run/bootstrap config|`PipelineRunRequest`|Complete training and saved-state request|
|A|B|exact KPI result|`KPIEDARunResult`|A→B handoff|
|B|C|exact preprocessing result|`PreprocessingRunnerResult`|B→C handoff|
|C|D|final C dataset|`Path`|Physical training dataset|
|C|D|resolved feature contract|object|Exact training features|
|C|D|minimum history|integer|Training split/history requirement|
|D|Bootstrap|`PartDTrainingResult`|Python object|Locates validation + finalized D artifacts|
|D filesystem|Bootstrap|metadata JSON|persisted JSON reload|Find saved per-series model paths/identities|
|D filesystem|Bootstrap|decision settings JSON|persisted JSON reload|Recover final model decision settings|
|B|Bootstrap|resolved B contract|Python object|Freeze training-time preprocessing behaviour|
|C|Bootstrap|resolved C contract|Python object|Freeze feature behaviour/history requirements|
|Training raw dataset|Bootstrap|original source CSV|persisted file copy|Initial full raw history|
|B final output|Bootstrap|cleaned KPI CSV|persisted file copy|Initial processed full history|
|Bootstrap|Part E|`inference_config.json`|persisted JSON|Frozen A/B/C/history/model/storage contract|
|Bootstrap|Part E|raw/processed history|CSV files|Long-term inference history|
|Bootstrap|Part E|raw/processed caches|CSV files|Rolling runtime context|
|Bootstrap|Part E|saved models|Part D model files|Runtime prediction|
|Test inference request|Inference workflow|run directory|`Path`|Temporary DB replacement|
|Test inference request|Part E|production request|`InferenceRequest` object|`run_id`, input, days|
|Part E|Route|inference result|`InferenceRunnerResult`|Response assembly|

---

# 21. Training Endpoint Response Contract

The existing Part D response remains.

Pipeline 5 adds a top-level:

```text
saved_run
```

block.

## Top level

```text
status
output_directory
kpi_count
eda_outputs
saved_run
kpi_results
```

---

## `saved_run`

Contains:

```text
run_id
run_directory
inference_config
inference_state_directory
raw_history_file
raw_cache_file
processed_history_by_kpi
processed_cache_by_kpi
inference_results_directory
history_contract
```

---

## History contract exposed in response

```text
part_b_required_history_points
part_b_required_history_days

part_c_required_history_points
part_c_maximum_lookback_points

final_required_history_points
final_required_history_days

cache_days
max_gap_days
max_gap_ratio
late_data_reconstruction_enabled
```

This makes the exact Part E history/cache requirement directly inspectable after training.

---

# 22. Part E Inference Response Contract

Successful inference returns:

```text
status
run_id
model_type
invocation_id
inference_window
output_directory
manifest_file
series_statistics
outputs
skipped_series
history_commit
```

---

## Inference window

```text
start
end_exclusive
```

---

## Series statistics

```text
total_saved_series
completed_series
skipped_series
unmodelled_part_c_series
```

---

## Per-series output

Each completed series exposes:

```text
model_type
kpi_name
series_key

identity:
    circle
    cluster
    site_name

result_file

total_window_rows
scorable_rows
unscorable_rows

anomaly_count
anomaly_rate

model_anomaly_count
lower_anomaly_count
upper_anomaly_count
```

Fields that are model-specific can naturally contain their applicable values as produced by the inference result.

---

## Skipped series

```text
kpi_name
series_key
identity
reason
```

---

## History commit

```text
raw_history_file
raw_cache_file

raw_history_rows
raw_cache_rows

finalized_end
cache_cutoff

kpis[]
```

Each KPI commit reports:

```text
kpi_name
mode

processed_history_file
processed_cache_file

processed_history_rows
processed_cache_rows

update_start
update_end
```

This is important because the API confirms not only inference output but also the resulting persistent history state.

---

# 23. Validation and Error Handling

## 23.1 Request/Pydantic validation

Training request validates:

```text
DatasetInputConfig
PreprocessingConfig
optional FeatureEngineeringConfig
model-specific TrainingConfig
output_directory
optional run_id
InferenceBootstrapConfig
```

Inference request validates the production inference fields plus temporary:

```text
run_directory
```

Both use:

```text
extra = forbid
```

---

## 23.2 Training-stage validation

Existing A/B/C/D validation remains unchanged.

---

## 23.3 New bootstrap validation

The bootstrap additionally validates:

- `inference_config.json` does not already exist;
    
- at least one completed KPI result exists;
    
- all KPIs use the same resolved B contract;
    
- all KPIs use the same resolved C contract;
    
- `points_per_day > 0`;
    
- enabled Part B Phase 4 has resolved Prophet history;
    
- raw/processed history timestamps are valid;
    
- initial caches are non-empty;
    
- Part D metadata contains `series_models`;
    
- metadata and decision-setting series keys match;
    
- every saved series contains identity;
    
- every saved series contains a model file;
    
- XGBoost contains a target column;
    
- all persisted contract paths remain inside the saved run root.
    

---

## 23.4 Inference workflow validation

Before calling the real Part E runner, the test workflow checks:

```text
run_directory exists
inference_config.json exists
```

Otherwise:

```text
FileNotFoundError
```

is raised.

---

## 23.5 Part E validation

The real Part E module then performs its own saved-contract/history/model-handoff validations, including validation of current Part C outputs against saved Part D model contracts.

Validation is therefore clearly layered:

```text
Pydantic
    ↓
test workflow
    ↓
saved bootstrap contract checks
    ↓
Part E saved-run loading
    ↓
A/B/C runtime validation
    ↓
saved-model handoff validation
    ↓
model inference
```

---

# 24. Failure Behaviour

## Training/bootstrap endpoint

Any uncaught A/B/C/D or bootstrap failure becomes:

```text
HTTP 500
```

with:

```json
{
  "detail": {
    "status": "failed",
    "stage": "training_pipeline_or_inference_bootstrap",
    "error_type": "...",
    "message": "..."
  }
}
```

Notably, the route does **not distinguish** whether the failure occurred in:

```text
Part A
Part B
Part C
Part D
or bootstrap
```

beyond the combined stage label.

---

## Inference endpoint

Any uncaught inference failure becomes:

```json
{
  "detail": {
    "status": "failed",
    "stage": "inference",
    "error_type": "...",
    "message": "..."
  }
}
```

with HTTP 500.

---

# 25. Failure Scope

Training remains sequential and all-or-nothing at the parent request level.

```text
KPI 1 succeeds
KPI 2 succeeds
KPI 3 training fails
        ↓
bootstrap never starts
```

Likewise:

```text
all A–D succeeds
        ↓
bootstrap fails
        ↓
endpoint reports failure
```

even though valid A/B/C/D artifacts may already exist.

---

## Important Part E persistence safety

Once an actual inference invocation starts, the final Part E module delays persistent history mutation until model inference succeeds.

Therefore a model-inference failure does not intentionally advance history/cache state.

This is stronger persistence behaviour than the surrounding temporary A–D workflow.

---

# 26. Responsibilities of the Test Workflow Itself

Pipeline 5 contains significantly more integration logic than previous versions.

## Existing A–D orchestration

Still owns:

```text
stage roots
KPI fan-out
A→B→C→D sequence
config propagation
model-matched C defaults
training provenance
training result aggregation
```

---

## New — saved run ID

The workflow generates or preserves:

```text
run_id
```

---

## New — history requirement calculation

It combines B and C requirements into the final saved Part E history/cache contract.

---

## New — state-folder creation

Creates:

```text
inference_state/history
inference_state/cache
inference_results
```

---

## New — initial history persistence

Copies:

```text
training raw source
Part B final outputs
```

into the saved inference state.

---

## New — initial cache generation

Builds:

```text
raw cache
per-KPI processed caches
```

---

## New — read finalized Part D artifacts

Reloads:

```text
metadata JSON
decision-settings JSON
```

to build inference model contracts.

---

## New — model-contract assembly

Creates model-specific XGBoost/Isolation Forest saved inference schemas.

---

## New — saved contract creation

Constructs and writes:

```text
SavedInferenceContract
→ inference_config.json
```

---

## New — temporary run-directory lookup replacement

During inference, the workflow accepts:

```text
run_directory
```

directly because no database/service exists yet.

---

## What remains inside Part E

The test workflow deliberately does not implement actual inference mechanics.

That remains:

```text
run_inference_pipeline()
```

and its internal modules.

---

# 27. Test-Only Behaviour

Clearly temporary/test-specific behaviours include:

- `/test-pipeline/run`;
    
- `/test-inference/run`;
    
- caller-supplied `output_directory`;
    
- explicitly supplied `run_directory`;
    
- filesystem rather than database `run_id → run_directory` resolution;
    
- workflow-owned construction of saved inference state;
    
- deterministic run ID derived from directory name when absent;
    
- direct filesystem paths returned in API responses;
    
- synchronous A→D training and bootstrap inside HTTP request;
    
- raw exception strings returned;
    
- global `logging.basicConfig()`;
    
- no durable job/run registry.
    

The schema explicitly states that production is expected to replace:

```text
run_directory
```

with:

```text
run_id → run_directory
```

resolution through a database/service.

---

# 28. Integration Rules Learned From Pipeline 5

## Rule 1 — Training and inference are separate lifecycles

Part E is not simply an in-memory stage immediately called after D.

```text
training
    ↓
persistent saved run
    ↓
later inference
```

---

## Rule 2 — `inference_config.json` is the central D→E contract

It freezes:

```text
dataset
B
C
history
storage
model
```

contracts for future inference.

---

## Rule 3 — Saved inference configuration must use the resolved training-time contracts

Part E should not depend on future application defaults.

---

## Rule 4 — Part D model artifacts alone are insufficient

Inference also requires:

```text
dataset mappings
bucket
B config + resolved B
C config + resolved C
history policy
storage paths
per-series model path
decision settings
model feature list
target where applicable
```

---

## Rule 5 — Part B final dataset is the persistent processed-history base

Not the Part C feature dataset.

---

## Rule 6 — Raw training input becomes initial raw full history

This preserves original historical observations for reconstruction.

---

## Rule 7 — Full history and rolling cache are different contracts

Part E maintains both.

---

## Rule 8 — Processed state remains KPI-specific

There is:

```text
processed history per KPI
processed cache per KPI
```

---

## Rule 9 — One saved run requires common resolved B/C contracts across KPIs

The bootstrap explicitly rejects inconsistent KPI contracts.

---

## Rule 10 — Saved model paths should be run-relative

The bootstrap deliberately serializes portable relative paths.

---

## Rule 11 — D→E requires persisted-file reloads

The bootstrap reloads Part D:

```text
metadata
decision settings
```

from disk.

Thus the filesystem is decisively part of the integration contract.

---

## Rule 12 — The real Part E runner remains the inference boundary

The test workflow does not reproduce inference logic.

---

## Rule 13 — Production inference request can remain small

The real request only needs:

```text
run_id
input_file
inference_days
```

The temporary `run_directory` exists only because there is no run registry yet.

---

## Rule 14 — History/cache mutation occurs after successful model inference

This protects persistent state from partially successful inference calls.

---

## Rule 15 — Cache size is derived from actual B/C requirements plus allowed gap

```text
cache_days =
final_required_history_days
+
max_gap_days
```

---

# 29. Limitations of This Pipeline Version

Pipeline 5 completes the historical A–E integration evidence, but still leaves several production concerns outside its scope:

```text
database run registry
run_id → run_directory service
scheduled inference
asynchronous jobs
concurrency control
multi-worker state locking
production authorization
persistent job statuses
partial-KPI training success
production artifact storage abstraction
```

The workflow itself notes that equivalent saved-run persistence/registration can eventually belong to the normal training/run service rather than this temporary test workflow.

---

# 30. Conflicts or Questionable Behaviour

|Issue|Severity|Evidence|Possible impact|
|---|---|---|---|
|Training + bootstrap failures share one broad stage label|**Important**|`"training_pipeline_or_inference_bootstrap"`|API cannot directly identify whether A/B/C/D or state bootstrap failed|
|Generic runtime failures remain HTTP 500|**Important**|Both routes catch all `Exception`|User/data errors remain mixed with true internal failures|
|Raw exception strings returned|**Important**|`message=str(error)`|Internal filesystem/model information may leak|
|No database run lookup yet|**Historical/Test-only**|Inference request explicitly requires `run_directory`|Caller must know server filesystem location|
|`output_directory` is still caller controlled|**Historical/Test-only**|Training request field|Weak production isolation|
|One failed training KPI aborts the entire saved run|**Important**|Sequential A→D loop before bootstrap|No usable saved run is created from partially successful KPI training|
|Bootstrap happens only after all D training completes|**Intentional / Important**|Workflow ordering|Good contract consistency, but late bootstrap failure leaves expensive D artifacts without a Part-E-ready saved run|
|Existing `inference_config.json` causes bootstrap failure|**Important / Historical**|Explicit `FileExistsError`|Reusing the same root requires external cleanup/new root|
|Derived `run_id` comes from directory name|**Historical/Test-only**|`_derive_run_id()`|Run identity is tied to filesystem naming in test rig|
|Same sanitized KPI naming collision risk remains for stage/cache files|**Potential bug**|Sanitized name used for filesystem filenames|Distinct raw KPI names could theoretically collide|
|All KPIs must share exactly equal resolved B/C contracts|**Important architectural constraint**|`_same_resolved_contracts()`|Heterogeneous per-KPI processing configs cannot coexist in one saved inference run|
|Model contract depends on Part D JSON artifact shape|**Important**|Reads `series_models` and `decision_settings`|Changes to Part D persisted schema can break bootstrap even if Python result types remain compatible|
|D→E is strongly filesystem dependent|**Important architectural observation**|JSON/model/history paths are required|Future workflow/storage design must preserve artifact linkage|
|Test workflow duplicates some eventual run-service responsibilities|**Historical/Test-only**|`_bootstrap_inference_state()` comment|Should not automatically be assigned to production HTTP route|
|Route imports Part D `SplitRange`|**Minor**|Response helper|API remains coupled to training implementation type|
|Training/bootstrap response exposes physical server paths|**Historical/Test-only**|`saved_run` block|Useful for testing but likely not future public contract|
|No explicit concurrency protection around saved state in this test layer|**Needs production decision**|Filesystem state + mutable future inference history|Concurrent inference calls may require dedicated state coordination outside demonstrated test workflow|

---

# 31. Compact Pipeline Contract

```text
Pipeline:
A → B → C → D
→ saved inference-state bootstrap
→ later Part E inference

Endpoints:

POST /api/v1/test-pipeline/run
    A→B→C→D + saved Part-E state

POST /api/v1/test-inference/run
    pure Part-E inference

Input — training:
PipelineRunRequest
├── dataset
├── preprocessing
├── feature_engineering | None
├── training
├── output_directory
├── run_id | None
└── inference_bootstrap
    ├── max_gap_days
    ├── max_gap_ratio
    └── late_data_reconstruction_enabled

Input — inference:
TestInferenceRunRequest
├── production InferenceRequest:
│   ├── run_id
│   ├── input_file
│   └── inference_days
└── run_directory       # test-only

Primary workflows:
run_test_pipeline_workflow()
run_test_inference_workflow()

A → B:
exact KPIEDARunResult

B → C:
exact PreprocessingRunnerResult

C → D:
final Part C CSV
+
resolved Part C config
+
minimum_history_points
+
dataset columns
+
training config

D → saved Part-E state:
PartDTrainingResult
+
persisted Part D metadata JSON
+
persisted decision-settings JSON
+
saved model files
+
B resolved config
+
C resolved config
+
original raw dataset
+
B final cleaned KPI datasets

Saved bridge:
inference_config.json

Saved state:
inference_state/
├── history/
│   ├── raw_history.csv
│   └── processed/<KPI>.csv
└── cache/
    ├── raw_cache.csv
    └── processed/<KPI>.csv

Model contract:
XGBoostInferenceConfig
OR
IsolationForestInferenceConfig

History contract:
final required history =
max(
    Part B history,
    Part C minimum history,
    Part C maximum lookback + 1
)

cache_days =
final_required_history_days
+
max_gap_days

Part E handoff:
production InferenceRequest
+
resolved saved run directory
        ↓
run_inference_pipeline()

Inference output:
InferenceRunnerResult
├── invocation identity
├── inference window
├── per-series result CSVs
├── manifest
├── completed/skipped counts
└── history commit state

Important validation:
- all normal A/B/C/D validation
- shared resolved B contract across KPIs
- shared resolved C contract across KPIs
- valid history calculations
- valid cache timestamps
- non-empty initial caches
- Part D metadata/decision key agreement
- required model identities/files
- XGB target existence
- run-relative saved paths
- run directory exists
- inference_config.json exists
- Part E saved-contract/model/history validation

Important errors:
training/bootstrap runtime:
HTTP 500
stage=training_pipeline_or_inference_bootstrap

inference runtime:
HTTP 500
stage=inference

Test-only logic:
- direct output_directory
- direct run_directory
- filesystem run lookup
- workflow-generated run_id fallback
- temporary saved-state creation
- physical paths returned through API

Key integration lessons:
1. Training and inference are separate request lifecycles.
2. A completed D run must be finalized into persistent inference state.
3. inference_config.json is the frozen A/B/C/D→E contract.
4. Saved B/C resolved configs are authoritative during inference.
5. Raw source history and Part B processed history must both be retained.
6. Rolling raw and per-KPI processed caches are explicit runtime state.
7. Cache length derives from B/C history requirements plus permitted gap.
8. D→E requires saved model files plus Part D metadata and decision settings.
9. Model/storage paths are stored relative to the saved run root.
10. One saved run requires common resolved B/C contracts across its KPIs.
11. Part E itself owns inference processing and history mutation.
12. Persistent history advances only after successful model inference.
13. Production inference needs run_id + input_file + inference_days; explicit run_directory is test-only.
```

---

# Final Historical Interpretation

Pipeline 5 changes the overall architecture from a purely linear processing chain into a **training lifecycle followed by a persistent inference lifecycle**:

```text
TRAINING

Request
  ↓
A
  ↓
B
  ↓
C
  ↓
D
  ↓
trained models + artifacts
  ↓
saved inference bootstrap
  ↓
inference_config.json
+
raw history
+
processed history
+
rolling caches
+
model contracts
```

Then independently:

```text
INFERENCE REQUEST
  ↓
run_id + input_file + inference_days
  ↓
resolve saved run
  ↓
load frozen inference contract/state
  ↓
Part E
  ↓
reuse A/B/C processing
  ↓
validate current features against saved models
  ↓
saved-model inference
  ↓
result CSVs + manifest
  ↓
commit raw/processed history + caches
```

The most important new architectural finding is that **D→E is not an ordinary Python result-object handoff**.

It is a persistent saved-run contract composed of:

```text
Part D model artifacts
+
Part D decision/model metadata
+
dataset contract
+
Part B config/resolved contract
+
Part C config/resolved contract
+
history requirements
+
raw/processed history
+
raw/processed caches
+
storage paths
        ↓
inference_config.json
```

Part E can therefore operate later, in a different request, without relying on live Part A–D Python objects.

Pipeline 5 also clearly establishes that the future production layer will need a durable way to resolve:

```text
run_id
    ↓
saved run state
```

while the current explicit `run_directory` is only a temporary test substitute.

This completes the five historical pipeline reports and provides the evidence needed for the **Final A–E Integration Pipeline Synthesis**.