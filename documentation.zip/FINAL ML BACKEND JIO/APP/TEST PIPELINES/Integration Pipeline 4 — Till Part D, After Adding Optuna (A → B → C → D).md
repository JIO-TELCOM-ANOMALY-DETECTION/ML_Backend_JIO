# Historical Integration Pipeline 4 — Till Part D, After Adding Optuna (A → B → C → D)

**Pipeline:** Part A EDA → Part B Preprocessing → Part C Feature Engineering → Part D Training with fixed or Optuna hyperparameter tuning  
**Historical role:** Fourth integration pipeline, extending the previous Part D integration so the same A→B→C→D workflow can execute Part D using the validated training schema's fixed/direct behaviour or Optuna tuning behaviour.

---

# 1. Pipeline Purpose

This pipeline connects:

```text
Part A — EDA
      ↓
Part B — Preprocessing
      ↓
Part C — Feature Engineering
      ↓
Part D — Training
        ├── tuning disabled / direct behaviour
        ├── fixed-candidate tuning
        └── Optuna tuning
```

Its purpose was to prove that:

- the established A→B→C→D integration remained reusable after adding Optuna;
    
- XGBoost and Isolation Forest still used one common Part D runner boundary;
    
- the request's model-specific training schema could now carry tuning behaviour;
    
- the workflow did not need separate fixed-training and Optuna-training pipelines;
    
- the same exact Part C dataset, resolved feature contract, and minimum-history requirement could feed Part D regardless of tuning method;
    
- tuning settings could be preserved in workflow metadata and exposed in the HTTP response;
    
- the exact validated training configuration used across all KPIs could be retained in the workflow result.
    

The workflow explicitly describes itself as supporting **fixed and Optuna tuning modes**.

This pipeline still does **not** include Part E inference.

---

# 2. File Map

|File|Responsibility|Main functions/classes|Calls / Depends On|
|---|---|---|---|
|`test_pipeline_till_part_d_after_adding_optuna.py`|Combined A+B+C+D request schema with tuning-capable model schemas|`PipelineRunRequest`, `TrainingConfig`|Dataset, preprocessing, feature-engineering, XGBoost and Isolation Forest schemas|
|`test_pipeline_routes_till_part_d_after_adding_optuna.py`|HTTP endpoint and A/B/C/D response construction including tuning information|`run_test_pipeline()`, `build_pipeline_response()`, `build_training_response()`, `split_range_to_response()`|Workflow, `SplitRange`, exact `TrainingConfig`|
|`test_pipeline_workflow_till_part_d_after_adding_optuna.py`|A→B→C→D orchestration with tuning metadata propagation|`run_test_pipeline_workflow()`, `KPIWorkflowResult`, `TestPipelineWorkflowResult`|A/B/C/D runners|
|`test_main_till_part_d_after_adding_optuna.py`|Temporary FastAPI app for fixed/Optuna Part D testing|`app`, `health_check()`|test router|

The schema still combines existing stage schemas rather than implementing training logic itself.

The route remains an HTTP/serialization layer.

The workflow owns actual stage connection and tuning-context propagation.

---

# 3. Public API Contract

```text
Method:
POST

Router path:
/test-pipeline/run

Application prefix:
/api/v1

Effective endpoint:
POST /api/v1/test-pipeline/run

Request:
PipelineRunRequest

Workflow:
run_test_pipeline_workflow()

Success:
HTTP 200

Runtime failure:
HTTP 500
```

The effective endpoint remains unchanged from Pipelines 1–3:

```text
POST /api/v1/test-pipeline/run
```

## Health endpoint

```text
GET /health
```

returns:

```json
{
  "status": "healthy"
}
```

The test application's description is updated to explicitly mention **fixed or Optuna hyperparameter tuning**.

---

# 4. Complete Request / Configuration Structure

```text
PipelineRunRequest
│
├── dataset
│   └── DatasetInputConfig
│
├── preprocessing
│   └── PreprocessingConfig
│
├── feature_engineering
│   └── FeatureEngineeringConfig | None
│
├── training
│   └── TrainingConfig
│       ├── XGBoostTrainingConfig
│       └── IsolationForestTrainingConfig
│
└── output_directory
    └── Path
```

---

## Dataset / shared configuration

```text
dataset: DatasetInputConfig
```

remains unchanged and is reused by Parts A, B and C, while its column mapping is also passed into Part D.

---

## Part B configuration

```text
preprocessing: PreprocessingConfig
```

remains a required complete Part B contract.

---

## Part C configuration

```text
feature_engineering:
FeatureEngineeringConfig | None
```

remains optional.

When provided:

```text
use request.feature_engineering
```

When omitted:

```text
FeatureEngineeringConfig(
    default_profile=request.training.model_type
)
```

is created in the workflow.

Therefore model-specific Part C default-profile selection from Pipeline 3 remains unchanged.

---

## Part D configuration

`TrainingConfig` remains a discriminated union:

```text
XGBoostTrainingConfig
        OR
IsolationForestTrainingConfig
```

selected by:

```text
model_type
```

The important change is that these training schemas now validate model-specific:

```text
direct
fixed-candidate
Optuna
```

hyperparameter inputs.

The pipeline itself does not reproduce those model-specific parameter schemas.

It passes the complete validated:

```text
request.training
```

object into Part D.

---

## Tuning-related request state

The workflow directly reads:

```text
request.training.hyperparameter_tuning_enabled
request.training.hyperparameter_tuning_method
```

It resolves:

```text
resolved_tuning_method =
    training.hyperparameter_tuning_method
    if hyperparameter_tuning_enabled
    else None
```

Therefore at integration level:

```text
tuning disabled
    ↓
method exposed as None

tuning enabled
    ↓
use validated training.hyperparameter_tuning_method
```

---

## Pipeline-level configuration

The only pipeline-level storage field remains:

```text
output_directory
```

The schema still uses:

```text
extra = "forbid"
```

and normalizes the output path with `expanduser()`.

---

# 5. Exact Integration Execution Flow

```text
POST /api/v1/test-pipeline/run
        │
        ▼
PipelineRunRequest
        │
        ▼
Pydantic validates:
A/B/C config
+
model-specific Part D config
+
fixed/Optuna settings
        │
        ▼
run_test_pipeline_workflow()
        │
        ▼
Create:
├── eda/
├── preprocessing/
├── feature_engineering/
└── part_d/
        │
        ▼
Resolve Part C config
        │
        ├── supplied → use it
        └── omitted → model-matched default profile
        │
        ▼
Resolve workflow-level tuning label
        │
        ├── disabled → None
        └── enabled → configured method
        │
        ▼
Part A once
        │
        ▼
EDARunnerResult
        │
        ▼
for each KPI
        │
        ▼
Part B
        │
        ▼
PreprocessingRunnerResult
        │
        ▼
Part C
        │
        ▼
FeatureEngineeringRunnerResult
        │
        ▼
extract:
├── final_dataset_file
├── resolved_config
└── minimum_history_points
        │
        ▼
Part D run_training()
        │
        ├── model_type
        ├── exact training config
        ├── fixed/Optuna behaviour encoded in config
        └── tuning metadata
        │
        ▼
PartDTrainingResult
        │
        ▼
KPIWorkflowResult
        │
        ▼
repeat
        │
        ▼
TestPipelineWorkflowResult
        │
        ├── eda_result
        ├── training_config
        └── kpi_results
        │
        ▼
HTTP response
```

---

## 5.1 Output-root creation

Unchanged from Pipeline 3:

```text
<output_root>/
├── eda/
├── preprocessing/
├── feature_engineering/
└── part_d/
```

---

## 5.2 Part C default resolution

The workflow resolves one Part C configuration before Part A runs:

```text
custom C config
    → use directly

no C config
    → default_profile = training.model_type
```

That single resolved request-level Part C configuration is reused for every KPI.

---

## 5.3 Tuning-method resolution

The workflow additionally resolves:

```text
resolved_tuning_method
```

from the training config.

This value is mainly used for:

- logging;
    
- training provenance metadata;
    
- final workflow completion logging.
    

The workflow does **not** itself run Optuna trials.

---

## 5.4 Part A

Part A still runs once:

```text
run_eda_pipeline(
    config=request.dataset,
    output_directory=eda_root
)
```

and produces the authoritative:

```text
EDARunnerResult
```

including KPI results and the resolved bucket.

---

## 5.5 Part A → Part B

Unchanged:

```text
KPIEDARunResult
+
DatasetInputConfig
+
PreprocessingConfig
+
resolved Part A BucketConfig
+
KPI-specific output directory
```

---

## 5.6 Part B → Part C

Unchanged:

```text
exact PreprocessingRunnerResult
+
DatasetInputConfig
+
resolved workflow FeatureEngineeringConfig
+
same Part A BucketConfig
```

Part C remains responsible for extracting and validating the exact Part B final dataset.

---

## 5.7 Part C → Part D

The core handoff is also structurally unchanged from Pipeline 3:

```text
model_type =
request.training.model_type

input_file =
feature_engineering_result.final_dataset_file

output_directory =
part_d/<KPI>/

dataset_columns =
request.dataset.columns

feature_config =
feature_engineering_result.resolved_config

minimum_history_points =
feature_engineering_result
    .resolved_config
    .minimum_history_points

training_config =
request.training
```

This is important:

**Optuna did not require a new C→D integration interface.**

The same `run_training()` boundary continues to work.

The fixed/Optuna difference is encoded inside:

```text
request.training
```

and handled downstream by Part D.

---

## 5.8 New training metadata

Pipeline 4 extends the metadata dictionary passed to Part D.

Pipeline 3 included:

```text
kpi_name
part_c_output_directory
part_c_final_dataset
```

Pipeline 4 adds:

```text
hyperparameter_tuning_enabled
hyperparameter_tuning_method
```

Therefore training artifacts can retain explicit provenance for whether the run used tuning and which tuning method was selected.

---

## 5.9 Exact training configuration retained by workflow

`TestPipelineWorkflowResult` now contains:

```text
training_config: TrainingConfig
```

in addition to:

```text
output_directory
eda_result
kpi_results
```

The workflow stores:

```text
training_config=request.training
```

This change enables the route to build its training response using the **exact validated training configuration actually used**.

---

# 6. Stage-to-Stage Handoff Contract

|From|To|Information passed|Form|Purpose|
|---|---|---|---|---|
|API|Workflow|Combined request|`PipelineRunRequest`|A–D configuration|
|Workflow|A|`request.dataset`|`DatasetInputConfig`|Source interpretation|
|A|Workflow|complete EDA result|`EDARunnerResult`|KPI set + resolved bucket|
|A|B|exact KPI result|`KPIEDARunResult`|Exact Part A artifacts|
|A|B/C|resolved bucket|`BucketConfig`|Shared frequency source|
|Request|B|preprocessing config|`PreprocessingConfig`|B behaviour|
|B|C|exact B result|`PreprocessingRunnerResult`|Exact Part B handoff|
|Request/workflow|C|custom or model-matched feature config|`FeatureEngineeringConfig`|C behaviour|
|C|Workflow|complete C result|`FeatureEngineeringRunnerResult`|Dataset + resolved feature contract|
|C|D|`final_dataset_file`|`Path`|Training dataset|
|C|D|`resolved_config`|resolved feature contract object|Defines generated Part C features|
|C|D|`minimum_history_points`|integer|History reservation/split requirement|
|Request|D|`dataset.columns`|`DatasetColumnMapping`|Physical dataset contract|
|Request|D|`training.model_type`|discriminator|Model dispatch|
|Request|D|complete `request.training`|model-specific config object|Direct/fixed/Optuna training behaviour|
|Workflow|D|upstream + tuning metadata|dictionary|Training provenance|
|D|Workflow|training result|`PartDTrainingResult`|Models, splits, validation, paths|
|Request|Workflow result|exact training config|`TrainingConfig`|Allows response to report requested tuning state|
|Workflow|Route|aggregate result|`TestPipelineWorkflowResult`|HTTP serialization|

---

# 7. KPI / Site / Model Iteration Behaviour

## KPI iteration

Still:

```text
Part A once
      ↓
for each KPI:
    Part B
      ↓
    Part C
      ↓
    Part D
```

The workflow remains KPI-major.

---

## Site iteration

Still delegated to module runners.

The parent workflow does not explicitly iterate sites for:

```text
Part B
Part C
Part D
```

Part D continues to train eligible site series internally.

---

## Model iteration

There is still **one selected model family per request**.

```text
training.model_type = xgboost
```

or:

```text
training.model_type = isolation_forest
```

That model type applies to every KPI in the request.

The pipeline does not run both model families automatically.

---

## Optuna iteration

A critical distinction:

The parent workflow contains **no Optuna trial loop**.

It does not do:

```text
for trial in ...
```

or invoke Optuna directly.

Instead:

```text
training configuration
        ↓
run_training()
        ↓
Part D internally decides fixed/direct/Optuna behaviour
```

Thus Optuna remains an internal Part D concern from the integration workflow's perspective.

---

# 8. Folder and Artifact Structure

The high-level hierarchy remains:

```text
<output_root>/
│
├── eda/
│
├── preprocessing/
│   └── <KPI>/
│
├── feature_engineering/
│   └── <KPI>/
│
└── part_d/
    └── <KPI>/
        └── training/
```

The Part D response continues to expose:

```text
training_directory
model_directory
model_files
split_plan
training_config
feature_contract
final_hyperparameters
training_summary
decision_settings
usable_row_counts
metadata
```

---

## Fixed vs Optuna artifact hierarchy

At this integration layer, there is **no different parent directory structure** for fixed vs Optuna.

Both use:

```text
part_d/<KPI>/
```

and Part D owns its internal training output structure.

Therefore tuning method is represented through:

```text
training configuration
saved training artifacts
metadata
final hyperparameters
```

rather than separate workflow roots.

---

## `final_hyperparameters` becomes especially important

The route continues to expose:

```text
final_hyperparameters_file
```

through:

```text
output_files.final_hyperparameters
```

For the post-Optuna pipeline, this persisted artifact becomes the natural integration-level record of the final parameters chosen/used by Part D regardless of how they were obtained.

The exact contents remain owned by Part D.

---

## Run/session naming

Still absent at the master workflow level:

```text
run_id
session_id
UUID
database record
```

The caller still supplies the output root.

---

# 9. Validation and Error Handling

## Route/schema validation

The Pydantic request validates:

```text
DatasetInputConfig
PreprocessingConfig
optional FeatureEngineeringConfig
XGBoostTrainingConfig
OR
IsolationForestTrainingConfig
including tuning-related fields
output_directory
```

The pipeline schema explicitly states that the model schema validates:

```text
direct
fixed-candidate
Optuna
```

hyperparameter inputs.

Therefore fixed/Optuna parameter validation remains in the Part D model schemas, not in the workflow.

---

## Workflow-level tuning resolution

The workflow reads:

```text
hyperparameter_tuning_enabled
hyperparameter_tuning_method
```

only after the training schema has already validated the request.

It does not independently verify Optuna ranges/candidates.

---

## Module validation chain

```text
Pydantic request
      ↓
Part A validation
      ↓
Part B validation
      ↓
Part C validation
      ↓
Part D validation
      ↓
model-specific fixed/Optuna execution
```

Validation therefore remains distributed across layers.

---

## Cross-stage validation

Unchanged important inputs to D:

```text
exact C final dataset
resolved C feature contract
C minimum_history_points
shared dataset column map
validated training config
```

This preserves the exact cross-stage contract regardless of tuning mode.

---

## Route runtime errors

Still:

```python
except Exception
```

→

```text
HTTP 500
```

with:

```json
{
  "detail": {
    "status": "failed",
    "error_type": "...",
    "message": "..."
  }
}
```

---

## Failure scope

Still all-or-nothing at parent workflow execution level.

Example:

```text
KPI 1 Optuna training succeeds

KPI 2 Optuna training fails
        ↓
workflow terminates
        ↓
remaining KPI runs do not start
        ↓
API returns HTTP 500
```

Previously created outputs remain on disk unless their owning module cleans them internally.

---

# 10. Response Contract

The A/B/C response sections remain essentially unchanged.

The major integration-level addition is explicit tuning information in:

```text
training.hyperparameter_tuning
```

---

## Part D response

```text
training
├── status
├── model_type
├── input_file
├── output_directory
├── minimum_history_points
├── hyperparameter_tuning
│   ├── enabled
│   └── method
├── series_statistics
├── skipped_series
├── validation
├── split_plan
└── output_files
```

---

## Hyperparameter tuning block

The route derives:

```text
enabled =
training_config.hyperparameter_tuning_enabled
```

and:

```text
method =
training_config.hyperparameter_tuning_method
if enabled
else None
```

This means the API now explicitly distinguishes:

```text
tuning disabled
    ↓
{
  enabled: false,
  method: null
}

tuning enabled
    ↓
{
  enabled: true,
  method: <validated method>
}
```

---

## Why `training_config` is now stored in workflow result

The route calls:

```text
build_training_response(
    training,
    training_config=result.training_config
)
```

The Part D result object alone is therefore not relied upon to reconstruct the requested tuning mode.

The workflow preserves the exact input training config for response construction.

This is a new integration behaviour compared with Pipeline 3.

---

## Split-plan tuning flag

The response separately includes:

```text
split_plan.hyperparameter_tuning_enabled
```

from Part D's generated split plan.

Thus two concepts are visible:

```text
request/config tuning state
        ↓
training.hyperparameter_tuning

Part D resolved split-plan state
        ↓
split_plan.hyperparameter_tuning_enabled
```

These should conceptually agree, but they originate from different objects.

---

## Detailed metrics

As before, the API intentionally does not reproduce every per-series training metric.

Detailed model outputs remain persisted in Part D artifacts.

---

# 11. Responsibilities of the Test Workflow Itself

Pipeline 4 retains all Pipeline 3 orchestration responsibilities and adds only a small amount of tuning-related logic.

## Existing responsibilities

```text
output-root creation
A→B→C→D sequencing
KPI iteration
KPI directory naming
model-matched Part C defaults
C→D field extraction
training model dispatch
Part C provenance metadata
result aggregation
```

---

## New — resolve tuning label

The workflow calculates:

```text
resolved_tuning_method
```

for logging and metadata.

It does not execute the tuning algorithm.

---

## New — tuning provenance metadata

It adds:

```text
hyperparameter_tuning_enabled
hyperparameter_tuning_method
```

to Part D metadata.

---

## New — preserve exact `TrainingConfig`

`TestPipelineWorkflowResult` now contains:

```text
training_config
```

so the HTTP route can report the exact validated tuning state used for the run.

---

## What the workflow still does NOT own

It does not decide:

```text
Optuna trial generation
parameter ranges
objective evaluation
best-trial selection
candidate search
final estimator parameters
per-site training internals
```

Those remain Part D responsibilities.

---

# 12. Test-Only Behaviour

The following historical/test characteristics remain:

- `/test-pipeline/run`;
    
- temporary FastAPI application;
    
- caller-supplied server filesystem output root;
    
- direct filesystem/model paths returned through HTTP;
    
- complete A→D execution synchronously inside the POST request;
    
- no persistent master run ID;
    
- no per-KPI partial-success response;
    
- global `logging.basicConfig()` in the test application;
    
- raw exception strings returned to the client.
    

The addition of Optuna does not change these test-server characteristics.

---

# 13. Integration Rules Learned From This Pipeline

## Confirmed Rule 1 — Existing A→B→C→D stage boundaries survive Optuna

No new orchestration architecture is introduced.

---

## Confirmed Rule 2 — A→B remains object handoff

```text
KPIEDARunResult
```

---

## Confirmed Rule 3 — B→C remains object handoff

```text
PreprocessingRunnerResult
```

---

## Confirmed Rule 4 — C→D remains mixed file/config handoff

```text
final_dataset_file
+
resolved feature config
+
minimum history
+
training config
```

Optuna does not change this.

---

## New Rule 5 — Training mode lives inside the Part D config

The parent workflow does not need different runner functions for:

```text
fixed
Optuna
```

The same:

```text
run_training()
```

interface remains reusable.

---

## New Rule 6 — Tuning state must be preserved as provenance

The workflow now attaches:

```text
hyperparameter_tuning_enabled
hyperparameter_tuning_method
```

to training metadata.

---

## New Rule 7 — Exact training request config may be required after execution

The workflow result now retains:

```text
training_config
```

because the HTTP response uses it to describe the tuning mode.

---

## Confirmed Rule 8 — Model selection still determines default Part C profile

When custom features are omitted:

```text
training.model_type
        ↓
Part C default profile
```

This behaviour is independent of fixed vs Optuna tuning.

---

## Confirmed Rule 9 — One model type per request

Optuna does not introduce model-family iteration.

---

## Confirmed Rule 10 — Part D owns the tuning algorithm

The workflow only transports validated tuning configuration.

---

## New Rule 11 — Final training parameters remain persisted independently of tuning mechanism

The stable output contract still contains:

```text
final_hyperparameters
```

so downstream consumers do not need to understand whether parameters came from fixed selection or Optuna merely to locate the final chosen configuration.

---

## Confirmed Rule 12 — Filesystem remains part of C→D and D-output integration

Training models and their contracts remain persisted artifacts.

---

# 14. Limitations of This Pipeline Version

Pipeline 4 completes the historical training evolution through:

```text
A → B → C → D
              ├── fixed/direct
              └── Optuna
```

but still does not cover:

```text
Part E inference
model loading for live inference
training-run → inference linkage
cache creation
cache updates
late data
inference window management
repeated/scheduled inference
```

It also still lacks:

- persistent master run lifecycle;
    
- asynchronous job management;
    
- per-KPI partial success;
    
- database-backed artifact indexing;
    
- production endpoint separation.
    

Those are outside the evidence of this pipeline.

---

# 15. Conflicts or Questionable Behaviour

|Issue|Severity|Evidence|Possible impact|
|---|---|---|---|
|All runtime failures still mapped to HTTP 500|**Important**|Generic route exception handler|Validation, Optuna and internal errors look the same at HTTP level|
|One failed KPI aborts all remaining KPIs|**Important**|Sequential workflow without KPI isolation|Expensive prior training/tuning outputs can exist under an overall failed request|
|Optuna can make synchronous request significantly more expensive|**Historical/Test-only**|Full D execution remains inside POST|Longer request lifetime/resource occupation|
|No master run ID|**Historical/Test-only**|Caller-controlled output root|Weak global lifecycle linkage|
|Raw exceptions returned|**Important**|`message=str(error)`|Internal tuning/filesystem details may leak|
|Sanitized KPI collision issue remains|**Potential bug**|Same safe name logic|Different KPIs could theoretically target same stage directories|
|No explicit per-KPI training config|**Historical limitation**|One `request.training` reused for all KPIs|Different KPIs cannot use different models/tuning policies in one request|
|Custom C config may not match model defaults|**Important but validated downstream**|Model-matched C defaults only used when C omitted|User can intentionally supply a different feature set; Part D must determine suitability|
|Request tuning state and split-plan tuning state are separate values|**Minor / sanity concern**|Response exposes both|If Part D ever resolved differently, response could expose inconsistency|
|Route still coupled to `SplitRange` from training loader|**Minor**|Direct internal import|HTTP layer knows Part D internal split representation|
|Training response depends on both result and original request config|**Important architectural observation**|`build_training_response(training, training_config=...)`|`PartDTrainingResult` alone does not provide every response-level tuning field|
|No separate workflow branch for Optuna|**Not a bug; important historical finding**|Same `run_training()` call|Confirms tuning mode is intentionally encapsulated inside Part D|
|Fixed/Optuna output directories are not separated at workflow level|**Historical / intentional**|Same `part_d/<KPI>` root|Identifying mode depends on config/metadata rather than parent folder name|

No contradiction should be silently resolved until Pipeline 5 and the final synthesis are compared.

---

# 16. Compact Pipeline Contract

```text
Pipeline:
Part A → Part B → Part C → Part D
with fixed/direct or Optuna-capable training

Endpoint:
POST /api/v1/test-pipeline/run

Input:
PipelineRunRequest
├── dataset: DatasetInputConfig
├── preprocessing: PreprocessingConfig
├── feature_engineering:
│   FeatureEngineeringConfig | None
├── training:
│   XGBoostTrainingConfig
│   OR
│   IsolationForestTrainingConfig
│
│   includes tuning configuration such as:
│   hyperparameter_tuning_enabled
│   hyperparameter_tuning_method
│   model-specific fixed/direct/Optuna settings
│
└── output_directory: Path

Stages:
Part A once

For each KPI:
    Part B
      ↓
    Part C
      ↓
    Part D

Primary workflow:
run_test_pipeline_workflow()

A → B:
exact KPIEDARunResult
+
DatasetInputConfig
+
PreprocessingConfig
+
resolved Part A BucketConfig

B → C:
exact PreprocessingRunnerResult
+
DatasetInputConfig
+
custom/model-matched FeatureEngineeringConfig
+
same resolved bucket

C → D:
final_dataset_file
+
resolved Part C feature config
+
Part C minimum_history_points
+
DatasetColumnMapping
+
request.training
+
training.model_type
+
KPI/Part C/tuning metadata

Fixed vs Optuna:
No separate workflow function.
Same run_training() boundary.
Training configuration determines behaviour inside Part D.

Workflow tuning logic:
resolved_tuning_method =
    training.hyperparameter_tuning_method
    if training.hyperparameter_tuning_enabled
    else None

Output:
Part A/B/C results
+
Part D:
- status
- model type
- tuning enabled/method
- trained/skipped series
- validation information
- chronological split plan
- model files
- training configuration
- feature contract
- final hyperparameters
- training summary
- decision settings
- usable-row counts
- metadata

Folder root:
caller-supplied output_directory

High-level structure:
<root>/
├── eda/
├── preprocessing/<KPI>/
├── feature_engineering/<KPI>/
└── part_d/<KPI>/
    └── training/...

Important validation:
- request/Pydantic validation
- model_type discrimination
- training schema validates fixed/direct/Optuna inputs
- A runtime validation
- B A-handoff validation
- C B-handoff and feature validation
- D training/feature/split validation

Important errors:
Request-validation errors:
    FastAPI validation path

Runtime errors:
    HTTP 500 with
    status
    error_type
    message

Failure scope:
Any stage/KPI failure stops the remaining overall request.

Test-only logic:
- temporary endpoint/server
- synchronous A→D + tuning execution
- direct output-directory control
- filesystem paths in API response
- no master run ID
- no partial-success handling

Key integration lessons:
1. Adding Optuna did not require a new A→D workflow architecture.
2. The same run_training() interface supports the tuning-capable Part D.
3. A→B and B→C structured result-object handoffs remain unchanged.
4. C→D remains final CSV + resolved feature contract + minimum history.
5. Fixed/Optuna differences are carried inside the validated training config.
6. The workflow does not run Optuna trials itself.
7. Model-specific Part C defaults still depend only on model_type, not tuning method.
8. One model/tuning config applies to every KPI in one request.
9. Tuning enabled/method are now persisted as upstream training metadata.
10. The exact TrainingConfig is retained in the workflow result.
11. The route exposes both requested tuning state and Part D split-plan tuning state.
12. Final models and final_hyperparameters remain stable persisted outputs regardless of tuning mechanism.
```

---

# Final Historical Interpretation

Pipeline 4 shows that the Optuna addition was primarily a **Part D configuration/execution evolution**, not a redesign of the integration chain.

The high-level flow remains:

```text
External request
      ↓
Part A
      ↓
KPIEDARunResult
      ↓
Part B
      ↓
PreprocessingRunnerResult
      ↓
Part C
      ↓
FeatureEngineeringRunnerResult
      ↓
final_dataset_file
+
resolved feature contract
+
minimum history
      ↓
Part D
      │
      ├── direct/fixed behaviour
      └── Optuna behaviour
      ↓
PartDTrainingResult
+
persisted training artifacts
```

The most important difference from Pipeline 3 is therefore **not a new handoff**.

It is:

```text
request.training
        ↓
now fully describes fixed/direct/Optuna training behaviour
        ↓
same run_training() integration boundary
```

The workflow adds only enough logic to understand and preserve that context:

```text
hyperparameter_tuning_enabled
hyperparameter_tuning_method
```

for logging, metadata and API reporting.

The other major change is that the exact validated `TrainingConfig` is now stored inside `TestPipelineWorkflowResult`, allowing the route to construct an explicit:

```text
hyperparameter_tuning:
    enabled
    method
```

response for every KPI.

Therefore the strongest historical conclusion from Pipeline 4 is:

> **Optuna was integrated behind the existing Part D runner contract rather than by creating a second orchestration path.**

The stable integration contract from Pipeline 3 survives, while tuning strategy becomes another validated Part D configuration dimension.