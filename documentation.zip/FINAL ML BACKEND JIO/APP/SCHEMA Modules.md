# [[Part A Shared Dataset Schema — schema common.dataset.py]]

# [[Part B Preprocessing Schema — app.schemas.preprocessing]]
# [[Part C Feature Engineering Schema — app.schemas.feature_engineering]]

# [[Part D Training Schema — app.schemas.training]]

# [[Part E Inference Schema — app.schemas.inference]]