# Services Module — `file_service.py` Final Technical Report

**File:** `app/services/file_service.py`  
**Role:** Shared reusable filesystem and file-format service for the backend.

---

# 1. File Purpose

`file_service.py` provides the backend's **common low-level persistence and file-validation operations**.

It owns reusable operations for:

- directory creation;
    
- filename sanitization;
    
- file existence/type validation;
    
- file-extension validation;
    
- file-size validation;
    
- complete input-file validation;
    
- SHA-256 checksums;
    
- file metadata extraction;
    
- copying validated input files;
    
- CSV reading;
    
- CSV writing;
    
- JSON reading;
    
- JSON writing;
    
- atomic JSON replacement.
    

The module explicitly does **not decide where a pipeline run should live**.

Its source states that destination/run paths are supplied by the separate:

```text
run_directory_service.py
```

Therefore its architectural responsibility is:

```text
another backend module decides WHERE
          ↓
file_service performs HOW
          ↓
filesystem
```

---

# 2. Public Functions

|Name|Type|Purpose|Inputs|Returns|Side effects|
|---|---|---|---|---|---|
|`ensure_directory()`|Function|Ensure a directory exists|`str \| Path`|Resolved `Path`|Creates directory hierarchy|
|`sanitise_filename()`|Function|Convert filename into safer standalone name|`str`|`str`|None|
|`validate_file_exists()`|Function|Confirm path exists and is a regular file|`str \| Path`|Resolved `Path`|Filesystem inspection|
|`validate_file_extension()`|Function|Validate extension against allowed set|path, optional extensions|Resolved `Path`|None|
|`validate_file_size()`|Function|Validate non-empty file and max size|path, optional byte limit|Resolved `Path`|Reads file metadata|
|`validate_input_file()`|Function|Perform general reusable input-file validation|path, optional extensions/limit|Resolved `Path`|Filesystem inspection|
|`calculate_file_sha256()`|Function|Produce memory-safe SHA-256 checksum|path, optional chunk size|Hexadecimal `str`|Reads complete file|
|`get_file_metadata()`|Function|Produce file metadata dictionary|path, checksum option|`dict[str, Any]`|Reads metadata; optionally file|
|`copy_input_file()`|Function|Validate and copy an input file|source, destination, optional name/overwrite|Resolved destination `Path`|Creates directory and copies file|
|`read_csv_file()`|Function|Load validated CSV into Pandas|path, Pandas options|`pd.DataFrame`|Reads file|
|`write_csv_file()`|Function|Persist DataFrame as CSV|DataFrame, path, options|Resolved `Path`|Creates directory/writes file|
|`read_json_file()`|Function|Read and decode JSON|path|`Any`|Reads file|
|`write_json_file()`|Function|Atomically persist JSON-like data|data, path, overwrite, indent|Resolved `Path`|Creates directory/temp file/final file|

There are no public classes or constants defined in this module.

---

# 3. Overall Service Architecture

The module can be grouped into four responsibility areas:

```text
file_service.py
│
├── Path / directory handling
│   ├── ensure_directory()
│   └── sanitise_filename()
│
├── Validation
│   ├── validate_file_exists()
│   ├── validate_file_extension()
│   ├── validate_file_size()
│   └── validate_input_file()
│
├── File information / movement
│   ├── calculate_file_sha256()
│   ├── get_file_metadata()
│   └── copy_input_file()
│
└── Format persistence
    ├── read_csv_file()
    ├── write_csv_file()
    ├── read_json_file()
    └── write_json_file()
```

---

# 4. `ensure_directory()`

## Purpose

Create a directory hierarchy when it does not already exist and return its normalized absolute path.

## Inputs

```text
directory_path: str | Path
```

## Processing

```text
directory_path
      ↓
Path(...)
      ↓
expanduser()
      ↓
resolve()
      ↓
mkdir(parents=True, exist_ok=True)
```

## Returns

Resolved `Path`.

## Files/directories affected

The supplied directory and any missing parents.

## Existing-directory behavior

Because:

```python
exist_ok=True
```

an already-existing directory does not cause failure.

No directory is cleared or replaced.

## Exceptions

`OSError` is converted into:

```text
FileProcessingError
error_code = "DIRECTORY_CREATION_FAILED"
```

with details containing:

```text
directory
original_error
```

and exception chaining preserves the original error.

---

# 5. `sanitise_filename()`

## Purpose

Convert a supplied filename into a safer standalone filename without retaining directory information.

## Input

```text
filename: str
```

## Processing

First:

```python
Path(filename).name.strip()
```

is used to retain only the filename component and remove surrounding whitespace.

Then characters matching:

```text
< > : " / \ | ? *
control characters 0x00–0x1F
```

are replaced with:

```text
_
```

Finally:

```python
safe_name.strip(" .")
```

removes leading/trailing spaces and periods.

## Return

Sanitized filename string.

## Validation

Rejected when the resulting name is:

- empty;
    
- `"."`;
    
- `".."`.
    

## Exceptions

Raises:

```text
InputValidationError
```

with either:

```text
EMPTY_FILENAME
INVALID_FILENAME
```

## Side effects

None.

---

# 6. Filename Safety Boundary

The function attempts to prevent directory/path components from being used directly as destination filenames.

Conceptually:

```text
user/service filename
        ↓
discard directory component
        ↓
replace unsafe characters
        ↓
trim unsafe ending/beginning
        ↓
safe standalone filename
```

It does not enforce:

- maximum filename length;
    
- a specific extension;
    
- uniqueness;
    
- reserved OS device names;
    
- application-specific naming conventions.
    

Those concerns are either handled elsewhere or are **UNKNOWN / NOT CONFIRMED**.

---

# 7. `validate_file_exists()`

## Purpose

Confirm that a supplied path refers to an existing regular file.

## Input

```text
file_path: str | Path
```

## Processing

Normalizes through:

```text
Path
→ expanduser()
→ resolve()
```

Then checks:

```text
exists()
is_file()
```

## Returns

Resolved `Path`.

## Exceptions

### Missing path

```text
InputValidationError
FILE_NOT_FOUND
```

### Exists but is not a file

```text
InputValidationError
PATH_IS_NOT_FILE
```

Details include the resolved path.

## Side effects

None beyond filesystem inspection.

---

# 8. `validate_file_extension()`

## Purpose

Verify that a file path has one of the permitted extensions.

## Inputs

```text
file_path
allowed_extensions: tuple[str, ...] | None
```

When no explicit set is supplied:

```text
settings.allowed_input_extensions
```

is used.

With current Core defaults this is:

```text
(".csv",)
```

## Extension normalization

Each configured extension:

- is lowercased;
    
- receives a leading `.` if missing.
    

Therefore these are treated equivalently:

```text
CSV
.csv
.CSV
```

after normalization.

The received suffix is also lowercased.

## Returns

Resolved `Path`.

## Exceptions

Unsupported extension:

```text
InputValidationError
INVALID_FILE_EXTENSION
```

with:

```text
file_path
received_extension
allowed_extensions
```

## Important boundary

This function does **not confirm that the file exists**.

It validates the path's suffix only.

---

# 9. `validate_file_size()`

## Purpose

Ensure that a file:

```text
is not empty
and
does not exceed the configured size limit
```

## Inputs

```text
file_path
max_size_bytes: int | None
```

Default size limit:

```text
settings.max_input_file_size_bytes
```

which comes from the Core configuration.

## Validation

First:

```text
permitted_size > 0
```

must hold.

An invalid limit produces:

```text
InputValidationError
INVALID_FILE_SIZE_LIMIT
```

Then:

```python
resolved_path.stat().st_size
```

is read.

### Empty file

```text
size == 0
```

produces:

```text
InputValidationError
EMPTY_FILE
```

### Oversized file

```text
size > permitted_size
```

produces:

```text
InputValidationError
FILE_TOO_LARGE
```

with size information included in `details`.

## Files affected

No file is modified.

## Filesystem failure

`OSError` during `stat()` becomes:

```text
FileProcessingError
FILE_SIZE_READ_FAILED
```

---

# 10. `validate_input_file()`

## Purpose

Provide one reusable high-level validation function for ordinary input files.

## Processing flow

```text
file_path
   │
   ▼
validate_file_exists()
   │
   ▼
validate_file_extension()
   │
   ▼
validate_file_size()
   │
   ▼
validated resolved Path
```

Therefore it guarantees that at the time of validation the input:

- exists;
    
- is a regular file;
    
- has a permitted extension;
    
- is not empty;
    
- is not over the allowed size.
    

## Inputs

```text
file_path
allowed_extensions=None
max_size_bytes=None
```

Both restrictions can be overridden per call.

## Returns

Validated resolved `Path`.

## Exceptions

Propagates the structured exceptions generated by the lower-level validators.

---

# 11. Validation Responsibility Split

The service deliberately separates granular validation:

```text
exists?
extension?
size?
```

from the combined convenience operation:

```text
validate_input_file()
```

This allows another backend component to perform only the checks appropriate for its use case.

For example, JSON reading deliberately uses:

```text
validate_file_exists()
```

instead of the complete generic input-file validation because global input extensions currently default to CSV.

---

# 12. `calculate_file_sha256()`

## Purpose

Calculate a SHA-256 checksum for exact file-content identification.

The source explicitly notes that this value can be stored in a run manifest to determine whether two files contain identical content.

## Inputs

```text
file_path
chunk_size_bytes = 1,048,576
```

Default chunk:

```text
1 MiB
```

## Validation

First ensures the file exists.

Then requires:

```text
chunk_size_bytes > 0
```

Invalid chunk size raises:

```text
InputValidationError
INVALID_CHECKSUM_CHUNK_SIZE
```

## Processing

```text
open file in binary mode
        ↓
read fixed-size chunk
        ↓
update SHA-256
        ↓
repeat until EOF
        ↓
hexdigest()
```

This avoids loading the entire file into memory at once.

## Return

64-character SHA-256 hexadecimal string.

## Exceptions

Filesystem read errors become:

```text
FileProcessingError
CHECKSUM_CALCULATION_FAILED
```

## Side effects

Reads the complete file but does not modify it.

---

# 13. `get_file_metadata()`

## Purpose

Generate a structured metadata record describing one file.

## Inputs

```text
file_path
include_checksum=False
```

## Return structure

Always includes:

```text
file_name
file_path
extension
size_bytes
size_mb
modified_at_utc
```

Optionally includes:

```text
sha256
```

## Modification time

The filesystem timestamp:

```text
st_mtime
```

is converted to a timezone-aware UTC datetime and returned via:

```text
isoformat()
```

## Size

Provides:

```text
size_bytes
```

and:

```text
size_mb = round(size / 1024**2, 3)
```

## Checksum

When requested:

```text
calculate_file_sha256()
```

is called.

## Exceptions

Metadata inspection failure becomes:

```text
FileProcessingError
FILE_METADATA_READ_FAILED
```

## Side effects

None except reading file metadata and optionally the complete file for checksum computation.

---

# 14. File Metadata Contract

Conceptually:

```text
file
 │
 ▼
get_file_metadata()
 │
 ├── identity
 │   ├── name
 │   ├── path
 │   └── extension
 │
 ├── storage metadata
 │   ├── bytes
 │   └── MB
 │
 ├── modified UTC time
 │
 └── optional SHA-256
```

This information is potentially useful for later:

- manifests;
    
- run registries;
    
- audit records;
    
- dataset provenance.
    

Actual persistence of this metadata is not performed by this file.

---

# 15. `copy_input_file()`

## Purpose

Validate an incoming file and copy it into a caller-supplied destination directory.

This is the bridge between:

```text
external/source input
```

and:

```text
backend-managed run storage
```

while leaving the destination location itself to another service.

## Inputs

```text
source_path
destination_directory
destination_filename=None
overwrite=False
```

## Processing

```text
source file
    ↓
validate_input_file()
    ↓
ensure_directory(destination)
    ↓
choose source name or supplied destination name
    ↓
sanitise_filename()
    ↓
construct destination path
    ↓
existing destination?
    │
    ├── yes + overwrite=False → fail
    └── otherwise
           ↓
        shutil.copy2()
```

## Returns

Resolved destination `Path`.

## Files/directories affected

May create destination directories and creates/replaces the destination file.

## Copy behavior

Uses:

```python
shutil.copy2()
```

which copies file content and attempts to preserve source metadata supported by the platform.

## Default overwrite behavior

```text
False
```

Therefore copying an input file is conservative by default.

## Existing destination failure

Raises:

```text
FileProcessingError
DESTINATION_FILE_EXISTS
```

## Copy failure

`OSError` becomes:

```text
FileProcessingError
FILE_COPY_FAILED
```

---

# 16. `read_csv_file()`

## Purpose

Provide a common validated CSV-loading operation for backend modules.

## Inputs

```text
file_path
**read_csv_options
```

## Validation

Calls:

```text
validate_input_file(
    allowed_extensions=(".csv",)
)
```

Therefore the file must:

- exist;
    
- be a regular file;
    
- use `.csv`;
    
- be non-empty;
    
- satisfy the global/default maximum size unless a different validator was called separately.
    

## Encoding

Default:

```text
settings.default_file_encoding
```

Currently:

```text
utf-8
```

Caller-supplied `read_csv_options` are merged afterward:

```python
{
    "encoding": settings.default_file_encoding,
    **read_csv_options,
}
```

Therefore callers can override the default encoding and other Pandas options.

## Processing

Delegates actual parsing to:

```python
pd.read_csv()
```

## Return

```text
pd.DataFrame
```

---

# 17. CSV Read Error Mapping

The service translates Pandas/Python failures into the shared Core error hierarchy.

### Encoding failure

```text
UnicodeDecodeError
      ↓
FileProcessingError
CSV_ENCODING_ERROR
```

### No readable columns

```text
pd.errors.EmptyDataError
      ↓
InputValidationError
EMPTY_CSV
```

### CSV parser failure

```text
pd.errors.ParserError
      ↓
FileProcessingError
CSV_PARSE_FAILED
```

### Other read/configuration errors

```text
OSError
ValueError
      ↓
FileProcessingError
CSV_READ_FAILED
```

This gives callers stable application-level error categories rather than requiring them to understand Pandas exceptions.

---

# 18. `write_csv_file()`

## Purpose

Persist a DataFrame to a `.csv` destination using consistent path handling and error conversion.

## Inputs

```text
dataframe: pd.DataFrame
file_path
index=False
overwrite=True
**to_csv_options
```

## Path validation

Destination suffix must be exactly `.csv` case-insensitively.

Otherwise:

```text
InputValidationError
INVALID_CSV_OUTPUT_EXTENSION
```

## Overwrite behavior

Default:

```text
overwrite=True
```

Therefore existing CSV output files are replaced by default.

If:

```text
overwrite=False
```

and destination exists:

```text
FileProcessingError
DESTINATION_FILE_EXISTS
```

## Directory behavior

Parent directory is automatically created using:

```text
ensure_directory()
```

## Encoding

Defaults to:

```text
settings.default_file_encoding
```

but caller-provided options can override it.

## Index behavior

Default:

```text
index=False
```

## Processing

Delegates to:

```python
dataframe.to_csv()
```

## Returns

Resolved destination `Path`.

## Exceptions

```text
OSError
ValueError
TypeError
```

are translated into:

```text
FileProcessingError
CSV_WRITE_FAILED
```

---

# 19. CSV Write Atomicity

`write_csv_file()` writes directly to:

```text
destination_path
```

It does **not** use a temporary file followed by replacement.

Therefore CSV writes are:

```text
direct writes
```

not atomic replacement writes.

A failure during `DataFrame.to_csv()` could potentially leave a partial output depending on when the failure occurs.

This differs intentionally or practically from JSON writing, which does implement a temporary-file replacement strategy.

Classification:

```text
Important observation
```

---

# 20. `read_json_file()`

## Purpose

Read and decode a JSON file into its Python representation.

## Inputs

```text
file_path
```

## Validation

First:

```text
validate_file_exists()
```

Then requires:

```text
suffix == ".json"
```

case-insensitively.

Invalid extension:

```text
InputValidationError
INVALID_JSON_EXTENSION
```

## Encoding

Uses:

```text
settings.default_file_encoding
```

## Processing

```python
json.load(file)
```

## Return

```text
Any
```

depending on JSON root type, for example:

- dictionary;
    
- list;
    
- string;
    
- number;
    
- boolean;
    
- `None`.
    

---

# 21. JSON Read Error Mapping

Invalid JSON syntax:

```text
json.JSONDecodeError
      ↓
FileProcessingError
JSON_DECODE_FAILED
```

Details include:

```text
file_path
line_number
column_number
original_error
```

Filesystem read failure:

```text
OSError
      ↓
FileProcessingError
JSON_READ_FAILED
```

This gives downstream consumers both a stable backend code and precise parse location where available.

---

# 22. JSON Read Size Behavior

Unlike CSV reading, `read_json_file()` does not call:

```text
validate_input_file()
```

or:

```text
validate_file_size()
```

Therefore the global input-file size restriction is **not automatically applied to JSON reads**.

The file must exist and use `.json`, but there is no explicit size check in this function.

Classification:

```text
Important observation
```

Whether JSON files are only expected to be small internal manifests/configuration files will need to be confirmed from their callers.

---

# 23. `write_json_file()`

## Purpose

Persist Python data to JSON while reducing the chance of leaving a partially written final file.

## Inputs

```text
data
file_path
overwrite=True
indent=4
```

## Destination validation

Destination must use:

```text
.json
```

Otherwise:

```text
InputValidationError
INVALID_JSON_OUTPUT_EXTENSION
```

## Overwrite behavior

Default:

```text
True
```

If destination exists and overwrite is disabled:

```text
FileProcessingError
DESTINATION_FILE_EXISTS
```

## Directory behavior

Parent directory is automatically created.

---

# 24. Atomic JSON Write Strategy

The temporary filename is constructed as:

```text
.<destination_filename>.<uuid4 hex>.tmp
```

inside the **same destination directory**.

Example:

```text
manifest.json
```

could temporarily use:

```text
.manifest.json.abc123....tmp
```

The lifecycle is:

```text
destination data
       │
       ▼
create temporary file
       │
       ▼
json.dump()
       │
       ▼
write completes
       │
       ▼
temporary_path.replace(destination_path)
       │
       ▼
final JSON
```

Because the final file is replaced only after successful temporary writing, the method reduces the chance of corrupting an existing final JSON file with a partial write.

---

# 25. Temporary JSON Cleanup

A `finally` block checks:

```text
temporary_path.exists()
```

and attempts to delete it.

Cleanup failure is deliberately ignored:

```python
except OSError:
    pass
```

Therefore a failed JSON operation generally attempts to remove its temporary file, but cleanup is best-effort.

A temporary file could remain if deletion itself fails.

Classification:

```text
Minor operational observation
```

---

# 26. JSON Serialization Behavior

The JSON writer calls:

```python
json.dump(
    data,
    file,
    indent=indent,
    ensure_ascii=False,
    default=str,
)
```

Important consequences:

### Unicode

```text
ensure_ascii=False
```

preserves non-ASCII characters directly when possible.

### Unknown value types

```text
default=str
```

means unsupported JSON value objects can often be converted to strings instead of raising a serialization failure.

For example, objects such as some `Path` or datetime-like values may become their string representation.

Therefore the function is actually more permissive than the docstring's narrow phrase:

```text
JSON-serialisable Python data
```

suggests.

This behavior is particularly relevant for manifests containing paths or timestamps.

---

# 27. JSON Write Error Mapping

The following are caught:

```text
OSError
TypeError
ValueError
```

and converted to:

```text
FileProcessingError
JSON_WRITE_FAILED
```

Details include:

```text
file_path
original_error
```

The original exception is chained.

---

# 28. Project Dependencies

## `app.core.config.settings`

Used for:

```text
allowed_input_extensions
max_input_file_size_bytes
default_file_encoding
```

This means the service consumes centralized Core configuration instead of redefining application-wide file restrictions.

---

## `app.core.exceptions.InputValidationError`

Used when caller/input conditions are invalid, including:

- unsafe filenames;
    
- missing files;
    
- path is not a file;
    
- unsupported extension;
    
- invalid size limit;
    
- empty/oversized files;
    
- invalid checksum chunk;
    
- invalid output extension;
    
- empty CSV.
    

---

## `app.core.exceptions.FileProcessingError`

Used when an operation fails while interacting with the filesystem or parser/writer, including:

- directory creation;
    
- metadata/stat operations;
    
- checksum reads;
    
- copy operations;
    
- CSV parsing/read/write;
    
- JSON read/decode/write.
    

This is a concrete example of Services consuming the common failure contract established by Core.

---

# 29. External / Standard Dependencies

## Pandas

```text
pandas
```

is used for:

```text
CSV → DataFrame
DataFrame → CSV
```

The service wraps Pandas operations so higher backend modules can use a common error and encoding contract.

---

## `pathlib.Path`

Provides path normalization, inspection, construction, file opening, replacement, and deletion.

---

## `json`

Provides JSON decoding/encoding.

---

## `hashlib`

Provides SHA-256 checksum calculation.

---

## `shutil`

Provides metadata-preserving file copying via:

```text
copy2()
```

---

## `re`

Provides filename-character replacement.

---

## `uuid4`

Creates unique temporary JSON filenames.

---

## `datetime`, `timezone`

Convert filesystem modification timestamps into timezone-aware UTC values.

---

# 30. Filesystem Behavior Summary

## Directories created

By:

```text
ensure_directory()
copy_input_file()
write_csv_file()
write_json_file()
```

when destination parents do not exist.

---

## Files read

Potentially:

```text
any validated file for metadata/checksum
CSV
JSON
source file being copied
```

---

## Files written

```text
copied input files
CSV output files
JSON output files
temporary JSON files
```

---

## Files deleted

Only temporary JSON files during cleanup.

No general-purpose deletion or directory cleanup function exists.

---

## Path normalization

Most file/directory paths are processed through:

```text
Path(...)
.expanduser()
.resolve()
```

before use.

---

# 31. Overwrite Contract

Overwrite defaults differ by operation.

|Operation|Default|
|---|---|
|`copy_input_file()`|`overwrite=False`|
|`write_csv_file()`|`overwrite=True`|
|`write_json_file()`|`overwrite=True`|

This distinction is important.

### Input copy

Protects an existing copied input by default.

### Generated outputs

CSV/JSON generated outputs replace existing destinations by default.

---

# 32. Atomicity Contract

|Operation|Atomic replacement?|
|---|---|
|Input copy|No explicit atomic strategy|
|CSV write|No|
|JSON write|Yes, via temp file + `replace()`|

JSON receives stronger persistence protection than CSV.

This is especially relevant if JSON is used for operational state such as manifests.

---

# 33. Validation / Error Classification

## Input validation errors

Examples:

```text
EMPTY_FILENAME
INVALID_FILENAME
FILE_NOT_FOUND
PATH_IS_NOT_FILE
INVALID_FILE_EXTENSION
INVALID_FILE_SIZE_LIMIT
EMPTY_FILE
FILE_TOO_LARGE
INVALID_CHECKSUM_CHUNK_SIZE
INVALID_CSV_OUTPUT_EXTENSION
EMPTY_CSV
INVALID_JSON_EXTENSION
INVALID_JSON_OUTPUT_EXTENSION
```

These represent unacceptable caller/input state.

---

## File processing errors

Examples:

```text
DIRECTORY_CREATION_FAILED
FILE_SIZE_READ_FAILED
CHECKSUM_CALCULATION_FAILED
FILE_METADATA_READ_FAILED
DESTINATION_FILE_EXISTS
FILE_COPY_FAILED
CSV_ENCODING_ERROR
CSV_PARSE_FAILED
CSV_READ_FAILED
CSV_WRITE_FAILED
JSON_DECODE_FAILED
JSON_READ_FAILED
JSON_WRITE_FAILED
```

These represent failure of filesystem/parsing/persistence operations.

---

# 34. Data Structures / Result Objects

This service defines no custom dataclasses or Pydantic result models.

It returns standard types:

```text
Path
str
dict[str, Any]
pd.DataFrame
Any
```

The closest thing to a structured result object is the dictionary returned by:

```text
get_file_metadata()
```

No separate file metadata class exists.

---

# 35. Relationship to Parts A–E

The file is designed as a reusable persistence abstraction.

Parts A–E can call shared operations such as:

```text
read_csv_file()
write_csv_file()
ensure_directory()
sanitise_filename()
```

rather than every ML module independently handling:

- encodings;
    
- extensions;
    
- filesystem exception conversion;
    
- directory creation.
    

Previously documented ML modules are already known to consume shared file-service functions such as CSV reads/writes and filename sanitization.

However, a complete exact caller map for every function is **UNKNOWN / NOT CONFIRMED** from `file_service.py` alone.

---

# 36. Relationship to Run Directory Service

The source establishes a clear boundary:

```text
run_directory_service
        │
        ▼
decides destination Path
        │
        ▼
file_service
        │
        ▼
creates / reads / writes / copies file
```

`file_service.py` therefore does not decide:

- run ID;
    
- run root;
    
- stage names;
    
- KPI directory layout;
    
- training/inference hierarchy.
    

It performs filesystem operations against paths supplied by those higher-level services/runners.

---

# 37. Relationship to Run Manifest Service

Several current operations are directly useful to manifests:

```text
get_file_metadata()
calculate_file_sha256()
read_json_file()
write_json_file()
```

The checksum docstring explicitly mentions storing SHA-256 information in a run manifest.

The atomic JSON writer also appears suitable for safely updating frequently changing manifest state.

However:

> Whether `run_manifest_service.py` actually uses these functions and exactly how is **UNKNOWN / NOT CONFIRMED** until that file is analyzed.

---

# 38. Architectural Significance

`file_service.py` serves as the backend's **common filesystem abstraction**.

Instead of higher modules repeatedly doing:

```text
Path.mkdir()
pd.read_csv()
DataFrame.to_csv()
json.load()
json.dump()
shutil.copy()
```

with independent error handling, this service provides one shared contract:

```text
backend module
      │
      ▼
file_service
      │
      ├── normalize path
      ├── validate
      ├── apply shared config
      ├── execute filesystem operation
      └── translate errors
      │
      ▼
filesystem / Pandas / JSON
```

This helps Parts A–E and workflow/services operate under consistent file-handling rules.

---

# 39. What Belongs Inside This Service

Based on current implementation:

```text
generic path normalization
generic directory creation
generic filename sanitization
general file restrictions
metadata/checksum generation
generic copying
CSV persistence
JSON persistence
filesystem exception translation
```

These are reusable backend-support functions independent of any specific ML stage.

---

# 40. What Does NOT Belong Inside This Service

The file deliberately does not own:

```text
run-ID generation
run directory hierarchy
stage directory naming
KPI directory naming
manifest state model
pipeline orchestration
ML calculations
dataset semantic validation
feature/model schema validation
database persistence
workflow status
```

It handles filesystem mechanics, not application workflow semantics.

---

# 41. Potential Issues / Observations

## Important — CSV writing is not atomic

`write_csv_file()` writes directly to the final destination.

Unlike JSON, there is no temporary file and replacement step.

A failed write can therefore theoretically leave a partial final CSV.

This may be acceptable for generated datasets that can be rerun, but it is a real persistence difference.

---

## Important — JSON reads do not enforce the global file-size limit

`read_json_file()` checks:

```text
exists
is_file
.json extension
```

but not:

```text
max_input_file_size_bytes
```

This is different from CSV input reading.

It may be intentional if JSON files are expected to be small internal backend files such as manifests.

Actual usage must be confirmed from callers.

---

## Important — JSON serialization uses `default=str`

Unsupported values may be silently converted to strings.

This improves usability for:

- paths;
    
- datetime-like values;
    
- other objects.
    

But it can also hide accidental use of a non-JSON-native value rather than failing fast.

This is particularly relevant if consumers expect strict type preservation across JSON read/write cycles.

---

## Important — overwrite checks are not concurrency locks

Operations generally perform:

```text
destination.exists()
        ↓
then write/copy
```

when `overwrite=False`.

Another process could theoretically create the destination between those operations.

Therefore the existence checks provide normal application protection but are not transactional/concurrency-lock mechanisms.

This is a general edge case rather than evidence of a current failure.

---

## Minor — `size_mb` is calculated using `1024²`

The metadata key is:

```text
size_mb
```

but calculation uses binary MiB-style conversion:

```text
bytes / 1024²
```

rather than decimal megabytes (`1,000,000`).

This is common in software but the label is technically approximate.

---

## Minor — `get_file_metadata(include_checksum=True)` inspects the file twice

It first calls:

```text
stat()
```

then later reopens and reads the full file for SHA-256.

This is correct behavior, but checksum-enabled metadata has full-file I/O cost.

For large input files this may be significant.

---

## Minor — temporary JSON cleanup failures are ignored

If cleanup cannot unlink a leftover temp file, the service suppresses the cleanup error.

This avoids masking the main failure but can leave temporary files behind in unusual filesystem-failure cases.

---

## Minor — filename sanitization is not a uniqueness mechanism

Different filenames can theoretically sanitize into the same result.

For example, distinct unsafe characters may all become `_`.

Collision handling must therefore come from the caller or overwrite policy.

---

## No issue / intentional — validation helpers are independently reusable

`validate_file_extension()` and `validate_file_size()` do not each repeat existence validation.

`validate_input_file()` composes the complete normal chain.

This avoids unnecessary duplication.

---

## No issue / intentional — input copy defaults to no overwrite

Copied source files are protected by default:

```text
overwrite=False
```

which is safer for preserving original run input provenance.

---

## No issue / intentional — JSON write uses same-directory temporary file

The temporary file is written beside the destination before `replace()`.

This supports stronger replacement semantics than writing a temp file somewhere unrelated and then copying it.

---

# 42. File I/O Architecture

The module's general architecture is:

```text
Backend caller
     │
     ▼
desired source/destination Path
     │
     ▼
file_service
     │
     ├── normalize
     ├── validate
     ├── ensure directory
     ├── perform operation
     └── translate failure
     │
     ▼
Filesystem
```

For CSV:

```text
Backend module
      ↓
read_csv_file / write_csv_file
      ↓
Pandas
      ↓
filesystem
```

For JSON:

```text
Backend service
      ↓
read_json_file / write_json_file
      ↓
Python json
      ↓
filesystem
```

---

# 43. Complete Function Responsibility Map

```text
ensure_directory()
→ Make a directory hierarchy exist.

sanitise_filename()
→ Produce a safer standalone filename.

validate_file_exists()
→ Confirm an existing regular file.

validate_file_extension()
→ Enforce permitted suffixes.

validate_file_size()
→ Enforce non-empty and maximum-size rules.

validate_input_file()
→ Combine normal file validation.

calculate_file_sha256()
→ Produce stable content checksum.

get_file_metadata()
→ Describe a file and optionally checksum it.

copy_input_file()
→ Validate and preserve a source file inside caller-defined storage.

read_csv_file()
→ Validate and parse CSV into DataFrame.

write_csv_file()
→ Persist DataFrame as CSV.

read_json_file()
→ Decode existing JSON.

write_json_file()
→ Persist JSON using temporary-file atomic replacement.
```

---

# 44. Compact File Contract

```text
FILE:
app/services/file_service.py

RESPONSIBILITY:
Provide reusable, centralized filesystem validation and file I/O operations
for the backend.

PUBLIC INTERFACE:
ensure_directory()
sanitise_filename()
validate_file_exists()
validate_file_extension()
validate_file_size()
validate_input_file()
calculate_file_sha256()
get_file_metadata()
copy_input_file()
read_csv_file()
write_csv_file()
read_json_file()
write_json_file()

INPUTS:
Filesystem paths
Allowed extensions
Maximum size limits
Filenames
Pandas DataFrames
JSON-like Python data
CSV reader/writer options
Overwrite policies

OUTPUTS:
Resolved Path objects
Sanitized filenames
SHA-256 strings
File metadata dictionaries
Pandas DataFrames
Decoded JSON objects

FILES/DIRECTORIES AFFECTED:
Creates requested parent directories.
Copies validated source files.
Reads CSV/JSON/general files.
Writes CSV outputs.
Writes JSON outputs through temporary-file replacement.
May remove temporary JSON files after writing.

VALIDATION:
File existence/type
File extension
File size
Non-empty input files
Filename safety
CSV/JSON output extension
Checksum chunk size
Overwrite rules

ERRORS:
InputValidationError for unacceptable caller/input state.
FileProcessingError for filesystem, parsing, decoding, copying, and
persistence failures.

OVERWRITE BEHAVIOUR:
Input copies default to overwrite=False.
CSV writes default to overwrite=True.
JSON writes default to overwrite=True.

ATOMICITY:
JSON writing uses temp-file + replace.
CSV writing does not.
Input copying has no explicit atomic replacement strategy.

ENCODING:
CSV and JSON normally use settings.default_file_encoding.
Caller CSV options can override the CSV encoding.

USED BY:
Expected Parts A-E, workflow/services, run-manifest code, and other backend
components requiring common persistence operations.
Exact usage of every function is UNKNOWN / NOT CONFIRMED from this file
alone.

ARCHITECTURAL ROLE:
Common filesystem/persistence abstraction beneath ML modules and higher
services. It owns generic file mechanics while run-directory placement,
manifest semantics, and workflow structure remain outside this file.
```

---

# Final Assessment

`file_service.py` is the **generic persistence foundation of the Services module**.

Its central role is:

```text
Higher backend layer
        │
        │ decides what file/path it needs
        ▼
file_service.py
        │
        ├── normalize
        ├── validate
        ├── create directories
        ├── read/write/copy
        └── translate errors
        ▼
Filesystem
```

The most important architectural distinction is:

```text
file_service.py
→ owns reusable filesystem mechanics

run_directory_service.py
→ expected to own run/stage directory structure

run_manifest_service.py
→ expected to own persisted run-state semantics

Parts A-E
→ own ML/data-processing behavior
```

This makes `file_service.py` a common persistence abstraction that allows the rest of the backend to avoid independently implementing low-level Pandas, JSON, path, validation, checksum, and filesystem-error behavior.