# Services Module — `run_directory_service.py` Final Technical Report

**File:** `app/services/run_directory_service.py`  
**Role:** Generate run IDs and own the standard filesystem directory contract for pipeline runs.

---

# 1. File Purpose

`run_directory_service.py` is the backend's **run-filesystem structure manager**.

It owns:

- generation of new run IDs;
    
- validation of supplied run IDs;
    
- standard run-directory naming;
    
- calculation of run/log/manifest paths;
    
- creation of the complete standard run folder hierarchy;
    
- validation of existing run roots;
    
- checking whether a run exists;
    
- listing previously created runs.
    

It explicitly does **not**:

- copy input files;
    
- write manifests;
    
- execute Parts A–E;
    
- configure logging handlers;
    
- write datasets/models/reports;
    
- determine stage-specific artifact filenames.
    

Those responsibilities belong to other Services, Core, workflow, or ML layers.

---

# 2. Public Classes / Functions / Constants

|Name|Type|Purpose|Inputs|Returns|Side effects|
|---|---|---|---|---|---|
|`RUN_SUBDIRECTORIES`|`dict[str, str]`|Define standard folders inside every run|None|Directory mapping|None|
|`RUN_ID_PATTERN`|compiled regex|Define permitted run-ID syntax|Run ID|Regex match|None|
|`generate_run_id()`|Function|Generate timestamp + UUID-based run ID|Optional prefix|`str`|Reads current UTC time / random UUID|
|`validate_run_id()`|Function|Validate and normalize run identifier|`run_id`|`str`|None|
|`get_run_directory()`|Function|Resolve `runs/<run_id>`|`run_id`|`Path`|None|
|`get_run_log_directory()`|Function|Resolve `logs/<run_id>`|`run_id`|`Path`|None|
|`get_run_paths()`|Function|Calculate all standard paths for a run|`run_id`|`dict[str, Path]`|None|
|`get_run_subdirectory()`|Function|Resolve one standard run subdirectory|`run_id`, key|`Path`|None|
|`create_run_directories()`|Function|Create a complete run filesystem area|Optional run ID, `exist_ok`|`dict[str, str \| Path]`|Creates directories|
|`validate_run_directory()`|Function|Confirm run root exists as directory|`run_id`|`Path`|Filesystem inspection|
|`run_directory_exists()`|Function|Check whether run root exists|`run_id`|`bool`|Filesystem inspection|
|`list_run_ids()`|Function|List valid existing run directory names|None|`list[str]`|Reads runs directory|

---

# 3. Standard Run Directory Contract

Every run receives the following configured subdirectories:

```python
RUN_SUBDIRECTORIES = {
    "input": "input",
    "preprocessing": "preprocessing",
    "models": "models",
    "reports": "reports",
    "agents": "agents",
    "temporary": "temporary",
}
```

Therefore the standard filesystem contract is:

```text
<project_root>/
│
├── runs/
│   └── <run_id>/
│       ├── manifest.json          # path reserved; NOT created here
│       ├── input/
│       ├── preprocessing/
│       ├── models/
│       ├── reports/
│       ├── agents/
│       └── temporary/
│
└── logs/
    └── <run_id>/
```

The logging directory is deliberately outside the main run artifact tree.

---

# 4. Run ID Contract

## `RUN_ID_PATTERN`

A valid run ID must match:

```text
^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$
```

Therefore:

- total length: **1–128 characters**;
    
- first character must be a letter or number;
    
- later characters may contain:
    
    - letters;
        
    - numbers;
        
    - `_`;
        
    - `-`;
        
    - `.`.
        

Characters such as:

```text
/
\
spaces
:
*
?
```

are rejected.

---

# 5. `generate_run_id()`

## Purpose

Generate a run identifier that is both readable and highly collision-resistant.

## Input

```text
prefix: str = "run"
```

## Prefix validation

The prefix:

- is stripped;
    
- cannot be empty;
    
- must match:
    

```text
[A-Za-z0-9][A-Za-z0-9_-]{0,31}
```

Therefore the prefix:

- is 1–32 characters;
    
- starts alphanumeric;
    
- may contain `_` and `-`;
    
- may **not** contain periods.
    

Invalid prefixes raise:

```text
RunDirectoryError
EMPTY_RUN_ID_PREFIX
```

or:

```text
RunDirectoryError
INVALID_RUN_ID_PREFIX
```

## Generation

The generated structure is:

```text
<prefix>_<UTC timestamp>_<8 hex UUID chars>
```

Example:

```text
run_20260723T041530123456Z_a4f918c2
```

Timestamp format:

```text
YYYYMMDDTHHMMSSffffffZ
```

including microseconds and explicit UTC `Z`.

The random component is:

```python
uuid4().hex[:8]
```

## Return

Validated-style run-ID string.

## Side effects

Reads:

- current UTC time;
    
- random UUID state.
    

No directory is created by this function.

---

# 6. Run-ID Uniqueness Behaviour

The generated ID combines:

```text
microsecond-resolution UTC timestamp
+
32-bit UUID fragment
```

which makes collisions highly unlikely.

However, `generate_run_id()` itself does not query the filesystem to prove uniqueness.

The actual protection occurs later when `create_run_directories()` rejects an already-existing run directory unless reuse is explicitly allowed.

Therefore:

```text
generate_run_id()
→ highly collision-resistant identifier

create_run_directories()
→ filesystem-level collision check
```

---

# 7. `validate_run_id()`

## Purpose

Normalize and enforce the shared run-ID path contract.

## Input

```text
run_id: str
```

## Processing

```text
run_id
  ↓
strip()
  ↓
empty?
  ↓
"." / ".."?
  ↓
RUN_ID_PATTERN
  ↓
validated run ID
```

## Errors

### Empty

```text
RunDirectoryError
EMPTY_RUN_ID
```

### `"."`, `".."`, unsupported characters or excessive length

```text
RunDirectoryError
INVALID_RUN_ID
```

Details include the rejected ID and, for pattern failures:

```text
allowed_characters
maximum_length = 128
```

## Return

Stripped validated run ID.

## Side effects

None.

---

# 8. `get_run_directory()`

## Purpose

Resolve the main artifact directory for a run.

## Processing

```text
validate_run_id(run_id)
        ↓
settings.get_run_directory()
```

## Return

```text
<project_root>/runs/<run_id>
```

## Side effects

None.

The directory is not created.

---

# 9. `get_run_log_directory()`

## Purpose

Resolve the separate logging area for the same run.

## Return

```text
<project_root>/logs/<run_id>
```

It validates the run ID first and then delegates path construction to Core configuration.

No directory is created.

---

# 10. `get_run_paths()`

## Purpose

Build the complete **standard path map** associated with one run without creating anything.

## Return

Conceptually:

```python
{
    "run": Path("runs/<run_id>"),
    "logs": Path("logs/<run_id>"),
    "manifest": Path("runs/<run_id>/manifest.json"),
    "input": Path("runs/<run_id>/input"),
    "preprocessing": Path("runs/<run_id>/preprocessing"),
    "models": Path("runs/<run_id>/models"),
    "reports": Path("runs/<run_id>/reports"),
    "agents": Path("runs/<run_id>/agents"),
    "temporary": Path("runs/<run_id>/temporary"),
}
```

## Important distinction

The function calculates:

```text
manifest.json
```

but does **not create the manifest file**.

That remains the responsibility of `run_manifest_service.py`.

---

# 11. `get_run_subdirectory()`

## Purpose

Resolve one configured run subdirectory by logical key.

## Inputs

```text
run_id
directory_key
```

The key is normalized using:

```text
strip()
lower()
```

Supported keys are:

```text
input
preprocessing
models
reports
agents
temporary
```

## Error

Unsupported key:

```text
RunDirectoryError
UNKNOWN_RUN_SUBDIRECTORY
```

with available keys included in the error details.

## Return

Requested `Path`.

## Side effects

None.

---

# 12. `create_run_directories()`

## Purpose

Create the complete standard filesystem area for one pipeline run.

This is the central write operation of the service.

## Inputs

```text
run_id: str | None = None
exist_ok: bool = False
```

---

# 13. Run ID Resolution During Creation

If the caller supplies a run ID:

```text
validate_run_id(run_id)
```

is used.

If no run ID is supplied:

```text
generate_run_id()
```

is used.

Therefore this service supports both:

```text
system-generated run ID
```

and:

```text
externally supplied validated run ID
```

---

# 14. Existing Run Behaviour

Default:

```text
exist_ok = False
```

If:

```text
runs/<run_id>
```

already exists, the service raises:

```text
RunDirectoryError
RUN_DIRECTORY_ALREADY_EXISTS
```

before attempting creation.

Therefore the normal contract treats every new run directory as unique.

---

# 15. Run Reuse / Reopening

When:

```text
exist_ok = True
```

an existing run directory may be reused.

The service then ensures that:

```text
run root
log root
standard subdirectories
```

exist.

Therefore a basic filesystem-level reopen/reuse capability exists.

However, it does **not** verify:

- manifest state;
    
- whether the prior run completed;
    
- whether directories contain compatible artifacts;
    
- workflow stage state;
    
- whether reopening is semantically safe.
    

So:

```text
exist_ok=True
```

means:

> filesystem reuse is permitted

—not—

> workflow resume is validated.

---

# 16. Directory Creation Sequence

`create_run_directories()` executes:

```text
resolve/generate run ID
        ↓
calculate all run paths
        ↓
existing run?
        ↓
settings.create_base_directories()
        ↓
create runs/<run_id>/
        ↓
create logs/<run_id>/
        ↓
create standard run subdirectories
        ↓
return path dictionary
```

The standard subdirectories are created using:

```text
exist_ok=True
```

after the main run root has been established.

---

# 17. Interaction With Core Base Directories

Before creating the run-specific structure, the service calls:

```python
settings.create_base_directories()
```

This ensures shared parents exist.

Because that Core method also establishes model artifact roots, calling `create_run_directories()` can indirectly ensure:

```text
runs/
logs/
model_artifacts/xgboost/
model_artifacts/isolation_forest/
model_artifacts/model_metadata/
```

exist.

The run-directory service itself then creates the run-specific directories.

---

# 18. Directory Creation Result

The return structure is:

```text
{
    "run_id": <str>,
    "run": <Path>,
    "logs": <Path>,
    "manifest": <Path>,
    "input": <Path>,
    "preprocessing": <Path>,
    "models": <Path>,
    "reports": <Path>,
    "agents": <Path>,
    "temporary": <Path>,
}
```

This gives workflows one structured path bundle rather than requiring them to reconstruct directory names manually.

The manifest path is returned even though the file does not yet exist.

---

# 19. Creation Failure Behaviour

Any `OSError` occurring during directory creation is converted to:

```text
RunDirectoryError
RUN_DIRECTORY_CREATION_FAILED
```

with details containing:

```text
run_id
run_directory
log_directory
original_error
```

The original exception is chained.

## Important behavior

There is no rollback mechanism.

If failure occurs after some directories have already been created, those directories may remain on disk.

Classification:

```text
Important observation
```

---

# 20. Which Folders This Service Creates

`create_run_directories()` directly creates:

```text
runs/<run_id>/
runs/<run_id>/input/
runs/<run_id>/preprocessing/
runs/<run_id>/models/
runs/<run_id>/reports/
runs/<run_id>/agents/
runs/<run_id>/temporary/

logs/<run_id>/
```

It does **not** create:

```text
manifest.json
```

nor any:

- KPI folder;
    
- Part A/B/C/D/E-specific folder;
    
- model-specific site folder;
    
- CSV;
    
- report;
    
- model artifact.
    

Those deeper directories/files must be created by workflows/runners/services as needed.

---

# 21. `validate_run_directory()`

## Purpose

Confirm that a requested run root already exists.

## Validation

The path:

```text
runs/<run_id>
```

must:

1. exist;
    
2. be a directory.
    

### Missing

```text
RunDirectoryError
RUN_DIRECTORY_NOT_FOUND
```

### Wrong filesystem type

```text
RunDirectoryError
RUN_PATH_IS_NOT_DIRECTORY
```

## Return

Existing run-directory `Path`.

## Important boundary

It validates only the **run root**.

It does not verify that:

```text
input/
preprocessing/
models/
reports/
agents/
temporary/
logs/
manifest.json
```

exist.

Therefore it is a run-root existence check rather than a complete structural-integrity validation.

---

# 22. `run_directory_exists()`

## Purpose

Return whether a valid run root currently exists as a directory.

## Return

```text
True
```

when:

```text
runs/<run_id>
```

exists and is a directory.

Otherwise:

```text
False
```

## Important behavior

The run ID is validated first through `get_run_directory()`.

Therefore malformed run IDs can still raise:

```text
RunDirectoryError
```

rather than simply returning `False`.

This function answers:

> Does this validly formed run ID have a directory?

not:

> Is any arbitrary supplied value a run?

Classification:

```text
Minor but important API-contract observation
```

---

# 23. `list_run_ids()`

## Purpose

Discover existing run directories beneath:

```text
settings.runs_directory
```

## Missing root behavior

If:

```text
runs/
```

does not exist:

```text
[]
```

is returned.

No error is raised.

## Filtering

Only entries satisfying both:

```text
path.is_dir()
```

and:

```text
RUN_ID_PATTERN.fullmatch(path.name)
```

are returned.

Therefore unrelated files/directories with invalid run-style names are ignored.

## Return ordering

The result is:

```python
sorted(run_ids)
```

so ordering is **alphabetical/lexicographic**, not explicitly based on:

- creation time;
    
- modification time;
    
- manifest timestamp.
    

Generated IDs with identical prefixes naturally contain sortable timestamps, but the service itself promises only alphabetic sorting.

## Failure

Directory inspection `OSError` becomes:

```text
RunDirectoryError
RUN_DIRECTORY_LIST_FAILED
```

---

# 24. Project Dependencies

## `app.core.config.settings`

Used for:

```text
runs root
logs root
base-directory initialization
run path construction
```

This means Services consumes Core's application-wide path contract rather than redefining project-root locations.

## `app.core.exceptions.RunDirectoryError`

All domain-specific failures in this service use one dedicated Core exception type.

Examples include:

```text
EMPTY_RUN_ID_PREFIX
INVALID_RUN_ID_PREFIX
EMPTY_RUN_ID
INVALID_RUN_ID
UNKNOWN_RUN_SUBDIRECTORY
RUN_DIRECTORY_ALREADY_EXISTS
RUN_DIRECTORY_CREATION_FAILED
RUN_DIRECTORY_NOT_FOUND
RUN_PATH_IS_NOT_DIRECTORY
RUN_DIRECTORY_LIST_FAILED
```

---

# 25. Standard Library Dependencies

## `re`

Provides run-ID and prefix validation.

## `datetime`, `timezone`

Produce UTC timestamp sections for generated IDs.

## `uuid4`

Adds a random collision-resistant section.

## `pathlib.Path`

Represents and inspects filesystem locations.

No third-party package is used by this service.

---

# 26. Filesystem Ownership

This service owns the **structural run directory skeleton**.

Conceptually:

```text
Core config
    │
    ▼
project-wide roots
    │
    ▼
run_directory_service
    │
    ├── run ID
    ├── run root
    ├── standard subdirectories
    └── logging root
    │
    ▼
workflow / ML / file services
    │
    ▼
actual artifacts
```

This distinguishes:

```text
directory structure
```

from:

```text
file persistence
```

The latter belongs primarily to `file_service.py` and domain runners.

---

# 27. Relationship With `file_service.py`

The responsibility split is clear:

```text
run_directory_service.py
        ↓
decides:
runs/<run_id>/input/
runs/<run_id>/models/
etc.
        ↓
file_service.py
        ↓
copies / reads / writes files there
```

For example:

```text
run_directory_service
→ returns input directory

file_service
→ copy_input_file(..., input directory)
```

`run_directory_service.py` itself performs no input copying or CSV/JSON writing.

---

# 28. Relationship With Logging

This service defines:

```text
logs/<run_id>
```

as part of the run path bundle and creates that folder.

However, it explicitly does not configure logging handlers.

That belongs to:

```text
app/core/logging_config.py
```

Therefore:

```text
run_directory_service
→ establishes log directory

logging_config
→ creates logger handlers/log files
```

Both use the same Core settings path definitions.

---

# 29. Relationship With Manifest Service

Every run receives a reserved manifest path:

```text
runs/<run_id>/manifest.json
```

through:

```text
get_run_paths()
```

but the file is not created here.

Therefore the intended relationship is already visible:

```text
run_id
   ↓
runs/<run_id>/
   ↓
manifest.json path
   ↓
run_manifest_service
```

The exact manifest contents and lifecycle remain **UNKNOWN / NOT CONFIRMED** until `run_manifest_service.py` is analyzed.

---

# 30. Relationship With Parts A–E

The service does not know Part A–E implementations directly.

It only provides broad artifact areas such as:

```text
preprocessing/
models/
reports/
```

It does **not** define:

```text
Part A folder
Part B folder
Part C folder
Part D folder
Part E folder
KPI folder
site folder
```

Therefore deeper ML directory ownership belongs to workflow/runners or another layer.

This is an important boundary: the service defines the stable **top-level run storage contract**, not every downstream artifact location.

---

# 31. Run Directory Lifecycle

The complete implemented lifecycle is:

```text
new pipeline request
       │
       ▼
optional externally supplied run_id?
       │
    ┌──┴──┐
   yes    no
    │      │
validate  generate
    │      │
    └──┬──┘
       ▼
   final run_id
       │
       ▼
 get_run_paths()
       │
       ▼
runs/<run_id> exists?
       │
       ├── yes + exist_ok=False
       │          ↓
       │       failure
       │
       └── otherwise
                  ↓
        create base directories
                  ↓
        create run root
                  ↓
        create log root
                  ↓
        create standard subdirectories
                  ↓
        return run_id + paths
```

Later:

```text
validate_run_directory()
run_directory_exists()
list_run_ids()
```

allow existing run roots to be discovered or checked.

---

# 32. Run Reopen Capability

The code contains one limited reopen mechanism:

```text
create_run_directories(
    run_id=<existing>,
    exist_ok=True
)
```

This can restore missing standard folders beneath an existing run.

However there is no concept here of:

```text
resume from Part C
restore stage state
validate manifest status
prevent modification of completed run
```

Therefore:

```text
filesystem reopen = supported
workflow resume = NOT CONFIRMED
```

This distinction matters for later production workflow design.

---

# 33. Information Relevant to a Future Database / Run Registry

Without designing that system, this service already establishes several important fields.

## Run ID

There is one stable identifier:

```text
run_id
```

that is suitable for linking filesystem artifacts with a future database record.

## Run root

```text
runs/<run_id>
```

provides the primary filesystem reference.

## Log root

```text
logs/<run_id>
```

is separately available.

## Manifest path

```text
runs/<run_id>/manifest.json
```

is deterministic.

## Standard artifact locations

```text
input
preprocessing
models
reports
agents
temporary
```

are deterministically derivable from the run ID.

Therefore a future run registry does not need to rediscover paths by scanning arbitrary directory layouts; the current service already defines the main path contract.

---

# 34. Naming / Sanitization

## Run IDs

Strictly validated through `RUN_ID_PATTERN`.

## Directory keys

Normalized through:

```text
strip().lower()
```

and must belong to `RUN_SUBDIRECTORIES`.

## Subdirectory physical names

Hardcoded internally through the standard mapping.

There is no caller-provided stage-directory name in the current public API.

This reduces arbitrary directory creation through this service.

---

# 35. Potential Issues / Observations

## Important — directory creation is not transactional

The service creates multiple directories sequentially.

If an `OSError` occurs midway:

```text
some directories may already exist
```

and there is no rollback/cleanup.

A retry may therefore encounter a partially created run tree.

The structured error reports the failure but does not restore the prior filesystem state.

---

## Important — `exist_ok=True` is filesystem reuse, not workflow validation

An existing run can be reused without checking:

- manifest status;
    
- stage compatibility;
    
- ownership;
    
- existing artifact consistency.
    

This is not necessarily wrong; it simply means semantic resume protection belongs elsewhere.

---

## Important — dotted run IDs confirm a logger namespace edge case

`RUN_ID_PATTERN` explicitly permits periods inside run IDs.

Core logging cleanup identifies a run using logger prefix:

```text
telecom_anomaly_backend.<run_id>.
```

Therefore valid manually supplied IDs such as:

```text
abc
abc.xyz
```

can overlap as logger-name prefixes.

For example, cleanup for:

```text
abc
```

can theoretically match:

```text
telecom_anomaly_backend.abc.xyz.pipeline
```

belonging to run `abc.xyz`.

Generated IDs from `generate_run_id()` do not contain periods, so the issue primarily affects externally supplied custom run IDs.

Classification:

```text
Important cross-module edge case
```

---

## Important — generated IDs are highly unique but not mathematically guaranteed

The function uses time + an 8-character UUID fragment but does not check the filesystem during generation.

Collision protection ultimately depends on the later existing-directory check.

This is acceptable operationally but should not be interpreted as a formal global uniqueness guarantee.

---

## Minor — `validate_run_directory()` does not validate full structure

A root run directory can pass validation even when:

```text
input/
models/
manifest.json
etc.
```

are absent.

This function should therefore be understood exactly as a root existence/type check.

---

## Minor — `run_directory_exists()` can raise on malformed IDs

The name suggests a simple boolean query, but input validation occurs first.

Invalid run IDs raise `RunDirectoryError` rather than returning `False`.

---

## Minor — `list_run_ids()` sorts names, not run timestamps

It returns alphabetical ordering.

For default generated IDs with a common prefix, this generally corresponds well with timestamp ordering because the timestamp is embedded in the name.

Different prefixes can disrupt chronological interpretation.

---

## Minor — no deletion/cleanup lifecycle

The service can:

```text
create
validate
check
list
```

run directories.

It does not:

```text
delete
archive
purge temporary
expire old runs
```

Those operations are not part of the current implementation.

---

## No issue / intentional — manifest path exists before manifest file

`get_run_paths()` treats the manifest location as part of the standard contract without creating it.

This cleanly separates:

```text
where the manifest belongs
```

from:

```text
how the manifest is written
```

---

## No issue / intentional — logging is a separate directory tree

Logs are not stored under:

```text
runs/<run_id>
```

but use:

```text
logs/<run_id>
```

The same run ID links both areas.

This is an explicit current architecture rather than accidental duplication.

---

# 36. What Belongs Inside This Service

Based on current implementation:

```text
run-ID generation
run-ID validation
run path calculation
standard top-level run folder definitions
run directory creation
existing-run root validation
run existence checking
run discovery/listing
```

These are run-filesystem lifecycle responsibilities.

---

# 37. What Does NOT Belong Inside This Service

The source explicitly or structurally keeps out:

```text
file copying
CSV/JSON writing
manifest content/state
logging handler configuration
pipeline execution
ML processing
model serialization
report generation
database records
user metadata
workflow status transitions
```

This service decides **where run resources live**, not what the resources contain.

---

# 38. Complete Directory Contract

```text
PROJECT ROOT
│
├── runs/
│   │
│   └── <run_id>/
│       │
│       ├── manifest.json
│       │      path reserved only
│       │
│       ├── input/
│       │      caller-owned input persistence
│       │
│       ├── preprocessing/
│       │      downstream preprocessing artifacts
│       │
│       ├── models/
│       │      downstream model artifacts
│       │
│       ├── reports/
│       │      downstream reports
│       │
│       ├── agents/
│       │      downstream agent artifacts
│       │
│       └── temporary/
│              temporary workflow artifacts
│
└── logs/
    └── <run_id>/
           Core logging infrastructure
```

The meanings of the child folders are implied by naming; exact artifact schemas inside them are controlled by their consumers and are **not defined here**.

---

# 39. Compact File Contract

```text
FILE:
app/services/run_directory_service.py

RESPONSIBILITY:
Generate and validate run IDs and define/create the standard filesystem
structure belonging to each pipeline run.

PUBLIC INTERFACE:
RUN_SUBDIRECTORIES
RUN_ID_PATTERN
generate_run_id()
validate_run_id()
get_run_directory()
get_run_log_directory()
get_run_paths()
get_run_subdirectory()
create_run_directories()
validate_run_directory()
run_directory_exists()
list_run_ids()

INPUTS:
Optional run ID
Optional run-ID prefix
Standard directory key
exist_ok reuse policy

OUTPUTS:
Validated/generated run ID
Run and logging Path objects
Manifest path
Standard subdirectory paths
Structured run-path dictionary
Existing run-ID list

FILES/DIRECTORIES AFFECTED:
Creates:
runs/<run_id>/
runs/<run_id>/input/
runs/<run_id>/preprocessing/
runs/<run_id>/models/
runs/<run_id>/reports/
runs/<run_id>/agents/
runs/<run_id>/temporary/
logs/<run_id>/

Does NOT create:
manifest.json
input files
CSV/JSON datasets
models
reports
logs themselves

RUN ID BEHAVIOUR:
Generated default:
run_<UTC timestamp with microseconds>_<8-char UUID fragment>

Valid IDs:
1-128 chars
first character alphanumeric
remaining characters may contain letters, numbers, '.', '_', '-'

EXISTING RUN BEHAVIOUR:
Default creation rejects existing run roots.
exist_ok=True permits filesystem-level reuse and ensures standard
directories exist, but does not validate workflow-resume semantics.

ERRORS:
RunDirectoryError with structured codes including:
EMPTY_RUN_ID_PREFIX
INVALID_RUN_ID_PREFIX
EMPTY_RUN_ID
INVALID_RUN_ID
UNKNOWN_RUN_SUBDIRECTORY
RUN_DIRECTORY_ALREADY_EXISTS
RUN_DIRECTORY_CREATION_FAILED
RUN_DIRECTORY_NOT_FOUND
RUN_PATH_IS_NOT_DIRECTORY
RUN_DIRECTORY_LIST_FAILED

USED BY:
Expected workflow/pipeline orchestration, file persistence, manifest
management, logging setup, Parts A-E runners and later run-registry/API
layers requiring deterministic run paths.

ARCHITECTURAL ROLE:
Own the stable top-level run filesystem contract and shared run ID that
links artifacts, logs, manifests, and future run-registry information,
while leaving actual artifact persistence and workflow state to other
modules.
```

---

# Final Assessment

`run_directory_service.py` is the **filesystem identity and layout authority for a pipeline run**.

Its core architecture is:

```text
Pipeline request
      │
      ▼
generate / validate run_id
      │
      ▼
        run_id
      /        \
     ▼          ▼
runs/<id>/   logs/<id>/
     │
     ├── manifest path
     ├── input
     ├── preprocessing
     ├── models
     ├── reports
     ├── agents
     └── temporary
```

The most important architectural contract already established is:

```text
Run ID
   ↓
deterministic run root
   ↓
deterministic manifest path
   ↓
deterministic artifact subdirectories
```

That makes the run ID the natural common identifier connecting the workflow, filesystem, logging system, manifest and—later—the database/run registry.

The service itself remains deliberately narrow: it owns the **run's filesystem skeleton**, while `file_service.py` owns generic persistence mechanics and `run_manifest_service.py` is expected to own persisted run metadata/state.