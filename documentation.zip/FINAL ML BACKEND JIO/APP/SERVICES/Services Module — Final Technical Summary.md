# Services Module — Final Technical Summary

**Module Location:** `app/services/`

### Files

|File|Main Responsibility|
|---|---|
|`file_service.py`|Generic filesystem validation, metadata, copying, CSV/JSON reading and writing|
|`run_directory_service.py`|Run-ID generation/validation and standard run-directory lifecycle|
|`run_manifest_service.py`|Persistent run/stage state, outputs, errors, summaries, and event history|
|`__init__.py`|Stable public Services import surface|

## The three implementation files are internally consistent and their responsibilities are clearly separated. `__init__.py` confirms that these three services together form the intended shared Services API.

# 1. Purpose of `app/services`

`app/services` provides the backend's **shared operational support layer between Core infrastructure and the ML/workflow modules**.

Its current responsibilities can be summarized as:

```text
Run identity + directory structure
            +
Generic filesystem persistence
            +
Persistent run-state management
```

Conceptually:

```text
                   Workflow / API
                        │
                        ▼
                  app/services
                        │
          ┌─────────────┼─────────────┐
          ▼             ▼             ▼
    Run Directory      File        Manifest
      Service         Service       Service
          │             │             │
          └─────────────┼─────────────┘
                        ▼
                    Filesystem
```

The Services layer does **not** perform EDA, preprocessing, feature engineering, training, or inference itself.

## It provides the reusable filesystem and run-management infrastructure that those modules and their orchestrators use.

# 2. File Responsibility Map

## `file_service.py`

Owns:

```text
generic file validation
directory creation
filename sanitization
file metadata/checksums
input copying
CSV reading/writing
JSON reading/writing
filesystem error conversion
```

It answers:

> How should files be safely handled?

---

## `run_directory_service.py`

Owns:

```text
run ID generation
run ID validation
run path construction
standard run subdirectories
run directory creation
run existence checks
run listing
```

It answers:

> Where does a pipeline run live?

---

## `run_manifest_service.py`

Owns:

```text
manifest creation
run status
stage status
metrics
outputs
errors
summary
event history
persistent run-state updates
```

It answers:

> What is happening, or what happened, in this run?

---

## `__init__.py`

Re-exports the intended Services interface so callers can use:

```python
from app.services import ...
```

without depending directly on the physical implementation file containing each helper.

---

# 3. Internal Dependency Structure

The Services dependency direction is:

```text
            Core
             │
      config + exceptions
             │
             ▼
        file_service
             │
             ├───────────────┐
             │               │
             ▼               ▼
run_directory_service   run_manifest_service
      │                      ▲
      └──────────────────────┘
```

More precisely:

```text
file_service
→ depends on Core config + Core exceptions

run_directory_service
→ depends on Core config + RunDirectoryError

run_manifest_service
→ depends on Core exceptions
→ depends on file_service
→ depends on run_directory_service
```

## `run_manifest_service.py` is therefore the highest-level service of the three because it composes the lower-level filesystem and run-directory abstractions.

# 4. Public Services API

`__init__.py` exposes the following intended package-level interface.

## Run-directory services

```text
RUN_SUBDIRECTORIES

generate_run_id
validate_run_id

get_run_directory
get_run_log_directory
get_run_paths
get_run_subdirectory

create_run_directories
validate_run_directory
run_directory_exists
list_run_ids
```

---

## File services

```text
ensure_directory
sanitise_filename

validate_file_exists
validate_file_extension
validate_file_size
validate_input_file

calculate_file_sha256
get_file_metadata
copy_input_file

read_csv_file
write_csv_file

read_json_file
write_json_file
```

---

## Manifest services

```text
MANIFEST_FILENAME
MANIFEST_VERSION
VALID_RUN_STATUSES
VALID_STAGE_STATUSES

get_current_utc_timestamp
get_manifest_path

validate_run_status
validate_stage_status
validate_manifest_structure

append_manifest_event

create_run_manifest
load_run_manifest
save_run_manifest

set_run_status

start_pipeline_stage
complete_pipeline_stage
skip_pipeline_stage
fail_pipeline_stage

convert_exception_to_record

record_output_file
update_run_summary
```

Everything in this list is explicitly included in `__all__`.

---

# 5. File I/O Architecture

The file-service layer centralizes generic filesystem interaction.

```text
Higher backend component
          │
          ▼
      file_service
          │
          ├── normalize paths
          ├── validate files
          ├── create directories
          ├── sanitize filenames
          ├── read/write CSV
          ├── read/write JSON
          ├── copy files
          └── translate low-level errors
          │
          ▼
      Filesystem / Pandas
```

This prevents individual ML modules from independently implementing slightly different file-handling rules.

---

# 6. File Validation Contract

The generic validation chain is:

```text
validate_input_file()
        │
        ├── validate_file_exists()
        │
        ├── validate_file_extension()
        │
        └── validate_file_size()
```

A successfully validated input file therefore:

- exists;
    
- is a regular file;
    
- uses an allowed extension;
    
- is non-empty;
    
- does not exceed the configured maximum size.
    

Global defaults come from Core:

```text
allowed_input_extensions
max_input_file_size_bytes
default_file_encoding
```

---

# 7. Filename Handling

`sanitise_filename()`:

```text
removes path components
replaces unsafe characters
trims leading/trailing periods/spaces
rejects empty or invalid names
```

Unsafe characters include common filesystem-reserved characters such as:

```text
< > : " / \ | ? *
```

and control characters.

It is a safety mechanism, not a uniqueness mechanism.

Two different supplied filenames can theoretically sanitize to the same output name.

---

# 8. CSV Contract

## Reading

```text
read_csv_file()
```

uses:

```text
validate_input_file()
+
pd.read_csv()
```

and applies the configured default encoding unless the caller overrides it.

It translates common Pandas/Python failures into:

```text
InputValidationError
FileProcessingError
```

with structured error codes.

---

## Writing

```text
write_csv_file()
```

requires a `.csv` destination and:

- creates missing parent directories;
    
- defaults to `index=False`;
    
- defaults to `overwrite=True`;
    
- uses configured file encoding.
    

CSV writes go directly to the final destination.

They do **not** use atomic temporary-file replacement.

---

# 9. JSON Contract

## Reading

```text
read_json_file()
```

requires:

```text
existing regular file
.json extension
```

and uses the configured encoding.

Unlike CSV input reading, it does not enforce the global file-size limit.

---

## Writing

```text
write_json_file()
```

uses:

```text
temporary file
      ↓
json.dump()
      ↓
replace destination
```

The temporary filename contains a random UUID fragment and lives in the same destination directory.

This reduces the risk of leaving a partially written JSON file.

This is especially important because the manifest service relies on JSON persistence.

---

# 10. Atomicity

Current persistence guarantees differ:

|Operation|Atomic replacement|
|---|---|
|Input copy|No explicit atomic strategy|
|CSV write|No|
|JSON write|Yes, temp file + replace|
|Manifest save|Yes indirectly through JSON writer|

## Therefore the strongest persistence guarantees are currently applied to state-oriented JSON files rather than large generated CSV datasets.

# 11. File Metadata and Provenance

The Services module can record:

```text
file_name
file_path
extension
size_bytes
size_mb
modified_at_utc
```

and optionally:

```text
sha256
```

through:

```text
get_file_metadata()
```

SHA-256 is calculated incrementally in memory-safe chunks.

This creates a useful provenance contract for:

```text
input files
generated outputs
run manifests
future run registry/database
```

---

# 12. Run-ID Lifecycle

`run_directory_service.py` is the authority for standard run IDs.

If no ID is supplied:

```text
generate_run_id()
```

creates:

```text
<prefix>_<UTC timestamp>_<8-char UUID fragment>
```

Default form:

```text
run_YYYYMMDDTHHMMSSffffffZ_<uuid8>
```

This combines:

- readable UTC creation time;
    
- microsecond precision;
    
- random UUID component.
    

---

# 13. Run-ID Validation

The run-ID pattern is:

```text
^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$
```

Therefore:

- length is 1–128;
    
- first character is alphanumeric;
    
- remaining characters may use:
    
    - letters;
        
    - digits;
        
    - `_`;
        
    - `-`;
        
    - `.`.
        

Run IDs are stripped before validation.

Invalid IDs raise:

```text
RunDirectoryError
```

rather than being silently modified.

---

# 14. Standard Run Directory Tree

Every normal run receives:

```text
<project_root>/
│
├── runs/
│   └── <run_id>/
│       ├── manifest.json
│       ├── input/
│       ├── preprocessing/
│       ├── models/
│       ├── reports/
│       ├── agents/
│       └── temporary/
│
└── logs/
    └── <run_id>/
```

Important distinction:

```text
manifest.json
```

has a deterministic reserved path, but is created by the manifest service rather than the directory service.

---

# 15. Run Directory Path Bundle

`get_run_paths()` returns:

```text
run
logs
manifest
input
preprocessing
models
reports
agents
temporary
```

for a validated `run_id`.

This provides a common path dictionary to higher workflow layers and eliminates the need for callers to reconstruct the folder contract manually.

---

# 16. Run Directory Creation

`create_run_directories()`:

```text
generate/validate run ID
        ↓
calculate path bundle
        ↓
check existing run
        ↓
create Core base directories
        ↓
create run root
        ↓
create logging root
        ↓
create standard subdirectories
```

Default:

```text
exist_ok=False
```

so a new run normally cannot overwrite/reuse an existing run root accidentally.

---

# 17. Existing Run / Reopen Behaviour

If:

```text
exist_ok=True
```

the service permits an existing run root to be reused and ensures the standard directories exist.

This means the filesystem layer technically supports reopening a run.

However this does **not** mean workflow resume is validated.

The function does not check:

```text
manifest status
completed/failed state
stage compatibility
existing artifacts
ownership/user identity
```

Therefore:

```text
filesystem reuse
≠
validated workflow resume
```

---

# 18. Existing Run Inspection

The Services module provides:

```text
validate_run_directory()
run_directory_exists()
list_run_ids()
```

These allow higher layers to:

- validate a known run;
    
- check existence;
    
- discover existing run directory names.
    

`list_run_ids()` returns valid run-style directory names sorted lexicographically.

---

# 19. Manifest Lifecycle

Each run's manifest begins with:

```text
create_run_manifest()
```

and then acts as the mutable persistent state document for that run.

Normal lifecycle:

```text
run directories created
        ↓
create_run_manifest()
        ↓
status = created
        ↓
queued        optional
        ↓
running
        ↓
stages execute
        ↓
outputs/errors/metrics recorded
        ↓
summary updated
        ↓
completed / failed / cancelled
```

---

# 20. Complete Manifest Shape

The initial manifest contains:

```text
manifest_version

run_id
run_directory

status

created_at_utc
updated_at_utc
started_at_utc
completed_at_utc

input

request
  ├── requested_models
  └── options

stages

outputs

errors

summary

events
```

This gives the current filesystem backend a rich persistent run record.

---

# 21. Run Status Lifecycle

Valid run states:

```text
created
queued
running
completed
failed
cancelled
```

When a run first reaches:

```text
running
```

the service records:

```text
started_at_utc
```

When it reaches:

```text
completed
failed
cancelled
```

it records:

```text
completed_at_utc
```

The service validates state names but does **not enforce a strict transition graph**.

---

# 22. Stage State Lifecycle

Valid stage statuses:

```text
pending
running
completed
failed
skipped
```

The main operations are:

```text
start_pipeline_stage()
complete_pipeline_stage()
skip_pipeline_stage()
fail_pipeline_stage()
```

A standard stage record contains:

```text
status
started_at_utc
completed_at_utc
metadata
metrics
outputs
error
```

---

# 23. Stage Start

`start_pipeline_stage()`:

- rejects empty stage names;
    
- marks stage `running`;
    
- records its first start timestamp;
    
- preserves existing metrics/outputs;
    
- merges metadata;
    
- clears previous error;
    
- appends a `stage_started` event.
    

An existing stage can therefore be restarted/reopened because strict transition rules are not enforced here.

---

# 24. Stage Completion

`complete_pipeline_stage()`:

- requires the stage to already exist;
    
- marks it `completed`;
    
- sets completion timestamp;
    
- merges new metrics;
    
- clears error;
    
- records a `stage_completed` event.
    

It does not require the prior stage status to be `running`.

---

# 25. Stage Skip

`skip_pipeline_stage()` creates/replaces the stage record with:

```text
status = skipped
started_at_utc = None
completed_at_utc = now
skip reason
empty metrics
empty outputs
no error
```

This is important because if the stage previously contained information, this operation replaces that stage record rather than merging it.

---

# 26. Stage Failure

`fail_pipeline_stage()` records:

```text
stage status = failed
completion timestamp
preserved metadata
preserved metrics
preserved outputs
structured error
```

and appends the same error to the global run error history.

Default:

```text
fail_run=True
```

so stage failure normally also changes the overall run status to:

```text
failed
```

but the caller can prevent this when a stage/model failure is non-fatal.

---

# 27. Error Persistence

The Services module integrates directly with Core's exception hierarchy.

For a:

```text
TelecomBackendError
```

it preserves:

```text
error_type
message
error_code
details
```

Unknown Python exceptions become:

```text
error_type = class name
message = str(error)
error_code = None
details = {}
```

This allows manifest persistence to handle both expected and unexpected failures with one common structure.

---

# 28. Error Storage

Errors are stored at two levels.

## Stage-level

```text
stages[stage_name]["error"]
```

represents the current failure associated with that stage.

## Run-level history

```text
errors[]
```

stores timestamped historical failures across the run.

This allows both:

```text
what failed in this stage?
```

and:

```text
what errors occurred during this entire run?
```

to be answered from one manifest.

---

# 29. Output Lifecycle

`record_output_file()`:

1. loads the manifest;
    
2. extracts actual filesystem metadata;
    
3. records:
    
    - stage;
        
    - output type;
        
    - recording timestamp;
        
    - filename;
        
    - path;
        
    - extension;
        
    - size;
        
    - modification time;
        
    - optional checksum;
        
4. adds the output to the global run list;
    
5. adds it to the stage if that stage exists;
    
6. records an event;
    
7. saves the manifest.
    

---

# 30. Output Deduplication

Outputs are deduplicated by:

```text
file_path
```

rather than:

- checksum;
    
- output type;
    
- stage;
    
- filename.
    

Therefore the same absolute path appears only once in each applicable output list.

However, if the file contents later change at the same path, re-recording does not refresh the old metadata entry.

This is an important actual behavior.

---

# 31. Summary Lifecycle

`update_run_summary()` merges caller-supplied values into:

```text
manifest["summary"]
```

Existing unrelated fields remain.

Matching keys are replaced by newer values.

The manifest service deliberately treats summary structure as generic and does not understand ML-specific semantics.

---

# 32. Event History

Current event types created by this implementation are:

```text
run_created
run_status_changed

stage_started
stage_completed
stage_skipped
stage_failed

output_recorded

summary_updated
```

Each event stores:

```text
timestamp_utc
event_type
message
details
```

The manifest therefore contains both:

```text
current snapshot
+
chronological event history
```

---

# 33. Directory / Manifest Relationship

The Services module establishes a strong separation:

```text
run_directory_service
      │
      ▼
runs/<run_id>/
      │
      ├── standard folders
      └── manifest path
              │
              ▼
run_manifest_service
      │
      ▼
manifest state
```

The directory service owns:

```text
location
structure
run identity
```

The manifest service owns:

```text
state
history
metadata
results
```

---

# 34. File Service / Manifest Relationship

`run_manifest_service.py` deliberately delegates generic file operations to `file_service.py`.

It uses:

```text
get_file_metadata()
read_json_file()
write_json_file()
```

Therefore:

```text
Manifest Service
→ understands what manifest data means

File Service
→ understands how JSON/filesystem persistence works
```

## This is a clean layering boundary.

# 35. Logging Relationship

The Services module determines:

```text
logs/<run_id>/
```

through the run-directory service.

But Services does not configure Python log handlers.

Core logging owns:

```text
logger creation
component log files
console handlers
cleanup
```

Therefore:

```text
run_directory_service
→ where the logging directory is

core.logging_config
→ how runtime logs are produced there
```

---

# 36. Interaction With Parts A–E

Services sits below or beside the workflow/runners.

The intended interaction is approximately:

```text
Workflow
   │
   ├── create_run_directories()
   │
   ├── create_run_manifest()
   │
   ├── copy_input_file()
   │
   ▼
Part A / B / C / D / E runner
   │
   ├── start_pipeline_stage()
   │
   ├── file_service reads/writes artifacts
   │
   ├── record_output_file()
   │
   ├── complete_pipeline_stage()
   │
   └── fail_pipeline_stage() on error
   │
   ▼
Final manifest + filesystem outputs
```

The exact orchestrator sequence and stage names are not defined by these Services files themselves.

## Therefore exact workflow usage remains **UNKNOWN / NOT CONFIRMED** where not already documented by the individual ML modules.

# 37. Services as a Current Filesystem-Backed Run Registry

Together, these files already form a primitive run-management system.

```text
run ID
   │
   ├── runs/<run_id>
   ├── logs/<run_id>
   └── manifest.json
          │
          ├── status
          ├── timestamps
          ├── input
          ├── request options
          ├── stages
          ├── metrics
          ├── outputs
          ├── errors
          ├── summary
          └── events
```

This is enough to inspect one run in significant detail without a database.

The manifest therefore acts as the current **per-run filesystem-backed state record**.

---

# 38. Interaction With a Future Database / Workflow Layer

Without designing that layer, the current Services implementation already establishes important integration facts.

## Stable shared identifier

```text
run_id
```

can link:

```text
database record
run directory
log directory
manifest
```

## Deterministic paths

From a run ID, the backend can derive:

```text
runs/<run_id>
logs/<run_id>
runs/<run_id>/manifest.json
```

## Existing metadata suitable for indexing

The manifest already contains:

```text
status
timestamps
input provenance
models/options
stage status
outputs
errors
summary
```

A future database could therefore act as a central searchable registry while the current files remain the detailed artifact/state locations.

## The Services module itself does not implement that database.

# 39. What Belongs Inside Services

Based strictly on the current implementation, Services owns reusable backend operations such as:

```text
generic file persistence
generic file validation
generic directory creation
run-ID lifecycle
run filesystem structure
run existence/listing
manifest persistence
run state
stage state
error recording
output registration
run summary
event history
```

The common characteristic is:

> reusable backend support behavior that is more operational than Core, but not ML/domain processing itself.

---

# 40. What Does NOT Belong Inside Services

The following remain outside this module:

```text
application-wide settings definitions
global exception definitions
logger handler implementation

Part A EDA
Part B preprocessing
Part C feature engineering
Part D training
Part E inference

model algorithms
schema validation rules
workflow orchestration policy
HTTP route behavior
database implementation
UI logic
email/agent execution logic itself
```

Services can support these layers but should not absorb their domain responsibilities based on the current architecture.

---

# 41. Sanity Check Findings

The three individual reports are **consistent with the actual code and with each other**.

No major contradiction exists.

The responsibility split is coherent:

```text
file_service
→ file mechanics

run_directory_service
→ run location

run_manifest_service
→ run state
```

`__init__.py` reinforces this exact grouping through the public package exports.

The previously identified caveats remain valid and should be retained as architectural observations rather than treated as contradictions.

---

# 42. Important Issues / Open Observations

## Important — manifest updates have no concurrency control

The normal pattern is:

```text
load
modify
save
```

Atomic JSON replacement prevents a partially written manifest but does not prevent two workers from overwriting each other's updates.

There is no:

```text
file locking
version counter
transaction
compare-and-swap
```

in the current implementation.

---

## Important — run state transitions are not enforced

The manifest validates allowed status values but does not prevent transitions such as:

```text
completed → running
failed → queued
cancelled → created
```

Workflow semantics must therefore be enforced by the orchestrating layer.

---

## Important — stage state transitions are also permissive

Stages can:

- restart;
    
- complete without having been `running`;
    
- fail without prior registration;
    
- be replaced with a skipped record.
    

Again, the service stores state but does not implement a strict state machine.

---

## Important — `save_run_manifest()` returns state with a timestamp nuance

The persisted manifest gets a new:

```text
updated_at_utc
```

but the original dictionary passed to `save_run_manifest()` is not mutated because the function saves a copied dictionary.

Functions that save and then return their in-memory manifest may therefore return a slightly older `updated_at_utc` than the value actually written to disk.

Reloading the manifest returns the persisted value.

---

## Important — manifest structural validation is minimum-only

The service validates only essential top-level structure.

It does not fully validate:

```text
nested stage records
output records
error records
event records
request shape
summary shape
timestamp formats
manifest-version compatibility
```

This is flexible but means the manifest is not currently backed by a strict formal schema.

---

## Important — canonical run-directory matching is strongest during creation

`create_run_manifest()` verifies:

```text
run_directory == runs/<run_id>
```

but later read/update helpers operate directly on caller-supplied run-directory paths.

They do not repeatedly re-confirm the path against the manifest's own `run_id`.

---

## Important — directory creation is not transactional

If run-directory creation fails partway through, some directories may already have been created.

No automatic rollback exists.

---

## Important — `exist_ok=True` does not validate workflow resume

It permits filesystem-level reuse only.

It should not be interpreted as proof that resuming an interrupted ML pipeline is safe.

---

## Important — CSV writes are not atomic

CSV output writes directly to the final destination.

JSON/manifest persistence has stronger atomic replacement behavior.

---

## Important — output metadata is not refreshed when a path is reused

Manifest output deduplication uses only:

```text
file_path
```

If a file changes at that same location, the previous stored metadata/checksum is retained rather than replaced.

---

## Important cross-module edge case — periods in custom run IDs

The Services run-ID contract allows periods.

Core logging cleanup uses a logger-name prefix based on `run_id`.

Therefore custom IDs such as:

```text
abc
abc.xyz
```

can theoretically overlap in logger-prefix matching.

Generated run IDs do not contain periods, so this mainly affects manually supplied IDs.

---

## Minor — JSON reads do not enforce global maximum input size

This differs from CSV input reading.

This may be intentional because JSON is likely used primarily for backend metadata such as manifests.

---

## Minor — `pending` stage status currently has no dedicated creation helper

It is allowed but no provided lifecycle function automatically creates pending stage entries.

---

## Minor — run listing is lexicographic

`list_run_ids()` does not explicitly sort by manifest or filesystem creation timestamp.

---

## No issue / intentional — package exports are broad

Unlike Core, where low-level logging handler helpers were intentionally hidden, Services `__init__.py` exposes most reusable helpers from all three service files.

This confirms that granular file/run/manifest operations are intended to be reusable across workflows and modules.

---

# 43. Complete Services Architecture

```text
                         APPLICATION / API
                               │
                               ▼
                          WORKFLOW LAYER
                               │
             ┌─────────────────┼─────────────────┐
             │                 │                 │
             ▼                 ▼                 ▼
  run_directory_service   file_service   run_manifest_service
             │                 │                 │
             │                 │                 │
      run identity          generic         persistent
      + paths               file I/O         run state
             │                 │                 │
             └─────────────────┼─────────────────┘
                               ▼
                           FILESYSTEM
                               │
               ┌───────────────┼───────────────┐
               ▼               ▼               ▼
          runs/<id>/       logs/<id>/     manifest.json
               │
               ├── input
               ├── preprocessing
               ├── models
               ├── reports
               ├── agents
               └── temporary
```

---

# 44. Compact Services Contract

```text
SERVICES PURPOSE:
Provide reusable filesystem, run-directory, and persistent run-state
infrastructure to workflows, API routes, and Parts A-E.

FILE SERVICE PROVIDES:
Directory creation
Filename sanitization
File existence/type checks
Extension validation
Size validation
General input validation
SHA-256 checksum generation
File metadata
Input copying
CSV read/write
JSON read/write
Atomic JSON replacement

RUN DIRECTORY SERVICE PROVIDES:
Run-ID generation
Run-ID validation
Run root calculation
Log root calculation
Standard run path bundle
Standard run subdirectories
Run-directory creation
Existing-run validation
Run existence checking
Run listing

MANIFEST SERVICE PROVIDES:
Manifest creation/loading/saving
Run status
Run timestamps
Input provenance
Requested models/options
Stage states
Stage metadata
Stage metrics
Stage outputs
Run-level outputs
Structured errors
Run summary
Event history

RUN ID BEHAVIOUR:
Default generated form:
run_<UTC timestamp with microseconds>_<8-character UUID fragment>

Valid IDs:
1-128 characters
first character alphanumeric
remaining characters may contain letters, numbers, '.', '_', '-'

RUN ID IS USED TO LINK:
runs/<run_id>/
logs/<run_id>/
runs/<run_id>/manifest.json

FILESYSTEM CONTRACT:
runs/<run_id>/
├── manifest.json
├── input/
├── preprocessing/
├── models/
├── reports/
├── agents/
└── temporary/

logs/<run_id>/

MANIFEST CONTRACT:
Per-run filesystem-backed persistent state document containing:
run identity
run status
timestamps
input metadata
request options
stage states
metrics
outputs
errors
summary
events

EXPECTED CALLERS:
Workflow/pipeline orchestrator
API routes
Parts A-E
model runners
preprocessing modules
reporting components
future UI/MCP layer
future database/run-registry synchronization

IMPORTANT ARCHITECTURAL INFORMATION:
Services owns reusable operational support, not ML logic.
The run-directory service decides WHERE the run lives.
The file service decides HOW generic files are handled.
The manifest service records WHAT is happening in the run.

The manifest currently serves as a lightweight per-run state registry.
It is atomic at the individual JSON-write level but not concurrency-safe.
Workflow/state-transition policy remains outside Services.
```

---

# Final Assessment

The Services module is structurally sound and the three individual reports can be treated as final.

Its central architectural separation is:

```text
run_directory_service.py
        ↓
WHERE does this run live?

file_service.py
        ↓
HOW are files safely handled?

run_manifest_service.py
        ↓
WHAT is the state/history of this run?

__init__.py
        ↓
Expose all three through one stable Services API
```

Together, Services provides the backend with a coherent **filesystem-backed execution infrastructure**:

```text
run_id
  │
  ├── deterministic directory structure
  ├── deterministic log location
  ├── copied/generated artifacts
  └── manifest.json
         ├── status
         ├── stages
         ├── metrics
         ├── outputs
         ├── errors
         ├── summary
         └── events
```

This module therefore forms the operational bridge between **Core infrastructure** and the **Parts A–E/workflow layer**, while remaining clearly separated from the ML algorithms and future centralized database/API/UI responsibilities.