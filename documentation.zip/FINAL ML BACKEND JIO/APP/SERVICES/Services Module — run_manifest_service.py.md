# Services Module — `run_manifest_service.py` Final Technical Report

**File:** `app/services/run_manifest_service.py`  
**Role:** Persistent run-state, stage-state, output, error, summary, and event-history management through `manifest.json`.

---

# 1. File Purpose

`run_manifest_service.py` manages the **persistent operational record of a pipeline run**.

Each run uses:

```text
runs/<run_id>/manifest.json
```

to record:

- run identity;
    
- overall run status;
    
- input-file metadata;
    
- requested models;
    
- request options;
    
- stage state;
    
- stage metrics;
    
- generated outputs;
    
- errors;
    
- summary information;
    
- timestamps;
    
- event history.
    

The source explicitly identifies the manifest as something the:

```text
API
UI
MCP layer
pipeline orchestrator
```

can inspect to understand both the current state and final result of a run.

This makes the manifest substantially more than a simple metadata file: it is the current filesystem-backed **run state record**.

---

# 2. Public Constants / Functions

|Name|Purpose|
|---|---|
|`MANIFEST_FILENAME`|Standard manifest filename: `manifest.json`|
|`MANIFEST_VERSION`|Current manifest schema version: `"1.0"`|
|`VALID_RUN_STATUSES`|Allowed overall run states|
|`VALID_STAGE_STATUSES`|Allowed stage states|
|`get_current_utc_timestamp()`|Generate UTC ISO timestamp|
|`get_manifest_path()`|Resolve manifest path|
|`validate_run_status()`|Validate run state|
|`validate_stage_status()`|Validate stage state|
|`validate_manifest_structure()`|Validate minimum manifest structure|
|`append_manifest_event()`|Add event-history record|
|`create_run_manifest()`|Create initial run manifest|
|`load_run_manifest()`|Read and validate existing manifest|
|`save_run_manifest()`|Validate and atomically persist manifest|
|`set_run_status()`|Change overall run state|
|`start_pipeline_stage()`|Mark stage running|
|`complete_pipeline_stage()`|Mark stage completed|
|`skip_pipeline_stage()`|Mark stage skipped|
|`convert_exception_to_record()`|Convert exception to persistent structure|
|`fail_pipeline_stage()`|Mark stage/run failed|
|`record_output_file()`|Register generated artifact|
|`update_run_summary()`|Merge run-summary information|

---

# 3. Manifest Version and File Location

Current constants:

```text
MANIFEST_FILENAME = "manifest.json"
MANIFEST_VERSION  = "1.0"
```

The normal location is:

```text
runs/<run_id>/manifest.json
```

The run-directory service already reserves the same location in its path contract.

Therefore:

```text
run_directory_service
        ↓
defines manifest path

run_manifest_service
        ↓
creates / reads / updates manifest contents
```

---

# 4. Complete Initial Manifest Structure

`create_run_manifest()` creates:

```text
{
    "manifest_version": "1.0",

    "run_id": <run_id>,
    "run_directory": <absolute run path>,

    "status": "created",

    "created_at_utc": <timestamp>,
    "updated_at_utc": <timestamp>,
    "started_at_utc": null,
    "completed_at_utc": null,

    "input": <file metadata or null>,

    "request": {
        "requested_models": [...],
        "options": {...}
    },

    "stages": {},

    "outputs": [],

    "errors": [],

    "summary": {},

    "events": [...]
}
```

---

# 5. Manifest Responsibility Map

```text
manifest.json
│
├── identity
│   ├── manifest_version
│   ├── run_id
│   └── run_directory
│
├── run lifecycle
│   ├── status
│   ├── created_at_utc
│   ├── updated_at_utc
│   ├── started_at_utc
│   └── completed_at_utc
│
├── request provenance
│   ├── input
│   └── request
│
├── pipeline lifecycle
│   └── stages
│
├── artifacts
│   └── outputs
│
├── failures
│   └── errors
│
├── final/run-level information
│   └── summary
│
└── audit/history
    └── events
```

This is the core persisted state contract for a pipeline run.

---

# 6. Run Status Contract

Allowed overall run statuses are:

```text
created
queued
running
completed
failed
cancelled
```

`validate_run_status()`:

```text
strip()
↓
lower()
↓
membership validation
```

and returns the normalized value.

Unsupported values raise:

```text
RunManifestError
INVALID_RUN_STATUS
```

with the allowed values recorded in `details`.

---

# 7. Stage Status Contract

Allowed stage states are:

```text
pending
running
completed
failed
skipped
```

`validate_stage_status()` normalizes and validates the same way.

Invalid status raises:

```text
RunManifestError
INVALID_STAGE_STATUS
```

### Important observation

The validator exists, but the normal stage lifecycle functions directly assign known status constants.

`validate_manifest_structure()` also does **not validate every existing stage's status**.

Therefore `VALID_STAGE_STATUSES` defines the intended contract, but arbitrary externally modified stage records are not comprehensively checked when a manifest is loaded.

Classification:

**Important observation.**

---

# 8. `get_current_utc_timestamp()`

Returns:

```text
datetime.now(timezone.utc).isoformat()
```

Therefore stored timestamps are:

- timezone-aware;
    
- UTC;
    
- ISO 8601 strings.
    

No separate timestamp model is used.

---

# 9. `get_manifest_path()`

## Purpose

Construct:

```text
<run_directory>/manifest.json
```

## Input

```text
str | Path
```

## Processing

```text
Path
→ expanduser()
→ resolve()
→ append MANIFEST_FILENAME
```

## Side effects

None.

The directory does not need to exist simply to calculate the path.

---

# 10. `validate_manifest_structure()`

## Purpose

Validate the **minimum required structure** needed by this service.

Required top-level fields:

```text
manifest_version
run_id
status
created_at_utc
updated_at_utc
stages
outputs
errors
events
```

Missing fields produce:

```text
RunManifestError
INVALID_MANIFEST_STRUCTURE
```

## Type checks

Explicitly validates:

```text
run_id   → str
stages   → dict
outputs  → list
errors   → list
events   → list
```

and validates the overall run status.

---

# 11. What Structural Validation Does NOT Enforce

The validator does not currently verify:

```text
manifest_version == "1.0"
run_id follows run-directory RUN_ID_PATTERN
timestamps are valid ISO-8601 values
run_directory exists
run_directory matches run_id
request structure
input structure
summary type
individual output-record structure
individual error-record structure
individual event-record structure
individual stage-record structure
individual stage status values
```

Fields such as:

```text
run_directory
input
request
summary
started_at_utc
completed_at_utc
```

are part of the created manifest but are not included in the minimum required-field set.

Therefore this is intentionally a **minimum structural validator**, not a complete schema validator.

---

# 12. `append_manifest_event()`

## Purpose

Add an audit-style event to the in-memory manifest.

## Event structure

```text
{
    "timestamp_utc": ...,
    "event_type": ...,
    "message": ...,
    "details": {...}
}
```

## Inputs

```text
manifest
event_type
message
details=None
```

## Behavior

Uses:

```python
manifest.setdefault("events", []).append(event)
```

and therefore modifies the supplied dictionary **in place**.

## Side effects

In-memory mutation only.

Persistence occurs only when the caller subsequently invokes `save_run_manifest()`.

---

# 13. `create_run_manifest()`

## Purpose

Create the initial persistent manifest for a new pipeline run.

## Inputs

```text
run_directory
run_id
input_file=None
requested_models=None
request_options=None
overwrite=False
```

---

# 14. Run ID / Directory Consistency

Creation performs an important integrity check.

First:

```text
validate_run_id(run_id)
```

Then:

```text
validate_run_directory(run_id)
```

determines the canonical expected run root.

The supplied `run_directory` is separately resolved.

The two must be identical.

Otherwise:

```text
RunManifestError
RUN_DIRECTORY_MISMATCH
```

is raised.

This prevents creating a manifest such as:

```text
run_id = run_A
directory = runs/run_B/
```

through the normal creation function.

---

# 15. Existing Manifest Behaviour

Default:

```text
overwrite=False
```

If:

```text
manifest.json
```

already exists:

```text
RunManifestError
MANIFEST_ALREADY_EXISTS
```

is raised.

If:

```text
overwrite=True
```

the existing manifest can be replaced with a newly initialized manifest.

This is a **full manifest replacement**, not a merge with the previous state.

---

# 16. Input File Metadata

If an input file is supplied:

```text
get_file_metadata(
    include_checksum=True
)
```

is called.

Therefore the initial manifest records:

```text
file_name
file_path
extension
size_bytes
size_mb
modified_at_utc
sha256
```

for the original input.

This gives the run strong file provenance because SHA-256 identifies exact input content.

---

# 17. Requested Models and Options

Creation stores:

```text
"request": {
    "requested_models": list(requested_models or []),
    "options": dict(request_options or {})
}
```

Therefore the manifest retains the caller's requested execution configuration at the run level.

Exact schemas for `requested_models` and `options` are not enforced here.

They remain generic lists/dictionaries.

---

# 18. Initial Manifest Event

Immediately after initialization:

```text
event_type = "run_created"
```

is appended.

Therefore a newly created manifest already begins with an event-history entry.

Then:

```text
save_run_manifest()
```

persists it.

---

# 19. `load_run_manifest()`

## Purpose

Read a stored manifest and validate its minimum structure.

## Processing

```text
run_directory
      ↓
get_manifest_path()
      ↓
manifest exists?
      ↓
read_json_file()
      ↓
must decode to dict
      ↓
validate_manifest_structure()
      ↓
return dict
```

---

# 20. Missing Manifest

If the file is absent:

```text
RunManifestError
MANIFEST_NOT_FOUND
```

is raised.

---

# 21. JSON Read Failure Conversion

Errors from `file_service`:

```text
FileProcessingError
InputValidationError
```

are converted to:

```text
RunManifestError
MANIFEST_READ_FAILED
```

with the underlying error message retained in `details`.

The original exception is chained.

This means callers of the manifest service normally deal with the manifest-specific exception category instead of low-level JSON errors.

---

# 22. Invalid Manifest Root Type

The JSON root must be a dictionary.

For example, a valid JSON file containing:

```json
[]
```

produces:

```text
RunManifestError
INVALID_MANIFEST_TYPE
```

with the received Python type included.

---

# 23. `save_run_manifest()`

## Purpose

Validate and persist manifest state.

## Processing

```text
Mapping
  ↓
dict(...)
  ↓
validate_manifest_structure()
  ↓
set updated_at_utc = now
  ↓
get manifest path
  ↓
write_json_file(overwrite=True)
```

The file-service JSON writer uses temporary-file replacement, so manifest persistence uses the backend's stronger atomic JSON write path.

---

# 24. Manifest Save Error Conversion

The following lower-level service failures:

```text
FileProcessingError
InputValidationError
```

are converted into:

```text
RunManifestError
MANIFEST_WRITE_FAILED
```

with:

```text
manifest_path
original_error
```

stored in details.

---

# 25. Important `updated_at_utc` Behaviour

`save_run_manifest()` does:

```python
manifest_dictionary = dict(manifest)
```

and then changes:

```text
manifest_dictionary["updated_at_utc"]
```

—not the original dictionary supplied by the caller.

Therefore:

```text
manifest passed to save
      ↓
shallow copy
      ↓
copy gets new updated_at_utc
      ↓
copy written to disk
```

The original in-memory manifest is not updated with the newly generated save timestamp.

This means functions such as:

```text
set_run_status()
start_pipeline_stage()
complete_pipeline_stage()
...
```

save a newer `updated_at_utc` value to disk but then return the older in-memory dictionary.

A subsequent reload will show the correct newer persisted timestamp.

Classification:

**Important behavioral inconsistency.**

---

# 26. `set_run_status()`

## Purpose

Change overall pipeline-run status.

## Processing

```text
validate new status
      ↓
load manifest
      ↓
remember previous status
      ↓
set new status
      ↓
manage lifecycle timestamps
      ↓
append run_status_changed event
      ↓
save
```

---

# 27. Run Timing Behaviour

### First transition to `running`

If:

```text
started_at_utc is None
```

then the first transition to:

```text
running
```

sets:

```text
started_at_utc
```

Subsequent transitions back to running preserve the first start time.

### Terminal states

These states:

```text
completed
failed
cancelled
```

set:

```text
completed_at_utc
```

to the current timestamp.

---

# 28. No Enforced Run-State Transition Graph

The service validates whether a status name is allowed but not whether the **transition** is logically permitted.

For example, the code does not prevent:

```text
completed → running
failed → queued
cancelled → created
```

Likewise, transitioning away from a terminal state does not automatically clear:

```text
completed_at_utc
```

Therefore:

```text
status validity
```

is enforced, but:

```text
state-machine validity
```

is not.

Classification:

**Important architectural observation.**

---

# 29. Stage Record Structure

A normal started stage has:

```text
{
    "status": "running",
    "started_at_utc": ...,
    "completed_at_utc": null,
    "metadata": {...},
    "metrics": {...},
    "outputs": [...],
    "error": null
}
```

This is the effective stage-state contract used by the lifecycle functions.

---

# 30. `start_pipeline_stage()`

## Purpose

Create or mark a pipeline stage as running.

## Inputs

```text
run_directory
stage_name
metadata=None
```

## Validation

Only explicitly rejects an empty/whitespace-only stage name:

```text
RunManifestError
EMPTY_STAGE_NAME
```

## Existing stage behavior

If the stage already exists:

- original `started_at_utc` is preserved;
    
- existing metadata is merged with new metadata;
    
- existing metrics are preserved;
    
- existing outputs are preserved;
    
- `completed_at_utc` becomes `None`;
    
- `error` becomes `None`;
    
- status becomes `running`.
    

Therefore calling `start_pipeline_stage()` on an existing completed/failed stage effectively **reopens/restarts that stage record**.

No transition restriction prevents this.

---

# 31. Stage Metadata Merge

Existing:

```text
metadata
```

is merged with caller-supplied metadata:

```text
existing metadata
+
new metadata
```

New values overwrite matching previous keys.

This supports incremental stage context/configuration recording.

---

# 32. `complete_pipeline_stage()`

## Purpose

Mark a registered stage as successfully completed.

## Requirement

The stage must already exist in:

```text
manifest["stages"]
```

Otherwise:

```text
RunManifestError
STAGE_NOT_FOUND
```

is raised.

## Processing

Sets:

```text
status = completed
completed_at_utc = now
error = None
```

and merges supplied metrics into any existing stage metrics.

## Important behavior

The function does not require the previous status to be:

```text
running
```

A registered skipped, failed, or completed stage can technically be marked completed.

Again, status transitions are not modeled as a strict state machine.

---

# 33. `skip_pipeline_stage()`

## Purpose

Record that a stage was intentionally not executed.

## Inputs

```text
run_directory
stage_name
reason
```

## Result

The stage record becomes:

```text
status            = skipped
started_at_utc    = None
completed_at_utc  = now
metadata          = {"skip_reason": reason}
metrics           = {}
outputs           = []
error             = None
```

## Important behavior

Unlike `start_pipeline_stage()`, this function does not merge with an existing record.

It **replaces** any previous stage record with a fresh skipped structure.

Therefore previous:

- metadata;
    
- metrics;
    
- outputs;
    
- error;
    
- start timestamp
    

would be discarded if the same stage already existed.

Classification:

**Important behavior to understand.**

---

# 34. `convert_exception_to_record()`

## Purpose

Create manifest-compatible structured error information.

### Custom backend exception

For any:

```text
TelecomBackendError
```

calls:

```text
error.to_dict()
```

preserving:

```text
error_type
message
error_code
details
```

### Unknown Python exception

Produces:

```text
{
    "error_type": <class name>,
    "message": str(error),
    "error_code": None,
    "details": {}
}
```

This allows both custom and unexpected exceptions to use one manifest error shape.

---

# 35. `fail_pipeline_stage()`

## Purpose

Record stage failure and optionally fail the whole run.

## Inputs

```text
run_directory
stage_name
error
fail_run=True
```

## Stage behavior

The failed stage stores:

```text
status = failed
started_at_utc = previous value if present
completed_at_utc = now
metadata = preserved
metrics = preserved
outputs = preserved
error = structured error record
```

Unlike `complete_pipeline_stage()`, the stage does **not need to have been previously registered**.

A failure can create a new failed stage record directly.

---

# 36. Global Error History

The same failure is appended to:

```text
manifest["errors"]
```

with:

```text
timestamp_utc
stage_name
error_type
message
error_code
details
```

Therefore errors exist at two levels:

```text
stage record
→ current stage error

manifest["errors"]
→ historical run-level error list
```

This is useful for both current stage inspection and complete failure history.

---

# 37. `fail_run=True`

Default:

```text
True
```

When enabled:

```text
manifest["status"] = "failed"
manifest["completed_at_utc"] = now
```

When disabled:

- the stage becomes failed;
    
- the error is recorded;
    
- overall run status is left unchanged.
    

This supports workflows where one stage/model can fail without necessarily terminating the overall run.

---

# 38. Failure Event

Every stage failure adds:

```text
event_type = "stage_failed"
```

containing:

```text
stage_name
error_type
error_code
```

Notably, when `fail_run=True`, the manifest status is changed directly to `failed`.

It does **not additionally create a `run_status_changed` event**.

Therefore event history records the stage failure responsible for the run failure rather than two separate events.

---

# 39. `record_output_file()`

## Purpose

Register a generated artifact in the manifest.

## Inputs

```text
run_directory
output_file
stage_name
output_type
include_checksum=False
```

## Metadata

Uses:

```text
get_file_metadata()
```

and builds:

```text
{
    "stage_name": ...,
    "output_type": ...,
    "recorded_at_utc": ...,

    "file_name": ...,
    "file_path": ...,
    "extension": ...,
    "size_bytes": ...,
    "size_mb": ...,
    "modified_at_utc": ...,

    "sha256": ...   # optional
}
```

---

# 40. Global Output Tracking

Every output can be added to:

```text
manifest["outputs"]
```

Deduplication is based solely on:

```text
file_path
```

If that path is already present, another global record is not added.

---

# 41. Stage Output Tracking

If:

```text
stage_name in manifest["stages"]
```

the same output record is also added to:

```text
manifest["stages"][stage_name]["outputs"]
```

again deduplicated by file path.

If the stage does not exist, the file is still added to the global outputs list, but no stage record is automatically created.

---

# 42. Output Recording Observations

## No stage-name validation

`stage_name` is not stripped or validated here.

## No output-type validation

`output_type` is a free string.

Examples in the docstring include:

```text
dataset
plot
model
report
```

but no enum is enforced.

## Existing path is not refreshed

If an output at the same path changes later, recording it again does not replace the existing metadata record.

Therefore size/checksum/modification information can remain from the first registration.

Classification:

**Important observation for mutable outputs.**

---

# 43. Output Events

An:

```text
output_recorded
```

event is appended on every call.

This happens even when the file path was already present and therefore no new output record was appended.

Thus:

```text
event count
```

does not necessarily equal:

```text
unique output count
```

---

# 44. `update_run_summary()`

## Purpose

Add or update run-level summary information.

## Input

```text
summary_values: Mapping[str, Any]
```

## Processing

Merges:

```text
existing summary
+
new values
```

New values overwrite matching existing fields.

The summary structure remains intentionally generic.

## Event

Adds:

```text
summary_updated
```

with:

```text
updated_fields
```

containing the sorted names of the supplied summary keys.

---

# 45. Event History Contract

The module currently creates the following event types:

```text
run_created
run_status_changed
stage_started
stage_completed
stage_skipped
stage_failed
output_recorded
summary_updated
```

Every event follows:

```text
timestamp_utc
event_type
message
details
```

This produces an append-style audit history of major run lifecycle actions.

---

# 46. Run Lifecycle

The intended normal lifecycle can be represented as:

```text
create_run_manifest()
        │
        ▼
      created
        │
        ▼
      queued          optional
        │
        ▼
      running
        │
        ├── stage started
        ├── output recorded
        ├── stage completed
        ├── ...
        │
        ▼
 completed / failed / cancelled
```

The statuses support this lifecycle, although the code does not enforce the transition order.

---

# 47. Stage Lifecycle

Normal intended stage lifecycle:

```text
stage absent/pending concept
        │
        ▼
start_pipeline_stage()
        │
        ▼
      running
       /   \
      /     \
     ▼       ▼
completed   failed
     \
      \
       skipped
```

More precisely, `skipped` can be created directly without a prior start.

`pending` is part of `VALID_STAGE_STATUSES`, but none of the provided lifecycle functions currently create a pending stage automatically.

Classification:

**Minor but relevant observation.**

---

# 48. Error Lifecycle

```text
Exception
   │
   ▼
convert_exception_to_record()
   │
   ├── TelecomBackendError
   │      ↓
   │   preserve error_code/details
   │
   └── generic Exception
          ↓
       class + message
   │
   ▼
stage["error"]
+
manifest["errors"] append
+
stage_failed event
```

This directly connects the Core exception architecture to persistent run state.

---

# 49. Persistence Architecture

Almost every state-mutating function follows:

```text
load manifest
      ↓
modify in memory
      ↓
append event
      ↓
save manifest
```

Examples:

```text
set_run_status()
start_pipeline_stage()
complete_pipeline_stage()
skip_pipeline_stage()
fail_pipeline_stage()
record_output_file()
update_run_summary()
```

This gives the service a simple file-backed state-management model.

---

# 50. Atomic Manifest Writes

Persistence ultimately uses:

```text
file_service.write_json_file()
```

which writes through a temporary file and then replaces the final JSON.

Therefore individual save operations reduce the risk of leaving:

```text
half-written manifest.json
```

after a write interruption.

However, this protects individual file replacement only.

It is **not a concurrency-control mechanism**.

---

# 51. Concurrency Behaviour

The common update pattern is:

```text
load
↓
modify
↓
save
```

There is no:

```text
file lock
database transaction
version check
compare-and-swap
```

If two workers load the same manifest simultaneously:

```text
Worker A loads version X
Worker B loads version X

A modifies + saves
B modifies + saves
```

B can overwrite A's update because both began from the same previous state.

Atomic file replacement prevents partial JSON but does not prevent **lost updates**.

Classification:

**Important production consideration.**

---

# 52. Relationship With `file_service.py`

Manifest service delegates generic persistence mechanics:

```text
get_file_metadata()
read_json_file()
write_json_file()
```

Therefore:

```text
run_manifest_service
→ owns manifest semantics/state

file_service
→ owns generic JSON/filesystem mechanics
```

The manifest service converts relevant low-level failures into:

```text
RunManifestError
```

so callers operate primarily at the manifest abstraction level.

---

# 53. Relationship With `run_directory_service.py`

The manifest service uses:

```text
validate_run_id()
validate_run_directory()
get_run_directory()
```

The most important interaction occurs during manifest creation:

```text
run_id
    ↓
canonical runs/<run_id>
    ↓
supplied run directory must match
    ↓
manifest.json
```

This ties manifest identity to the canonical run filesystem location.

`get_run_directory` is imported but is not directly used in the provided file.

Classification:

**Minor unused import observation.**

---

# 54. Relationship With Core Exceptions

The service imports:

```text
FileProcessingError
InputValidationError
RunManifestError
TelecomBackendError
```

Roles:

```text
FileProcessingError / InputValidationError
→ lower-level file-service failures that get wrapped

RunManifestError
→ public manifest-specific failure category

TelecomBackendError
→ detect structured backend exceptions for persistent error records
```

This creates the chain:

```text
ML/service error
      ↓
TelecomBackendError
      ↓
manifest-compatible error record
      ↓
manifest.json
```

---

# 55. Expected Interaction With Parts A–E

The service is positioned above individual ML stage logic.

A workflow can conceptually do:

```text
start_pipeline_stage("part_a")
        ↓
run Part A
        ↓
record_output_file(...)
        ↓
complete_pipeline_stage(...)
```

or:

```text
stage raises exception
        ↓
fail_pipeline_stage(...)
```

This lets the workflow persist execution state without requiring Parts A–E themselves to define manifest structure.

Exact stage names used by the current workflow are **UNKNOWN / NOT CONFIRMED** from this file alone.

---

# 56. Manifest as a Lightweight Run Database

The current manifest already stores many fields normally associated with a run registry:

```text
run_id
run location
status
timestamps
input provenance
request configuration
stage state
metrics
outputs
errors
summary
event history
```

Therefore it currently acts as a **filesystem-backed primitive run database / run-state document**.

However it lacks capabilities normally associated with a real database, including:

```text
cross-run queries
indexed search
user ownership
transactional concurrent updates
centralized filtering
database-level uniqueness
relational links
efficient analytics across runs
```

So the correct architectural interpretation is:

> `manifest.json` is the authoritative per-run state document in the current filesystem design, not a replacement for a future central database.

---

# 57. Information Relevant to Future Database Integration

Without designing the database, this file establishes fields that would naturally matter:

```text
run_id
manifest_version
status
created_at_utc
updated_at_utc
started_at_utc
completed_at_utc
input metadata
requested models
request options
stage states
outputs
errors
summary
events
```

A future database/run registry can reference the run's filesystem state without changing what the individual ML stages mean.

---

# 58. Side Effects

## Reads

```text
manifest.json
input/output file metadata
optional SHA-256 content
```

## Writes

```text
manifest.json
```

through atomic JSON replacement.

## In-memory mutation

`append_manifest_event()` directly mutates its supplied dictionary.

Most lifecycle functions also mutate a loaded manifest before persistence.

## No direct directory creation semantics

The JSON file service may create the manifest parent path while saving, but this service's normal creation workflow expects the canonical run directory to already exist.

---

# 59. Error Contract

Manifest-specific error codes include:

```text
INVALID_RUN_STATUS
INVALID_STAGE_STATUS

INVALID_MANIFEST_STRUCTURE
INVALID_MANIFEST_RUN_ID
INVALID_MANIFEST_STAGES
INVALID_MANIFEST_OUTPUTS
INVALID_MANIFEST_ERRORS
INVALID_MANIFEST_EVENTS

RUN_DIRECTORY_MISMATCH
MANIFEST_ALREADY_EXISTS

MANIFEST_NOT_FOUND
MANIFEST_READ_FAILED
INVALID_MANIFEST_TYPE
MANIFEST_WRITE_FAILED

EMPTY_STAGE_NAME
STAGE_NOT_FOUND
```

Other errors from run-directory validation may also propagate because not every lower-level exception is wrapped by this module.

---

# 60. Important Exception-Boundary Observation

`create_run_manifest()` documents `RunManifestError`, but calls:

```text
validate_run_id()
validate_run_directory()
get_file_metadata()
```

without wrapping all of their possible exceptions.

Therefore callers may also receive lower-level exceptions such as:

```text
RunDirectoryError
InputValidationError
FileProcessingError
```

during manifest creation.

Similarly, not every possible lower-level failure is converted to `RunManifestError`.

Classification:

**Important actual-behavior observation.**

The implementation—not the docstring—is the source of truth.

---

# 61. Canonical Directory Enforcement Is Strongest During Creation

`create_run_manifest()` verifies:

```text
supplied directory == runs/<run_id>
```

However:

```text
load_run_manifest()
save_run_manifest()
set_run_status()
start_pipeline_stage()
...
```

accept a `run_directory` path directly and do not re-check that it corresponds to:

```text
manifest["run_id"]
```

or the canonical `runs/<run_id>` location.

Therefore, after creation, manifest operations rely on the caller supplying the correct directory.

A structurally valid manifest could theoretically be read/written from another directory.

Classification:

**Important architectural observation.**

---

# 62. Potential Issues / Observations

## Important — returned manifest can have stale `updated_at_utc`

As described earlier, `save_run_manifest()` updates a copied dictionary rather than the caller's object.

The disk file therefore has the newest timestamp, while the dictionary returned by update functions may retain the previous timestamp.

A reload resolves this discrepancy.

---

## Important — no run state-transition enforcement

Allowed states are validated individually, but logical transitions are unrestricted.

A terminal run can be moved back to a non-terminal status.

---

## Important — no stage state-transition enforcement

Stages can be restarted, completed from non-running states, failed without prior registration, or replaced by `skip_pipeline_stage()`.

This provides flexibility but means the orchestrator must enforce workflow semantics.

---

## Important — concurrent updates can be lost

Atomic JSON writes protect file integrity, but load-modify-save has no locking/version protection.

---

## Important — manifest validation is deliberately shallow

The validator confirms only enough structure for the service to function.

It does not fully validate nested stage/output/event/error/request schemas.

---

## Important — `skip_pipeline_stage()` replaces existing stage history

Calling it on a previously populated stage discards that stage's prior metrics, outputs, metadata, error, and start timestamp from the stage record.

Historical events may still preserve some prior actions.

---

## Important — output records deduplicate by path only

If a file is overwritten at the same path and changes content, calling `record_output_file()` again does not refresh its existing global/stage metadata.

---

## Important — manifest creation can propagate non-`RunManifestError` types

Run directory, file metadata, or input validation failures are not universally wrapped.

---

## Minor — `pending` stage status has no dedicated lifecycle operation

It is valid but not automatically created by any provided function.

---

## Minor — `queued` and `cancelled` have no dedicated helper

They are supported through:

```text
set_run_status()
```

rather than specialized operations.

---

## Minor — free-form stage names

Only empty stage names are rejected.

There is no central configured stage-name list.

---

## Minor — free-form output types

`output_type` has no enum or validation.

---

## Minor — unused `get_run_directory` import

It is imported but not directly called in the provided implementation.

---

## No issue / intentional — errors are recorded at stage and run level

This supports both immediate failure inspection and historical run-level error review.

---

## No issue / intentional — events are append-style

The event history provides chronological context separate from the latest state snapshot.

---

## No issue / intentional — generic summary structure

The summary dictionary can support different pipeline/model result formats without the manifest service understanding their domain meaning.

---

# 63. What Belongs Inside This Service

Based on the implementation:

```text
manifest file location
manifest lifecycle
minimum manifest validation
run status
run timestamps
stage status
stage metadata
stage metrics
output registration
error history
exception serialization
summary storage
event history
persistent run-state updates
```

---

# 64. What Does NOT Belong Inside This Service

It does not own:

```text
run-ID generation
run folder creation
generic CSV persistence
generic JSON implementation details
ML processing
stage execution
model training
inference
report generation
API HTTP mapping
database queries
workflow transition policy
```

It records those systems' state rather than performing their work.

---

# 65. Manifest Lifecycle

```text
create run directories
        │
        ▼
create_run_manifest()
        │
        ▼
manifest.json
status = created
        │
        ▼
set_run_status()
        │
        ▼
running
        │
        ├─────────────────────────────┐
        │                             │
        ▼                             ▼
start stage                    skip stage
        │
        ▼
     running
      /   \
     ▼     ▼
complete   fail
   │         │
   │         ├── record error
   │         └── optionally fail run
   │
   ├── record outputs
   ├── update metrics
   └── update summary
        │
        ▼
completed / failed / cancelled
        │
        ▼
manifest contains final run record
```

---

# 66. Compact File Contract

```text
FILE:
app/services/run_manifest_service.py

RESPONSIBILITY:
Own the filesystem-backed persistent state document for each pipeline run.

PUBLIC INTERFACE:
MANIFEST_FILENAME
MANIFEST_VERSION
VALID_RUN_STATUSES
VALID_STAGE_STATUSES
get_current_utc_timestamp()
get_manifest_path()
validate_run_status()
validate_stage_status()
validate_manifest_structure()
append_manifest_event()
create_run_manifest()
load_run_manifest()
save_run_manifest()
set_run_status()
start_pipeline_stage()
complete_pipeline_stage()
skip_pipeline_stage()
convert_exception_to_record()
fail_pipeline_stage()
record_output_file()
update_run_summary()

MANIFEST LOCATION:
runs/<run_id>/manifest.json

MANIFEST VERSION:
1.0

RUN STATUSES:
created
queued
running
completed
failed
cancelled

STAGE STATUSES:
pending
running
completed
failed
skipped

MANIFEST CONTENT:
run identity
filesystem location
run status
timestamps
input metadata + optional SHA-256
requested models
request options
stage states
stage metadata
stage metrics
stage outputs
global outputs
errors
summary
event history

OUTPUT TRACKING:
Generated files are recorded using file metadata and optionally SHA-256.
Outputs are deduplicated by absolute/resolved file path.

ERROR TRACKING:
TelecomBackendError objects preserve:
error_type
message
error_code
details

Unknown exceptions preserve:
class name
message

Failures can be attached to:
individual stage
global errors list
event history

PERSISTENCE:
Uses file_service JSON read/write.
Writes use temporary-file replacement for stronger file integrity.

SIDE EFFECTS:
Reads and rewrites manifest.json.
Reads file metadata/checksums for input/output registration.
Mutates in-memory manifest dictionaries during updates.

EXPECTED CALLERS:
Pipeline/workflow orchestrator
API/UI/MCP inspection layers
Parts A-E integration workflow
future run registry/database synchronization layer

IMPORTANT ARCHITECTURAL INFORMATION:
The manifest is the current per-run filesystem-backed state record.
It tracks both latest state and event/error history.
Run-directory creation remains separate.
Generic file I/O remains separate.
Workflow transition semantics are not enforced here.
Atomic writes protect individual file integrity but not concurrent updates.
```

---

# Final Assessment

`run_manifest_service.py` is the **state-management center of the current Services architecture**.

Its core role is:

```text
Pipeline execution
       │
       ▼
run_manifest_service
       │
       ├── run state
       ├── stage state
       ├── metrics
       ├── outputs
       ├── errors
       ├── summary
       └── event history
       │
       ▼
runs/<run_id>/manifest.json
```

Together with the two Services files already analyzed, the responsibility split is now very clear:

```text
run_directory_service.py
→ WHERE the run exists

file_service.py
→ HOW files are safely read/written/copied

run_manifest_service.py
→ WHAT the run's current and historical state is
```

The manifest is therefore effectively the current backend's **per-run persistent state document and lightweight filesystem-backed run registry**, while still leaving central database functionality, cross-run search, workflow orchestration, and ML execution outside this service.