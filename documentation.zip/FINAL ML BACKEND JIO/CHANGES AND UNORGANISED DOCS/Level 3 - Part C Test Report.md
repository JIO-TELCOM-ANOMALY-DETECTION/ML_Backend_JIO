# Level 3 — Part C Feature Engineering Deep Integration Test Report

**Status:** PASS  
**Purpose:** Certify Part C through the real Part A → Part B → Part C production lineage, including feature-profile resolution, generated feature mathematics, physical run-directory artifacts, lifecycle enforcement, retry behavior, and Part C-specific error handling.

## Cases Passed

| Case | Job | Result |
|---|---|---|
| 01 — XGBoost default profile | Run A → B → C using the XGBoost feature profile and verify the exact resolved feature contract together with persisted Part C artifacts. | PASS |
| 02 — Isolation Forest profile | Verify the Isolation Forest feature profile, explicit-config authority, and corrected-history intermediate audit output. | PASS |
| 03 — Explicit config authority | Supply an explicit custom Part C configuration together with a model hint and verify the explicit configuration remains authoritative. | PASS |
| 04 — Feature mathematics | Independently recalculate selected lag, difference, percentage-change, rolling, time-bucket, cyclic-time, and calendar features from the persisted Part B final CSV and compare them with the Part C output. | PASS |
| 05 — Invalid + short history | Verify invalid Part B sites remain represented without generated feature values, while valid sites with insufficient history are retained and handled through natural feature warm-up/NaN behavior. | PASS |
| 06 — Prerequisite | Verify Part C cannot start before Part B completes and that no Part C execution directory is created. | PASS |
| 07 — Immutability | Complete Part C, attempt to run it again in the same attempt, and verify `409 COMPLETED_STAGE_IS_IMMUTABLE` with exactly one physical Part C execution directory. | PASS |
| 08 — Failure + retry | Force a real Part C configuration-resolution failure, persist `execution_0001`, retry the same attempt with corrected configuration, and complete as `execution_0002`. | PASS |
| 09 — Public + schema errors | Verify missing run/attempt errors and invalid Part C request combinations map to the correct public 404/422 contracts without illegal state mutation. | PASS |

## Deep Physical Artifact Validation

Level 3 extended the certification beyond API responses and `/runs`.

For successful Part C cases, the runner directly inspected the production run hierarchy:

```text
runs/<run_id>/
├── .run.lock
├── manifest.json
└── attempts/
    └── attempt_0001/
        ├── request.json
        ├── input/
        └── stages/
            ├── part_a/
            ├── part_b/
            └── part_c/
```

The runner verified:

- the Level 3 run exists in `run_registry/runs.json`;
- registry and `manifest.json` agree on the run;
- the immutable attempt-owned input physically exists;
- Part B `result.json` and final cleaned CSV physically exist;
- requested Part B intermediate checkpoint files and summary files physically exist;
- Part C `result.json`, final feature CSV, and site-summary CSV physically exist;
- Part C `source_file` is exactly the successful Part B final cleaned CSV;
- Part C outputs stay inside the correct `part_c/execution_xxxx` directory;
- feature columns match the persisted resolved Part C configuration;
- original Part B rows and columns remain preserved where required;
- generated numerical features contain no unexpected infinity values;
- physical row/site counts agree with persisted Part C results.

## Feature Mathematics Proved

The deep feature case independently recalculated selected features from the saved Part B dataset rather than trusting the Part C summary.

Examples verified include:

```text
lag_1[t]
= value[t - 1]

lag_4[t]
= value[t - 4]

difference_1[t]
= value[t] - value[t - 1]

percentage_change_1[t]
= (value[t] - value[t - 1]) / value[t - 1]

rolling_mean_4[t]
= mean of the previous 4 historical values

rolling_median_4[t]
= median of the previous 4 historical values
```

Time-bucket, cyclic time, weekend, and day-of-week features were also independently recomputed.

The runner was self-tested by deliberately corrupting a generated `lag_1` value; the deep checker correctly rejected the corrupted feature output.

## Retry Result Proved

The Part C retry case verified:

```text
Part A → completed
Part B → completed

Part C execution_0001
→ failed
→ InputValidationError
→ FEATURE_CONFIG_RESOLUTION_FAILED
→ reason:
   20-minute corrected-history window is not exactly
   divisible by the 15-minute dataset bucket

same run_id + attempt_id

Part C execution_0002
→ completed
→ corrected 30-minute window

successful_execution_id
→ execution_0002
```

This proves Part C failure history remains persisted while retrying the same incomplete stage creates a new execution instead of a new attempt.

## Test-Harness Correction During Certification

During Case 08, the first Level 3 tester expected the inner raw `ValueError`. The production Part C boundary correctly wrapped that low-level configuration error as:

```text
InputValidationError
FEATURE_CONFIG_RESOLUTION_FAILED
```

with the original divisibility explanation preserved in `details.reason`.

The tester expectation was corrected to match the actual stable Part C public/domain contract. The retry lifecycle itself was already behaving correctly. The corrected case then passed.

The runner was also hardened so execution IDs are still captured when another assertion mismatches, preventing misleading downstream `KeyError` cascades during diagnosis.

## Run Identification

Level 3 runs were intentionally labelled without changing the production `run_id` format:

```text
employee_code = CERT_LEVEL_3
run_name       = LEVEL_3_PART_C__<CASE>
```

The runner also produces:

```text
level_3_run_index.json
level_3_run_index.csv
```

to map each Level 3 case to its real `run_id`, `attempt_id`, and physical run directory.

## What Level 3 Proved

- The real A → B → C persisted handoff works.
- XGBoost and Isolation Forest feature profiles resolve correctly.
- Explicit Part C configuration remains authoritative over model hints.
- Generated feature datasets are physically persisted in the correct run hierarchy.
- Selected feature mathematics is independently correct.
- Leakage-safe historical feature behavior is preserved.
- Part B rows/provenance are retained correctly in Part C outputs.
- Invalid sites and insufficient-history sites are handled without corrupting lineage.
- Part C prerequisite enforcement works.
- Failed Part C execution persistence and same-attempt retry work.
- Completed Part C is immutable.
- Public 404/409/422 boundaries behave correctly.
- Run registry, manifest, API state, execution folders, and generated artifacts agree.

## Final Result

**9/9 logical cases passed — Level 3 / Part C deep certification complete.**
