### Changes made

- Added **run-registry configuration**
    
    - `run_registry_backend = "local_json"`
        
    - optional `run_registry_root`
        
    - `run_registry_filename = "runs.json"`
        
    - derived `run_registry_directory`
        
    - derived `run_registry_file`
        
- Added **run-lock configuration**
    
    - `run_lock_timeout_seconds = 30.0`
        
- Added **contract versioning**
    
    - `workflow_schema_version = "1.0"`
        
    - `run_manifest_version = "2.0"`
        
- Added validation for:
    
    - registry backend
        
    - registry path
        
    - registry JSON filename
        
    - schema/manifest version format
        
- Added:
    
    ```text
    run_management.log
    ```
    
    as a dedicated logging component.
    
- Updated `create_base_directories()` so the V1 local registry directory is created automatically.
    
- Preserved all existing:
    
    - API settings
        
    - input restrictions
        
    - runs/log paths
        
    - model artifact paths
        
    - XGBoost/Isolation Forest settings
        
    - existing logging components
        

### Documentation note

The main conceptual change to document later is:

> `config.py` now also provides infrastructure configuration for the new workflow/run-management layer, including local run-registry persistence, run locking and persisted contract versioning.

