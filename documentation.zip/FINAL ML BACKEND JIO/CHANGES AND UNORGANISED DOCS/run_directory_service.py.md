### Changes made

The top-level run structure is now:

```text
runs/<run_id>/
├── manifest.json
├── attempts/
├── inference/
├── reports/
├── agents/
└── temporary/
```

Logs still remain separately under:

```text
logs/<run_id>/
```

### Important structural change

Removed the old top-level:

```text
input/
preprocessing/
models/
```

Those now belong **inside individual attempts/stage executions**, which the future Run Management layer will create.

So this service only knows:

> “What permanent top-level folders does every run have?”

It does **not** know about:

```text
attempt_0001
part_a
execution_0001
input snapshots
model directories
inference invocations
```

Those are deliberately left for Run Management.

### Other updates

- `get_run_paths()` now returns:
    
    - `run`
        
    - `logs`
        
    - `manifest`
        
    - `attempts`
        
    - `inference`
        
    - `reports`
        
    - `agents`
        
    - `temporary`
        
- Updated `get_run_subdirectory()` documentation/validation for the new keys.
    
- Updated terminology from purely “pipeline run” to broader **backend run**, because a run now includes training attempts plus later inference.
    
- Clarified that `list_run_ids()` is only a low-level filesystem utility; future user-facing lookup should use the Run Registry.
    
- Preserved:
    
    - run-ID generation
        
    - run-ID validation
        
    - traversal protection
        
    - duplicate-directory protection
        
    - base-directory initialization
        
    - directory validation/listing behavior.
        

### Documentation note

> `run_directory_service.py` now owns only the stable run-level filesystem skeleton. Attempt, stage, execution, input, training-model, and inference-invocation directories are intentionally delegated to the future Run Management layer, allowing the deeper folder structure to evolve without changing the low-level run-directory service.