# Feature Engineering API — Final Technical Report

**File:** `app/api/feature_engineering.py`  
**Final implementation:** v1  
**Module:** `app/api/`  
**Status:** Final sanity checked — PASS / suitable to freeze  
**Primary role:** Production HTTP endpoint for standalone Part C feature-engineering execution.

---

# 1. Purpose

`feature_engineering.py` is the API-layer entry point for running **Part C — Feature Engineering** independently inside an existing training attempt.

Its role is intentionally narrow:

```
HTTP request
    ↓
Pydantic request validation
    ↓
caller-owned run / attempt validation
    ↓
run-scoped workflow logger
    ↓
run_part_c_workflow(...)
    ↓
StandaloneStageResponse
```

The route does not implement feature-generation algorithms, inspect Part B artifacts directly, or own Part C lifecycle rules.

---

# 2. Architectural Position

```
Client / UI
    ↓
POST /api/v1/feature-engineering/run
    ↓
app/api/feature_engineering.py
    ↓
app/workflows/part_c.py
    ↓
Run Management
    ↓
app/ml/feature_engineering/
    ↓
Services / filesystem
```

The API file is therefore a thin HTTP bridge into the already-frozen Part C workflow.

---

# 3. Router Contract

Router prefix:

```
/api/v1/feature-engineering
```

Endpoint:

```
POST /api/v1/feature-engineering/run
```

Request model:

```
FeatureEngineeringStageRequest
```

Response model:

```
StandaloneStageResponse
```

---

# 4. Request Contract

The frozen Part C request contains:

```
run_id
attempt_id
feature_engineering: FeatureEngineeringConfig | None
model_type_hint: "xgboost" | "isolation_forest" | None
```

Part C always targets an existing run + attempt.

Unlike Part A, it cannot create:

```
a new run
or
a new attempt
```

---

# 5. Part C Configuration Modes

Part C supports two request modes.

## Explicit configuration

```
feature_engineering supplied
```

Meaning:

```
use the supplied FeatureEngineeringConfig
```

`model_type_hint` may still be present, but it is not required.

## Default-profile mode

```
feature_engineering omitted
```

Then:

```
model_type_hint is required
```

The workflow uses the hint to construct the model-matched schema-owned Part C default profile.

---

# 6. Why `model_type_hint` Exists

In the master A→D pipeline, Part C defaults historically came from:

```
training.model_type
```

A standalone Part C call has no Part D training request yet.

Therefore when the entire Part C configuration is omitted, the standalone request must supply:

```
model_type_hint
```

so the workflow knows whether the default profile should match:

```
xgboost
or
isolation_forest
```

---

# 7. Request-Schema Ownership of Config/Hint Validation

`feature_engineering.py` deliberately does not reimplement:

```
if feature_engineering is None:
    require model_type_hint
```

That rule already belongs to:

```
FeatureEngineeringStageRequest
```

Pydantic therefore rejects an omitted config with no hint before the route executes.

---

# 8. Explicit Config + Hint Is Allowed

The frozen request schema permits:

```
feature_engineering supplied
+
model_type_hint supplied
```

The API route does not invent a stricter rule.

This is intentional.

The Part C workflow treats the explicit configuration as authoritative.

---

# 9. Explicit Configuration Remains Authoritative

The workflow resolves Part C configuration conceptually as:

```
feature_engineering exists
→ use it unchanged

feature_engineering omitted
→ use model_type_hint
→ build model-matched default profile
```

Therefore a supplied hint does not override an explicit Part C configuration.

---

# 10. Public Run Validation

The route first checks:

```
manager.registry.exists(request.run_id)
```

This targeted lookup is used only to establish genuine caller-owned run absence.

If the caller references a run that is not registered:

```
API_RUN_NOT_FOUND
→ HTTP 404
```

Safe public detail:

```
run_id
```

---

# 11. Why Generic `RUN_NOT_FOUND` Is Not Automatically 404

A low-level `RUN_NOT_FOUND` may also represent:

```
registered run directory missing
manifest corruption
registry/manifest mismatch
internal lifecycle failure
```

Those are backend failures.

Therefore only the explicit public-boundary absence becomes:

```
API_RUN_NOT_FOUND
```

Later low-level failures remain internal and normally map to 500.

---

# 12. Public Attempt Validation

After proving the run exists, the route calls:

```
manager.resolve_attempt(
    request.run_id,
    request.attempt_id,
)
```

If the exact caller-requested attempt does not exist:

```
AttemptNotFoundError
        ↓
API_ATTEMPT_NOT_FOUND
        ↓
HTTP 404
```

Safe details:

```
run_id
attempt_id
```

---

# 13. Why Only `AttemptNotFoundError` Is Translated

`resolve_attempt()` can also fail for internal reasons such as:

```
attempt request snapshot missing
attempt immutable input missing
path containment violation
manifest problem
registered run state inconsistency
```

Those are not caller-owned 404 conditions.

The route catches only the exact missing-attempt exception.

---

# 14. No External File Validation

Part C accepts no new external dataset.

Its authoritative input comes from the successful Part B execution inside the same attempt.

Conceptually:

```
successful Part B
        ↓
B→C persisted handoff
        ↓
PreprocessingRunnerResult.final_dataset_file
        ↓
Part C workflow
```

Therefore `feature_engineering.py` contains no:

```
read_csv_file()
validate_input_file()
API_INPUT_FILE_*
API_INPUT_CSV_*
```

logic.

---

# 15. Why Missing Part B Files Are Not Caller 422s

If the backend later discovers that a persisted Part B artifact is missing or corrupt, that is:

```
backend-owned state failure
```

not:

```
caller supplied an invalid Part C file
```

because Part C has no caller file field.

Such failures remain workflow/internal errors.

---

# 16. No Manual Part B Prerequisite Check

The route does not inspect:

```
Part B status
Part B successful_execution_id
Manifest V2 stage state
```

That would duplicate Run Management.

---

# 17. Where the Part B Prerequisite Is Enforced

The Part C workflow begins with:

```
manager.prepare_stage_execution(
    run_id,
    attempt_id,
    "part_c",
    ...
)
```

Run Management resolves the authoritative successful Part B prerequisite before the workflow uses it.

---

# 18. Missing Part B Prerequisite

If Part B has not successfully completed:

```
STAGE_PREREQUISITE_NOT_COMPLETED
→ HTTP 409
```

The route does not catch or rewrite this lifecycle error.

---

# 19. Why 409 Is Correct

This situation means:

```
request is structurally valid
run exists
attempt exists
backend state is healthy
but Part C is not currently allowed to start
```

That is a lifecycle conflict, not malformed input.

Therefore:

```
409 Conflict
```

is correct.

---

# 20. Completed Part C Immutability

If Part C already completed successfully:

```
COMPLETED_STAGE_IS_IMMUTABLE
→ HTTP 409
```

Changing completed Part C behavior requires:

```
a new training attempt
```

rather than mutating an existing immutable attempt lineage.

---

# 21. Already-Running Part C

If Part C already has an active execution:

```
STAGE_EXECUTION_ALREADY_RUNNING
→ HTTP 409
```

The route does not manually inspect active execution state.

Run Management remains the single lifecycle authority.

---

# 22. Retry Legality

A failed Part C stage may be retried in the same attempt if Run Management permits it.

Typical valid case:

```
Part B completed
Part C failed
→ retry Part C
```

Typical invalid case:

```
Part C completed
→ retry forbidden in same attempt
```

The API route does not encode these rules.

---

# 23. Run-Scoped Logger

Part C always has an existing:

```
run_id
```

before the request reaches the route.

Therefore:

```
get_workflow_logger(
    request.run_id,
    component_name="pipeline",
)
```

returns the run-scoped pipeline logger.

There is no process-level/new-run logger case.

---

# 24. Workflow Delegation

After caller target validation:

```
return run_part_c_workflow(
    request=request,
    manager=manager,
    logger=logger,
)
```

The API route does not reshape the returned response.

---

# 25. Part C Workflow Responsibilities

The frozen Part C workflow owns:

```
prepare Part C execution
resolve successful Part B prerequisite
load authoritative B→C handoff
resolve request feature configuration
create deterministic KPI output directories
run feature engineering once per KPI
validate result KPI identity
validate output-directory ownership
validate Part B source-file continuity
validate final Part C output files
validate feature column contract
validate minimum history
validate headline counts
validate exact B→C KPI continuity
build C→D persisted snapshot
complete/fail stage
return StandaloneStageResponse
```

None of this is duplicated in the API route.

---

# 26. Authoritative Part B Handoff

Run Management supplies the successful prerequisite result.

The workflow reconstructs:

```
PartBHandoff
├── dataset_config
├── bucket
└── preprocessing_results[]
```

The route never scans folders or selects the newest Part B result.

---

# 27. Part C Input Per KPI

For each persisted Part B result, the workflow calls the feature-engineering runner with:

```
PreprocessingRunnerResult
workflow-owned output directory
DatasetInputConfig
resolved FeatureEngineeringConfig
BucketConfig
logger
```

The exact Part B final dataset path remains authoritative.

---

# 28. Config Resolution Happens in the Workflow

The route intentionally does not call:

```
resolve_feature_engineering_config()
```

The workflow owns the exact resolution.

For explicit config:

```
use unchanged
```

For omitted config:

```
model_type_hint
→ FeatureEngineeringConfig(default_profile=...)
```

This keeps the HTTP layer free of ML/profile logic.

---

# 29. Defensive Workflow Guard

The workflow also contains a defensive check for:

```
feature_engineering is None
and
model_type_hint is None
```

even though normal Pydantic validation prevents that state.

This protects direct/internal workflow calls that could bypass the API schema.

The API route does not duplicate that defensive logic.

---

# 30. Unique KPI Directory Names

The workflow protects against two distinct logical KPI names sanitizing to the same filesystem directory name.

It creates deterministic unique workflow-owned KPI directories while preserving original KPI identity in the result objects.

This filesystem concern remains below the API route.

---

# 31. KPI Identity Validation

For every Part C runner result:

```
result.kpi_name
```

must match the Part B input KPI identity.

Mismatch produces an internal Part C contract failure.

The route never needs to inspect KPI names.

---

# 32. Source-File Continuity

The Part C workflow requires:

```
result.source_file
==
Part B preprocessing_result.final_dataset_file
```

This ensures Part C actually used the authoritative Part B output rather than another file.

Again, this validation belongs in the workflow, not HTTP.

---

# 33. Output Containment

Part C verifies that workflow-produced artifacts stay under the workflow-owned KPI directory.

Examples:

```
final_dataset_file
site_summary_file
corrected_history_audit_file
```

must remain within the expected Part C output root.

The route exposes none of these paths.

---

# 34. Feature Contract Validation

The workflow checks:

```
result.feature_columns
==
result.resolved_config.feature_columns
```

and validates:

```
minimum_history_points >= 1
```

This protects the C→D contract that Part D will trust.

---

# 35. Headline Result Count Validation

The workflow rejects impossible negative counts for values such as:

```
total_rows
total_sites
processed_sites
skipped_invalid_sites
insufficient_history_sites
populated_feature_cells
missing_feature_cells
```

It also validates:

```
processed_sites + skipped_invalid_sites
<= total_sites
```

These are workflow-level result-contract checks.

---

# 36. Exact B→C KPI Continuity

Before Part C can complete successfully:

```
Part B KPI set
==
Part C KPI set
```

The workflow rejects:

```
missing KPI
extra KPI
duplicate KPI
count mismatch
```

This guarantees that Part D receives a complete and exact KPI lineage.

---

# 37. C→D Persisted Handoff

After validation, the workflow builds:

```
Part C result snapshot
```

containing the exact `FeatureEngineeringRunnerResult` objects needed by Part D.

Conceptually:

```
Part C handoff
├── dataset_config
└── feature_engineering_results[]
```

The API route does not construct this snapshot.

---

# 38. Part D Dependency on Part C

Part D later reconstructs the Part C handoff into one training input per KPI.

Important downstream values include:

```
final_dataset_file
dataset columns
resolved feature config
minimum_history_points
feature columns
```

Therefore the Part C workflow performs strong result validation before marking the stage successful.

---

# 39. Structured Part C Success

Successful Part C execution returns:

```
StandaloneStageResponse
```

with:

```
status = completed
requested_stage = part_c
next_stage = part_d
inference_ready = false
```

and a safe summary.

---

# 40. Part C Summary Metrics

The workflow summary contains safe high-level values such as:

```
kpi_count
kpi_names
total_rows
total_sites
processed_sites
skipped_invalid_sites
insufficient_history_sites
```

No physical paths are included in the public workflow response.

---

# 41. Structured Part C Failure

Once the Part C execution has safely started, a feature-engineering or contract failure is persisted with:

```
manager.fail_stage(...)
```

and the workflow returns:

```
StandaloneStageResponse(
    status="failed",
    ...
)
```

The API route returns that response unchanged.

---

# 42. Why Started-Stage Failure Is Not Automatically HTTP 500

A structured failed stage response represents a known workflow execution outcome with persisted lifecycle identity.

It is different from:

```
invalid API request
missing public resource
pre-execution lifecycle conflict
unexpected uncaught backend failure
```

Therefore the route preserves the workflow response contract.

---

# 43. Pre-Execution vs Post-Execution Failure

## Before Part C starts

Examples:

```
Part B incomplete
Part C already completed
Part C already running
```

These propagate as exceptions and become 409.

## After Part C starts

Examples:

```
runner output contract mismatch
KPI continuity failure
feature contract mismatch
output file missing
```

The workflow persists the failed execution and returns a structured failed response.

---

# 44. Pydantic Validation

`FeatureEngineeringStageRequest` validates:

```
run_id shape
attempt_id shape
feature_engineering config
model_type_hint enum
required hint when config omitted
```

Malformed requests become:

```
REQUEST_VALIDATION_FAILED
→ HTTP 422
```

before the route executes.

---

# 45. Invalid Model Hint

Unsupported values such as:

```
random_forest
```

do not reach the workflow.

The request schema rejects them as:

```
422 REQUEST_VALIDATION_FAILED
```

---

# 46. Invalid Explicit Feature Config

Invalid `FeatureEngineeringConfig` values are rejected by the existing Part C schema.

The API route does not redefine:

```
features
lag settings
rolling settings
time settings
baseline settings
minimum history
default profile behavior
```

---

# 47. Extra External File Fields Are Rejected

Part C has no caller file boundary.

Unexpected fields such as:

```
input_file
dataset
output_directory
```

are rejected by the strict workflow request schema.

This prevents reintroducing temporary-test API semantics into production.

---

# 48. Error Handler Relationship

The route directly creates only the public missing-resource codes it can prove:

```
API_RUN_NOT_FOUND
API_ATTEMPT_NOT_FOUND
```

The global `error_handlers.py` remains responsible for:

```
404 mapping
409 lifecycle mapping
422 request validation
500 fail-closed behavior
safe messages
safe detail allowlists
logging
```

---

# 49. Final 404 Behavior

```
unknown caller run
→ API_RUN_NOT_FOUND
→ 404
```

```
known run + unknown caller attempt
→ API_ATTEMPT_NOT_FOUND
→ 404
```

---

# 50. Final 409 Behavior

The route lets existing lifecycle codes propagate:

```
STAGE_PREREQUISITE_NOT_COMPLETED
→ 409
```

```
COMPLETED_STAGE_IS_IMMUTABLE
→ 409
```

```
STAGE_EXECUTION_ALREADY_RUNNING
→ 409
```

---

# 51. Final 422 Behavior

Part C 422s are request/schema problems.

Examples:

```
missing model_type_hint when config omitted
invalid hint
invalid feature configuration
malformed run/attempt ID
extra forbidden field
```

These become:

```
REQUEST_VALIDATION_FAILED
→ 422
```

There is no Part C external-file 422 family.

---

# 52. Final 500 Behavior

Examples that remain internal:

```
registered run cannot resolve technically
attempt-owned state corruption
Part B handoff corruption
Part B artifact missing
unexpected workflow contract error before structured failure handling
unknown future backend error
```

The global handler fails closed to 500.

---

# 53. Runtime Flow — Explicit Config

```
POST /api/v1/feature-engineering/run
        ↓
request contains explicit feature_engineering
        ↓
schema validates config
        ↓
run/attempt public checks
        ↓
run-scoped logger
        ↓
Part C workflow
        ↓
explicit feature config preserved
        ↓
run feature engineering
```

---

# 54. Runtime Flow — Default XGBoost Profile

```
feature_engineering omitted
model_type_hint = xgboost
        ↓
schema accepts
        ↓
workflow resolves:
FeatureEngineeringConfig(default_profile="xgboost")
        ↓
Part C runs
```

---

# 55. Runtime Flow — Default Isolation Forest Profile

```
feature_engineering omitted
model_type_hint = isolation_forest
        ↓
schema accepts
        ↓
workflow resolves:
FeatureEngineeringConfig(default_profile="isolation_forest")
        ↓
Part C runs
```

---

# 56. Runtime Flow — Missing Config and Hint

```
feature_engineering omitted
model_type_hint omitted
        ↓
Pydantic model validator
        ↓
REQUEST_VALIDATION_FAILED
        ↓
422
```

Route/workflow are not called.

---

# 57. Runtime Flow — Missing Run

```
caller run_id
        ↓
registry.exists(run_id) = false
        ↓
API_RUN_NOT_FOUND
        ↓
404
```

Workflow is not called.

---

# 58. Runtime Flow — Missing Attempt

```
known run
        ↓
resolve_attempt()
        ↓
AttemptNotFoundError
        ↓
API_ATTEMPT_NOT_FOUND
        ↓
404
```

---

# 59. Runtime Flow — Registered But Broken Run

```
registry says run exists
        ↓
resolve_attempt()
        ↓
internal RUN_NOT_FOUND / technical failure
        ↓
not reclassified by route
        ↓
500
```

---

# 60. Runtime Flow — Part B Incomplete

```
run + attempt exist
        ↓
workflow
        ↓
prepare_stage_execution(part_c)
        ↓
Part B successful execution absent
        ↓
STAGE_PREREQUISITE_NOT_COMPLETED
        ↓
409
```

---

# 61. Runtime Flow — Part C Already Completed

```
workflow
        ↓
Run Management detects successful completed Part C
        ↓
COMPLETED_STAGE_IS_IMMUTABLE
        ↓
409
```

---

# 62. Runtime Flow — Part C Already Running

```
workflow
        ↓
Run Management detects active Part C execution
        ↓
STAGE_EXECUTION_ALREADY_RUNNING
        ↓
409
```

---

# 63. Runtime Flow — Started Part C Fails

```
prepare_stage_execution succeeds
        ↓
Part C execution exists
        ↓
feature runner / handoff / contract error
        ↓
workflow persists failure
        ↓
StandaloneStageResponse(status="failed")
        ↓
API route returns unchanged
```

---

# 64. No Direct RunManager Construction

The route receives:

```
RunManagerDependency
```

from `dependencies.py`.

It does not instantiate `RunManager` directly.

This preserves:

```
shared manager state
FastAPI dependency overrides
centralized configuration
testability
```

---

# 65. No Manifest Mutation

`feature_engineering.py` never calls:

```
prepare_stage_execution
complete_stage
fail_stage
save_manifest
```

directly.

The workflow owns those RunManager operations.

---

# 66. No Artifact Resolver Use in the API

The route does not call artifact-resolution functions itself.

The successful Part B prerequisite is resolved through Run Management and consumed by the Part C workflow.

---

# 67. No Feature ML Logic in the API

The route has no knowledge of how Part C generates:

```
current value
lags
differences
percentage changes
rolling statistics
time features
calendar features
seasonal baselines
residuals
```

Those remain inside the tested Part C ML module.

---

# 68. Security / Information Exposure

The route exposes no:

```
run directory
attempt directory
Part B source file
Part C output directory
final dataset path
site summary path
audit path
Manifest path
```

Public missing-resource errors contain only:

```
run_id
attempt_id
```

Internal errors remain protected by the global fail-closed handler.

---

# 69. Final Sanity Check

The exact generated `feature_engineering.py` was reviewed against:

```
FeatureEngineeringStageRequest
current Part C workflow
current config-resolution helper
Run Management lifecycle ownership
frozen error policy
existing dependencies
```

No blocking mismatch was found.

---

# 70. Syntax Verification

The exact file passed Python compilation:

```
FEATURE_ENGINEERING_API_V1_SYNTAX=PASS
```

---

# 71. Runtime Regression

The full route regression passed:

```
FEATURE_ENGINEERING_API_V1_RUNTIME_SMOKE=PASS
FEATURE_ENGINEERING_API_V1_FULL_REGRESSION=PASS
```

The runtime smoke was rerun again during the final freeze-level sanity check and remained green.

---

# 72. Regression Coverage

The tests explicitly covered:

```
explicit FeatureEngineeringConfig
omitted config + XGBoost hint
omitted config + Isolation Forest hint
explicit config + hint simultaneously
omitted config + omitted hint → 422
invalid hint → 422
invalid explicit config → 422
missing run → 404
missing attempt → 404
registered-but-broken run → 500
Part B incomplete → 409
Part C already completed → 409
Part C already running → 409
internal post-boundary failure → 500
structured Part C failed response unchanged
external input_file field rejected
malformed IDs rejected
run-scoped logger used
```

---

# 73. Sanity-Check Result on Config + Hint Semantics

The final review confirmed:

```
FeatureEngineeringStageRequest
```

requires a hint only when the entire config is omitted.

It does not prohibit:

```
explicit config + hint
```

The workflow also preserves explicit config unchanged.

Therefore the API is correct not to introduce a new mismatch/rejection rule.

---

# 74. Relationship with `preprocessing.py`

```
preprocessing.py
→ Part B
→ existing run/attempt
→ PreprocessingConfig
→ Part A prerequisite

feature_engineering.py
→ Part C
→ existing run/attempt
→ FeatureEngineeringConfig / model_type_hint
→ Part B prerequisite
```

Both routes are intentionally thin and lifecycle-neutral.

---

# 75. Relationship with Future `training.py`

Part D will consume the persisted Part C handoff.

Therefore Part C's strongest contract responsibility is below the API route:

```
exact KPI continuity
validated final feature dataset
validated feature columns
validated minimum history
stable C→D snapshot
```

The future `training.py` route should similarly remain a thin HTTP bridge.

---

# 76. Known V1 Boundaries

There are no blocking limitations specific to this API route.

Deliberate architectural choices include:

```
route does not inspect Part B prerequisite itself
route does not compare explicit config against model_type_hint
route does not expose Part C artifact paths
started-stage failures remain structured workflow responses
```

These are intentional, not missing functionality.

---

# 77. Final Responsibility Boundary

```
feature_engineering.py
→ HTTP + caller run/attempt identity

FeatureEngineeringStageRequest
→ config/hint request validation

Part C workflow
→ config resolution + orchestration + B→C/C→D contract checks

Run Management
→ Part B prerequisite + retry/immutability authority

ML feature-engineering module
→ actual feature generation

error_handlers.py
→ safe HTTP mapping
```

No layer responsibility is duplicated.

---

# 78. Final Compact Contract

```
FILE:
app/api/feature_engineering.py

ROLE:
Standalone Part C HTTP route.

ENDPOINT:
POST /api/v1/feature-engineering/run

REQUEST:
FeatureEngineeringStageRequest

REQUEST FIELDS:
run_id
attempt_id
feature_engineering | None
model_type_hint | None

CONFIG RULE:
explicit config supplied
→ use explicit config

config omitted
→ model_type_hint required

PUBLIC 404:
API_RUN_NOT_FOUND
API_ATTEMPT_NOT_FOUND

LIFECYCLE 409:
STAGE_PREREQUISITE_NOT_COMPLETED
COMPLETED_STAGE_IS_IMMUTABLE
STAGE_EXECUTION_ALREADY_RUNNING

REQUEST 422:
REQUEST_VALIDATION_FAILED

DEFAULT UNKNOWN/INTERNAL:
500 through global fail-closed handler

LOGGER:
run-scoped pipeline logger

WORKFLOW:
run_part_c_workflow()

INPUT SOURCE:
authoritative successful Part B handoff/result

OUTPUT CONTRACT:
validated C→D snapshot

DOES NOT:
read external CSV
inspect Part B manually
decide retry legality
resolve feature profile in API
call Part C ML directly
mutate Manifest V2
resolve artifacts directly
reshape workflow responses
```

---

# 79. Final Assessment

`app/api/feature_engineering.py` is a correctly bounded production Part C route.

Its governing rule is:

```
The API proves only caller-owned run/attempt identity
and accepts the schema-approved Part C request.

The request schema decides whether a model hint is required.

Run Management decides lifecycle legality.

The Part C workflow resolves the feature configuration and validates the
B→C/C→D contracts.

The ML module performs the actual feature generation.
```

This preserves the frozen error model:

```
genuine missing caller resource → 404
healthy lifecycle conflict → 409
invalid request/config → 422
internal/unexpected failure → 500
started-stage failure → structured workflow response
```

**Final status: PASS / suitable to freeze.**