# Workflow Common + Handoffs — Final Technical Report

**Package location:** `app/workflows/`  
**Phase scope:** `common.py` and `handoffs.py`

---

## 1. Purpose

This phase provides the persistence/reconstruction bridge required because the  
final backend no longer assumes that Parts A, B, C, and D execute in one Python  
process.

The tested integration pipelines established the in-memory flow:

```
Part A
  ↓
KPIEDARunResult + DatasetInputConfig + resolved BucketConfig
  ↓
Part B
  ↓
PreprocessingRunnerResult + same DatasetInputConfig + same BucketConfig
  ↓
Part C
  ↓
final_dataset_file + resolved Part C feature contract
+ minimum_history_points + dataset columns
  ↓
Part D
```

Production workflows persist enough structured state in each successful stage's  
`result.json` to reconstruct those exact runner contracts later.

Part E is deliberately outside this normal handoff model:

```
Part D
  ↓
inference_bootstrap
  ↓
persistent inference-ready saved state
  ↓
later independent Part E invocations
```

---

## 2. Files

```
app/workflows/
├── common.py
└── handoffs.py
```

---

# 3. `common.py`

`common.py` owns shared workflow mechanics only.

It does not:

- execute Parts A/B/C/D;
    
- decide lineage;
    
- resolve prerequisites;
    
- manage HTTP responses;
    
- create Run Management state.
    

Those responsibilities remain in stage workflows, Run Management, and API  
layers.

---

## 4. Attempt-owned runtime dataset configuration

### `build_runtime_dataset_config()`

Run Management first copies the caller's source input into the immutable attempt  
directory.

The external request may contain:

```
/user/upload/source.csv
```

but Part A must execute against:

```
runs/<run_id>/attempts/<attempt_id>/input/source.csv
```

`build_runtime_dataset_config()` reconstructs `DatasetInputConfig` with that  
attempt-owned path while preserving the remaining validated dataset settings.

This preserves the tested pipeline behavior while preventing an external file  
from remaining mutable training state.

---

## 5. Part C default-profile resolution

### `resolve_feature_engineering_config()`

The tested A→D pipelines established:

```
explicit Part C configuration
→ preserve unchanged

Part C configuration omitted
→ FeatureEngineeringConfig(default_profile=training.model_type)
```

This helper centralizes that rule.

Part C itself therefore does not need to guess a profile and Part D does not  
need to know feature-engineering internals.

---

## 6. KPI identity helpers

### `normalize_kpi_name()`

The final implementation requires a KPI identity to be:

```
real string
+
nonblank after trimming
```

Examples:

```
" KPI_A " → "KPI_A"
""        → rejected
"   "     → rejected
None      → rejected
123       → rejected
```

This prevents accidental identities such as:

```
None → "None"
```

from entering persisted workflow state.

Errors are structured as:

```
INVALID_WORKFLOW_KPI_NAME
BLANK_WORKFLOW_KPI_NAME
```

### `safe_kpi_directory_name()`

Once the KPI identity is validated, this helper applies the shared filename  
sanitization convention used by the tested integration pipelines.

The KPI's logical identity remains unchanged; only its filesystem directory name  
is sanitized.

---

## 7. Strict JSON-safe persistence

### `to_json_safe()`

Successful stage result snapshots must be portable JSON because they may be  
reloaded after a process restart or by a later API call.

Supported values include:

- Pydantic models;
    
- dataclasses;
    
- `Path`;
    
- `datetime`;
    
- `date`;
    
- enums;
    
- mappings;
    
- tuples/lists;
    
- sets/frozensets;
    
- normal scalar primitives;
    
- pandas `Timestamp`;
    
- pandas `Timedelta`;
    
- NumPy scalar values.
    

### Finite-float requirement

Standard JSON does not define:

```
NaN
+Infinity
-Infinity
```

The final implementation therefore accepts only finite Python floats.

```
1.25        → persisted
NaN         → rejected
+Infinity   → rejected
-Infinity   → rejected
```

NumPy float scalars are first converted to their Python scalar equivalent and  
then pass through the same finite-float validation.

Error:

```
NON_FINITE_WORKFLOW_FLOAT
```

### Strict pandas scalar handling

The persistence layer accepts only the pandas scalar types actually expected in  
current runner results:

```
pandas.Timestamp
pandas.Timedelta
```

Objects such as:

```
DataFrame
Series
```

are rejected instead of being silently converted into strings.

This preserves the intended rule:

> unsupported opaque runtime objects must not be silently stringified into  
> persisted workflow contracts.

Error:

```
UNSUPPORTED_WORKFLOW_PANDAS_OBJECT
```

Any other unsupported runtime object is rejected as:

```
UNSUPPORTED_WORKFLOW_RESULT_VALUE
```

---

## 8. JSON loading

### `load_json_object()`

A persisted workflow handoff must contain a top-level JSON object.

Arrays, strings, scalars, or other malformed top-level values are rejected  
before reconstruction.

Error:

```
INVALID_WORKFLOW_HANDOFF_JSON
```

---

# 9. `handoffs.py`

`handoffs.py` owns persisted A→B→C→D training handoff contracts.

It does not execute ML runners and does not decide stage lineage.

Its responsibility is:

```
runner result
→ strict JSON snapshot
→ persisted result.json
→ later reconstruction
→ exact runner result object
```

---

## 10. Snapshot envelope

Part A/B/C successful results use:

```
{
  "handoff_schema_version": "1.0",
  "stage": "part_a",
  "payload": {}
}
```

The version is sourced from:

```
settings.workflow_schema_version
```

A later incompatible workflow version can therefore reject an old snapshot  
instead of reconstructing it incorrectly.

---

## 11. Part A handoff

Persisted:

```
dataset_config
eda_result
```

Reconstructed:

```
PartAHandoff
├── dataset_config: DatasetInputConfig
└── eda_result: EDARunnerResult
    └── kpi_results: tuple[KPIEDARunResult, ...]
```

The bucket comes from:

```
eda_result.preparation.bucket
```

rather than being recalculated.

This gives Part B the exact contract proven by the tested A→B pipeline.

---

## 12. Part B handoff

Persisted:

```
dataset_config
bucket
preprocessing_results[]
```

Reconstructed:

```
PartBHandoff
├── dataset_config
├── bucket
└── preprocessing_results:
    tuple[PreprocessingRunnerResult, ...]
```

The same resolved `BucketConfig` from Part A is preserved into the B→C  
boundary.

---

## 13. Part C handoff

Persisted:

```
dataset_config
feature_engineering_results[]
```

Reconstructed:

```
PartCHandoff
├── dataset_config
└── feature_engineering_results:
    tuple[FeatureEngineeringRunnerResult, ...]
```

---

## 14. C → D runner-input bridge

`build_part_d_runner_inputs()` creates one `PartDRunnerInput` per KPI.

Each item contains:

```
kpi_name
input_file
dataset_columns
feature_config
minimum_history_points
metadata
```

Mapping:

```
input_file
= FeatureEngineeringRunnerResult.final_dataset_file

dataset_columns
= DatasetInputConfig.columns

feature_config
= FeatureEngineeringRunnerResult.resolved_config

minimum_history_points
= resolved_config.minimum_history_points
```

The Part D workflow remains responsible for:

```
model_type
training_config
output_directory
```

This exactly preserves the tested Part D runner boundary.

---

## 15. Exact result-object reconstruction

The production system may execute stages in separate requests or processes.

The existing ML runners still expect rich Python objects such as:

```
KPIEDARunResult
PreprocessingRunnerResult
FeatureEngineeringRunnerResult
```

`handoffs.py` therefore reconstructs the exact object graph using known target  
annotations.

It supports:

- dataclasses;
    
- Pydantic models;
    
- nested paths;
    
- tuples/lists/sets/mappings;
    
- union/optional fields;
    
- enums;
    
- datetime/date;
    
- pandas Timestamp/Timedelta scalar fields.
    

Persisted JSON does **not** contain arbitrary importable class names.

This avoids a dynamic type-loading/injection mechanism.

---

## 16. Required-null protection

The final reconstruction behavior is:

```
Optional[T] + persisted null
→ allowed

required T + persisted null
→ rejected
```

A missing required snapshot field therefore cannot silently become `None`.

Failure becomes:

```
WORKFLOW_HANDOFF_RECONSTRUCTION_FAILED
```

---

## 17. Path containment

`handoffs.py` recursively checks reconstructed paths inside:

- Pydantic models;
    
- dataclasses;
    
- mappings;
    
- tuples/lists/sets.
    

Every reconstructed `Path` must remain under:

```
runs/<run_id>/
```

A corrupted snapshot referencing a path outside the owning run is rejected as:

```
WORKFLOW_HANDOFF_PATH_OUTSIDE_RUN
```

This complements Run Management's validation of the `result.json` artifact  
itself.

---

## 18. KPI snapshot validation

Part B and Part C snapshots reject duplicate KPI identities.

Example:

```
KPI_A
KPI_A
```

cannot become a successful persisted stage result.

Error:

```
DUPLICATE_WORKFLOW_KPI_RESULT
```

Cross-stage KPI-set equality is intentionally **not** a serialization  
responsibility.

The individual Part B and Part C workflow files enforce:

```
Part A KPI set = Part B KPI set

Part B KPI set = Part C KPI set
```

before their successful snapshots are persisted.

This keeps:

```
handoffs.py
→ serialization/reconstruction invariants

part_b.py / part_c.py
→ orchestration continuity invariants
```

as separate responsibilities.

---

## 19. Part C → D defensive validation

Before one Part D input is created:

```
minimum_history_points >= 1
```

and:

```
result.feature_columns
==
result.resolved_config.feature_columns
```

must hold.

This catches a corrupted or internally inconsistent Part C result before model  
training starts.

---

## 20. Optuna boundary

There is no Optuna-specific handoff.

Both fixed and tuned training use the same public:

```
run_training(...)
```

entry point.

Hyperparameter tuning remains entirely inside Part D.

---

## 21. Part E exclusion

Part E is intentionally not reconstructed through these handoffs.

```
A → B → C → D
= persisted result-object handoffs

D → inference_bootstrap
= saved inference-state creation

later Part E invocation
= pure saved-run inference lifecycle
```

This preserves the existing Part E architecture rather than forcing it into the  
A/B/C result-object mechanism.

---

## 22. Final sanity expectations

Before freezing this phase, the following behavior is expected:

```
attempt-owned DatasetInputConfig replacement
Part C default profile resolution
explicit Part C config preservation

valid string KPI normalization
non-string KPI rejection
blank KPI rejection

finite float persistence
NaN / ±Infinity rejection
NumPy scalar conversion
pandas Timestamp/Timedelta persistence
DataFrame/Series rejection

A snapshot reconstruction
B snapshot reconstruction
C snapshot reconstruction
required-null rejection
handoff-version rejection
path containment
duplicate KPI rejection
Part C feature-contract validation
C → D argument mapping
```

---

## 23. Final assessment

The final Common + Handoffs phase provides the persistence boundary needed to  
convert the already-tested in-memory A→B→C→D pipeline into independently  
callable production workflows.

Responsibility split:

```
common.py
→ shared workflow mechanics + strict persistence primitives

handoffs.py
→ exact A/B/C result snapshot/reconstruction contracts

Run Management
→ identity, lineage, artifact authority, state

individual workflows
→ actual stage orchestration

ML modules
→ unchanged A/B/C/D algorithms
```

With the final KPI-name and strict-JSON hardening in `common.py`, these two files  
are ready to serve as the baseline for Phase 4.