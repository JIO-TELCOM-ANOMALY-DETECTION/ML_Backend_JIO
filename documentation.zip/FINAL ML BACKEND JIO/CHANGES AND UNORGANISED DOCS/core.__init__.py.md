### Changes made

Added imports and public exports for the new run-management exceptions:

```text
RunManagementError
RunNotFoundError
AttemptNotFoundError
StagePrerequisiteError
StageConflictError
ArtifactResolutionError
RunRegistryError
RunLockError
```

Everything else remains unchanged.

### Documentation note

> `app/core/__init__.py` now exposes the complete run-management exception family through the Core package, allowing later workflow, API, and run-management code to import these exceptions directly from `app.core`.

No behavioral logic was added to the package initializer.