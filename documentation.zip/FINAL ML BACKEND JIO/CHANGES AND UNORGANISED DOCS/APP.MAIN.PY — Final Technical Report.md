# `app/main.py` — Final Technical Report

**File:** `app/main.py`  
**Role:** Production FastAPI application assembly and application entry point.

---

# 1. Purpose

`main.py` is the final application-assembly layer of the current production backend.

Its responsibility is deliberately narrow:

```
create FastAPI application
        ↓
register centralized API error handlers
        ↓
mount all finalized production routers
        ↓
expose `app`
```

It does not implement workflow orchestration, Run Management, filesystem behavior, or Parts A–E ML logic.

The file therefore sits at the top of the backend dependency tree:

```
app/main.py
    ↓
app/api
    ↓
workflows
    ↓
Run Management
    ↓
ML Parts A–E
```

---

# 2. Final File Structure

The implementation imports:

```
from fastapi import FastAPI
```

and from the finalized API package:

```
eda_router
feature_engineering_router
health_router
inference_router
pipeline_router
preprocessing_router
register_error_handlers
runs_router
training_router
```

It also imports:

```
settings
```

from:

```
app.core
```

The module then:

1. creates the FastAPI application;
    
2. registers global error handlers;
    
3. includes the production routers;
    
4. exports only `app`.
    

---

# 3. FastAPI Application Creation

The application is created as:

```
app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    debug=settings.debug,
)
```

This keeps application metadata centralized in Core configuration rather than duplicating values in `main.py`.

The following values therefore come from:

```
app/core/config.py
```

rather than being hardcoded:

```
application name
application version
debug mode
```

---

# 4. Why Core Settings Are Reused

The final application does not hardcode values such as:

```
Telecom Anomaly Detection Backend
0.1.0
False
```

Instead:

```
Core configuration
        ↓
main.py
        ↓
FastAPI
```

This ensures application metadata remains controlled from one shared configuration source.

---

# 5. Central Error Handler Registration

Immediately after application creation:

```
register_error_handlers(
    app
)
```

is called.

This makes the frozen API error policy authoritative for the complete application.

The centralized error layer owns translation of:

```
FastAPI / Pydantic validation failures
known public backend failures
lifecycle conflicts
known caller-owned data errors
unknown backend errors
unexpected Python exceptions
```

into safe HTTP responses.

`main.py` does not implement or duplicate error mapping itself.

---

# 6. Final Error Boundary

At application level, the intended behavior is:

```
validated caller/request problem
→ 422

genuinely missing caller-owned resource
→ 404

workflow/lifecycle conflict
→ 409

unknown/internal backend failure
→ 500
```

Unknown failures remain fail-closed.

The application entry point only registers this policy.

The policy itself remains in:

```
app/api/error_handlers.py
```

---

# 7. Router Registration

All finalized production routers are included explicitly.

The registration order is organized by responsibility:

```
1. health
2. run/attempt inspection
3. standalone training stages
4. complete training pipeline
5. production inference
```

The code therefore reads approximately as:

```
health_router

runs_router

eda_router
preprocessing_router
feature_engineering_router
training_router

pipeline_router

inference_router
```

---

# 8. Health Router

The application mounts:

```
health_router
```

which exposes:

```
GET /health
```

The route remains root-level and is not prefixed again inside `main.py`.

The exact health response is:

```
{
  "status": "healthy"
}
```

The endpoint is a liveness check only.

---

# 9. Run Inspection Router

The application mounts:

```
runs_router
```

which exposes the read-only run-management HTTP surface:

```
GET /api/v1/runs
GET /api/v1/runs/{run_id}
GET /api/v1/runs/{run_id}/attempts/{attempt_id}
```

These endpoints inspect authoritative run/attempt state.

They do not execute ML workflows.

---

# 10. Part A Router

The application mounts:

```
eda_router
```

which exposes:

```
POST /api/v1/eda/run
```

This is the production standalone Part A execution endpoint.

---

# 11. Part B Router

The application mounts:

```
preprocessing_router
```

which exposes:

```
POST /api/v1/preprocessing/run
```

This executes standalone Part B through the workflow/Run Management lifecycle.

---

# 12. Part C Router

The application mounts:

```
feature_engineering_router
```

which exposes:

```
POST /api/v1/feature-engineering/run
```

The route delegates Part C execution without embedding feature-generation logic in `main.py`.

---

# 13. Part D + Bootstrap Router

The application mounts:

```
training_router
```

which exposes:

```
POST /api/v1/training/run
```

The production standalone training lifecycle remains:

```
Part D
    ↓
inference_bootstrap
```

`main.py` only exposes the router.

It does not understand training internals.

---

# 14. Master Pipeline Router

The application mounts:

```
pipeline_router
```

which exposes:

```
POST /api/v1/pipeline/run
```

The workflow below this endpoint remains:

```
Part A
  ↓
Part B
  ↓
Part C
  ↓
Part D
  ↓
inference_bootstrap
```

The application layer does not coordinate these stages directly.

---

# 15. Inference Router

The application mounts:

```
inference_router
```

which exposes:

```
POST /api/v1/inference/run
```

The Part E route receives:

```
run_id
input_file
inference_days
```

and Run Management resolves the authoritative active inference-ready training attempt below the API boundary.

No inference state is resolved inside `main.py`.

---

# 16. Final Endpoint Tree

Once all routers are mounted, the production HTTP surface is:

```
GET  /health

GET  /api/v1/runs
GET  /api/v1/runs/{run_id}
GET  /api/v1/runs/{run_id}/attempts/{attempt_id}

POST /api/v1/eda/run
POST /api/v1/preprocessing/run
POST /api/v1/feature-engineering/run
POST /api/v1/training/run

POST /api/v1/pipeline/run

POST /api/v1/inference/run
```

No temporary test endpoints are registered.

---

# 17. No Extra API Prefix

`main.py` deliberately does not execute:

```
app.include_router(
    router,
    prefix="/api/v1",
)
```

because the production routers already own their final prefixes.

This prevents accidental paths such as:

```
/api/v1/api/v1/pipeline/run
```

The final design is:

```
router owns route prefix
main.py only mounts router
```

---

# 18. No Direct Run Manager Construction

`main.py` does not create:

```
RunManager
```

and does not import:

```
app.run_management
```

The API dependency layer remains responsible for resolving the shared/lazy Run Manager when an endpoint requires it.

This keeps application startup independent from run-registry and Manifest V2 state.

---

# 19. No Direct Workflow Imports

The file does not import:

```
app.workflows
```

Workflow entry points are imported by their corresponding route modules.

The dependency direction remains:

```
main.py
  ↓
API routes
  ↓
workflows
```

rather than:

```
main.py
→ workflows
```

---

# 20. No Direct ML Imports

`main.py` contains no direct dependency on:

```
app.ml.eda
app.ml.preprocessing
app.ml.feature_engineering
app.ml.training
app.ml.inference
```

This is an important architectural boundary.

The application entry point should not know how Part A–E computation is implemented.

---

# 21. No Filesystem Startup Work

The file deliberately does not call:

```
settings.create_base_directories()
```

or create:

```
runs/
logs/
models/
history/
cache/
```

during application import/startup.

Run/service infrastructure creates the required storage when actual backend operations require it.

This keeps FastAPI startup lightweight and avoids coupling application availability to persisted run state.

---

# 22. No Model Loading at Startup

`main.py` does not preload:

```
XGBoost models
Isolation Forest models
saved inference contracts
history caches
training artifacts
```

Models remain loaded according to the downstream training/inference lifecycle.

This preserves the memory design of Part E and prevents startup from scaling with historical runs.

---

# 23. No Run Validation at Startup

The application does not inspect every existing run when starting.

It therefore does not require:

```
every registry entry to be valid
every manifest to be readable
every model to exist
every cache to be consistent
```

for the API process itself to become available.

Individual requests resolve the state they actually need.

---

# 24. No CORS Configuration in V1

`main.py` does not currently add:

```
CORSMiddleware
```

This is deliberate.

No frontend-origin requirement has yet been frozen into the backend architecture.

CORS can be added later when the actual deployment/frontend origin policy is known.

This avoids using permissive defaults such as:

```
allow_origins=["*"]
```

without an explicit requirement.

---

# 25. No Root Welcome Endpoint

The application does not expose an additional:

```
GET /
```

welcome or informational endpoint.

Application liveness is already represented by:

```
GET /health
```

The production HTTP surface therefore contains only required endpoints.

---

# 26. No Temporary Integration Routes

The final application does not mount the earlier development/testing routes:

```
/api/v1/test-pipeline/run
/api/v1/test-inference/run
```

Those temporary endpoints were used to validate earlier integration stages.

Production now uses:

```
/api/v1/pipeline/run
/api/v1/inference/run
```

instead.

---

# 27. `app/api/__init__.py` Relationship

`main.py` imports its routers from:

```
app.api
```

rather than importing every physical route file directly.

`app/api/__init__.py` therefore acts as the stable public application-assembly interface.

Conceptually:

```
app/api individual files
        ↓
app/api/__init__.py
        ↓
app/main.py
```

This keeps `main.py` independent from internal API-package file organization.

---

# 28. Why Router Assembly Lives in `main.py`

Router inclusion is intentionally explicit here.

It does not occur automatically when:

```
import app.api
```

is executed.

This avoids:

```
hidden application mutations
duplicate route registration
circular imports
unclear assembly ownership
```

The final rule is:

```
API package
→ exposes components

main.py
→ assembles application
```

---

# 29. Public Export

The module exposes only:

```
__all__ = [
    "app",
]
```

Therefore the intended public application entry point is:

```
app.main:app
```

This supports a normal ASGI server invocation pattern such as conceptually:

```
uvicorn app.main:app
```

The report only documents the application object contract; deployment-command configuration remains outside this file.

---

# 30. Application Lifecycle Boundary

`main.py` has no custom startup or shutdown handlers.

No application-lifecycle hook currently performs:

```
RunManager construction
model loading
manifest scanning
cache reconstruction
ML initialization
filesystem cleanup
```

The application object is therefore primarily static router/error-handler assembly.

---

# 31. Complete Backend Dependency Direction

The final dependency chain is:

```
app/main.py
      │
      ▼
   app/api
      │
      ▼
  workflows
      │
      ▼
Run Management
      │
      ▼
   Services
      │
      ▼
 ML Parts A–E
```

with Core infrastructure supporting multiple layers.

More practically:

```
HTTP
 ↓
FastAPI app
 ↓
API route
 ↓
workflow
 ↓
Run Management
 ↓
artifact handoff / lifecycle
 ↓
ML computation
```

This layering prevents application assembly from absorbing domain logic.

---

# 32. Training Lifecycle From `main.py`

From the application user's perspective:

```
POST /api/v1/pipeline/run
        │
        ▼
pipeline router
        │
        ▼
master workflow
        │
        ▼
fresh attempt
        │
        ▼
A → B → C → D → bootstrap
        │
        ▼
inference-ready attempt
```

`main.py` participates only by making the route available.

---

# 33. Inference Lifecycle From `main.py`

Similarly:

```
POST /api/v1/inference/run
        │
        ▼
inference router
        │
        ▼
Part E workflow
        │
        ▼
Run Management
        │
        ▼
active inference-ready attempt
        │
        ▼
Part E
```

The application entry point remains unaware of cache/history/model details.

---

# 34. Run Inspection Lifecycle

For observation:

```
GET /api/v1/runs/...
        │
        ▼
runs router
        │
        ▼
Run Management / registry / Manifest V2
        │
        ▼
safe read-only response
```

No training or inference execution occurs through these endpoints.

---

# 35. Health Lifecycle

For liveness:

```
GET /health
        │
        ▼
health router
        │
        ▼
{"status": "healthy"}
```

This route intentionally avoids deeper system readiness checks.

---

# 36. Sanity Check — Syntax

The written file was compiled successfully.

Result:

```
MAIN_PY_SYNTAX = PASS
```

---

# 37. Sanity Check — Core Settings

Static verification confirmed use of:

```
settings.app_name
settings.app_version
settings.debug
```

Result:

```
CORE_SETTINGS_INTEGRATION = PASS
```

---

# 38. Sanity Check — Error Registration

Static verification confirmed:

```
register_error_handlers(app)
```

is called after FastAPI application creation.

Result:

```
ERROR_HANDLER_REGISTRATION = PASS
```

---

# 39. Sanity Check — Router Assembly

The final file includes:

```
health_router
runs_router
eda_router
preprocessing_router
feature_engineering_router
training_router
pipeline_router
inference_router
```

Result:

```
ROUTER_ASSEMBLY = PASS
```

---

# 40. Sanity Check — No Duplicate Prefix

The file does not supply:

```
/api/v1
```

as an additional include-time prefix.

Result:

```
NO_DOUBLE_API_PREFIX = PASS
```

---

# 41. Sanity Check — No Direct ML Dependency

Static verification:

```
from app.ml ...
```

does not exist.

Result:

```
NO_DIRECT_ML_IMPORT = PASS
```

---

# 42. Sanity Check — No Direct Workflow Dependency

Static verification:

```
from app.workflows ...
```

does not exist.

Result:

```
NO_DIRECT_WORKFLOW_IMPORT = PASS
```

---

# 43. Sanity Check — No Direct Run Management Dependency

The file contains no direct:

```
app.run_management
RunManager(...)
```

usage.

Result:

```
NO_DIRECT_RUN_MANAGER = PASS
```

---

# 44. Sanity Check — No Startup Side Effects

The file does not:

```
create base directories
load models
read manifests
scan runs
load inference history
```

during application creation.

Result:

```
STARTUP_SIDE_EFFECT_BOUNDARY = PASS
```

---

# 45. Sanity Check — No Temporary Routes

The file does not reference:

```
test-pipeline
test-inference
```

Result:

```
NO_TEST_ROUTES = PASS
```

---

# 46. Whole-Backend Sanity Context

The final whole-backend architectural regression performed after writing `main.py` also confirmed:

```
API assembly                PASS
API exports                 PASS
central error boundary      PASS
standalone A/B/C            PASS
training D + bootstrap      PASS
master A→B→C→D→bootstrap    PASS
Part E inference            PASS
Run Management contracts    PASS
handoff contracts           PASS
security/path boundaries    PASS
```

No blocking integration conflict was found.

---

# 47. Important Non-Blocking Observation — API Prefix

Core configuration contains:

```
settings.api_prefix
```

with the current default:

```
/api/v1
```

The production routers currently define their own explicit:

```
/api/v1/...
```

prefixes.

Therefore changing `settings.api_prefix` alone in the future would not automatically move those routes.

This is a maintainability observation, not a current defect, because the frozen production prefix and configured default currently agree.

---

# 48. Important Non-Blocking Observation — Old Test Files

Historical temporary route files may still exist elsewhere in the project source/history.

However:

```
app/api/__init__.py
```

does not export them, and:

```
app/main.py
```

does not include them.

Therefore they are not part of the final production HTTP surface.

---

# 49. Responsibility Boundary

The final `main.py` does:

```
FastAPI creation
application metadata wiring
global error-handler registration
router registration
public app export
```

It does **not**:

```
request validation logic
caller CSV validation
run creation
attempt creation
execution creation
manifest mutation
artifact resolution
workflow orchestration
Parts A–E computation
model loading
history/cache mutation
report generation
agent execution
```

Those responsibilities remain in their appropriate lower layers.

---

# 50. Final Compact Contract

```
FILE:
app/main.py

ROLE:
Production FastAPI application assembly.

CREATES:
FastAPI app

METADATA SOURCE:
app.core.settings

REGISTERS:
register_error_handlers(app)

ROUTERS:
health_router
runs_router
eda_router
preprocessing_router
feature_engineering_router
training_router
pipeline_router
inference_router

PUBLIC APPLICATION:
app

FINAL HTTP SURFACE:
GET  /health

GET  /api/v1/runs
GET  /api/v1/runs/{run_id}
GET  /api/v1/runs/{run_id}/attempts/{attempt_id}

POST /api/v1/eda/run
POST /api/v1/preprocessing/run
POST /api/v1/feature-engineering/run
POST /api/v1/training/run
POST /api/v1/pipeline/run
POST /api/v1/inference/run

DOES NOT:
construct RunManager
import workflows directly
import ML directly
create storage at startup
load models at startup
scan manifests
add duplicate /api/v1 prefixes
add temporary test routes
add CORS without requirement
add root welcome endpoint

FINAL SANITY:
syntax                         PASS
Core settings                  PASS
error-handler registration     PASS
router assembly                PASS
no duplicate prefix            PASS
no direct ML dependency        PASS
no direct workflow dependency  PASS
no direct RunManager           PASS
startup boundary               PASS
whole-backend architecture     PASS

BLOCKING ISSUES:
NONE

STATUS:
FROZEN
```

---

# Final Assessment

`app/main.py` correctly completes the application layer without violating any of the responsibility boundaries established during the backend build.

Its final role is simply:

```
assemble
register
mount
expose
```

while all domain behavior remains below it.

With the API module, workflows, Run Management contracts, Parts A–E, and application assembly aligned, the current core training + inference backend is structurally complete.

**Final status: PASS — FROZEN.**