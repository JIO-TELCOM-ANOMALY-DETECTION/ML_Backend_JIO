# Windows Filesystem Reliability Fix — Technical Summary

## 1. Overview

During backend certification testing, particularly during **Level 5 — Master Pipeline Certification**, intermittent Windows filesystem failures were observed while publishing completed Part D training artifacts and inference-bootstrap state.

The failures were non-deterministic. The same pipeline configuration and dataset could fail once and then pass repeatedly without any changes. In successful test periods, the problem could occur only once across many executions, which strongly suggested a transient operating-system-level filesystem condition rather than an application-logic defect.

The most common observed error was:

```text
[WinError 5] Access is denied
```

The affected operations were directory rename/replace operations used as the final atomic publication step.

Examples included:

```text
.training_build
    →
training
```

and:

```text
outputs/inference_state
    →
inference/attempt_0001
```

The final solution preserved the existing atomic staging architecture but introduced a common, bounded retry mechanism for transient Windows filesystem access and sharing errors.

The implementation required changes to three files:

```text
app/services/file_service.py

app/ml/training/model_output.py

app/run_management/manager.py
```

No ML algorithms, model-training logic, schemas, workflow contracts, lifecycle rules, or inference algorithms were modified.

---

# 2. Problem Description

## 2.1 Part D publication failure

Part D intentionally writes all training artifacts into a temporary staging directory:

```text
<output_directory>/
│
├── .training_build/
│   ├── model/
│   ├── split_plan.json
│   ├── training_config.json
│   ├── feature_contract.json
│   ├── final_hyperparameters.json
│   ├── training_summary.json
│   ├── decision_settings.json
│   ├── usable_row_counts.json
│   └── metadata.json
│
└── training/            ← does not exist until publication
```

After every model and metadata artifact has been successfully generated, Part D publishes the package by renaming:

```text
.training_build
    →
training
```

The original implementation used a direct one-shot filesystem operation:

```python
session.staging_directory.rename(
    session.training_directory
)
```

On Windows, this occasionally failed with `WinError 5` even though:

- the source directory existed;
    
- the destination did not already exist;
    
- all model artifacts had been written successfully;
    
- the same operation frequently succeeded on immediate reruns.
    

This meant a fully successful model-training operation could incorrectly become a failed Part D execution only because the final directory publication encountered a short-lived filesystem lock.

---

# 3. Inference Bootstrap Publication Failure

The same class of failure was independently observed in Run Management during inference-bootstrap publication.

Bootstrap first creates the complete inference state inside an execution-specific staging location:

```text
attempts/
└── attempt_0001/
    └── stages/
        └── inference_bootstrap/
            └── execution_0001/
                └── outputs/
                    └── inference_state/
                        ├── inference_config.json
                        ├── history/
                        ├── cache/
                        ├── models/
                        └── inference_results/
```

Once bootstrap has successfully created the complete state, Run Management publishes it to:

```text
runs/<run_id>/inference/attempt_0001/
```

The original implementation used:

```python
staging.replace(stable)
```

The same intermittent Windows error occurred here:

```text
[WinError 5] Access is denied
```

Because inference bootstrap does not perform XGBoost or Isolation Forest training, this was important diagnostic evidence.

It demonstrated that the common failure was not:

```text
XGBoost
Isolation Forest
Optuna
feature engineering
training configuration
dataset content
```

Instead, both failures occurred at the same conceptual boundary:

```text
completed staging directory
        ↓
filesystem rename/replace
        ↓
published final directory
```

---

# 4. Root-Cause Classification

The exact external process temporarily holding the filesystem resource was not conclusively identified.

Potential sources on Windows can include:

```text
Windows Defender
filesystem indexing
temporary OS sharing locks
native library filesystem handles
other filesystem scanners
```

However, the backend-side defect was identifiable:

> A transient Windows sharing/access condition was treated as an immediate permanent application failure.

The original code performed only one rename/replace attempt.

Therefore even a filesystem lock lasting only a few milliseconds could fail an otherwise valid pipeline execution.

The solution was not to remove the staging architecture.

Instead, the solution was:

```text
preserve atomic staging
+
recognize known transient Windows filesystem errors
+
retry the same filesystem operation for a short bounded period
```

---

# 5. Why the Atomic Rename Architecture Was Retained

It would have been possible to remove `.training_build` and write directly into:

```text
training/
```

or create bootstrap state directly inside:

```text
inference/attempt_0001/
```

This was intentionally rejected.

The staging architecture provides an important persistence guarantee.

Without staging:

```text
training/
├── model A written
├── model B written
├── metadata partly written
└── process crashes
```

The directory would exist and could incorrectly appear to downstream components as a completed training package.

With staging:

```text
.training_build/
        ↓
all artifacts successfully completed
        ↓
single final publication operation
        ↓
training/
```

Until the final rename succeeds, no finalized training directory exists.

Therefore the directory rename is effectively a **commit operation**.

The same principle applies to inference bootstrap.

The design was retained because it protects the backend from partially published persistent state.

---

# 6. File 1 — `app/services/file_service.py`

## 6.1 Purpose of the change

`file_service.py` was selected as the common location for generic filesystem reliability behavior.

Before the fix, the module already centralized operations such as:

```text
directory creation
input-file copying
CSV reading/writing
JSON reading/writing
atomic JSON replacement
```

However, retry behavior for transient filesystem operations did not exist.

The fix therefore established this module as the low-level filesystem retry layer.

---

## 6.2 Transient Windows error classification

The retry mechanism was intentionally restricted to known transient Windows filesystem conditions.

The implemented codes are:

```text
WinError 5
ACCESS_DENIED

WinError 32
SHARING_VIOLATION

WinError 33
LOCK_VIOLATION
```

These errors can occur temporarily when another process or the operating system holds an incompatible handle to a file or directory.

The retry system does **not** retry arbitrary filesystem errors.

For example, errors representing:

```text
invalid path
missing source
destination conflicts
invalid filesystem configuration
unsupported operation
```

continue to fail immediately.

This prevents the retry mechanism from hiding genuine application or configuration defects.

> Note: the implemented protection covers WinError **5, 32 and 33**. If “WinError 22” was referenced elsewhere, it should be checked separately because it was not part of this transient-lock classification.

---

# 7. Retry Policy

The retry logic uses bounded exponential backoff.

The operation is first attempted immediately.

If a recognized transient Windows error occurs, subsequent retries approximately follow:

```text
Attempt 1     immediate

Retry 1       50 ms

Retry 2       100 ms

Retry 3       200 ms

Retry 4       400 ms

Retry 5       800 ms
```

Maximum additional waiting time is approximately:

```text
1.55 seconds
```

Therefore:

### Normal filesystem operation

```text
rename
↓
success
↓
continue immediately
```

There is effectively no added latency.

### Temporary Windows lock

```text
rename
↓
WinError 5
↓
wait briefly
↓
retry
↓
success
↓
continue normally
```

### Persistent filesystem problem

```text
rename
↓
WinError 5
↓
bounded retries
↓
still failing
↓
original exception propagated
```

This prevents indefinite waits and preserves genuine failure behavior.

---

# 8. Exception Preservation

A major design requirement was that the new shared helper must not change the backend's existing exception contracts.

The low-level retry helper therefore does not replace the final failure with a new arbitrary exception type.

If retries are exhausted, it re-raises the underlying filesystem error.

This allows the calling layer to preserve its existing domain-specific error handling.

For example:

```text
filesystem helper
↓
retries exhausted
↓
original OSError / PermissionError
↓
RunManager catches it
↓
ArtifactResolutionError
↓
INFERENCE_STATE_PUBLISH_FAILED
```

Therefore existing API and manifest error contracts remain valid.

---

# 9. Atomic JSON Writes Were Also Hardened

`write_json_file()` already used an atomic persistence strategy:

```text
create temporary JSON
        ↓
write complete payload
        ↓
temporary_path.replace(destination_path)
        ↓
final JSON
```

The original implementation used a one-shot:

```python
temporary_path.replace(
    destination_path
)
```

Because this uses the same Windows replace mechanism, it could theoretically encounter the same transient access/share condition.

The shared retry mechanism was therefore also applied to the final temporary-file replacement.

This automatically improves reliability for many backend files, including:

```text
manifest.json
request.json
result.json
error.json
runs.json
stage records
attempt records
inference request records
```

without modifying all modules that call `write_json_file()`.

This also provides additional protection against rare pre-execution persistence failures such as the previously observed case where a new attempt was not committed.

---

# 10. File 2 — `app/ml/training/model_output.py`

## 10.1 Part D final publication

The Part D publication operation was changed from a direct one-shot rename:

```text
.training_build
→
training
```

to the common retry-safe filesystem operation.

The logical behavior remains exactly the same.

Before:

```text
finalize artifacts
↓
Path.rename()
↓
failure immediately on transient Windows lock
```

After:

```text
finalize artifacts
↓
retry-safe atomic move
↓
transient lock → retry
↓
success
```

The following Part D behavior remains unchanged:

```text
model training
XGBoost serialization
Isolation Forest serialization
hyperparameter persistence
training summaries
decision settings
feature contracts
metadata
series identities
final output structure
```

Only the filesystem publication mechanism changed.

---

# 11. Part D Cleanup Hardening

Part D also contains cleanup behavior for a failed output session.

Originally:

```python
shutil.rmtree(
    session.staging_directory
)
```

was used directly.

This operation can also encounter a temporary Windows sharing/access conflict.

Therefore staging-directory cleanup was routed through the same retry-safe filesystem layer.

This prevents situations such as:

```text
actual Part D failure occurs
↓
cleanup begins
↓
temporary Windows lock
↓
cleanup itself throws another filesystem failure
```

The original training error therefore has less chance of being complicated by a secondary cleanup failure.

---

# 12. File 3 — `app/run_management/manager.py`

Two critical publication paths were hardened.

---

## 12.1 Bootstrap forward publication

The primary failing operation was:

```text
execution outputs/inference_state
        ↓
runs/<run_id>/inference/<attempt_id>
```

Previously:

```python
staging.replace(stable)
```

was used directly.

This was replaced with the shared retry-safe filesystem move/replace mechanism.

The existing Run Management behavior remains:

```text
if publication eventually succeeds
→ bootstrap continues

if retries are exhausted
→ RunManager raises
  INFERENCE_STATE_PUBLISH_FAILED
```

Therefore the lifecycle/error contract was preserved.

---

# 13. Bootstrap Rollback Hardening

`manager.py` also contains a reverse operation used if bootstrap state has already been published but a later completion operation fails.

Conceptually:

```text
staging
↓
published stable state
↓
later persistence operation fails
↓
stable state moved back to staging
```

Previously the rollback also used a direct `Path.replace()` operation.

That meant the forward publication could be made retry-safe while the rollback remained vulnerable to exactly the same Windows transient lock.

The rollback was therefore changed to use the same shared retry mechanism:

```text
staging → stable
```

and:

```text
stable → staging
```

now receive equivalent filesystem protection.

This keeps the publication transaction internally consistent.

---

# 14. Run Management Cleanup Hardening

`manager.py` contains several best-effort cleanup paths involving `shutil.rmtree()`.

Examples include cleanup after:

```text
failed run creation
failed attempt preparation
failed stage preparation
failed inference-request preparation
```

These cleanup operations were also routed through the shared retry-safe removal mechanism where appropriate.

The existing semantics remain unchanged:

- critical lifecycle errors are still propagated;
    
- best-effort cleanup remains best-effort;
    
- cleanup failures do not improperly replace the primary domain error.
    

---

# 15. Files That Were Intentionally Not Changed

## `app/workflows/inference_bootstrap.py`

The bootstrap workflow performs:

```python
shutil.copytree(
    source,
    destination,
)
```

while creating the inference-state staging directory.

This file was reviewed but intentionally left unchanged.

No observed production failure occurred at `copytree()`.

Every bootstrap filesystem failure occurred later during:

```text
staged inference state
→
stable inference state
```

Retrying `copytree()` also requires additional partial-copy handling because a failed copy operation can leave part of the destination populated.

Since there was no evidence of failure at this boundary, additional complexity was deliberately avoided.

---

# 16. Files and Logic That Were Not Modified

The fix did not require changes to:

```text
XGBoost training
Isolation Forest training
Optuna tuning
fixed hyperparameter training
Part A
Part B
Part C
Part E inference algorithms
schemas
feature engineering
Run Management lineage
registry semantics
locking architecture
API endpoints
workflow contracts
```

The problem was isolated to filesystem reliability, so the solution remained at that boundary.

---

# 17. Architectural Result

Before the fix, filesystem publication logic was partially decentralized:

```text
model_output.py
    └── Path.rename()

manager.py
    ├── Path.replace()
    └── Path.replace() rollback

file_service.py
    └── Path.replace() for JSON
```

After the fix:

```text
                     file_service.py
                           │
             shared Windows retry logic
                           │
          ┌────────────────┼────────────────┐
          │                │                │
          ▼                ▼                ▼
    JSON publication   directory move   directory cleanup
          │                │
          │          ┌─────┴──────┐
          │          │            │
          ▼          ▼            ▼
      manifests  Part D        Run Manager
      registry   publication   bootstrap
      requests                 publication
      results                  rollback
```

The higher-level modules continue deciding **what** must be published.

`file_service.py` now provides the common mechanism for **how** transient filesystem failures are handled.

---

# 18. Important Preserved Invariants

The following backend guarantees remain unchanged:

### Part D finalization

```text
training/ never represents an incomplete package.
```

### Bootstrap publication

```text
inference/<attempt_id>/ is created only after the complete inference state exists.
```

### Existing destination protection

Existing completed training or inference-state directories are not silently overwritten.

### Atomic JSON persistence

JSON continues to use:

```text
temporary file
→
atomic final replacement
```

### Failure transparency

Persistent filesystem problems still produce real failures.

### No stage-level retry

The entire ML stage is not retrained simply because the final filesystem rename encountered a short temporary lock.

Only the individual filesystem operation is retried.

---

# 19. Validation Results

After implementing the three-file change, the backend underwent repeated Level 5 certification runs.

Previously the failures appeared intermittently across otherwise identical runs.

After the fix, Level 5 was executed approximately **five to six complete times consecutively** without reproducing the filesystem publication failure.

Every run completed successfully.

Level 6 Run Management certification was subsequently executed repeatedly as well and passed consistently.

This provides strong practical evidence that the bounded retry mechanism addressed the transient Windows publication problem without destabilizing Run Management.

---

# 20. Final Outcome

The defect was ultimately classified as a **filesystem reliability issue at atomic publication boundaries**, rather than an ML, inference, pipeline, or Run Management state-machine defect.

The final approach was:

```text
KEEP
atomic staging architecture

ADD
centralized transient Windows retry handling

RETRY
only individual filesystem operations

PRESERVE
existing exception contracts and lifecycle behavior
```

The resulting backend is more tolerant of short-lived Windows filesystem sharing/access conflicts while still failing correctly when a genuine persistent filesystem problem exists.

## Final Modified Files

```text
app/services/file_service.py

app/ml/training/model_output.py

app/run_management/manager.py
```

## Reviewed but Unchanged

```text
app/workflows/inference_bootstrap.py
```

## Confirmed Result

```text
Intermittent Windows publication failure
        ↓
filesystem retry hardening
        ↓
repeated Level 5 PASS
        ↓
repeated Level 6 PASS
        ↓
issue considered resolved
```