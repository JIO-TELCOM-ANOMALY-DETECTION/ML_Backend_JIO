## Goals:

- Design and build the **Reporting + Plotting module** first.
    
- Then design the **final production pipeline/workflow architecture**.
    
- Create the final **workflow schemas**.
    
- Create the final **API routes/endpoints**.
    
- Integrate **run ID + database/run-folder management**.
    
- Create final `app/main.py`.
    
- Perform final end-to-end integration testing.
    

## What is already completed

- **Part A — EDA**
    
    - ML module report completed
        
    - Schema report completed
        
- **Part B — Preprocessing**
    
    - ML module report completed
        
    - Schema report completed
        
- **Part C — Feature Engineering**
    
    - ML module report completed
        
    - Schema report completed
        
- **Part D — Training**
    
    - ML module report completed
        
    - Schema report completed
        
- **Part E — Inference**
    
    - ML module report completed
        
    - Schema report completed
        
- **Shared dataset schema**
    
    - Final technical report completed
        
- **Core module**
    
    - Individual reports for:
        
        - `config.py`
            
        - `exceptions.py`
            
        - `logging_config.py`
            
        - `__init__.py`
            
    - Final Core summary completed
        
- **Services module**
    
    - Individual reports for:
        
        - `file_service.py`
            
        - `run_directory_service.py`
            
        - `run_manifest_service.py`
            
        - `__init__.py`
            
    - Final Services summary completed
        
- **Historical integration/test pipelines**
    
    - A → B
        
    - A → B → C
        
    - A → B → C → D before Optuna
        
    - A → B → C → D after Optuna
        
    - Training + Part E inference
        
    - Individual reports completed
        
    - Combined integration/pipeline synthesis completed
        

## Agreed architecture direction

- A, B, C, D and E remain independent ML modules.
    
- Each stage gets **one reusable workflow**.
    
- Individual API endpoints and the master workflow call those same stage workflows — **no duplicated pipeline logic**.
    
- Validation happens at multiple levels:
    
    - schema/request validation;
        
    - runtime/data validation;
        
    - cross-stage validation.
        
- Expected validation failures should return useful information so the UI can tell the user what to change.
    
- Reporting/plots sit around the ML modules and can participate in stage/master workflows.
    
- **LLM summarizer + email agent come later**, after the core pipeline is complete.
    
- **MCP comes much later** and should simply call the same finished production workflows.
    

## First task in the next chat

Use all completed Part A–E, Core, Services and pipeline reports to determine:

1. What information is already produced at each stage.
    
2. Which reports are actually useful.
    
3. Which plots should exist for A/B/C/D/E and final training/inference.
    
4. What should be saved as artifacts versus returned as UI-ready data.
    

Then implement the **Reporting + Plotting module** before final workflow design.

---
# PLAN:

The central rule is:

> **`app/run_management` owns identity, attempts, execution folders, lineage, lookup and persistence. `app/workflows` owns A→E orchestration. `app/ml` remains completely unaware of runs, users, databases, APIs and retries.**

That fits the current backend well because Core already owns configuration/errors/logging, while Services already own generic files, run directories and manifest persistence.

---

# 1. Final backend layering

```text
                    UI / Scheduler / MCP later
                              │
                              ▼
                        app/main.py
                              │
                              ▼
                         API ROUTES
                              │
                              ▼
                       RUN MANAGEMENT
                 identity / attempts / lineage
                 registry / paths / persistence
                              │
                              ▼
                          WORKFLOWS
                 A / B / C / D / Master / E
                              │
                              ▼
                         ML MODULES
                       existing A → E
                              │
                              ▼
                          SERVICES
                    filesystem / manifest
                              │
                              ▼
                          FILESYSTEM
```

The Run Manager therefore lives **inside `app/`**, but **outside both `services/` and `ml/`**.

Why?

```text
services/
→ low-level mechanics

run_management/
→ meaning of a run/attempt/execution

workflows/
→ what should execute

ml/
→ actual algorithms
```

Your current Services already follow exactly this lower-level separation: directory service answers _where_, file service answers _how to store_, and manifest service answers _what happened_.

---

# 2. Proposed final application structure

```text
app/
│
├── main.py                                  NEW
│
├── core/                                    EXISTING
│   ├── __init__.py
│   ├── config.py                            SMALL UPDATE
│   ├── exceptions.py                        SMALL UPDATE
│   └── logging_config.py
│
├── services/                                EXISTING
│   ├── __init__.py                          UPDATE EXPORTS IF NEEDED
│   ├── file_service.py
│   ├── run_directory_service.py             UPDATE
│   └── run_manifest_service.py              UPDATE
│
├── run_management/                          NEW
│   ├── __init__.py
│   ├── models.py
│   ├── identifiers.py
│   ├── lineage.py
│   ├── locking.py
│   ├── artifact_resolver.py
│   ├── manager.py
│   │
│   └── registry/
│       ├── __init__.py
│       ├── base.py
│       └── local_json.py
│
├── workflows/                               NEW
│   ├── __init__.py
│   ├── common.py
│   ├── handoffs.py
│   │
│   ├── part_a.py
│   ├── part_b.py
│   ├── part_c.py
│   ├── part_d.py
│   │
│   ├── training_pipeline.py
│   ├── inference_bootstrap.py
│   └── part_e.py
│
├── api/                                     NEW
│   ├── __init__.py
│   ├── dependencies.py
│   ├── error_handlers.py
│   │
│   └── routes/
│       ├── __init__.py
│       ├── health.py
│       ├── runs.py
│       ├── eda.py
│       ├── preprocessing.py
│       ├── feature_engineering.py
│       ├── training.py
│       ├── pipeline.py
│       └── inference.py
│
├── schemas/
│   ├── common/                              EXISTING
│   ├── preprocessing/                       EXISTING
│   ├── feature_engineering/                 EXISTING
│   ├── training/                            EXISTING
│   ├── inference/                           EXISTING
│   │
│   └── workflows/                           NEW
│       ├── __init__.py
│       ├── common.py
│       ├── run.py
│       ├── stage_requests.py
│       ├── pipeline.py
│       └── responses.py
│
└── ml/                                      UNCHANGED
    ├── eda/
    ├── preprocessing/
    ├── feature_engineering/
    ├── training/
    └── inference/
```

The existing Part B/C/D/E schema packages remain untouched as the actual ML configuration contracts.

---

# 3. `app/run_management/`

This is the major new module.

## `models.py`

Internal data structures such as:

```text
RunContext
StageExecutionContext
ArtifactReference
RunRecord
AttemptRecord
ExecutionRecord
```

Conceptually:

```text
RunContext
├── run_id
├── attempt_id
├── run_directory
├── attempt_directory
├── employee_code
├── employee_name
├── run_name
└── manifest information
```

And:

```text
StageExecutionContext
├── run_id
├── attempt_id
├── execution_id
├── stage
├── execution_directory
├── request_file
└── prerequisite references
```

These are **internal contracts**, not public API schemas.

---

## `identifiers.py`

Generates:

```text
attempt_id
execution_id
invocation_id
```

Example:

```text
attempt_0001

part_c/
    execution_0001
    execution_0002

inference:
    invocation_000001
```

`run_id` generation itself can continue using the existing `run_directory_service`, which already owns run-ID generation.

---

## `lineage.py`

This contains the rules we just decided.

```text
A completed → cannot change A inside same attempt

B completed → cannot change B inside same attempt

C completed → cannot change C inside same attempt

D completed → cannot change D inside same attempt
```

But:

```text
stage failed
→ may create another execution
→ may correct that stage's request
→ upstream completed stages remain unchanged
```

And:

```text
want to change completed upstream stage
→ create NEW ATTEMPT
→ restart from A
```

It also answers:

```text
Can B run?
→ only if A completed

Can C run?
→ only if B completed

Can D run?
→ only if C completed
```

No fuzzy checking of whether two datasets/configs are "similar enough."

---

## `locking.py`

Very important even in V1.

Prevents two requests from mutating the same run simultaneously.

Especially important for Part E because inference modifies persistent history/cache.

Conceptually:

```text
acquire run lock
    ↓
modify manifest/state
    ↓
release lock
```

One mutable operation per run at a time.

---

## `artifact_resolver.py`

Answers things such as:

```text
Where is the successful Part A result for attempt_001?

Where is B's active result snapshot?

Which Part C execution is authoritative?

Where is the inference-ready training attempt?

Where is inference_config.json?
```

No workflow manually searches directories.

---

## `registry/base.py`

Stable database abstraction.

Conceptually:

```python
create_run(...)
get_run(...)
update_run(...)
run_exists(...)
list_runs(...)
```

The rest of the backend depends on this interface.

---

## `registry/local_json.py`

V1 implementation.

Could store:

```text
<configured registry location>/
└── runs.json
```

containing only lookup/search information:

```text
run_id
run_directory
run_name
employee_code
employee_name
created_at
latest_attempt_id
active_inference_attempt_id
status
```

Exact requests and detailed results remain in the run folder.

Later:

```text
local_json.py
        ↓ replace
mongodb.py
```

and nothing above the registry interface needs to change.

---

## `manager.py`

The public façade of Run Management.

API routes should mainly talk to this file.

Responsibilities:

```text
create/resolve run
create attempt
create execution
save request
copy/snapshot input
check lineage
resolve prerequisites
create execution folders
mark running
call workflow
record success
record failure
update registry
update manifest
return response information
```

This is effectively the **traffic controller**.

---

# 4. Run folder structure

I recommend this:

```text
runs/
└── <run_id>/
    │
    ├── manifest.json
    │
    ├── attempts/
    │   │
    │   ├── attempt_0001/
    │   │   │
    │   │   ├── input/
    │   │   │   ├── source.csv
    │   │   │   └── metadata.json
    │   │   │
    │   │   └── stages/
    │   │       │
    │   │       ├── part_a/
    │   │       │   ├── execution_0001/
    │   │       │   │   ├── request.json
    │   │       │   │   ├── result.json
    │   │       │   │   └── outputs/
    │   │       │   │
    │   │       │   └── execution_0002/
    │   │       │
    │   │       ├── part_b/
    │   │       │   └── execution_0001/
    │   │       │       ├── request.json
    │   │       │       ├── result.json
    │   │       │       └── outputs/
    │   │       │
    │   │       ├── part_c/
    │   │       │   ├── execution_0001/      failed
    │   │       │   │   ├── request.json
    │   │       │   │   ├── error.json
    │   │       │   │   └── outputs/
    │   │       │   │
    │   │       │   └── execution_0002/      successful retry
    │   │       │       ├── request.json
    │   │       │       ├── result.json
    │   │       │       └── outputs/
    │   │       │
    │   │       └── part_d/
    │   │           └── execution_0001/
    │   │               ├── request.json
    │   │               ├── result.json
    │   │               └── outputs/
    │   │
    │   └── attempt_0002/
    │       └── ...
    │
    ├── inference/
    │   │
    │   ├── attempt_0001/
    │   │   ├── inference_config.json
    │   │   │
    │   │   ├── state/
    │   │   │   ├── history/
    │   │   │   └── cache/
    │   │   │
    │   │   └── invocations/
    │   │       ├── invocation_000001/
    │   │       │   ├── request.json
    │   │       │   ├── input/
    │   │       │   └── result.json
    │   │       └── invocation_000002/
    │   │
    │   └── attempt_0002/
    │
    ├── reports/
    ├── agents/
    └── temporary/
```

The exact directory names are **not the architectural contract**.

The contract is:

```text
Run Manager + manifest + artifact resolver
```

So if we later reorganize the physical tree, only those components change.

---

# 5. Why `result.json` is important

The historical pipelines passed:

```text
A → B
KPIEDARunResult object

B → C
PreprocessingRunnerResult object
```

directly in memory.

That works inside one request.

But with separate endpoints:

```text
Tuesday:
run A

Wednesday:
run B
```

the Python A result object no longer exists.

Therefore every successful stage must persist a **workflow result snapshot**.

That is the job of:

```text
app/workflows/handoffs.py
```

It converts:

```text
A result object
→ JSON-safe snapshot
```

and later:

```text
snapshot
→ exact A handoff required by B
```

Same for:

```text
B → C
C → D
```

This is one of the most important pieces of the final architecture.

---

# 6. `app/workflows/`

The workflows remain aware of the ML modules.

The ML modules remain unaware of workflows.

## `common.py`

Shared workflow helpers:

```text
logger selection
result serialization helpers
KPI name handling
workflow utility functions
common metadata
```

---

## `handoffs.py`

Persist/reconstruct cross-stage contracts.

```text
load Part A handoff for B
load Part B handoff for C
load Part C contract for D

save stage result snapshot
validate snapshot version
```

It prevents workflows from guessing filenames.

---

## `part_a.py`

Calls:

```python
run_eda_pipeline(...)
```

Part A runs once.

Produces:

```text
A outputs
+
A result snapshot
```

---

## `part_b.py`

Receives resolved Part A handoff.

Then:

```text
for each KPIEDARunResult
    ↓
run_preprocessing_pipeline()
```

This preserves the proven historical behaviour that A determines the KPI set and B runs once per KPI.

---

## `part_c.py`

Loads successful Part B results.

For each KPI:

```text
PreprocessingRunnerResult
        ↓
run_feature_engineering_pipeline()
```

---

## `part_d.py`

Loads C outputs and extracts:

```text
final_dataset_file
resolved feature config
minimum_history_points
dataset columns
training config
metadata
```

then calls:

```python
run_training(...)
```

This preserves the existing C→D contract.

---

## `inference_bootstrap.py`

This contains the large **D→E finalization logic** demonstrated by Pipeline 5.

It creates:

```text
inference_config.json

raw history
processed history
raw cache
processed cache

saved model contract
storage contract
history contract
```

D→E is already proven to be a persistent saved-state lifecycle rather than a normal result-object handoff.

---

## `part_e.py`

Very thin.

Run Manager resolves:

```text
run_id
    ↓
active inference-ready training attempt
    ↓
saved run state
```

Workflow then calls:

```python
run_inference_pipeline(
    request=...,
    run_directory=...
)
```

Part E already explicitly expects some external service layer to resolve `run_id → run_directory`; Part E itself should not query the registry/database.

---

## `training_pipeline.py`

The master A→D pipeline.

Conceptually:

```text
A
↓
B
↓
C
↓
D
↓
inference bootstrap
```

But critically it uses the **same stage workflow functions** as the standalone endpoints.

There is no:

```text
standalone B implementation
+
master B implementation
```

There is only one B workflow.

---

# 7. Workflow schemas

New package:

```text
app/schemas/workflows/
```

Existing ML schemas remain untouched.

## `common.py`

Shared API concepts:

```text
RunReference
RunOwnerMetadata

run_id
attempt_id
employee_code
employee_name
run_name

StageName
stage status
```

Employee code/name should initially just be metadata.

**No uniqueness requirement yet.**

`run_id` remains the actual unique key.

---

## `run.py`

Responses/query contracts for:

```text
run summary
attempt summary
stage state
execution state
```

Used by the UI to inspect an existing run.

---

## `stage_requests.py`

### Part A

```text
EDAStageRequest
├── run_id | None
├── attempt_id | None
├── run metadata
└── dataset: DatasetInputConfig
```

Semantics:

```text
no run_id
→ new run + new attempt

run_id but no attempt_id
→ new attempt inside existing run

run_id + failed attempt
→ potentially retry failed A
```

---

### Part B

```text
PreprocessingStageRequest
├── run_id
├── attempt_id
└── preprocessing: PreprocessingConfig
```

---

### Part C

```text
FeatureEngineeringStageRequest
├── run_id
├── attempt_id
├── feature_engineering: FeatureEngineeringConfig | None
└── model_type_hint | None
```

The `model_type_hint` solves an important ambiguity.

When C is called standalone and features are omitted, there is no D request yet to tell us whether to use XGBoost or Isolation Forest defaults.

So:

```text
explicit C config
→ use it

C config omitted
→ model_type_hint required
```

Master A→D doesn't need this because it already knows `training.model_type`.

---

### Part D

```text
TrainingStageRequest
├── run_id
├── attempt_id
├── training: TrainingConfig
└── inference_bootstrap
```

Part D still owns its internal train/test evaluation; we're not creating another duplicate model-testing endpoint.

---

## `pipeline.py`

Master request:

```text
TrainingPipelineRequest
├── run_id | None
├── run metadata
├── dataset
├── preprocessing
├── feature_engineering | None
├── training
└── inference_bootstrap
```

This is essentially the production replacement for the historical test-pipeline schema.

---

## `responses.py`

One standard response family.

Successful stage:

```json
{
  "status": "completed",
  "run_id": "...",
  "attempt_id": "...",
  "execution_id": "...",
  "stage": "part_c",
  "message": "Feature engineering completed.",
  "summary": {},
  "next_stage": "part_d",
  "inference_ready": false
}
```

Failure:

```json
{
  "status": "failed",
  "run_id": "...",
  "attempt_id": "...",
  "execution_id": "...",
  "stage": "part_c",
  "error": {
    "error_type": "...",
    "error_code": "...",
    "message": "...",
    "details": {}
  }
}
```

No need to return every physical server path to the UI.

The manifest/run manager retains those.

---

# 8. Final endpoint set

|Endpoint|Purpose|Route file|
|---|---|---|
|`GET /health`|Server health|`api/routes/health.py`|
|`POST /api/v1/eda/run`|Part A only|`eda.py`|
|`POST /api/v1/preprocessing/run`|Part B only|`preprocessing.py`|
|`POST /api/v1/feature-engineering/run`|Part C only|`feature_engineering.py`|
|`POST /api/v1/training/run`|Part D only + inference finalization|`training.py`|
|`POST /api/v1/pipeline/training/run`|Master A→B→C→D|`pipeline.py`|
|`POST /api/v1/inference/run`|Part E invocation|`inference.py`|
|`GET /api/v1/runs/{run_id}`|Run summary/status|`runs.py`|
|`GET /api/v1/runs/{run_id}/attempts/{attempt_id}`|Detailed attempt state|`runs.py`|

Later:

```text
/api/v1/reporting/...
```

can be added completely independently.

Scheduler/LLM/email/MCP also simply call these APIs later.

---

# 9. `app/api/dependencies.py`

Creates/provides shared objects such as:

```text
RunManager
RunRegistryBackend
```

For V1:

```text
RunManager
    ↓
LocalJsonRunRegistry
```

Later:

```text
RunManager
    ↓
MongoRunRegistry
```

Routes never know which storage backend is being used.

---

# 10. `app/api/error_handlers.py`

This is where we finally fix the broad historical:

```text
everything = HTTP 500
```

behaviour.

Recommended mapping:

```text
Pydantic request failure
→ HTTP 422

run / attempt not found
→ HTTP 404

prerequisite stage missing
completed stage cannot be changed
invalid lineage
run currently locked
→ HTTP 409

runtime dataset/input/config error
→ HTTP 400

unexpected backend bug
→ HTTP 500
```

Existing Core exceptions already provide structured `message`, `error_code`, `details` and `to_dict()`, so we should build on that instead of inventing another unrelated error system.

---

# 11. Small Core changes

## `config.py`

Add settings such as:

```text
run_registry_backend
run_registry_path

run_lock_timeout

workflow_schema_version
```

Possibly also add log components:

```text
run_management
eda
feature_engineering
training
inference
```

Current logging is already based on `run_id + component`.

---

## `exceptions.py`

Add a small run/workflow family:

```text
RunManagementError
RunNotFoundError
AttemptNotFoundError
StagePrerequisiteError
StageConflictError
ArtifactResolutionError
```

All still inherit:

```text
TelecomBackendError
```

---

# 12. Services changes

## `file_service.py`

Probably almost no change.

It already provides the generic file mechanics we need.

---

## `run_directory_service.py`

Change the standard production structure from the older simple:

```text
input/
preprocessing/
models/
...
```

toward:

```text
attempts/
inference/
reports/
agents/
temporary/
```

The Run Manager then creates execution-level subfolders.

---

## `run_manifest_service.py`

This deserves the main Services update.

Current manifest already tracks statuses, stage state, outputs, errors, summaries and events with atomic JSON writes.

We extend it to something like Manifest V2:

```text
manifest_version

run_id
run metadata

status

latest_attempt_id
active_inference_attempt_id

attempts
    attempt_0001
        status
        dataset
        stages
            part_a
                status
                active_execution_id
                executions
            part_b
            part_c
            part_d
            inference_bootstrap

inference invocations

outputs
errors
events
summary
```

This becomes the technical truth of the run.

---

# 13. Standalone Part A success flow

```text
POST /eda/run
        ↓
Pydantic validation
        ↓
Run Manager
        ↓
create run if needed
        ↓
create attempt
        ↓
copy/snapshot source dataset
        ↓
create Part A execution folder
        ↓
save request.json
        ↓
manifest:
A = running
        ↓
Part A workflow
        ↓
existing run_eda_pipeline()
        ↓
EDA result
        ↓
write result.json
register output artifacts
        ↓
manifest:
A = completed
        ↓
registry update
        ↓
HTTP success
```

---

# 14. Standalone B/C/D success flow

Example Part C:

```text
POST /feature-engineering/run
        ↓
Run Manager
        ↓
resolve run_id + attempt_id
        ↓
lineage check
        ↓
B must be completed
        ↓
Artifact Resolver
        ↓
find successful B result snapshot
        ↓
create C execution
        ↓
save C request
        ↓
C = running
        ↓
Part C workflow
        ↓
handoffs.py reconstructs
PreprocessingRunnerResult
        ↓
existing Part C ML runner
        ↓
save C result snapshot
        ↓
C = completed
        ↓
HTTP success
```

The ML module only sees the exact inputs it already expects.

---

# 15. Failure and retry

Suppose C fails.

```text
Attempt 001

A ✓
B ✓
C execution_0001 ✗
```

We save:

```text
part_c/
└── execution_0001/
    ├── request.json
    ├── error.json
    └── any partial outputs
```

Manifest:

```text
C = failed
```

The user corrects the C request.

Run Manager sees:

```text
A completed
B completed
C not successfully completed
```

Therefore new C execution is allowed:

```text
part_c/
├── execution_0001   failed
└── execution_0002   running → completed
```

No A/B work is repeated.

---

# 16. Changing an already completed stage

Suppose:

```text
A ✓
B ✓
C ✓
```

and user says:

> Change preprocessing configuration.

Run Manager refuses to modify B inside Attempt 001:

```text
HTTP 409
STAGE_ALREADY_COMPLETED
```

UI can tell them:

> These settings belong to a completed pipeline lineage. Start a new attempt to change preprocessing.

Then:

```text
run_123
├── attempt_0001
└── attempt_0002
      ↓
      start again from A
```

This is the V1 safety rule that prevents silent lineage corruption.

---

# 17. Master A→D flow

```text
POST /api/v1/pipeline/training/run
        ↓
Run Manager
        ↓
new run or new attempt
        ↓
Training master workflow
        ↓
same Part A workflow
        ↓
same Part B workflow
        ↓
same Part C workflow
        ↓
same Part D workflow
        ↓
inference_bootstrap.py
        ↓
inference-ready saved state
        ↓
manifest completed
        ↓
HTTP success
```

If C fails:

```text
A ✓
B ✓
C ✗
D not run
bootstrap not run
```

Request returns failure.

But the attempt stays intact.

The UI can later call:

```text
POST /feature-engineering/run
```

with that exact:

```text
run_id + attempt_id
```

and continue from B.

---

# 18. Part D → Part E finalization

Whether Part D came from:

```text
standalone D endpoint
```

or:

```text
master A→D endpoint
```

the same `inference_bootstrap.py` runs.

Only after bootstrap succeeds does Run Manager set:

```text
active_inference_attempt_id = attempt_0001
inference_ready = true
```

This is important.

A partially trained attempt must **never become the active inference model**.

---

# 19. Retraining under the same run

Later:

```text
run_123
```

gets:

```text
attempt_0002
```

with newer data/settings.

While Attempt 002 is training:

```text
active_inference_attempt_id
    = attempt_0001
```

Only if Attempt 002 fully completes D + bootstrap:

```text
active_inference_attempt_id
    = attempt_0002
```

Old model/state is preserved.

This gives us clean model versioning almost for free.

---

# 20. Part E flow

Public request remains beautifully small, exactly as the Part E design intended:

```text
run_id
input_file
inference_days
```

The current Part E schema was explicitly designed around external run-ID resolution.

Flow:

```text
POST /inference/run
        ↓
Run Manager
        ↓
resolve run_id
        ↓
active_inference_attempt_id
        ↓
resolve inference directory
        ↓
create invocation_id
        ↓
copy incoming file
        ↓
save request.json
        ↓
Part E workflow
        ↓
existing run_inference_pipeline()
        ↓
model inference
        ↓
Part E commits history/cache
ONLY after successful inference
        ↓
save result.json
        ↓
manifest records invocation
        ↓
HTTP success
```

If inference fails:

```text
invocation marked failed

history/cache should remain unchanged
```

which matches the current Part E persistence guarantee.

---

# 21. Server startup

`app/main.py` becomes the **final ASGI application entrypoint**.

Conceptually:

```python
app = FastAPI(...)

register error handlers

include health router
include run router
include EDA router
include preprocessing router
include feature router
include training router
include pipeline router
include inference router
```

Do **not** put:

```python
uvicorn.run(...)
```

inside `main.py`.

Production/dev server starts externally:

```text
uvicorn app.main:app
```

So:

```text
app/main.py
→ defines server application

Uvicorn/Gunicorn/etc.
→ actually launches the process
```

---

# 22. What we are NOT building right now

Keep these outside this phase:

```text
reporting/
plotting/
scheduler/
email agent/
LLM agent/
MCP/
MongoDB
```

But this architecture deliberately gives all of them an easy entry point later:

```text
run_id
    ↓
Run Manager
    ↓
run folder + manifest + artifacts
```

---

# 23. Recommended implementation order

I would build it in this exact sequence:

**Phase 1 — Foundation**

```text
1. workflow schemas
2. Core exception/config additions
3. run-directory changes
4. manifest V2
```

**Phase 2 — Run Management**

```text
5. models.py
6. identifiers.py
7. lineage.py
8. locking.py
9. registry/base.py
10. registry/local_json.py
11. artifact_resolver.py
12. manager.py
```

**Phase 3 — Workflow persistence/handoffs**

```text
13. workflows/common.py
14. workflows/handoffs.py
```

This needs particular care because it is what makes independent A/B/C/D HTTP calls possible.

**Phase 4 — Individual workflows**

```text
15. part_a.py
16. part_b.py
17. part_c.py
18. part_d.py
```

Test each independently before continuing.

**Phase 5 — Training lifecycle**

```text
19. inference_bootstrap.py
20. training_pipeline.py
```

**Phase 6 — Part E**

```text
21. part_e.py
```

**Phase 7 — API**

```text
22. dependencies.py
23. error_handlers.py
24. runs.py
25. eda.py
26. preprocessing.py
27. feature_engineering.py
28. training.py
29. pipeline.py
30. inference.py
31. health.py
```

**Phase 8**

```text
32. app/main.py
```

Then do final integration testing.

---

## Final picture

```text
                         app/main.py
                              │
                              ▼
                            API
                              │
                              ▼
                        Run Manager
             ┌────────────────┼────────────────┐
             ▼                ▼                ▼
          Registry         Manifest         Resolver
             │                │                │
             └────────────────┼────────────────┘
                              ▼
                           Workflow
                 ┌────┬────┬────┬────┐
                 ▼    ▼    ▼    ▼    ▼
                 A    B    C    D    E
                 │    │    │    │    │
                 └────┴────┴────┴────┘
                              │
                              ▼
                          Artifacts
```

This gives us the freedom you wanted: **we can later change folder structure, local JSON → MongoDB, add reporting, introduce scheduling, or improve retries without modifying Parts A–E.**

The first code/design target should now be **`app/schemas/workflows/` + the exact Manifest V2/RunContext contract**, because those become the foundation every subsequent file depends on.


# API Module:

### Job of each file

|#|File|Main responsibility|
|---|---|---|
|22|`dependencies.py`|**API dependency wiring.** Provides shared objects routes need—primarily `RunManager`, application logger, and similar backend dependencies. Routes should obtain infrastructure from here rather than constructing it themselves.|
|23|`error_handlers.py`|**Backend error → HTTP response translation.** Converts our structured Core / Run Management / workflow exceptions into consistent FastAPI HTTP responses. Keeps HTTP semantics out of workflows.|
|24|`runs.py`|**Run-management API endpoints.** Run/attempt/status/manifest-style operations exposed to the UI. It should call Run Management only—not ML modules.|
|25|`eda.py`|HTTP endpoint for **standalone Part A**. Validate `EDAStageRequest` → call `run_part_a_workflow()` → return workflow response.|
|26|`preprocessing.py`|HTTP endpoint for **standalone Part B** → `run_part_b_workflow()`.|
|27|`feature_engineering.py`|HTTP endpoint for **standalone Part C** → `run_part_c_workflow()`.|
|28|`training.py`|Final standalone **training lifecycle endpoint**. Calls `run_training_stage_workflow()` — therefore D + bootstrap/retry logic, not raw `part_d.py` directly.|
|29|`pipeline.py`|**Master training endpoint**: A → B → C → D → bootstrap through `run_training_pipeline()`.|
|30|`inference.py`|**Part E endpoint**. `InferenceRequest` → `run_part_e_workflow()` against the active inference-ready attempt.|
|31|`health.py`|Lightweight **server health/readiness endpoint**. No ML execution and normally no run creation.|

Then:

```text
app/main.py
```

is just the final **FastAPI application assembly**:

```text
create app
↓
configure logging/middleware if required
↓
register error handlers
↓
include all routers
↓
health/API available
```

### Best implementation strategy

I recommend **conceptual groups, but still write and sanity-check one file at a time**:

```text
GROUP 1 — API infrastructure
22. dependencies.py
23. error_handlers.py
→ combined sanity check

GROUP 2 — stage/run routes
24. runs.py
25. eda.py
26. preprocessing.py
27. feature_engineering.py
28. training.py
29. pipeline.py
30. inference.py
31. health.py
→ each file checked individually
→ then complete API-module sanity check

FINAL
32. app/main.py
→ full application/router sanity check
```

This is safer than generating all routes together because a small dependency or schema mistake in `dependencies.py` would otherwise propagate through nine files.

Also, these route files should be **very small**. By design, most should essentially be:

```text
request schema
↓
dependency injection
↓
one workflow call
↓
response schema
```

There should be **no A/B/C/D/E business logic duplicated inside the API layer**.

So next I recommend we start with **`dependencies.py` only**, sanity-check it, then `error_handlers.py`.