# Level 7 Part E Inference Testing Coverage Report

## Telecom Anomaly Detection Backend

**Project:** JIO Internship — Telecom Anomaly Detection Backend  
**Testing Level:** Level 7  
**Primary Scope:** Production Stateful Inference Certification  
**Status:** PASSED

---

## 18.1 Objective

Level 7 was the final functional certification layer.

The key difference from earlier inference tests was that Level 7 did not use a manually prepared fake saved run.

Instead, it created real inference-ready training runs through:

```text
POST /api/v1/pipeline/run
```

and then executed inference through:

```text
POST /api/v1/inference/run
```

The runner was intentionally black-box/external:

```text
no app.* imports
```

The suite contained:

```text
16 cases
```

and used:

```text
7 independently trained baseline runs
```

---

# 19. Level 7 — Production Baseline Creation

Before inference cases were executed, the tester created genuine training baselines through the production master pipeline.

The baseline set covered scenarios such as:

- main XGBoost stateful run;
- Isolation Forest inference;
- multi-KPI XGBoost inference;
- exact gap-ratio boundary behavior;
- above-gap-ratio failure;
- max-gap-days behavior;
- large reconstruction history.

Each baseline therefore had a real:

```text
run_id
attempt_id
inference_config.json
models
raw history
raw cache
processed history
processed cache
```

created by the same backend used in production.

---

# 20. Level 7 — Normal Forward Inference

The suite verified normal inference where new data begins immediately after finalized history.

The expected lifecycle was:

```text
saved training state
        +
new forward raw data
        ↓
history-aware A → B → C
        ↓
saved model
        ↓
row-level inference results
        ↓
successful history/cache commit
```

Successful calls had to advance the persistent histories and caches to exactly the requested finalized end.

---

# 21. Level 7 — XGBoost and Isolation Forest

Both production inference implementations were exercised.

### XGBoost

The test verified that inference used:

- saved model feature order;
- saved XGBoost estimator;
- saved residual threshold(s);
- saved threshold direction;
- no retraining or recalibration.

---

### Isolation Forest

The test verified use of:

- saved Isolation Forest model;
- saved feature contract;
- saved contamination/model decision rule;
- saved directional filtering semantics.

---

# 22. Level 7 — Multi-KPI Inference

A production baseline containing multiple KPIs was used to verify that:

```text
KPI A
  ├── site models
KPI B
  └── site models
```

were all discovered, reconstructed and scored correctly.

The inference state mappings had to cover the trained KPI set consistently.

---

# 23. Level 7 — Repeated Inference on One Saved Run

This was one of the most important Level 7 requirements.

The main XGBoost baseline was deliberately reused across many inference calls.

Conceptually:

```text
Training Run
     │
     ▼
Inference 1
     │
     ▼
history/cache updated
     │
     ▼
Inference 2
     │
     ▼
history/cache updated
     │
     ▼
Inference 3
     │
     ▼
...
```

The final audit required the main run to contain:

```text
exactly 10 unique completed inference invocations
```

This proved that Part E was not merely capable of running once.

It validated long-lived saved-run behavior across repeated state mutation.

---

# 24. Level 7 — Model and Configuration Immutability

Before inference began, the runner calculated hashes of:

```text
inference_config.json
saved model files
```

After successful inference calls, these hashes had to remain identical.

Therefore repeated inference was prohibited from:

- retraining the model;
- replacing the model;
- recalibrating thresholds;
- modifying the saved frozen training contract.

Only history/cache/result state was expected to evolve.

---

# 25. Level 7 — History and Cache Evolution

The runner independently inspected:

```text
raw full history
raw rolling cache
processed full history per KPI
processed rolling cache per KPI
```

For successful calls it verified:

- row count changes;
- minimum/maximum timestamps;
- correct finalized end;
- synchronized raw and processed state;
- cache advancement;
- correct reconstruction delta where applicable.

This did not rely solely on values returned by the inference API.

---

# 26. Level 7 — Late Data Reconstruction

Level 7 tested the Part E reconstruction path.

Supported late data was inserted within the maintained reconstruction window.

The expected behavior was:

```text
late genuine raw observation
        +
existing cache/history
        +
new forward data
        ↓
reconstruction mode
        ↓
rebuild required A → B → C range
        ↓
replace affected processed interval
        ↓
run saved model on requested forward window
        ↓
commit corrected history
```

Coverage included:

- one-day late-data reconstruction;
- mixed late + forward data;
- larger reconstruction scenarios;
- seven-day historical reconstruction coverage.

---

# 27. Level 7 — Historical Data Outside Cache

Historical observations older than the maintained reconstruction cache were tested separately.

The Part E contract treats these as:

```text
ignored historical input
```

rather than allowing an old upload to arbitrarily rewrite deep finalized history.

Valid forward inference can still proceed.

---

# 28. Level 7 — Gap Ratio Boundary

The suite specifically tested the configured:

```text
max_gap_ratio = 0.25
```

boundary.

For 15-minute data:

```text
32 missing bridge points
96 incoming points

32 / (32 + 96)
=
0.25
```

The exact boundary was expected to pass.

A slightly larger bridge:

```text
33 / (33 + 96)
>
0.25
```

was expected to fail.

This was important because boundary mistakes are common when code incorrectly uses:

```text
<
instead of
<=
```

or vice versa.

---

# 29. Level 7 — Maximum Gap Days

The suite separately exercised:

```text
max_gap_days
```

so the day-based gap rule and ratio-based gap rule were both covered.

A request violating the saved gap policy had to fail without changing persistent inference state.

---

# 30. Level 7 — Failure State Must Not Commit

This was another central certification rule.

For failed inference:

```text
persistent raw history
persistent raw cache
persistent processed histories
persistent processed caches
saved models
inference_config.json
published inference results
```

were not allowed to change.

Failure cases could create forensic request/error records, but the finalized inference state had to remain unchanged.

This verified transaction-like behavior:

```text
prepare
        ↓
run A/B/C
        ↓
run models
        ↓
stage outputs
        ↓
commit history
```

with persistent commit occurring only after successful model inference.

---

# 31. Level 7 — Inference Result Publication

Each successful invocation had to publish a result directory containing:

```text
manifest.json
row-level result CSV(s)
```

The published manifest was checked for information such as:

```text
run_id
invocation_id
model_type
inference window
history_committed
completed series
skipped series
outputs
```

The final published manifest had to show:

```text
history_committed = true
```

---

# 32. Level 7 — Manifest V2 Integration

The production runner also inspected the run's Manifest V2 rather than only Part E's local inference result manifest.

It verified:

- completed inference invocation records;
- unique invocation IDs;
- absence of stale running invocation records;
- correct attempt association;
- completed state after successful calls.

The final audit of the main run required exactly the expected number of completed invocations.

---

# 33. Level 7 — Request-Owned Input Files

Inference requests also followed ownership rules.

The test verified that incoming inference source files were copied into backend-owned request storage rather than leaving persistent inference execution dependent on a caller-controlled file path.

This supports future API/UI upload behavior.

---

# 34. Level 7 — Non-Ready Run Rejection

The suite included inference against a run that was not legitimately inference-ready.

The backend had to reject the request rather than attempting to infer merely because a run ID existed.

This verified that inference readiness was tied to valid completed bootstrap state.

---

## Level 7 Result

After all production cases and the final audit passed:

```text
LEVEL 7 — PASSED
```

Level 7 certified:

> A completed training run can be safely reused for repeated future XGBoost or Isolation Forest inference while maintaining correct history/cache state, supporting bounded late-data reconstruction, respecting gap policy, preserving frozen models/contracts and preventing state mutation on failed calls.

---
