# Inference API — Final Technical Report

**File:** `app/api/inference.py`  
**Role:** Production FastAPI boundary for Part E pure inference.

---

# 1. Purpose

`inference.py` exposes the production HTTP endpoint that executes **Part E inference against an already inference-ready logical run**.

Its responsibility is deliberately narrow:

```
caller request
    ↓
InferenceRequest validation
    ↓
prove caller run exists
    ↓
preflight caller-owned inference CSV
    ↓
obtain run-scoped workflow logger
    ↓
delegate once to run_part_e_workflow()
    ↓
InferenceWorkflowResponse
```

The file does not implement Part E inference itself.

It provides the HTTP boundary between:

```
FastAPI
```

and:

```
app.workflows.run_part_e_workflow()
```

The workflow, Run Management layer, and Part E ML module remain responsible for all lifecycle, artifact, history, cache, reconstruction, and prediction behavior.

---

# 2. Final Production Endpoint

The router is:

```
router = APIRouter(
    prefix="/api/v1/inference",
    tags=["inference"],
)
```

The route is:

```
POST /api/v1/inference/run
```

Its response model is:

```
InferenceWorkflowResponse
```

Therefore the final public operation is conceptually:

```
POST /api/v1/inference/run

InferenceRequest
        ↓
InferenceWorkflowResponse
```

---

# 3. Relationship to the Training Pipeline

The training pipeline and the inference route serve different lifecycle roles.

Training finishes with:

```
Part A
  ↓
Part B
  ↓
Part C
  ↓
Part D
  ↓
inference_bootstrap
```

The bootstrap stage publishes the reusable inference state and marks the appropriate completed training attempt as inference-ready.

`inference.py` then consumes that state.

Conceptually:

```
training / pipeline
    ↓
produce inference-ready saved state

inference.py
    ↓
consume active inference-ready saved state
```

The inference API does not rerun training or bootstrap.

---

# 4. Runtime Request Contract

The route consumes the existing production:

```
InferenceRequest
```

from:

```
app.schemas.inference.request
```

The request contains only:

```
run_id
input_file
inference_days
```

There is intentionally no:

```
attempt_id
```

in the public inference request.

This is a major production design rule.

---

# 5. `InferenceRequest.run_id`

`run_id` identifies the logical training run whose active inference-ready attempt should be used.

The schema requires a nonblank run identifier matching the established Part E-compatible run-ID syntax.

The route does not accept another attempt selector.

Run Management resolves the authoritative active inference attempt internally.

---

# 6. `InferenceRequest.input_file`

`input_file` is the new caller-owned raw CSV supplied for the current Part E request.

It can contain:

```
forward inference rows
+
overlapping historical rows
+
accepted/ignored late-data candidates
```

depending on the saved Part E history policy.

The API validates only the generic external-file boundary.

It does not interpret timestamps, forward windows, late data, or history semantics.

---

# 7. `InferenceRequest.inference_days`

The schema requires:

```
inference_days >= 1
```

This numeric rule belongs to the schema.

`inference.py` does not duplicate it.

An invalid value is rejected by normal FastAPI/Pydantic request validation and becomes:

```
REQUEST_VALIDATION_FAILED
→ HTTP 422
```

through the central error handlers.

---

# 8. Response Contract

The route declares:

```
response_model = InferenceWorkflowResponse
```

The response contains the workflow-level Part E identity:

```
status
run_id
training_attempt_id
invocation_id
stage = inference
message
summary
error
```

A physical server path is not part of the public response.

The route does not reshape the workflow response.

---

# 9. Why the API Does Not Accept `attempt_id`

Part E must use the run's authoritative published inference state.

The correct resolution flow is:

```
run_id
   ↓
Run Management
   ↓
active_inference_attempt_id
   ↓
published inference state
```

Allowing the caller to supply an arbitrary training `attempt_id` would bypass that lifecycle contract.

Therefore:

```
InferenceRequest
≠ run_id + attempt_id + input_file + inference_days
```

Instead:

```
InferenceRequest
= run_id + input_file + inference_days
```

This preserves one source of truth for inference activation.

---

# 10. No Public Attempt Validation

Because the request contains no `attempt_id`, the API deliberately does not call:

```
manager.resolve_attempt(...)
```

for Part E.

The route validates only the logical run's public existence.

All active-attempt resolution is delegated to Run Management through the Part E workflow.

---

# 11. Public Run Validation

The helper:

```
_validate_public_run(...)
```

checks only:

```
manager.registry.exists(request.run_id)
```

If the caller-supplied run is genuinely absent, it raises:

```
RunNotFoundError
error_code = API_RUN_NOT_FOUND
```

with safe public detail:

```
run_id
```

The central error mapping converts this to:

```
HTTP 404
```

---

# 12. Why Registry Existence Is Checked at the API Boundary

The route must distinguish:

```
caller requests a run that does not exist
```

from:

```
the registry says the run exists,
but internal run state is technically broken
```

Only the first case is a public 404.

Therefore the API performs a targeted registry membership check solely to establish genuine caller-owned absence.

---

# 13. Registered-but-Broken Run Behavior

Once:

```
manager.registry.exists(run_id) == True
```

the route stops classifying run errors.

If later Run Management discovers:

```
missing manifest
missing run directory
corrupt registry state
broken inference state
artifact resolution failure
```

those failures propagate unchanged.

They are not converted into:

```
API_RUN_NOT_FOUND
```

The central fail-closed error policy therefore normally returns:

```
HTTP 500
```

for such internal failures.

---

# 14. Validation Ordering

The route executes:

```
1. public run validation
2. caller CSV validation
3. logger acquisition
4. Part E workflow
```

Therefore:

```
invalid run
→ rejected before expensive CSV parsing
```

For a valid registered run:

```
caller CSV is fully validated
→ before Part E request state is created
```

---

# 15. Caller-Owned External File Boundary

Part E is different from standalone Parts B/C/D because it receives a new external CSV.

The file belongs to the caller until Run Management creates the inference request snapshot and request-owned input copy.

Therefore generic input-file validation belongs at the HTTP boundary.

---

# 16. Shared File Service

The route reuses:

```
app.services.file_service.read_csv_file()
```

rather than implementing independent filesystem or Pandas parsing logic.

This keeps the API aligned with the same shared file contract already used by the frozen Part A and master-pipeline routes.

---

# 17. External CSV Validation

The API preflight covers:

```
file exists
regular file
.csv extension
non-empty bytes
configured maximum size
configured/default encoding
Pandas CSV parsing
readable columns
non-zero dataframe rows
```

`read_csv_file()` handles the reusable file-service rules.

The route additionally checks:

```
dataframe.empty
```

to reject a successfully parsed zero-row CSV.

---

# 18. Why the CSV Is Fully Parsed

A path-existence check alone cannot prove whether the caller supplied:

```
invalid encoding
malformed CSV
no readable columns
zero rows
```

before Part E creates request state.

Therefore the route intentionally performs a full CSV parse during preflight.

---

# 19. Duplicate Read Is Intentional

A normal successful inference request can read the input more than once:

```
API preflight
    ↓
external caller file parsed

Run Management inference session
    ↓
request-owned copy created

Part E runner
    ↓
copied input processed
```

The preflight dataframe is not reused by the workflow.

This duplicate I/O is intentional V1 behavior because it preserves clean ownership and reproducibility.

---

# 20. Why the Preflight DataFrame Is Discarded

After validation:

```
del dataframe
```

is executed.

The dataframe is not passed into Part E.

The authoritative runtime source becomes Run Management's request-owned copied input, not an in-memory dataframe originating from the external caller path.

This preserves the persisted request boundary.

---

# 21. Frozen External-File Error Map

The route uses the same caller-owned external CSV mapping as the frozen Part A/master-pipeline API contract.

```
FILE_NOT_FOUND
→ API_INPUT_FILE_NOT_FOUND
→ 422
```

```
PATH_IS_NOT_FILE
→ API_INPUT_PATH_NOT_FILE
→ 422
```

```
INVALID_FILE_EXTENSION
→ API_INPUT_FILE_EXTENSION_INVALID
→ 422
```

```
EMPTY_FILE
→ API_INPUT_FILE_EMPTY
→ 422
```

```
FILE_TOO_LARGE
→ API_INPUT_FILE_TOO_LARGE
→ 422
```

```
CSV_PARSE_FAILED
→ API_INPUT_CSV_PARSE_FAILED
→ 422
```

```
CSV_ENCODING_ERROR
→ API_INPUT_CSV_ENCODING_INVALID
→ 422
```

```
EMPTY_CSV
→ API_INPUT_CSV_EMPTY
→ 422
```

A successfully parsed dataframe containing zero rows also becomes:

```
API_INPUT_CSV_EMPTY
→ 422
```

---

# 22. Safe Detail Forwarding

The route does not copy arbitrary low-level file-service details into public errors.

For invalid extension it preserves only:

```
received_extension
allowed_extensions
```

For excessive size it preserves only:

```
file_size_bytes
maximum_size_bytes
maximum_size_gb
```

Fields such as:

```
file_path
original_error
parser internals
```

are deliberately excluded.

The central error handler applies its own detail allowlist as a second safety layer.

---

# 23. Unknown File-Service Failures

If `read_csv_file()` raises a backend error whose code is not in the known caller-owned mapping, `_translate_external_input_error()` re-raises the original exception unchanged.

For example:

```
CSV_READ_FAILED
FILE_SIZE_READ_FAILED
unknown future file-service code
```

are not automatically treated as caller errors.

The central fail-closed handler therefore maps them to:

```
HTTP 500
```

unless another explicit public policy exists.

---

# 24. Why Unknown File Failures Stay Internal

The frozen error architecture is:

```
public 4xx must be proven safe
```

A generic filesystem/OS/service failure does not necessarily mean the caller supplied invalid data.

Therefore the route translates only the exact error codes whose ownership is known at this external-input boundary.

---

# 25. No File Reclassification After Workflow Start

The translation helper is used only around:

```
request.input_file
```

during API preflight.

After:

```
run_part_e_workflow(...)
```

begins, failures involving:

```
request-owned copied input
saved inference config
history
cache
models
manifest
published outputs
```

are backend-owned failures.

They are not incorrectly converted into:

```
API_INPUT_*
```

422 errors.

---

# 26. Part E-Specific Validation Does Not Belong Here

The route deliberately does not validate:

```
forward timestamp availability
requested inference window
history gap duration
history gap ratio
late-data classification
cache sufficiency
saved KPI set
saved feature contract
saved model availability
site usability
model feature order
timestamp continuity
history reconstruction eligibility
```

These belong to the existing Part E workflow/ML/history layers.

---

# 27. Confirmed Part E Caller-Data Errors

The central error handler already recognizes specific Part E runtime conditions as public 422 responses, including:

```
NO_FORWARD_INFERENCE_DATA
NO_FORWARD_DATA_IN_REQUESTED_INFERENCE_WINDOW
INFERENCE_HISTORY_MAX_GAP_DAYS_EXCEEDED
INFERENCE_HISTORY_MAX_GAP_RATIO_EXCEEDED
```

`inference.py` does not manually detect these conditions.

It simply allows the authoritative Part E error to propagate.

---

# 28. Inference Readiness

The API route does not inspect:

```
inference_ready
active_inference_attempt_id
bootstrap execution state
```

directly.

Run Management owns that determination.

If the run has no currently inference-ready attempt, the established lifecycle code:

```
RUN_NOT_INFERENCE_READY
```

is allowed to propagate.

The central error policy maps it to:

```
HTTP 409
```

---

# 29. Why Readiness Is Not Duplicated in the Route

Duplicating readiness checks in `inference.py` would require the API to understand:

```
Manifest V2
active attempt publication
bootstrap state
saved inference directory structure
```

Those responsibilities already belong to Run Management.

The route therefore remains a thin boundary.

---

# 30. Logger Selection

Inference always contains a caller-supplied existing `run_id`.

The route obtains:

```
get_workflow_logger(
    request.run_id,
    component_name="pipeline",
)
```

The `"pipeline"` component is intentional.

The current shared logging configuration contains:

```
pipeline
run_management
preprocessing
xgboost
isolation_forest
reporting
agents
api
```

but no separate `"inference"` component.

Using `"pipeline"` preserves the frozen production logging configuration without modifying Core settings.

---

# 31. No New Logging System

`inference.py` does not:

```
construct Logger directly
create FileHandler
create log directory
invent component name
configure formatter
```

It reuses the existing API dependency/logging infrastructure.

---

# 32. Workflow Delegation

The route ends with exactly one orchestration call:

```
return run_part_e_workflow(
    request=request,
    manager=manager,
    logger=logger,
)
```

This is the most important implementation boundary in the file.

---

# 33. No Direct ML Runner Call

The API does not call:

```
run_inference_pipeline()
```

directly.

That call belongs to:

```
app.workflows.part_e
```

The production layering is therefore:

```
HTTP route
    ↓
Part E workflow
    ↓
Run Management inference_session
    ↓
pure Part E ML runner
```

---

# 34. Why the Workflow Layer Is Required

The Part E workflow owns behavior the API should not duplicate:

```
active inference-ready attempt resolution
run-level locking
request snapshot creation
input copying
runtime request reconstruction
Part E runner execution
invocation-ID validation
runner-result validation
invocation registration
failure persistence
safe workflow response creation
```

Therefore calling the pure ML runner directly from the API would bypass essential lifecycle guarantees.

---

# 35. Run Management Inference Session

`run_part_e_workflow()` enters:

```
manager.inference_session(...)
```

This operation resolves and holds the active inference context for the request.

The session owns:

```
active training attempt resolution
request identity
request snapshot
request-owned input copy
inference-state directory
run lock
failure finalization
```

The API does not reproduce any of this.

---

# 36. Authoritative Runtime Input Copy

The workflow replaces the external caller path with the Run Management-owned copied path before the pure Part E runner executes.

Conceptually:

```
request.input_file
    ↓
Run Management copies input
    ↓
context.input_file
    ↓
new runtime InferenceRequest
    ↓
run_inference_pipeline()
```

This makes persisted request state authoritative after the HTTP boundary.

---

# 37. Saved-State Resolution

`inference.py` never constructs paths such as:

```
runs/<run_id>/inference/<attempt_id>/
```

and never reads:

```
inference_config.json
history/
cache/
models/
inference_results/
```

directly.

The resolution flow remains:

```
run_id
    ↓
Run Management
    ↓
active inference attempt
    ↓
published inference-state directory
    ↓
Part E loader / history / model logic
```

---

# 38. Invocation Identity

Part E uses a real invocation identity such as:

```
invocation_000001
invocation_000002
...
```

The API does not generate this ID.

The pure Part E runner owns the returned invocation ID, and the workflow validates and registers it.

---

# 39. Why the API Cannot Invent Invocation IDs

The public response requires a real:

```
invocation_id
```

If failure happens before Part E produces one, neither the workflow nor API substitutes:

```
request_id
synthetic placeholder
None
```

Instead the original failure propagates to the API error boundary.

This prevents misleading workflow identity.

---

# 40. Part E Failure Boundary

The existing Part E workflow distinguishes three broad cases.

## Before active training attempt resolution

```
no training_attempt_id
```

The workflow cannot truthfully construct `InferenceWorkflowResponse`.

The error propagates to central API handling.

---

## After session/request creation but before a real invocation ID

Run Management records the request-level failure.

The workflow still cannot truthfully create `InferenceWorkflowResponse`, because `invocation_id` is mandatory.

The original error propagates.

---

## After a valid invocation ID exists

The failure can be represented honestly.

The workflow may return:

```
InferenceWorkflowResponse(
    status="failed",
    run_id=...,
    training_attempt_id=...,
    invocation_id=...,
    ...
)
```

The API returns that response unchanged.

---

# 41. Structured Failure vs HTTP Error

A structured failed inference response is different from an API-level error.

### API-level failure

Examples:

```
missing public run
run not inference-ready
invalid caller file
uncaught internal state problem
```

These become HTTP error responses through `error_handlers.py`.

### Structured Part E execution failure

If the workflow has a valid invocation identity and can persist the execution failure, it may return:

```
status = failed
```

inside a normal `InferenceWorkflowResponse`.

The route does not reinterpret it.

---

# 42. Sequential Inference

The API has no special sequential-run logic.

The Part E workflow/runner already implements:

```
invocation 1
    ↓
successful history/cache commit
    ↓
invocation 2 sees updated state
```

Each HTTP call simply delegates to the same authoritative Part E lifecycle.

---

# 43. Run Locking

The Part E workflow keeps the run lock through the complete inference operation.

This serializes stateful inference updates for one logical run and protects shared persistent history/cache state.

`inference.py` does not acquire or release the lock itself.

---

# 44. Late Data

The route does not identify or interpret late data.

The frozen Part E design owns behavior such as:

```
late data outside cache
→ ignored according to history policy
```

and:

```
accepted late data inside reconstruction range
→ temporary reconstruction context
→ reuse A → B → C
→ infer requested forward window
```

This remains completely below the API layer.

---

# 45. A/B/C Reconstruction

Any A/B/C execution during inference is an internal Part E reconstruction workflow.

It is not a rerun of the original training attempt.

The API does not manually call:

```
Part A route
Part B route
Part C route
```

during inference.

---

# 46. No Training Mutation

The inference API never:

```
reruns Part D
reruns inference_bootstrap
changes training configuration
changes active training attempt
recalibrates thresholds
re-trains models
```

It consumes the current active inference-ready saved state.

---

# 47. Pure Inference Model Behavior

The model-specific Part E logic remains unchanged below the route.

Conceptually:

```
saved XGBoost
or
saved Isolation Forest
        ↓
current reconstructed Part C features
        ↓
one site/model at a time
        ↓
saved decision rules
        ↓
inference outputs
```

No model decision mathematics exists inside `inference.py`.

---

# 48. Persistent History/Cache Mutation

The HTTP route never writes history or cache files.

The Part E runner commits persistent history/cache only after required inference execution succeeds according to its frozen transaction-like lifecycle.

The route merely receives the resulting workflow response.

---

# 49. No Physical Path Exposure

The route response model is the workflow response.

The Part E workflow deliberately constructs only safe headline summary information.

Physical locations such as:

```
run directory
inference-state directory
model files
history files
cache files
manifest path
output directory
```

remain internal.

---

# 50. Dependencies

## FastAPI

Used for:

```
APIRouter
route declaration
response-model binding
```

---

## Core

The route imports:

```
InputValidationError
RunNotFoundError
TelecomBackendError
```

These are used only for API-boundary validation/error translation.

---

## Inference Schema

Imports:

```
InferenceRequest
```

This remains the single production runtime request contract for Part E.

---

## Workflow Schemas

Imports:

```
InferenceWorkflowResponse
```

The route does not define a duplicate API-specific success response.

---

## File Service

Imports:

```
read_csv_file
```

to reuse the shared caller-file validation/parsing contract.

---

## Workflows

Imports:

```
run_part_e_workflow
```

which owns the complete production Part E lifecycle.

---

## API Dependencies

Imports:

```
RunManagerDependency
get_workflow_logger
```

The route therefore receives the shared Run Manager through FastAPI dependency injection rather than constructing one itself.

---

# 51. No Direct RunManager Construction

The route receives:

```
manager: RunManagerDependency
```

It does not execute:

```
RunManager()
```

This preserves the shared lazy/cached manager lifecycle defined in `dependencies.py`.

---

# 52. No Direct Run Management Imports

The route does not import:

```
app.run_management.manager
artifact_resolver
locking
registry
manifest helpers
```

directly.

This keeps run lifecycle ownership centralized.

---

# 53. No Direct Part E ML Imports

The route does not import:

```
app.ml.inference.runner
app.ml.inference.history
app.ml.inference.loader
app.ml.inference.validation
app.ml.inference.xgboost
app.ml.inference.isolation_forest
```

This is intentional.

The API depends on the workflow interface, not implementation internals.

---

# 54. HTTP Error Mapping Relationship

`inference.py` creates only the public boundary codes it can prove:

```
API_RUN_NOT_FOUND
API_INPUT_*
```

It does not assign HTTP status codes directly.

The central:

```
app/api/error_handlers.py
```

remains responsible for:

```
404
409
422
500
safe messages
safe details
diagnostic logging
```

---

# 55. Final 404 Behavior

```
unknown caller run
→ API_RUN_NOT_FOUND
→ HTTP 404
```

No attempt-level public 404 exists in this route because no `attempt_id` is accepted.

---

# 56. Final 409 Behavior

Relevant inference lifecycle behavior includes:

```
RUN_NOT_INFERENCE_READY
→ HTTP 409
```

The route does not create this error itself.

It propagates from Run Management/workflow logic.

---

# 57. Final 422 Behavior — Schema

Examples:

```
blank/invalid run_id
missing input_file
invalid inference_days
unexpected extra field
```

are rejected by `InferenceRequest`.

They become:

```
REQUEST_VALIDATION_FAILED
→ HTTP 422
```

---

# 58. Final 422 Behavior — External File

Known caller-owned file problems become:

```
API_INPUT_FILE_NOT_FOUND
API_INPUT_PATH_NOT_FILE
API_INPUT_FILE_EXTENSION_INVALID
API_INPUT_FILE_EMPTY
API_INPUT_FILE_TOO_LARGE
API_INPUT_CSV_PARSE_FAILED
API_INPUT_CSV_ENCODING_INVALID
API_INPUT_CSV_EMPTY
```

and are mapped centrally to:

```
HTTP 422
```

---

# 59. Final 422 Behavior — Part E Data Semantics

Confirmed caller-data conditions generated below the API can also become 422, including:

```
NO_FORWARD_INFERENCE_DATA
NO_FORWARD_DATA_IN_REQUESTED_INFERENCE_WINDOW
INFERENCE_HISTORY_MAX_GAP_DAYS_EXCEEDED
INFERENCE_HISTORY_MAX_GAP_RATIO_EXCEEDED
```

The API route does not duplicate their detection.

---

# 60. Final 500 Behavior

Examples that remain internal include:

```
registered run with broken backend state
manifest corruption
artifact resolution failure
saved inference contract mismatch
missing internal model artifact
history/cache corruption
unexpected Run Management failure
unknown file-service failure
unknown future TelecomBackendError
unexpected Python exception
```

The error handler fails closed to 500.

---

# 61. Security / Information-Boundary Rules

The route follows the frozen production information policy:

```
caller-owned problems
→ explicitly translated only when proven

internal paths/details
→ never exposed by route

unknown backend failures
→ remain internal

workflow physical paths
→ not added to response

caller cannot select arbitrary attempt
→ active inference state remains authoritative
```

---

# 62. Sanity Check — Syntax

Final source check:

```
INFERENCE_API_SYNTAX = PASS
```

The file compiles successfully.

---

# 63. Sanity Check — Architecture

Static verification confirmed:

```
direct app.ml imports                    = NONE
direct app.run_management imports        = NONE
request.attempt_id access                = NONE
run_part_e_workflow calls in route       = EXACTLY 1
workflow logger component                = pipeline
```

Result:

```
INFERENCE_API_ARCHITECTURE = PASS
```

---

# 64. Sanity Check — External File Mapping

The final `_INPUT_FILE_ERROR_MAP` was checked against the already-frozen Part A/master-pipeline contract.

Result:

```
mapping_matches_frozen = True
```

Therefore inference uses the same stable caller-owned CSV policy as the existing production external-file routes.

---

# 65. Sanity Check — Missing Run Ordering

Executable smoke verification confirmed:

```
registry.exists(run_id) = False
        ↓
API_RUN_NOT_FOUND
        ↓
CSV reader is NOT called
```

Result:

```
MISSING_RUN_BEFORE_FILE_VALIDATION = PASS
```

---

# 66. Sanity Check — Known File Translation

Executable smoke verification confirmed:

```
FILE_NOT_FOUND
→ API_INPUT_FILE_NOT_FOUND
```

with no physical path copied into public details.

Result:

```
KNOWN_FILE_TRANSLATION = PASS
```

---

# 67. Sanity Check — Safe Detail Allowlist

For:

```
INVALID_FILE_EXTENSION
```

only:

```
received_extension
allowed_extensions
```

were preserved.

Fields such as:

```
file_path
original_error
```

were discarded.

Result:

```
FILE_DETAIL_ALLOWLIST = PASS
```

---

# 68. Sanity Check — Unknown File Failure

Executable smoke verification confirmed:

```
CSV_READ_FAILED
```

is re-raised unchanged rather than converted into a caller 422.

Result:

```
UNKNOWN_FILE_FAIL_CLOSED = PASS
```

---

# 69. Sanity Check — Zero-Row CSV

A successfully parsed dataframe with zero rows produces:

```
API_INPUT_CSV_EMPTY
```

Result:

```
ZERO_ROW_CSV = PASS
```

---

# 70. Sanity Check — Valid Route Delegation

A valid request was smoke-tested through the route boundary.

Verified:

```
public run check passes
caller CSV validation passes
pipeline logger requested
workflow receives original request
workflow receives injected manager
workflow called exactly once
workflow response returned
```

Result:

```
VALID_ROUTE_DELEGATION = PASS
```

---

# 71. Sanity Check — Router Contract

FastAPI router smoke verification confirmed:

```
path            = /api/v1/inference/run
method          = POST
response_model  = InferenceWorkflowResponse
```

Result:

```
ROUTER_CONTRACT = PASS
```

---

# 72. Regression Against `Context Sharing Advice`

The final file was checked against the frozen production decisions established during the API build.

Required rules:

```
thin HTTP route
no duplicated ML/business logic
no public attempt_id
public run absence only
caller-owned CSV preflight
same API_INPUT_* mapping as external training routes
unknown failures fail closed
pipeline logger
single workflow delegation
Run Management owns active inference attempt
Part E owns invocation ID
no manifest/path guessing
no cache/history mutation in API
no training mutation
structured workflow response preserved
```

Final result:

```
ALL FROZEN INFERENCE API RULES PRESERVED
```

---

# 73. Issues / Observations

## Blocking issues

```
NONE
```

## Important issues

```
NONE
```

## Required code changes

```
NONE
```

## Intentional behaviors

The following are deliberate:

```
full caller CSV is parsed at API preflight
preflight dataframe is discarded
input is later copied/read again below the API
run validation happens before CSV validation
inference readiness is not pre-checked by route
no caller-selected attempt_id
pipeline logger is reused rather than adding an inference logger
unknown low-level file failures remain 500
```

---

# 74. Final Runtime Flow

```
POST /api/v1/inference/run
        │
        ▼
InferenceRequest
        │
        ├── run_id
        ├── input_file
        └── inference_days
        │
        ▼
_validate_public_run()
        │
        ├── unknown run
        │      ↓
        │   API_RUN_NOT_FOUND
        │      ↓
        │     404
        │
        ▼
_validate_external_input_file()
        │
        ├── known caller file failure
        │      ↓
        │   API_INPUT_*
        │      ↓
        │     422
        │
        └── unknown file failure
               ↓
              500
        │
        ▼
get_workflow_logger(
    run_id,
    component_name="pipeline"
)
        │
        ▼
run_part_e_workflow()
        │
        ▼
manager.inference_session()
        │
        ├── resolve active inference-ready attempt
        ├── hold run lock
        ├── create request snapshot
        ├── copy caller input
        └── expose inference-state directory
        │
        ▼
run_inference_pipeline()
        │
        ├── saved contract
        ├── history/cache
        ├── A → B → C reconstruction as required
        ├── model validation
        ├── one-site-at-a-time inference
        ├── output staging/publication
        └── history/cache commit
        │
        ▼
real invocation_id
        │
        ▼
Run Management finalization
        │
        ▼
InferenceWorkflowResponse
```

---

# 75. Final Compact Contract

```
FILE:
app/api/inference.py

RESPONSIBILITY:
Expose the production Part E HTTP endpoint and validate only the
caller-owned request boundary before delegating to the Part E workflow.

PUBLIC INTERFACE:
router

ENDPOINT:
POST /api/v1/inference/run

REQUEST:
InferenceRequest
- run_id
- input_file
- inference_days

RESPONSE:
InferenceWorkflowResponse

PUBLIC RUN RULE:
Unknown registered run
→ API_RUN_NOT_FOUND
→ 404

ATTEMPT RULE:
No public attempt_id.
Run Management resolves active_inference_attempt_id.

CALLER FILE RULE:
Use read_csv_file() preflight.
Known caller-owned failures
→ API_INPUT_* → 422.

UNKNOWN FILE RULE:
Do not guess.
Unknown service/internal failures
→ propagate → fail closed to 500.

LIFECYCLE CONFLICT:
RUN_NOT_INFERENCE_READY
→ workflow/Run Management owned
→ 409.

LOGGER:
get_workflow_logger(
    request.run_id,
    component_name="pipeline",
)

WORKFLOW:
run_part_e_workflow(
    request=request,
    manager=manager,
    logger=logger,
)

API DOES NOT:
- accept attempt_id
- resolve inference state directly
- inspect Manifest V2
- read inference_config.json
- construct saved-state paths
- generate invocation IDs
- classify late data
- reconstruct A/B/C
- run models
- mutate history/cache
- rerun training/bootstrap
- reshape workflow responses

SIDE EFFECTS:
Only those caused by shared CSV preflight and delegated workflow execution.
The route itself does not persist run/inference lifecycle state.

FINAL SANITY:
SYNTAX=PASS
ARCHITECTURE=PASS
FILE_MAPPING=PASS
ERROR_BOUNDARY=PASS
ROUTER_SMOKE=PASS
WORKFLOW_DELEGATION=PASS

BLOCKING ISSUES:
NONE

STATUS:
FROZEN
```

---

# Final Assessment

The production `inference.py` is consistent with the architecture established across the completed API module and with the finalized Part E workflow.

The key separation is correct:

```
API
→ validates the caller-owned boundary

Run Management / workflow
→ owns lifecycle and active saved state

Part E
→ owns inference computation and history progression
```

No blocking issue was found, and no modification is required before proceeding to the remaining production API files.

**Final status: PASS — FROZEN.**