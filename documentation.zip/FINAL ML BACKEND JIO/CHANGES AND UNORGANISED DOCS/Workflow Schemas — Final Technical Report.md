# Workflow Schemas — Final Technical Report

**Package:** `app/schemas/workflows/`

## 1. Purpose

This package is the production schema boundary between:

```text
API / UI
    ↓
Run Management
    ↓
Workflows
    ↓
existing A / B / C / D / E modules
```

It does **not** redefine the ML configuration owned by Parts A–E.

Instead it reuses the existing contracts:

- `DatasetInputConfig` for the shared dataset/Part A contract;
- `PreprocessingConfig` for Part B;
- `FeatureEngineeringConfig` for Part C;
- discriminated XGBoost/Isolation Forest training configs for Part D;
- the existing production `InferenceRequest` for Part E.

This preserves the already-tested A→B→C→D and saved-state→E integration boundaries.

---

## 2. Files

| File | Responsibility |
|---|---|
| `common.py` | Shared IDs, lifecycle status types, run metadata, authoritative Part D training types/union, bootstrap config, structured errors |
| `run.py` | Read-only run/attempt/stage/execution inspection response models |
| `stage_requests.py` | Standalone Part A/B/C/D request contracts |
| `pipeline.py` | Master A→B→C→D training request |
| `responses.py` | Standard standalone, master, inference, and API-error response contracts |
| `__init__.py` | Stable public exports |

---

## 3. Core V1 lifecycle encoded by the schemas

The schemas support the V1 rule:

```text
RUN
└── ATTEMPT
    └── STAGE
        └── EXECUTION
```

A run is long-lived.

A master A→D request always starts a **fresh attempt**.

A failed stage can later receive another execution under the same attempt if
Run Management permits it.

The schema package does not itself decide lineage legality. That belongs to
`app/run_management/lineage.py`.

---

## 4. Identifier contract

`common.py` defines one safe record-ID format reused for:

```text
run_id
attempt_id
execution_id
invocation_id
```

Allowed form:

```text
^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$
```

This mirrors the existing run-directory safety contract and prevents path
separator/traversal-style identifiers at the schema boundary.

---

## 5. Run metadata

`RunMetadata` stores optional descriptive fields:

```text
employee_code
employee_name
run_name
```

These fields are intentionally non-authoritative in V1.

The schemas do not enforce uniqueness or authentication rules.

`run_id` remains the technical identity.

---

## 6. Part D training union

`TrainingConfig` is retained as the proven discriminated union:

```text
XGBoostTrainingConfig
OR
IsolationForestTrainingConfig
```

selected by:

```text
model_type
```

The workflow schemas therefore do not duplicate Part D hyperparameter,
threshold, split, fixed-candidate, or Optuna validation.

---

## 7. Inference bootstrap config

The tested temporary Part-E bootstrap policy is promoted into the production
workflow layer as:

```text
InferenceBootstrapConfig
├── max_gap_days >= 0
├── 0 <= max_gap_ratio <= 1
└── late_data_reconstruction_enabled
```

Defaults remain:

```text
max_gap_days = 0
max_gap_ratio = 0.0
late_data_reconstruction_enabled = True
```

This policy is consumed only after successful Part D training when the workflow
freezes the saved inference state.

---

## 8. Standalone Part A request

`EDAStageRequest`

Fields:

```text
run_id | None
attempt_id | None
run_metadata
dataset: DatasetInputConfig
```

Selection semantics:

```text
no run_id
→ new run + new attempt

run_id only
→ new attempt under existing run

run_id + attempt_id
→ target existing attempt, normally failed-A retry
```

Validation forbids:

```text
attempt_id without run_id
```

Actual permission to retry is still a Run Management decision.

---

## 9. Standalone Part B request

`PreprocessingStageRequest`

```text
run_id
attempt_id
preprocessing: PreprocessingConfig
```

It does not accept:

```text
dataset path
Part A artifact path
Part C config
Part D config
```

Run Management resolves the authoritative successful Part A handoff.

---

## 10. Standalone Part C request

`FeatureEngineeringStageRequest`

```text
run_id
attempt_id
feature_engineering: FeatureEngineeringConfig | None
model_type_hint: "xgboost" | "isolation_forest" | None
```

Rules:

```text
explicit feature_engineering supplied
→ model_type_hint optional

feature_engineering omitted
→ model_type_hint required
```

This is necessary because the historical A→D workflow selected the Part C
default profile from `training.model_type`. A standalone C call has no Part D
training request yet, so it needs the hint when defaults are requested.

---

## 11. Standalone Part D request

`TrainingStageRequest`

```text
run_id
attempt_id
training: TrainingConfig
inference_bootstrap: InferenceBootstrapConfig
```

Successful standalone D execution is followed by saved-state bootstrap.

An attempt becomes inference-ready only after both:

```text
Part D completed
AND
inference_bootstrap completed
```

---

## 12. Master A→D request

`TrainingPipelineRequest`

```text
run_id | None
run_metadata
dataset
preprocessing
feature_engineering | None
training
inference_bootstrap
```

Important rule:

```text
there is NO attempt_id field
```

Therefore every master request is a fresh attempt.

If `run_id` is absent:

```text
create new run
→ create attempt
→ A → B → C → D → bootstrap
```

If `run_id` is supplied:

```text
existing logical run
→ create new attempt
→ A → B → C → D → bootstrap
```

A failed master attempt is resumed through the standalone stage endpoint rather
than by submitting the master request again.

---

## 13. Part C default behavior in master pipeline

When the master request supplies:

```text
feature_engineering = None
```

the workflow must construct the schema-owned Part C profile matching:

```text
training.model_type
```

This preserves the behavior proven by the final A→D integration pipeline.

The workflow schema deliberately does not duplicate Part C's default-profile
implementation.

---

## 14. Part E request

This package does **not** create a second inference request.

Production Part E continues using:

```text
app.schemas.inference.request.InferenceRequest
```

with only:

```text
run_id
input_file
inference_days
```

Run Management resolves:

```text
run_id
→ active_inference_attempt_id
→ run/inference state
```

before the Part E workflow invokes the existing inference runner.

This preserves the existing Part E database/service boundary.

---

## 15. Read-only run inspection

`run.py` defines:

```text
ExecutionView
StageView
AttemptView
RunSummaryResponse
AttemptDetailResponse
```

The read models also include `InferenceInvocationView`, allowing the run summary to expose Part E invocation history already stored by Manifest V2.

These are intended for future endpoints such as:

```text
GET /api/v1/runs/{run_id}

GET /api/v1/runs/{run_id}/attempts/{attempt_id}
```

They expose lifecycle state without exposing raw physical server paths.

---

## 16. Standard workflow responses

`responses.py` defines:

### `StageExecutionSummary`

One execution result:

```text
stage
execution_id
status
summary
error
```

### `StandaloneStageResponse`

Used by A/B/C/D endpoints:

```text
status
run_id
attempt_id
requested_stage
executions
message
next_stage
inference_ready
summary
error
```

The `executions` tuple allows the Part D endpoint to report both:

```text
part_d
inference_bootstrap
```

without creating a special incompatible response shape.

### `TrainingPipelineResponse`

Used by master A→D:

```text
status
run_id
attempt_id
stages
failed_stage
next_stage
inference_ready
summary
error
```

### `InferenceWorkflowResponse`

Used by Part E:

```text
status
run_id
training_attempt_id
invocation_id
stage = inference
message
summary
error
```

### `WorkflowErrorResponse`

Used when API/run-management failure happens before a normal workflow result can
be formed.

---

## 17. Error representation

Normal workflow response errors use:

`WorkflowErrorDetail`

Manifest/run-inspection error history uses:

`WorkflowErrorRecord`

`WorkflowErrorRecord` extends the same core error shape with optional timestamp/scope/attempt/stage/execution/invocation context so Manifest V2 scoped errors can be represented without losing provenance.

```text
error_type
message
error_code
details
```

This shape intentionally mirrors `TelecomBackendError.to_dict()` so the future
API error handlers can translate existing structured backend exceptions without
losing information.

---

## 18. Public-path policy

The new workflow response schemas intentionally do not expose:

```text
run_directory
attempt_directory
execution_directory
model paths
history/cache paths
physical result paths
```

Those remain internal technical details owned by:

```text
Run Manager
Manifest V2
Artifact Resolver
```

The UI receives IDs, statuses, summaries, and structured errors.

---

## 19. Relationship to Manifest V2

The schema status types align with the new manifest lifecycle:

```text
Run:
created
running
partially_completed
completed
failed
cancelled

Attempt:
created
running
partially_completed
completed
failed
cancelled

Stage:
pending
running
completed
failed

Execution / inference invocation:
running
completed
failed
cancelled
```

The schemas model the public contract; `run_manifest_service.py` remains the
persistence implementation.

---

## 20. Responsibility boundary

### `app/schemas/workflows`

Answers:

```text
What does an API caller submit?
What IDs identify run/attempt/execution/invocation state?
What status values are exposed?
What does a standardized response look like?
```

### `app/run_management` (next phase)

Will answer:

```text
Which run/attempt does this request target?
Is this retry legal?
Which artifact is authoritative?
Which folders should be created?
Which manifest records should be changed?
```

### `app/workflows`

Will answer:

```text
Which stages execute and in what order?
How are A→B, B→C, C→D handoffs reconstructed?
When is inference bootstrap called?
```

### `app/ml`

Continues answering:

```text
How does EDA/preprocessing/feature engineering/training/inference actually work?
```

---

## 21. Sanity/compatibility conclusions

The package was written to preserve these tested integration facts:

1. Dataset, Part B, Part C and Part D configuration remain schema-owned by their
   existing modules.
2. Part D remains one discriminated XGBoost/Isolation Forest configuration
   boundary.
3. Omitted Part C configuration in the master workflow is resolved using the
   selected training model's default profile.
4. D→E is persistent saved-state bootstrap, not an immediate in-memory Part E
   call.
5. Part E runtime request remains `run_id + input_file + inference_days`.
6. Physical run-directory lookup is moved out of the request and into the
   future Run Management layer.
7. Workflow response contracts no longer expose test-only server filesystem
   paths.

---

## 22. Package tree

```text
app/
└── schemas/
    └── workflows/
        ├── __init__.py
        ├── common.py
        ├── run.py
        ├── stage_requests.py
        ├── pipeline.py
        └── responses.py
```

This completes the workflow-schema portion of Phase 1.


---

## 23. Post-generation sanity corrections

A final cross-check against the Part D schema and Manifest V2 identified and
corrected two schema-boundary issues:

1. `TrainingModelType` is now imported from the authoritative
   `app.schemas.training.common` contract rather than being re-declared in the
   workflow package.

2. Manifest V2 scoped error records contain provenance fields in addition to the
   base backend error shape. `WorkflowErrorRecord` now represents those records,
   and run/attempt inspection schemas use it.

The run inspection contract was also completed with `InferenceInvocationView`
plus invocation/error collections on `RunSummaryResponse`, matching the Part E
history already persisted by Manifest V2.
