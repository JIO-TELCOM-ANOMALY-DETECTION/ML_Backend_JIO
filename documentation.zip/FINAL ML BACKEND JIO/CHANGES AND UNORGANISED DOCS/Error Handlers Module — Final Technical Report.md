**File:** `app/api/error_handlers.py`  
**Scope:** Internal working and integration of the FastAPI error-handler module  
**Status:** Frozen after v4 sanity and regression checks

---

# 1. Purpose

`app/api/error_handlers.py` is the single FastAPI exception-handling boundary  
for the backend.

Its job is:

```
exception occurs
        ↓
error_handlers.py
        ↓
safe structured HTTP response
```

It does not decide ML behavior, retry behavior, lineage, or manifest recovery.

Those responsibilities remain in their owning modules.

---

# 2. Position in the Backend

```
API route
    ↓
workflow / Run Management / Services / ML
    ↓
exception
    ↓
error_handlers.py
    ↓
WorkflowErrorResponse
    ↓
HTTP client
```

The module is deliberately placed at the outer HTTP boundary.

---

# 3. What the Module Owns

It owns:

```
HTTP status selection
public error message
public error code normalization
public detail filtering
5xx information hiding
FastAPI validation normalization
framework HTTP exception normalization
generic exception fallback
server-side diagnostic-family classification
handler registration
```

---

# 4. What the Module Does NOT Own

It does not:

```
execute workflows
run Part A/B/C/D/E
create runs or attempts
mark stage executions failed
persist Manifest V2 state
repair manifests
resolve artifacts
retry failed stages
activate inference attempts
validate model contracts
perform file copying
perform inference
```

This separation keeps HTTP concerns outside the backend execution layers.

---

# 5. Main Components

The final module contains these main pieces:

```
_PublicErrorPolicy
_PUBLIC_ERROR_POLICIES
DiagnosticFamily
diagnostic_family()
backend_http_status()
public-detail safety helpers
telecom_backend_exception_handler()
request_validation_exception_handler()
http_exception_handler()
unhandled_exception_handler()
register_error_handlers()
```

Each has a narrow responsibility.

---

# 6. `_PublicErrorPolicy`

The module defines an internal frozen policy object:

```
status_code
message
detail_keys
```

Conceptually:

```
_PublicErrorPolicy(
    status_code=404,
    message="The requested run was not found.",
    detail_keys=("run_id",),
)
```

This means the handler owns the public representation of the error.

The original backend exception does not decide which details or message are  
safe to expose.

---

# 7. `_PUBLIC_ERROR_POLICIES`

This is the central explicit public-policy table.

Only codes present in this table can become:

```
404
409
422
```

Every other `TelecomBackendError` becomes 500.

This makes the module fail-closed.

The mapping table is described separately in:

```
Error Mapping — Final Technical Report.md
```

---

# 8. `_normalized_error_code()`

The helper canonicalizes internal/public application codes.

Example:

```
" api_run_not_found "
        ↓
strip
uppercase
        ↓
API_RUN_NOT_FOUND
```

This normalized value is used for:

```
policy lookup
diagnostic-family matching
public approved error_code output
```

Approved 4xx responses therefore have deterministic canonical codes.

---

# 9. `_public_policy()`

This helper:

```
receives TelecomBackendError
        ↓
normalizes error_code
        ↓
looks up _PUBLIC_ERROR_POLICIES
```

Returns:

```
_PublicErrorPolicy
```

or:

```
None
```

`None` means:

```
the error is not explicitly public
→ fail closed to 500
```

---

# 10. `backend_http_status()`

This is the pure HTTP-status resolver.

Logic:

```
policy exists?
    │
    ├── yes → policy.status_code
    │
    └── no  → 500
```

It does not inspect broad exception classes to guess 404/409/422.

That behavior is intentional.

---

# 11. Public Policy Self-Validation

The module validates the policy table during import/tests.

The validator checks:

```
error code:
- nonblank
- trimmed
- uppercase

status:
- only 404 / 409 / 422

message:
- nonblank

detail_keys:
- no duplicates
- no empty keys
- no forbidden diagnostic keys
- no path/file/directory/root keys
```

If someone adds an unsafe public policy, the module raises an error immediately.

This converts security assumptions into executable invariants.

---

# 12. Sensitive Detail Keys

The module treats filesystem-oriented keys as sensitive.

Examples:

```
path
paths
file
files
directory
directories
root
```

and suffixes:

```
*_path
*_paths
*_file
*_files
*_directory
*_directories
*_root
```

Forbidden diagnostic fields include:

```
original_error
traceback
stack_trace
exception
raw_error
```

These should never appear in public 4xx policies.

---

# 13. `_public_json_value()`

Approved public details still need safe serialization.

This helper converts values conservatively.

Supported examples:

```
None
str
int
bool
finite float
date
datetime
Enum
Pydantic BaseModel
dataclass
mapping
sequence
set
frozenset
```

A `Path` becomes:

```
"[redacted]"
```

Non-finite floating-point values become:

```
None
```

Unknown opaque objects become:

```
{
  "type": "ObjectTypeName"
}
```

Their `repr()` is not exposed.

---

# 14. `_public_details()`

This helper enforces **allowlist-first detail handling**.

Flow:

```
backend error.details
        ↓
policy.detail_keys
        ↓
select only approved keys
        ↓
safe JSON conversion
        ↓
public details
```

Example:

Internal details:

```
{
  "run_id": "run_001",
  "run_directory": "/server/runs/run_001",
  "original_error": "registry failure",
  "debug_context": "..."
}
```

Policy:

```
detail_keys = ("run_id",)
```

Public output:

```
{
  "run_id": "run_001"
}
```

Everything else is discarded.

---

# 15. `_error_response()`

This helper renders the common Pydantic response:

```
WorkflowErrorResponse
```

It receives:

```
status_code
WorkflowErrorDetail
optional safe headers
```

and returns:

```
JSONResponse
```

This avoids repeating response-construction logic in every handler.

---

# 16. `telecom_backend_exception_handler()`

This is the main handler for:

```
TelecomBackendError
```

It has two branches.

---

# 17. Approved Public 4xx Branch

If `_public_policy(error)` returns a policy:

```
TelecomBackendError
        ↓
approved public policy
        ↓
warning log
        ↓
fixed public message
canonical error_code
allowlisted details
        ↓
404 / 409 / 422
```

Important:

The handler does **not** return:

```
error.message
```

directly as the public message.

Instead:

```
policy.message
```

is returned.

This prevents an internal developer message from leaking paths or backend  
context.

---

# 18. Internal 500 Branch

If no public policy exists:

```
TelecomBackendError
        ↓
no approved policy
        ↓
diagnostic_family(error)
        ↓
server error log
        ↓
HTTP 500
```

Public response:

```
error_type = original exception class
error_code = original backend error code
message = generic
details = {}
```

The full exception remains server-side.

---

# 19. Server Logging for Backend Errors

Public 4xx errors are logged as warnings.

Conceptually:

```
Public backend error
status
code
type
request method
request path
```

Internal 500s are logged as errors with:

```
diagnostic family
error code
exception type
exception text
traceback when available
request method/path
```

This keeps diagnostics available internally without exposing them publicly.

---

# 20. `DiagnosticFamily`

The module defines server-side failure families:

```
RUN_STATE
REGISTRY
MANIFEST
ARTIFACT
LOCK_INTERNAL
CONFIGURATION
FILE_IO
VALIDATION
MODEL
PIPELINE
INFERENCE_CONTRACT
HISTORY_STATE
REPORTING
AGENT
EMAIL
UNKNOWN
```

This is not an HTTP status.

It is an operational debugging classification.

---

# 21. `diagnostic_family()`

This helper inspects:

```
exception class
+
normalized error_code
```

to decide which subsystem operators should investigate.

Examples:

```
RunRegistryError
→ REGISTRY
```

```
RunManifestError
→ MANIFEST
```

```
ArtifactResolutionError
→ ARTIFACT
```

```
RunLockError
→ LOCK_INTERNAL
```

```
ConfigurationError
→ CONFIGURATION
```

```
generic shared file-service validation code
→ FILE_IO
```

```
unknown InputValidationError
→ VALIDATION
```

```
INFERENCE_MODEL_*
→ INFERENCE_CONTRACT
```

```
HISTORY_* / INFERENCE_HISTORY_*
→ HISTORY_STATE
```

This improves debugging while leaving the public response unchanged.

---

# 22. Why Diagnostic Families Are Not Public

An internal response may conceptually be:

```
HTTP 500
error_code = INFERENCE_PART_C_FEATURE_COLUMNS_MISMATCH
family = INFERENCE_CONTRACT
```

But the API client only receives:

```
HTTP 500
error_code = INFERENCE_PART_C_FEATURE_COLUMNS_MISMATCH
generic message
details = {}
```

The family remains server-side because it is operational metadata.

---

# 23. `request_validation_exception_handler()`

FastAPI/Pydantic validation errors are handled separately.

Example:

```
inference_days expected integer >= 1
caller sends invalid value
```

FastAPI raises:

```
RequestValidationError
```

The handler returns:

```
HTTP 422
error_type = RequestValidationError
error_code = REQUEST_VALIDATION_FAILED
```

Public message:

```
The request did not satisfy the API schema.
```

---

# 24. Safe FastAPI Validation Details

The handler returns only:

```
type
loc
msg
```

for each validation error.

It deliberately excludes:

```
input
ctx
```

because those fields may contain:

```
raw request values
large payload fragments
complex objects
sensitive data
```

---

# 25. Framework `HTTPException` Handling

Framework/router HTTP exceptions use a separate handler.

Examples:

```
404
401
405
```

The handler does not trust:

```
HTTPException(detail="...")
```

for public text.

Instead the message is derived only from the HTTP status.

Examples:

```
401 → Unauthorized
404 → Not Found
405 → Method Not Allowed
```

This blocks arbitrary internal detail strings from being reflected.

---

# 26. Framework Header Filtering

The handler also filters:

```
HTTPException.headers
```

Only these headers are permitted:

```
WWW-Authenticate
Allow
Retry-After
```

Reason:

```
WWW-Authenticate
→ authentication challenge

Allow
→ method information for 405

Retry-After
→ retry timing
```

Arbitrary headers are discarded.

Examples blocked:

```
X-Internal-Path
X-Debug-Token
X-Internal-Auth
```

---

# 27. `_public_http_exception_headers()`

This helper receives arbitrary framework headers.

It:

```
normalizes header name
        ↓
checks explicit allowlist
        ↓
keeps only approved headers
```

If no approved headers remain:

```
None
```

is returned.

---

# 28. `_http_exception_message()`

This helper derives a fixed human-readable phrase from:

```
HTTP status code
```

using the standard HTTP reason phrase.

Examples:

```
404 → Not Found
405 → Method Not Allowed
```

It never reflects arbitrary exception detail text.

---

# 29. `unhandled_exception_handler()`

This is the last-resort handler for:

```
Exception
```

that does not belong to the known structured backend hierarchy.

Server side:

```
full traceback logged
```

Public side:

```
HTTP 500
error_type = InternalServerError
error_code = INTERNAL_SERVER_ERROR
message = An unexpected internal server error occurred.
details = {}
```

No original Python exception text is exposed.

---

# 30. `register_error_handlers()`

The module exposes one application-registration function:

```
register_error_handlers(app)
```

It registers handlers for:

```
TelecomBackendError
RequestValidationError
StarletteHTTPException
Exception
```

`app/main.py` should call this exactly once during FastAPI application assembly.

---

# 31. Handler Registration Flow

Conceptually:

```
FastAPI app created
        ↓
register_error_handlers(app)
        ↓
backend exception policies become active
```

No route should need to manually register its own version of these handlers.

---

# 32. Route Responsibility

The route layer has one critical responsibility introduced by the final  
fail-closed design:

```
translate genuinely caller-owned boundary errors
into unambiguous API_* codes
```

Example:

```
caller requests missing run
        ↓
RunManager raises RUN_NOT_FOUND
        ↓
route knows the caller performed this lookup
        ↓
route translates to API_RUN_NOT_FOUND
        ↓
error handler returns 404
```

---

# 33. File Boundary Translation

Example:

```
caller input CSV
        ↓
file_service emits CSV_PARSE_FAILED
        ↓
route knows this is external request input
        ↓
translate to API_INPUT_CSV_PARSE_FAILED
        ↓
handler returns 422
```

If the same failure occurs on an internal cache file:

```
CSV_PARSE_FAILED
        ↓
no route translation
        ↓
500
```

---

# 34. Why Translation Does Not Belong Inside `error_handlers.py`

The handler receives:

```
exception
```

but may no longer know:

```
which file was caller-owned
which lookup was caller-requested
which missing state was internal
```

The route has that context.

Therefore:

```
route decides ownership
error handler decides public representation
```

This is a clean separation of responsibilities.

---

# 35. Relationship with Core Exceptions

Core `exceptions.py` defines the backend exception vocabulary.

It owns:

```
exception classes
message
error_code
details
```

It does not own:

```
HTTP status
public wording
public detail selection
FastAPI registration
```

`error_handlers.py` performs that translation at the API boundary.

---

# 36. Relationship with Run Management

Run Management owns:

```
runs
attempts
stage executions
inference sessions
registry
manifest
locks
lineage
artifact resolution
failure persistence
```

The error handler does not mutate any of these.

It only receives exceptions after Run Management has already made the  
appropriate lifecycle decision.

---

# 37. Relationship with Workflows

Workflows own:

```
A/B/C/D orchestration
training pipeline
bootstrap
Part E wrapper
```

A workflow may:

```
return a structured failed workflow response
or
propagate a backend exception
```

Propagated backend exceptions reach the FastAPI handler.

The handler does not duplicate workflow logic.

---

# 38. Relationship with Services

Services provide low-level operations such as:

```
file reading/writing
run directory mechanics
manifest mechanics
```

Their generic error codes remain context-neutral.

The error handler intentionally does not assume a service failure belongs to  
the caller.

This is why API-boundary translation exists.

---

# 39. Relationship with `dependencies.py`

`error_handlers.py` imports:

```
get_api_logger()
```

from:

```
app/api/dependencies.py
```

The handler uses the shared process-level API logger for:

```
public warning logs
internal backend error logs
unexpected exception logs
framework HTTP logs
validation logs
```

It does not construct a separate logging subsystem.

---

# 40. Relationship with `app/main.py`

`main.py` should contain only application assembly:

```
create FastAPI app
register error handlers
include routers
configure application middleware/startup
```

Error mapping must not be duplicated inside `main.py`.

The only error-handler-specific action required is:

```
register_error_handlers(app)
```

---

# 41. Complete Runtime Flow — Known Public Error

```
request
   ↓
route/workflow
   ↓
TelecomBackendError
   ↓
telecom_backend_exception_handler
   ↓
_public_policy
   ↓
policy exists
   ↓
warning log
   ↓
fixed message
canonical error_code
allowlisted details
   ↓
JSONResponse 404/409/422
```

---

# 42. Complete Runtime Flow — Internal Backend Error

```
request
   ↓
backend
   ↓
TelecomBackendError
   ↓
telecom_backend_exception_handler
   ↓
_public_policy
   ↓
None
   ↓
diagnostic_family
   ↓
server error log
   ↓
generic message
specific error_code
details={}
   ↓
HTTP 500
```

---

# 43. Complete Runtime Flow — FastAPI Schema Error

```
request
   ↓
Pydantic validation
   ↓
RequestValidationError
   ↓
request_validation_exception_handler
   ↓
safe validation summary
   ↓
HTTP 422
REQUEST_VALIDATION_FAILED
```

---

# 44. Complete Runtime Flow — Framework 404

```
unknown route
   ↓
Starlette HTTPException(404)
   ↓
http_exception_handler
   ↓
message derived from 404
   ↓
Not Found
   ↓
HTTP_404
```

Arbitrary `detail` is ignored.

---

# 45. Complete Runtime Flow — Unknown Python Error

```
unexpected Python exception
   ↓
unhandled_exception_handler
   ↓
traceback logged
   ↓
generic public response
   ↓
500 INTERNAL_SERVER_ERROR
```

---

# 46. Security Model

The final module protects against four main information leaks.

## Raw backend message leak

Prevented by:

```
fixed 4xx policy messages
generic 5xx messages
```

## Detail leak

Prevented by:

```
per-policy detail allowlist
```

## Filesystem path leak

Prevented by:

```
no path keys in public policies
Path redaction as defense in depth
```

## Framework leak

Prevented by:

```
HTTPException.detail ignored
HTTPException headers allowlisted
```

---

# 47. Regression-Tested Behavior

Final v4 regression tests confirmed:

```
API_RUN_NOT_FOUND              → 404
RUN_NOT_FOUND                  → 500

API_ATTEMPT_NOT_FOUND          → 404
ATTEMPT_NOT_FOUND              → 500

known lifecycle codes          → 409

API_INPUT_*                    → 422
API_INPUT_CSV_*                → 422

generic file-service codes     → 500

confirmed Part E input codes   → 422
uncertain Part E codes         → 500

RUN_LOCK_TIMEOUT               → 500

unknown backend code           → 500

Pydantic validation            → 422

canonical public error codes   → enforced

unapproved details             → discarded

HTTPException.detail           → ignored

WWW-Authenticate               → preserved
Allow                          → preserved
Retry-After                    → preserved

arbitrary HTTP headers         → discarded
```

---

# 48. Public Module Interface

The file publicly exports:

```
DiagnosticFamily
backend_http_status
diagnostic_family
telecom_backend_exception_handler
request_validation_exception_handler
http_exception_handler
unhandled_exception_handler
register_error_handlers
```

Internal helpers remain private.

---

# 49. Final Compact Module Contract

```
FILE:
app/api/error_handlers.py

ROLE:
central FastAPI exception translation boundary

INPUT:
backend/framework exceptions

OUTPUT:
safe WorkflowErrorResponse JSON responses

BACKEND ERROR POLICY:
explicitly approved public code → 404/409/422
anything else → 500

PUBLIC 4xx:
fixed message
canonical error_code
explicit detail allowlist

PUBLIC 500:
generic message
specific internal error_code
no details

DIAGNOSTICS:
server-side DiagnosticFamily

FRAMEWORK VALIDATION:
RequestValidationError → 422

FRAMEWORK HTTP:
status preserved
reason phrase only
detail ignored
headers filtered

UNKNOWN EXCEPTION:
500 INTERNAL_SERVER_ERROR

SIDE EFFECT:
server logging

DOES NOT:
execute workflows
mutate run state
persist stage failure
repair manifest
retry
run ML
```

---

# Final Assessment

`app/api/error_handlers.py` is a deliberately small but security-critical  
boundary.

Its implementation follows three principles:

```
1. Fail closed.
2. Expose only deliberately approved information.
3. Keep HTTP/public behavior separate from backend execution semantics.
```

The separate error-mapping document defines **which codes belong to which HTTP  
status**.

This document defines **how the module enforces that mapping safely at runtime**.

**Final status: Frozen implementation contract.**