# Training API — Final Technical Report

**File:** `app/api/training.py`  
**Final implementation:** v1  
**Module:** `app/api/`  
**Status:** Final sanity checked — PASS / suitable to freeze  
**Primary role:** Production HTTP endpoint for the final standalone training lifecycle: **Part D → inference bootstrap → inference-ready attempt**.

---

# 1. Purpose

`training.py` is the API-layer entry point for finalizing training inside an existing attempt.

Its endpoint does **not** represent only raw Part D execution.

The final production lifecycle is:

```
Part D training
        ↓
inference_bootstrap
        ↓
published saved Part-E state
        ↓
attempt becomes inference-ready
```

The route itself remains intentionally small:

```
HTTP request
    ↓
Pydantic request validation
    ↓
caller-owned run / attempt validation
    ↓
run-scoped workflow logger
    ↓
run_training_stage_workflow(...)
    ↓
StandaloneStageResponse
```

---

# 2. Architectural Position

```
Client / UI
    ↓
POST /api/v1/training/run
    ↓
app/api/training.py
    ↓
run_training_stage_workflow()
    ├── run_part_d_workflow()
    └── run_inference_bootstrap_workflow()
            ↓
Run Management
            ↓
ML training + Services + saved inference state
```

The route delegates the D/bootstrap lifecycle rather than reproducing it.

---

# 3. Router Contract

Router prefix:

```
/api/v1/training
```

Endpoint:

```
POST /api/v1/training/run
```

Request:

```
TrainingStageRequest
```

Response:

```
StandaloneStageResponse
```

---

# 4. Request Contract

The final standalone training request contains:

```
run_id
attempt_id
training
inference_bootstrap
```

where:

```
training
→ XGBoostTrainingConfig
OR
→ IsolationForestTrainingConfig
```

and:

```
inference_bootstrap
→ InferenceBootstrapConfig
```

The request always targets an existing run and attempt.

---

# 5. Why the Training Request Includes Bootstrap Policy

Part D by itself produces trained model artifacts.

That is not yet enough for production Part E inference.

The completed training attempt must also be converted into a self-contained saved inference contract containing:

```
inference_config.json
history
cache
models
storage contract
dataset contract
preprocessing contract
feature-engineering contract
```

Therefore standalone training finalization includes both:

```
Part D
+
inference_bootstrap
```

---

# 6. Important Final Design Rule

The production API route must call:

```
run_training_stage_workflow()
```

not:

```
run_part_d_workflow()
```

directly.

`run_part_d_workflow()` remains the canonical lower-level Part D stage.

The composed training workflow is the final standalone training-endpoint behavior.

---

# 7. Why Direct Part D Delegation Would Be Wrong

If the API called only Part D:

```
Part D completed
bootstrap failed later
```

a subsequent training request could incorrectly attempt to rerun immutable completed D.

The composed lifecycle avoids that.

It inspects persisted state before deciding what to launch.

---

# 8. Final Standalone Lifecycle Cases

`run_training_stage_workflow()` handles four principal persisted states.

## Case A — Part D incomplete / failed

```
run or retry Part D
        ↓
if D succeeds
        ↓
run inference_bootstrap
```

## Case B — Part D completed, bootstrap incomplete / failed

```
reuse completed Part D
        ↓
run bootstrap only
```

## Case C — Part D and bootstrap both completed

```
TRAINING_ATTEMPT_ALREADY_INFERENCE_READY
```

The lifecycle is already complete.

## Case D — bootstrap completed while Part D is incomplete

```
INCONSISTENT_TRAINING_LIFECYCLE
```

This is internally inconsistent persisted state.

---

# 9. Public Run Validation

Before entering the training workflow, the API checks:

```
manager.registry.exists(request.run_id)
```

If the caller references a run that is genuinely not registered:

```
API_RUN_NOT_FOUND
→ HTTP 404
```

Safe detail:

```
run_id
```

---

# 10. Why Low-Level `RUN_NOT_FOUND` Is Not Automatically 404

A later run-resolution failure can mean:

```
registry knows the run
but
manifest/directory/backend state is broken
```

That is not caller-owned absence.

Therefore the API only creates:

```
API_RUN_NOT_FOUND
```

at the explicit caller-owned lookup boundary.

Later low-level run errors remain internal.

---

# 11. Public Attempt Validation

After the run exists, the route performs:

```
manager.resolve_attempt(
    run_id,
    attempt_id,
)
```

If the exact caller-requested attempt is absent:

```
AttemptNotFoundError
        ↓
API_ATTEMPT_NOT_FOUND
        ↓
HTTP 404
```

Safe details:

```
run_id
attempt_id
```

---

# 12. Why Only Missing Attempt Is Translated

`resolve_attempt()` may also expose internal technical failures such as:

```
missing immutable attempt input
missing persisted request
manifest inconsistency
path containment failure
registered run corruption
```

Those are not public 404s.

The route therefore catches only `AttemptNotFoundError`.

---

# 13. No External CSV Validation

`training.py` accepts no new training dataset file.

Its data lineage is already persisted through successful upstream stages.

Conceptually:

```
Part C completed
        ↓
C→D persisted handoff
        ↓
Part D training
```

Bootstrap additionally reloads persisted B/C/D contracts and the immutable attempt-owned raw training input.

Therefore no:

```
read_csv_file()
API_INPUT_FILE_*
API_INPUT_CSV_*
```

logic belongs in the route.

---

# 14. No Manual Part C Prerequisite Check

The API does not inspect:

```
Part C status
Part C successful_execution_id
Manifest V2 stage records
```

Part D's workflow uses Run Management's stage preparation/prerequisite resolution.

If Part C is not successfully completed:

```
STAGE_PREREQUISITE_NOT_COMPLETED
→ HTTP 409
```

---

# 15. Why Part C Prerequisite Enforcement Stays Below API

The same lifecycle authority is shared by:

```
standalone training endpoint
master A→D pipeline
internal workflow calls
retry paths
```

Centralizing it in Run Management avoids API-specific lineage drift.

---

# 16. No Stage-State Branching in the Route

The route does not ask:

```
is Part D complete?
is bootstrap complete?
did bootstrap fail?
should D rerun?
```

Those decisions are owned by:

```
run_training_stage_workflow()
```

The route simply delegates the validated request.

---

# 17. Part D Incomplete / Failed Flow

When D is not complete:

```
run_training_stage_workflow()
        ↓
run_part_d_workflow()
```

If D fails after its execution begins:

```
Part D workflow persists failure
        ↓
returns failed StandaloneStageResponse
        ↓
training workflow returns that exact D response
        ↓
bootstrap is not attempted
```

---

# 18. Fresh D Success Flow

If Part D succeeds:

```
Part D complete
        ↓
run_inference_bootstrap_workflow()
```

Only after bootstrap completes successfully does the composed training lifecycle return:

```
inference_ready = true
next_stage = inference
```

---

# 19. Bootstrap-Only Retry

This is the most important retry behavior.

Suppose:

```
Part D execution_0001 = completed
bootstrap execution_0001 = failed
```

A later call to:

```
POST /api/v1/training/run
```

must perform:

```
reuse Part D execution_0001
        ↓
start bootstrap execution_0002
```

It must not create a second Part D execution.

---

# 20. Why Bootstrap-Only Retry Preserves Immutability

Completed training is an immutable lineage result.

Bootstrap failure does not invalidate model training.

Therefore:

```
D completed
+
bootstrap failed
```

means:

```
retry saved-state finalization
```

not:

```
retrain the model
```

---

# 21. Bootstrap-Only Successful Response

When Part D was already completed and bootstrap retry succeeds:

```
status = completed
requested_stage = part_d
executions = inference_bootstrap only
next_stage = inference
inference_ready = true
```

The response lists only executions launched by that request.

Historical completed D remains in Manifest V2.

---

# 22. Fresh D + Bootstrap Successful Response

For a new successful final training call:

```
status = completed
requested_stage = part_d
executions:
    part_d
    inference_bootstrap
next_stage = inference
inference_ready = true
```

This is the normal full-success case.

---

# 23. Bootstrap Failure After D Success

If D completes but bootstrap fails:

```
status = partially_completed
requested_stage = part_d
next_stage = inference_bootstrap
inference_ready = false
```

The response can contain:

```
part_d completed
inference_bootstrap failed
```

The same attempt remains eligible for bootstrap retry.

---

# 24. Already Inference-Ready Attempt

If both stages are already completed:

```
Part D = completed
bootstrap = completed
```

the workflow raises:

```
TRAINING_ATTEMPT_ALREADY_INFERENCE_READY
```

The frozen error map explicitly approves this lifecycle conflict as:

```
HTTP 409
```

---

# 25. Safe Details for Already-Ready Conflict

The public 409 may expose:

```
run_id
attempt_id
part_d_execution_id
bootstrap_execution_id
```

This is an explicitly approved lifecycle response.

---

# 26. Inconsistent Training Lifecycle

If persisted state says:

```
bootstrap = completed
Part D != completed
```

the workflow raises:

```
INCONSISTENT_TRAINING_LIFECYCLE
```

This violates the canonical prerequisite relationship:

```
Part D
→ inference_bootstrap
```

---

# 27. Why Inconsistent Lifecycle Remains 500

`INCONSISTENT_TRAINING_LIFECYCLE` is not in the frozen public 409 allowlist.

Therefore the global fail-closed policy treats it as internal:

```
HTTP 500
```

with:

```
specific error_code retained
generic public message
details = {}
```

This is intentional.

---

# 28. Training Configuration Ownership

The API route does not inspect model-specific fields.

Training config remains the proven discriminated union:

```
XGBoostTrainingConfig
OR
IsolationForestTrainingConfig
```

selected by:

```
model_type
```

The existing Part D schemas own:

```
hyperparameter validation
fixed tuning
Optuna tuning
split configuration
threshold direction
model-specific settings
```

---

# 29. Invalid Training Request

Invalid model configuration is rejected by Pydantic/FastAPI before workflow execution.

Examples:

```
unsupported model_type
invalid hyperparameter field
invalid enum
missing required model configuration
extra forbidden field
```

Public result:

```
REQUEST_VALIDATION_FAILED
→ 422
```

---

# 30. Bootstrap Configuration Ownership

The route does not calculate:

```
cache_days
required history
gap allowances
history/cache file locations
late-data behavior
```

It simply passes:

```
request.inference_bootstrap
```

into the composed training workflow.

---

# 31. Bootstrap Policy Fields

The production workflow schema provides:

```
max_gap_days
max_gap_ratio
late_data_reconstruction_enabled
```

with schema-owned validation and defaults.

---

# 32. Completed Part D Training Config Is Immutable

A bootstrap retry may reuse completed Part D only if the supplied training config still matches the persisted D snapshot.

Conceptually:

```
persisted Part D training config
==
request.training
```

must remain true.

---

# 33. Changed Training Config During Bootstrap Retry

If D is already completed and the caller supplies a different training configuration:

```
COMPLETED_PART_D_TRAINING_CONFIG_MISMATCH
```

is raised by bootstrap preflight.

This happens before a new bootstrap execution is created.

---

# 34. Current HTTP Mapping for Training-Config Mismatch

The current frozen error map does **not** approve:

```
COMPLETED_PART_D_TRAINING_CONFIG_MISMATCH
```

as a public 409 or 422.

Therefore it intentionally fails closed:

```
HTTP 500
```

The specific application code is retained, while public details are removed.

This is the current V1 behavior and is not reclassified inside `training.py`.

---

# 35. Why the Route Does Not Translate Training-Config Mismatch

The final API error policy states:

```
public 4xx = explicit opt-in
500 = default
```

Routes must not improvise new public lifecycle mappings.

Therefore changing this condition to 409 would require a deliberate error-policy revision, not a local route patch.

---

# 36. Bootstrap Policy May Change While Bootstrap Is Incomplete

The immutable rule applies to completed Part D training settings.

The bootstrap policy belongs to the still-incomplete bootstrap stage.

Therefore a bootstrap retry may use an updated allowed bootstrap policy while retaining the same completed D config.

This lets the caller retry saved-state finalization without retraining.

---

# 37. Part D Output Contract

The Part D workflow persists a stable snapshot containing:

```
part_d_snapshot_version
stage = part_d
dataset_config
training_config
training_records
```

The bootstrap later reloads this persisted snapshot.

---

# 38. Part D Training Records

Each persisted training record includes the model-side information required for saved-state finalization, including:

```
kpi_name
status
model_type
training_directory
metadata_file
decision_settings_file
model_files
model_feature_columns
target_column
minimum_history_points
training counts
```

The API route does not inspect these artifacts.

---

# 39. Bootstrap Purpose

`inference_bootstrap` converts completed training into the self-contained state consumed by Part E.

Conceptually:

```
completed Part D
        ↓
bootstrap staging state
        ├── inference_config.json
        ├── history/
        ├── cache/
        ├── models/
        └── inference_results/
        ↓
atomic publish
        ↓
runs/<run_id>/inference/<attempt_id>/
```

---

# 40. Persisted Contracts Reloaded by Bootstrap

Bootstrap uses authoritative persisted state from:

```
Part B
Part C
Part D
immutable attempt input
```

It does not depend only on in-memory objects from the original training request.

This is essential for bootstrap-only retries across later requests/processes.

---

# 41. Saved Dataset Contract

Bootstrap persists the dataset-level contract required by inference, including the canonical dataset column mapping and KPI identity information.

The API route does not build this contract.

---

# 42. Saved Preprocessing Contract

Bootstrap persists:

```
Part B request config
+
resolved preprocessing contract
```

so inference reconstruction uses the same preprocessing behavior as training.

---

# 43. Saved Feature-Engineering Contract

Bootstrap persists:

```
Part C request/default config
+
resolved feature-engineering contract
```

so Part E can rebuild feature history consistently.

---

# 44. Saved History Contract

History requirements are derived from the actual upstream B/C contracts.

Conceptually:

```
final required history
=
max(
    Part B requirements,
    Part C minimum history,
    Part C lookback requirements
)
```

Then cache requirements incorporate the bootstrap gap policy.

The API route does not calculate this.

---

# 45. Saved Model Contract

Bootstrap copies finalized Part D model packages into the inference state and constructs the appropriate saved model schema for:

```
XGBoost
or
Isolation Forest
```

The final inference state is self-contained.

---

# 46. Model Artifact Containment

Bootstrap validates that required Part D artifacts are owned by the run and copied into the published inference package.

Failures such as missing model artifacts remain backend contract failures.

The API route exposes no physical model paths.

---

# 47. Atomic Publication

Bootstrap first builds state under a staging root.

Successful completion is published through Run Management into:

```
runs/<run_id>/inference/<attempt_id>/
```

Run Management owns the actual stage completion/publication lifecycle.

---

# 48. Inference Activation

The API route never calls:

```
activate_inference_attempt()
```

directly.

The attempt is activated only after successful bootstrap publication/completion.

This prevents an incomplete saved state from being advertised as inference-ready.

---

# 49. Inference-Ready Meaning

For the final backend:

```
Part D completed
AND
inference_bootstrap completed
```

is the actual readiness condition.

A completed Part D by itself is not enough.

---

# 50. Why Part E Is Still a Separate Request Lifecycle

Training finalization creates reusable saved inference state.

Part E runs later from:

```
InferenceRequest
+
active inference attempt
+
published saved state
```

Therefore:

```
training.py
```

does not execute inference itself.

---

# 51. Training Route vs Inference Route

```
training.py
→ produce/finalize inference-ready training attempt

inference.py
→ consume the active inference-ready attempt
```

These are deliberately separate API lifecycles.

---

# 52. Run-Scoped Logger

The training route always has a real run ID.

It obtains:

```
get_workflow_logger(
    request.run_id,
    component_name="pipeline",
)
```

There is no new-run/process-level logger case.

---

# 53. Why `component_name="pipeline"`

Training finalization is orchestration across:

```
Part D
+
bootstrap
```

Using the existing pipeline logger keeps workflow-level lifecycle logs grouped consistently.

---

# 54. Workflow Delegation

The endpoint ends with:

```
return run_training_stage_workflow(
    request=request,
    manager=manager,
    logger=logger,
)
```

No response rewriting occurs.

---

# 55. Structured D Failure

If Part D starts and fails:

```
Part D workflow
→ fail_stage(...)
→ StandaloneStageResponse(status="failed")
```

The composed workflow returns that exact D response.

The API route returns it unchanged.

---

# 56. Structured Bootstrap Failure

If bootstrap starts and later fails:

```
bootstrap workflow
→ persist failed bootstrap execution
→ failed bootstrap response
```

The composed workflow transforms the overall training lifecycle into:

```
status = partially_completed
```

because Part D remains completed.

The API does not perform this transformation itself.

---

# 57. Preflight Bootstrap Failures

Some bootstrap checks occur before a new bootstrap execution exists.

Examples include:

```
completed D config mismatch
persisted D snapshot resolution failure
internal lifecycle inconsistency
```

Those exceptions propagate to the global API error handler.

---

# 58. Public Error Ownership

`training.py` directly creates only:

```
API_RUN_NOT_FOUND
API_ATTEMPT_NOT_FOUND
```

because those are the only caller-owned missing-resource conditions the route explicitly proves.

All other backend conditions remain owned by:

```
workflow
Run Management
error_handlers.py
```

---

# 59. Final 404 Behavior

```
unknown caller run
→ API_RUN_NOT_FOUND
→ 404
```

```
known run + unknown caller attempt
→ API_ATTEMPT_NOT_FOUND
→ 404
```

---

# 60. Final 409 Behavior

Approved lifecycle conflicts relevant to training include:

```
STAGE_PREREQUISITE_NOT_COMPLETED
→ 409
```

```
STAGE_EXECUTION_ALREADY_RUNNING
→ 409
```

```
TRAINING_ATTEMPT_ALREADY_INFERENCE_READY
→ 409
```

Other unapproved lifecycle/internal codes remain 500.

---

# 61. Final 422 Behavior

Training route 422s are request-schema problems.

Examples:

```
invalid run/attempt ID
invalid model discriminator
invalid XGBoost config
invalid Isolation Forest config
invalid bootstrap policy
extra forbidden field
```

They become:

```
REQUEST_VALIDATION_FAILED
→ 422
```

There is no training-route external-file 422 family.

---

# 62. Final 500 Behavior

Examples include:

```
registered-but-broken run
INCONSISTENT_TRAINING_LIFECYCLE
COMPLETED_PART_D_TRAINING_CONFIG_MISMATCH
missing/corrupt persisted artifacts
bootstrap contract mismatch
unknown workflow failure
```

The frozen handler fails closed unless a code is explicitly public.

---

# 63. Runtime Flow — Fresh Training Success

```
POST /api/v1/training/run
        ↓
TrainingStageRequest validated
        ↓
public run exists
        ↓
public attempt exists
        ↓
run-scoped logger
        ↓
run_training_stage_workflow()
        ↓
Part D not complete
        ↓
run Part D
        ↓
Part D complete
        ↓
run bootstrap
        ↓
publish saved inference state
        ↓
activate attempt
        ↓
completed / inference_ready=true
```

---

# 64. Runtime Flow — Part C Incomplete

```
run + attempt exist
        ↓
training workflow decides Part D must run
        ↓
Part D prepare_stage_execution()
        ↓
Part C prerequisite missing
        ↓
STAGE_PREREQUISITE_NOT_COMPLETED
        ↓
409
```

---

# 65. Runtime Flow — Part D Already Running

```
training workflow attempts Part D
        ↓
Run Management sees active Part D execution
        ↓
STAGE_EXECUTION_ALREADY_RUNNING
        ↓
409
```

---

# 66. Runtime Flow — Part D Failure

```
Part D execution starts
        ↓
training/model/contract failure
        ↓
Part D failure persisted
        ↓
failed Part D StandaloneStageResponse
        ↓
training workflow returns exact D response
        ↓
bootstrap not started
```

---

# 67. Runtime Flow — Bootstrap Failure

```
Part D completes
        ↓
bootstrap execution starts
        ↓
saved-state build/publication fails
        ↓
bootstrap failure persisted
        ↓
training workflow returns:
status = partially_completed
next_stage = inference_bootstrap
inference_ready = false
```

---

# 68. Runtime Flow — Bootstrap Retry

```
Part D already completed
bootstrap incomplete/failed
        ↓
training endpoint called again
        ↓
workflow skips Part D
        ↓
bootstrap preflight
        ↓
new bootstrap execution
        ↓
success
        ↓
inference_ready = true
```

---

# 69. Runtime Flow — Duplicate Completed Training Lifecycle

```
Part D completed
bootstrap completed
        ↓
training endpoint called again
        ↓
TRAINING_ATTEMPT_ALREADY_INFERENCE_READY
        ↓
409
```

No new execution is launched.

---

# 70. Runtime Flow — Changed D Config During Bootstrap Retry

```
Part D already completed with config X
        ↓
caller retries training endpoint with config Y
        ↓
bootstrap immutable-D preflight
        ↓
COMPLETED_PART_D_TRAINING_CONFIG_MISMATCH
        ↓
no new bootstrap execution
        ↓
current frozen error map
        ↓
500
```

---

# 71. Runtime Flow — Inconsistent Persisted Lifecycle

```
bootstrap completed
Part D incomplete
        ↓
run_training_stage_workflow()
        ↓
INCONSISTENT_TRAINING_LIFECYCLE
        ↓
fail-closed 500
```

---

# 72. No Direct RunManager Construction

The route receives:

```
RunManagerDependency
```

from the shared API dependency module.

It does not instantiate its own manager.

This preserves:

```
shared lifecycle facade
consistent registry
test dependency overrides
central configuration
```

---

# 73. No Manifest Mutation in API

`training.py` never directly calls:

```
prepare_stage_execution()
complete_stage()
fail_stage()
activate_inference_attempt()
save_manifest()
```

All lifecycle mutation is below the API layer.

---

# 74. No Artifact Resolution in API

The route does not resolve:

```
Part C result
Part D result
metadata files
model files
inference state
```

Workflows and Run Management own authoritative artifact resolution.

---

# 75. No Direct ML Training Calls

The route does not call:

```
run_training()
XGBoost runner
Isolation Forest runner
Optuna
```

directly.

Part D workflow owns the ML training boundary.

---

# 76. No Bootstrap State Construction in API

The route does not write:

```
inference_config.json
history CSVs
cache CSVs
model copies
saved model contracts
```

Bootstrap workflow owns saved-state construction.

---

# 77. Security / Information Exposure

The route itself exposes no physical paths.

Public boundary errors include only safe logical IDs.

Internal failures are sanitized by the frozen fail-closed error handler.

The route never serializes:

```
run_directory
attempt_directory
training_directory
model_file
metadata_file
decision_settings_file
bootstrap staging directory
inference state directory
```

---

# 78. Final Sanity Check

The exact generated `training.py` was checked against the final:

```
TrainingStageRequest
workflow package contract
run_training_stage_workflow()
bootstrap retry semantics
frozen HTTP error policy
```

No blocking mismatch was found.

---

# 79. Syntax Verification

The exact generated file passed Python compilation:

```
TRAINING_API_V1_SYNTAX=PASS
```

A freeze-level `py_compile` check was also rerun successfully.

---

# 80. Runtime Regression

The implementation passed the earlier route smoke/regression suite:

```
TRAINING_API_V1_RUNTIME_SMOKE=PASS
TRAINING_API_V1_FULL_REGRESSION=PASS
```

---

# 81. Regression Coverage

The route-level tests covered:

```
fresh XGBoost D + bootstrap success
fresh Isolation Forest D + bootstrap success
bootstrap config passthrough
missing run → 404
missing attempt → 404
registered-but-broken run → 500
Part C incomplete → 409
Part D already running → 409
already inference-ready → 409
inconsistent lifecycle → 500
completed-D config mismatch → fail-closed 500 behavior
Part D structured failure
D success + bootstrap structured failure
bootstrap-only retry
internal post-boundary failure
invalid training discriminator → 422
invalid bootstrap config → 422
extra external file field → 422
malformed attempt ID → 422
run-scoped workflow logger
```

---

# 82. Sanity-Check Finding: Final Endpoint Is Not D-Only

During planning, an earlier shorthand description referred to the standalone route as Part D-only.

The final frozen source contract confirms that this would be incorrect.

The production standalone training request is explicitly:

```
Part D execution
+
saved-state finalization
```

and the final workflow is:

```
run_training_stage_workflow()
→ D
→ inference_bootstrap
```

The implemented route follows the final contract.

---

# 83. Sanity-Check Finding: Config-Mismatch Mapping Is Deliberately Conservative

The bootstrap correctly raises a structured internal code:

```
COMPLETED_PART_D_TRAINING_CONFIG_MISMATCH
```

when a completed D configuration is changed.

The frozen API mapping does not list it among public 409 codes.

Therefore:

```
500
```

is the currently correct HTTP behavior under the fail-closed policy.

No local route translation was added.

---

# 84. Relationship with `feature_engineering.py`

```
feature_engineering.py
→ Part C
→ successful output becomes D prerequisite

training.py
→ final Part D + bootstrap lifecycle
→ produces inference-ready attempt
```

Both routes validate only caller-owned run/attempt identity at the HTTP layer.

---

# 85. Relationship with `pipeline.py`

The future master API route will use:

```
run_training_pipeline()
```

for:

```
A → B → C → D → inference_bootstrap
```

The standalone `training.py` uses:

```
run_training_stage_workflow()
```

for an already existing attempt.

These are intentionally different entry points.

---

# 86. Master-Pipeline Retry Rule

The master training request creates a fresh attempt.

If that master attempt fails at D/bootstrap, recovery occurs through the appropriate standalone stage endpoint rather than resubmitting the master pipeline request.

For the final training portion:

```
training.py
```

is the recovery/finalization endpoint.

---

# 87. Relationship with `inference.py`

After successful bootstrap:

```
attempt becomes inference-ready
```

Then a separate Part E request can use that run.

`training.py` never runs Part E itself.

---

# 88. Final Responsibility Boundary

```
training.py
→ HTTP + caller run/attempt identity

TrainingStageRequest
→ D + bootstrap request validation

run_training_stage_workflow()
→ persisted D/bootstrap lifecycle selection

run_part_d_workflow()
→ canonical Part D orchestration

run_inference_bootstrap_workflow()
→ saved Part-E state finalization

Run Management
→ prerequisite, execution, immutability, publication, activation

ML training module
→ XGBoost / Isolation Forest training and tuning

error_handlers.py
→ safe 404 / 409 / 422 / 500 representation
```

No layer responsibility is duplicated.

---

# 89. Final Compact Contract

```
FILE:
app/api/training.py

ROLE:
Standalone final training HTTP route.

ENDPOINT:
POST /api/v1/training/run

REQUEST:
TrainingStageRequest

REQUEST FIELDS:
run_id
attempt_id
training
inference_bootstrap

FINAL LIFECYCLE:
Part D
→ inference_bootstrap
→ inference-ready

DELEGATE:
run_training_stage_workflow()

PUBLIC 404:
API_RUN_NOT_FOUND
API_ATTEMPT_NOT_FOUND

PUBLIC 409 RELEVANT HERE:
STAGE_PREREQUISITE_NOT_COMPLETED
STAGE_EXECUTION_ALREADY_RUNNING
TRAINING_ATTEMPT_ALREADY_INFERENCE_READY

REQUEST 422:
REQUEST_VALIDATION_FAILED

FAIL-CLOSED 500 EXAMPLES:
INCONSISTENT_TRAINING_LIFECYCLE
COMPLETED_PART_D_TRAINING_CONFIG_MISMATCH
internal persisted-state/artifact failures

FRESH SUCCESS:
executions = part_d + inference_bootstrap
inference_ready = true

D FAILURE:
exact Part D failed response
bootstrap not launched

BOOTSTRAP FAILURE:
status = partially_completed
D remains completed
bootstrap retry allowed

BOOTSTRAP-ONLY RETRY:
completed D is reused
only bootstrap launches

LOGGER:
run-scoped pipeline logger

DOES NOT:
accept external CSV
inspect Part C manually
choose D/bootstrap branch in API
rerun immutable completed D
train model directly
construct bootstrap state directly
activate inference directly
mutate Manifest V2 directly
reshape workflow response
```

---

# 90. Final Assessment

`app/api/training.py` is correctly aligned with the final production training architecture.

Its defining rule is:

```
The API validates caller-owned run/attempt identity.

The workflow decides whether D or bootstrap must run.

Part D produces the immutable trained-model contract.

Bootstrap converts that completed contract into persistent Part-E state.

Only successful bootstrap makes the attempt inference-ready.
```

The final implementation preserves the frozen HTTP policy:

```
genuine missing caller resource → 404
approved healthy lifecycle conflict → 409
invalid request schema → 422
unapproved/internal condition → 500
started-stage failures → structured workflow responses
```

**Final status: PASS / suitable to freeze.**