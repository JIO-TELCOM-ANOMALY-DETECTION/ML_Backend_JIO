# Level 1 — Part A EDA Integration Test Report

**Status:** PASS  
**Purpose:** Certify standalone Part A through the production API together with Run Management, retry behavior, persisted execution state, and Part A-specific error handling.

## Cases Passed

| Case | Job | Result |
|---|---|---|
| 01 — Single KPI | Create a new run + attempt, execute Part A successfully, and confirm persisted Part A state. | PASS |
| 02 — Multi KPI | Verify Part A splits multiple KPIs correctly and persists the completed execution. | PASS |
| 03 — Fresh attempt | Reuse the same logical `run_id` without an `attempt_id` and verify a new immutable attempt is created. | PASS |
| 04 — Immutability | Attempt to rerun already-completed Part A in the same attempt and verify `409 COMPLETED_STAGE_IS_IMMUTABLE`. | PASS |
| 05 — Failure + retry | Force a real Part A runtime failure, verify failed execution persistence, delete the caller CSV, retry the same attempt using immutable input, and complete as a new execution. | PASS |
| 06 — Missing targets | Verify unknown run and unknown attempt return the correct public `404` error families. | PASS |
| 07 — File errors | Verify missing file, directory path, bad extension, zero-byte CSV, malformed CSV, invalid UTF-8, and header-only CSV map to the correct `422 API_INPUT_*` errors without creating runs. | PASS |
| 08 — Schema errors | Verify invalid Part A request combinations are rejected with standardized `422 / REQUEST_VALIDATION_FAILED`. | PASS |

## Retry Result Proved

The retry case verified:

```text
execution_0001 → failed
same run_id + attempt_id
original external CSV deleted
retry uses immutable attempt-owned input
execution_0002 → completed
successful_execution_id → execution_0002
```

This confirms failed Part A executions can be retried safely inside the same attempt while completed Part A remains immutable.

## What Level 1 Proved

- Part A request → API → workflow → Run Management → ML integration works.
- New run creation works.
- Fresh attempt creation works.
- Multi-KPI Part A works.
- Part A execution state is persisted correctly.
- Failed executions remain recorded.
- Same-stage retry after failure works.
- Completed-stage rerun protection works.
- Public 404/409/422 error families behave correctly.
- File preflight failures do not create runs.
- `/runs` inspection agrees with execution responses.

## Final Result

**8/8 logical cases passed — Level 1 / Part A certified.**
