# EDA API — Final Technical Report

**File:** `app/api/eda.py`  
**Frozen implementation:** v4  
**Module:** `app/api/`  
**Status:** Final sanity checked — PASS / suitable to freeze  
**Primary role:** Production HTTP endpoint for standalone Part A EDA execution.

---

# 1. Purpose

`eda.py` is the API-layer entry point for running **Part A — Exploratory Data Analysis** independently.

Its responsibility is deliberately narrow:

```
HTTP request
    ↓
API-boundary validation
    ↓
caller-owned run / attempt checks
    ↓
logger selection
    ↓
run_part_a_workflow(...)
    ↓
StandaloneStageResponse
```

The file does not implement EDA algorithms, manipulate Manifest V2 directly, create stage execution records itself, or duplicate Run Management logic.

---

# 2. Architectural Position

```
Client / UI
    ↓
POST /api/v1/eda/run
    ↓
app/api/eda.py
    ↓
app/workflows/part_a.py
    ↓
Run Management
    ↓
app/ml/eda/
    ↓
Services / filesystem
```

The API route therefore bridges HTTP semantics into the already-tested Part A production workflow.

---

# 3. Router Contract

Router prefix:

```
/api/v1/eda
```

Endpoint:

```
POST /api/v1/eda/run
```

Request model:

```
EDAStageRequest
```

Response model:

```
StandaloneStageResponse
```

---

# 4. Supported Part A Lifecycle Modes

The request supports three modes.

## New run

```
run_id = None
attempt_id = None
```

Meaning:

```
create new run
→ create first attempt
→ execute Part A
```

## Fresh attempt under existing run

```
run_id supplied
attempt_id = None
```

Meaning:

```
reuse logical run
→ create fresh immutable attempt
→ execute Part A
```

## Retry Part A in existing attempt

```
run_id supplied
attempt_id supplied
```

Meaning:

```
resolve existing run
→ resolve existing attempt
→ reuse immutable attempt-owned input
→ retry Part A if Run Management allows it
```

The route never decides stage immutability or retry legality itself.

---

# 5. Why Part A Requires More API Boundary Logic

Part A is the only standalone training stage that can create:

```
a completely new run
or
a new training attempt
```

Parts B/C/D operate only inside an already existing run/attempt.

Therefore Part A is also the natural boundary for validating the external source CSV before a new attempt is created.

---

# 6. Caller-Owned Run Validation

When a request supplies a `run_id`, the route first checks:

```
manager.registry.exists(run_id)
```

This check is used only to establish whether the caller is referring to a genuinely unknown public resource.

If the run is not registered:

```
API_RUN_NOT_FOUND
→ HTTP 404
```

---

# 7. Why Generic `RUN_NOT_FOUND` Is Not Converted Globally

A later low-level `RUN_NOT_FOUND` may indicate:

```
registered run directory missing
manifest corruption
registry inconsistency
internal lifecycle failure
```

Those are backend failures.

Therefore `eda.py` only creates:

```
API_RUN_NOT_FOUND
```

when it has explicit caller-boundary evidence that the run is not registered.

After that boundary has passed, later internal errors propagate unchanged and normally become 500 through the frozen global error handler.

---

# 8. Caller-Owned Attempt Validation

If both `run_id` and `attempt_id` are supplied, the route performs a read-only:

```
manager.resolve_attempt(
    run_id,
    attempt_id,
)
```

If the exact caller-requested attempt does not exist:

```
AttemptNotFoundError
→ API_ATTEMPT_NOT_FOUND
→ HTTP 404
```

The safe public details are:

```
run_id
attempt_id
```

---

# 9. Why Only `AttemptNotFoundError` Is Translated

`resolve_attempt()` may also fail because of:

```
missing attempt request snapshot
missing immutable attempt input
artifact path violation
manifest problem
run-state problem
```

Those are not caller-owned 404 conditions.

The route catches only `AttemptNotFoundError`; all other failures remain internal.

---

# 10. New-Attempt External CSV Boundary

For requests where:

```
attempt_id is None
```

the workflow is going to create a new immutable attempt from:

```
request.dataset.input_file
```

That external file belongs to the caller boundary.

The route therefore fully validates it **before** calling the workflow.

---

# 11. Shared CSV Validation

The route reuses:

```
app.services.file_service.read_csv_file()
```

rather than implementing its own filesystem/Pandas logic.

That shared service validates:

```
file existence
regular-file status
.csv extension
non-zero file size
configured maximum file size
encoding
CSV parser behavior
presence of readable columns
```

The route additionally checks:

```
dataframe.empty
```

so a header-only / zero-row CSV is also rejected before attempt creation.

---

# 12. Final External Input Error Mapping

The route converts known caller-owned file errors into the frozen API-specific codes.

```
FILE_NOT_FOUND
→ API_INPUT_FILE_NOT_FOUND
→ 422
```

```
PATH_IS_NOT_FILE
→ API_INPUT_PATH_NOT_FILE
→ 422
```

```
INVALID_FILE_EXTENSION
→ API_INPUT_FILE_EXTENSION_INVALID
→ 422
```

```
EMPTY_FILE
→ API_INPUT_FILE_EMPTY
→ 422
```

```
FILE_TOO_LARGE
→ API_INPUT_FILE_TOO_LARGE
→ 422
```

```
CSV_PARSE_FAILED
→ API_INPUT_CSV_PARSE_FAILED
→ 422
```

```
CSV_ENCODING_ERROR
→ API_INPUT_CSV_ENCODING_INVALID
→ 422
```

```
EMPTY_CSV
→ API_INPUT_CSV_EMPTY
→ 422
```

Successfully parsed CSV with zero rows:

```
→ API_INPUT_CSV_EMPTY
→ 422
```

---

# 13. Safe Detail Forwarding

The route does not expose arbitrary `file_service` details.

Approved details are limited to:

## Invalid extension

```
received_extension
allowed_extensions
```

## Oversized file

```
file_size_bytes
maximum_size_bytes
maximum_size_gb
```

Raw fields such as:

```
file_path
original_error
```

are not forwarded.

The global error handler applies its own allowlist again as defense in depth.

---

# 14. Unknown File-Service Errors Remain Internal

Errors such as:

```
FILE_SIZE_READ_FAILED
CSV_READ_FAILED
unknown future file error
```

are not automatically converted into caller 422 responses.

They propagate unchanged and therefore fail closed to 500 unless explicitly mapped elsewhere.

This prevents filesystem/OS/internal parser failures from being incorrectly blamed on the caller.

---

# 15. Existing-Attempt Retry Input Rule

For:

```
run_id + attempt_id
```

the route deliberately skips external CSV validation.

This is required by the immutable-attempt architecture.

The authoritative retry input is:

```
attempt_context.input_file
```

not the original external source path.

---

# 16. Why Retry Must Ignore the Original External File

When the attempt was created, Run Management copied the caller's source file into:

```
runs/<run_id>/attempts/<attempt_id>/input/
```

The Part A workflow later rebuilds the runtime dataset configuration using this immutable attempt-owned copy.

Therefore the original external file may legitimately:

```
move
be renamed
be deleted
```

without invalidating the attempt.

---

# 17. Retry Bug Fixed During Sanity Review

An earlier version validated the external request path for every request.

That caused the invalid behavior:

```
attempt-owned input exists
+
original external file later deleted
+
retry Part A
        ↓
API_INPUT_FILE_NOT_FOUND / 422
```

The final implementation fixes this:

```
attempt_id is None
→ validate external CSV

attempt_id supplied
→ skip external CSV validation
→ workflow uses immutable attempt copy
```

---

# 18. Retry-Time Internal Input Problems

If the attempt-owned immutable input itself is missing/corrupt, that is no longer a caller external-file issue.

It represents persisted backend state.

Therefore such a failure is not converted to an `API_INPUT_*` error by `eda.py`.

It remains a workflow / Run Management / internal failure.

---

# 19. Preflight Order

The route performs:

```
_validate_public_target()
        ↓
_validate_external_dataset_file()
        ↓
workflow
```

This means an invalid run/attempt reference is rejected before the backend spends time parsing a potentially large CSV.

For a completely new run, the target check is a no-op and CSV validation runs immediately.

---

# 20. Logger Selection

The route uses:

```
get_workflow_logger(
    request.run_id,
    component_name="pipeline",
)
```

Behavior:

```
run_id is None
→ process-level API logger

run_id supplied
→ run-scoped pipeline logger
```

The route does not create its own logging system.

---

# 21. New-Run Logging Boundary

When `run_id` is absent, the run has not yet been created.

The route therefore cannot obtain a truthful run-scoped logger before workflow execution.

Using the shared process API logger is the correct V1 behavior rather than inventing a fake run identifier.

---

# 22. Workflow Delegation

After boundary validation:

```
return run_part_a_workflow(
    request=request,
    manager=manager,
    logger=logger,
)
```

The Part A workflow remains responsible for:

```
create/resolve run
create/resolve attempt
copy immutable input
prepare stage execution
run EDA ML logic
validate Part A result
persist A→B handoff
complete stage
persist execution failure
construct StandaloneStageResponse
```

---

# 23. Why the Route Does Not Call ML Directly

Incorrect layering:

```
eda.py
→ run_eda_pipeline()
```

Correct layering:

```
eda.py
→ run_part_a_workflow()
→ Run Management
→ run_eda_pipeline()
```

The workflow layer is required because it owns lineage, persistence, execution identity, handoffs, and failure recording.

---

# 24. Structured Workflow Failures

Once a stage execution has been created, Part A runner/contract failures are owned by the workflow.

The workflow may return:

```
StandaloneStageResponse(
    status="failed",
    ...
)
```

The API route returns that response unchanged.

It does not convert every persisted stage failure into a global HTTP exception.

---

# 25. API Rejection vs Persisted Stage Failure

These are intentionally different.

## API rejection

Example:

```
caller submits malformed CSV
```

Result:

```
HTTP 422
API_INPUT_CSV_PARSE_FAILED
```

No new attempt is created.

## Persisted Part A failure

Example:

```
Part A execution started
→ internal EDA/result contract fails
```

Result:

```
stage execution persisted as failed
StandaloneStageResponse.status = failed
```

The route preserves the workflow response.

---

# 26. No Post-Boundary Reclassification

If boundary validation succeeds and a generic backend error later occurs, `eda.py` does not reinterpret it merely because its error code resembles a caller-input code.

This protects the frozen fail-closed rule:

```
caller ownership must be proven
not guessed
```

---

# 27. Pydantic Validation

Request-shape problems are handled before the route executes.

Example:

```
attempt_id supplied without run_id
```

The schema rejects the request and the global FastAPI validation handler returns:

```
422
REQUEST_VALIDATION_FAILED
```

The route does not duplicate request-model validation.

---

# 28. Relationship with Global `error_handlers.py`

`eda.py` raises structured backend exceptions with API-specific codes.

The global handler owns:

```
HTTP status
fixed public message
canonical error_code
public detail allowlist
safe logging
```

The route does not create raw `JSONResponse` error bodies.

---

# 29. Final Public Errors Produced by `eda.py`

## 404

```
API_RUN_NOT_FOUND
API_ATTEMPT_NOT_FOUND
```

## 422

```
API_INPUT_FILE_NOT_FOUND
API_INPUT_PATH_NOT_FILE
API_INPUT_FILE_EXTENSION_INVALID
API_INPUT_FILE_EMPTY
API_INPUT_FILE_TOO_LARGE
API_INPUT_CSV_PARSE_FAILED
API_INPUT_CSV_ENCODING_INVALID
API_INPUT_CSV_EMPTY
```

Everything else is allowed to preserve its original backend meaning.

---

# 30. No Direct Manifest Mutation

`eda.py` does not call:

```
create_run_manifest
save_run_manifest
start_stage_execution
complete_stage_execution
fail_stage_execution
```

All persistent lifecycle mutation remains behind workflows and Run Management.

---

# 31. No Run-Folder Knowledge

The route does not construct or scan:

```
runs/<run_id>/
attempts/<attempt_id>/
stages/part_a/
execution_0001/
```

The only filesystem path it directly receives is the caller-owned external dataset path for a new attempt.

---

# 32. No Handoff Logic

`eda.py` does not build or load:

```
PartAHandoff
A→B result snapshots
result.json
```

The Part A workflow owns those contracts.

This keeps the HTTP route stable if internal handoff serialization changes later.

---

# 33. No EDA Algorithm Logic

The route contains no knowledge of:

```
KPI enumeration
server validation
missing-data analysis
coverage
gap distributions
duplicate handling
Part A metrics
```

Those remain inside the tested Part A ML module.

---

# 34. New-Attempt CSV Double Read

A new-attempt CSV is intentionally parsed twice.

## Read 1

```
API boundary
→ caller validation
```

## Read 2

```
workflow
→ immutable attempt copy
→ Part A ML runner
```

The DataFrame from the first read is discarded.

---

# 35. Why Double Read Is Accepted in V1

Passing the first DataFrame into the workflow would weaken the immutable-attempt-file contract and modify the already-tested Part A execution design.

The final implementation chooses:

```
extra read cost
in exchange for
clean API error ownership
+
no attempt creation for obvious bad input
+
unchanged Part A workflow
```

This is an intentional V1 tradeoff.

---

# 36. Performance Boundary

The duplicate parse means new Part A requests incur additional:

```
I/O
CPU parsing
temporary DataFrame memory
```

The existing maximum-input-file-size policy still applies.

If this later becomes expensive at production scale, a dedicated upload/staging layer could validate once and make the staged object the immutable source.

That future optimization does not require changing the current HTTP contract.

---

# 37. File Change / TOCTOU Boundary

There is a small interval between:

```
API preflight parses external file
and
workflow copies external file into attempt storage
```

An external process could theoretically modify/delete the file during this interval.

The workflow still performs its own copy/read operations, so the backend cannot silently continue with a nonexistent file.

However the final classification of such a race may differ from the preflight classification.

This is a known filesystem V1 boundary rather than a correctness bug in the current route.

---

# 38. Side Effects Before Workflow

Before workflow execution, `eda.py` performs only:

```
registry lookup
attempt resolution when requested
external CSV read for new attempts
logger selection
```

It does not persist run/stage state itself.

Actual run lifecycle mutation begins in:

```
run_part_a_workflow()
```

---

# 39. Dependency Injection

The route receives:

```
RunManagerDependency
```

from `dependencies.py`.

It does not instantiate a new `RunManager()` directly.

This preserves:

```
shared manager behavior
FastAPI dependency overrides
testability
centralized infrastructure wiring
```

---

# 40. Public Module Interface

The file exports only:

```
router
```

Internal helpers remain private:

```
_normalized_error_code()
_translate_external_input_error()
_validate_external_dataset_file()
_validate_public_target()
```

---

# 41. Runtime Flow — New Run

```
POST /api/v1/eda/run
        ↓
EDAStageRequest validation
        ↓
no public target to validate
        ↓
external CSV full preflight
        │
        ├── invalid → API_INPUT_* → 422
        │
        └── valid
              ↓
process API logger
              ↓
run_part_a_workflow()
              ↓
create run
              ↓
create attempt + immutable copy
              ↓
create Part A execution
              ↓
run EDA
              ↓
persist A→B handoff
              ↓
complete stage
              ↓
StandaloneStageResponse
```

---

# 42. Runtime Flow — Fresh Attempt Under Existing Run

```
run_id supplied
attempt_id absent
        ↓
registry proves run exists
        ↓
external CSV preflight
        ↓
run-scoped logger
        ↓
workflow resolves run technically
        ↓
creates fresh attempt
        ↓
copies immutable source
        ↓
executes Part A
```

If technical run resolution fails after the public existence check, that error remains internal.

---

# 43. Runtime Flow — Existing Attempt Retry

```
run_id supplied
attempt_id supplied
        ↓
registry proves run exists
        ↓
resolve_attempt preflight
        ↓
external CSV validation skipped
        ↓
run-scoped logger
        ↓
workflow resolves existing attempt
        ↓
uses immutable attempt_context.input_file
        ↓
Run Management decides retry legality
        ↓
execute Part A retry
```

---

# 44. Runtime Flow — Missing Run

```
caller supplies run_id
        ↓
registry.exists(run_id) = false
        ↓
API_RUN_NOT_FOUND
        ↓
global error handler
        ↓
404
```

The CSV is not unnecessarily parsed.

---

# 45. Runtime Flow — Missing Attempt

```
known run
attempt_id supplied
        ↓
resolve_attempt()
        ↓
AttemptNotFoundError
        ↓
API_ATTEMPT_NOT_FOUND
        ↓
404
```

Other attempt-resolution failures remain 500/internal.

---

# 46. Runtime Flow — Malformed Caller CSV

```
new attempt request
        ↓
read_csv_file(external source)
        ↓
CSV_PARSE_FAILED
        ↓
route knows this exact read is caller-owned
        ↓
API_INPUT_CSV_PARSE_FAILED
        ↓
422
```

Workflow execution is never entered.

---

# 47. Sanity-Check History

The final route was hardened through several targeted checks.

## Issue 1 — Existing retry validated stale external path

Fixed by:

```
attempt_id present
→ skip external validation
```

## Issue 2 — CSV parse/encoding API codes unreachable

Fixed by using:

```
read_csv_file()
```

for new-attempt preflight.

## Issue 3 — Post-workflow CSV translation would create state before returning 422

That approach was rejected.

Final design:

```
parse caller source before new attempt creation
```

## Issue 4 — Invalid target should be rejected before parsing large CSV

Final ordering:

```
target validation
→ CSV preflight
→ workflow
```

---

# 48. Final Verification

The final v4 implementation passed:

```
EDA_API_V4_SYNTAX=PASS
EDA_API_V4_RUNTIME_SMOKE=PASS
EDA_API_V4_FULL_REGRESSION=PASS
```

A final freeze-level source review also confirmed consistency with the actual:

```
RunManager.resolve_run()
RunManager.resolve_attempt()
Part A immutable-input workflow behavior
file_service.read_csv_file()
dependencies.get_workflow_logger()
frozen API error mappings
```

---

# 49. Regression Coverage

The completed route tests covered:

```
new run Part A
fresh attempt under existing run
existing-attempt Part A retry
correct logger selection
missing run 404
missing attempt 404
registered-but-broken run 500
missing file 422
path-not-file 422
invalid extension 422
empty byte file 422
oversized file 422
CSV parse failure 422
CSV encoding failure 422
empty/no-column CSV 422
zero-row CSV 422
unknown file-service failure 500
retry after original external file disappears
retry despite stale invalid external path
post-boundary generic file error not reclassified
structured workflow failure unchanged
workflow exception not reclassified
Pydantic request validation 422
path/parser-detail leakage prevention
```

---

# 50. Final Responsibility Boundary

```
eda.py
→ HTTP boundary + caller ownership

Part A workflow
→ execution orchestration + lifecycle persistence

Run Management
→ run / attempt / execution authority

ML EDA module
→ EDA computation

Services
→ validated file operations

error_handlers.py
→ public HTTP error rendering
```

This separation is the core reason the final route remains small and maintainable.

---

# 51. Final Compact Contract

```
FILE:
app/api/eda.py

ROLE:
Standalone Part A HTTP route.

ENDPOINT:
POST /api/v1/eda/run

REQUEST:
EDAStageRequest

RESPONSE:
StandaloneStageResponse

MODES:
no run_id
→ new run + new attempt

run_id only
→ new attempt under existing run

run_id + attempt_id
→ retry existing Part A attempt

PUBLIC 404:
API_RUN_NOT_FOUND
API_ATTEMPT_NOT_FOUND

PUBLIC 422:
API_INPUT_FILE_NOT_FOUND
API_INPUT_PATH_NOT_FILE
API_INPUT_FILE_EXTENSION_INVALID
API_INPUT_FILE_EMPTY
API_INPUT_FILE_TOO_LARGE
API_INPUT_CSV_PARSE_FAILED
API_INPUT_CSV_ENCODING_INVALID
API_INPUT_CSV_EMPTY

DEFAULT UNKNOWN/INTERNAL:
fail closed through global handler

NEW ATTEMPT INPUT:
fully validate external CSV before workflow

EXISTING ATTEMPT RETRY:
do not validate external request path
use immutable attempt-owned input

LOGGER:
new run → process API logger
existing run → run-scoped pipeline logger

WORKFLOW:
run_part_a_workflow()

DOES NOT:
implement EDA
mutate Manifest directly
create execution directly
scan run folders
build handoffs
translate arbitrary internal errors
```

---

# 52. Final Assessment

`app/api/eda.py` is now a correctly bounded production API route.

Its governing rule is:

```
Before a new attempt exists:
the API may classify caller-owned run/attempt/file problems.

After workflow execution begins:
the API stops guessing ownership and preserves the workflow / Run Management
failure semantics.
```

This provides:

```
correct 404 ownership
correct 422 ownership
fail-closed internal handling
immutable retry correctness
no duplicated EDA/lifecycle logic
```

**Final status: PASS / suitable to freeze.**