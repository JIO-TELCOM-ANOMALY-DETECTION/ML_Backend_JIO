# Level 5 Testing Coverage Report

## Telecom Anomaly Detection Backend

**Project:** JIO Internship — Telecom Anomaly Detection Backend  
**Testing Level:** Level 5  
**Primary Scope:** Complete Master Pipeline Certification  
**Status:** PASSED

---

## 6.1 Objective

Level 5 moved one level higher.

Instead of starting near Part D, it tested the complete production training workflow:

```text
raw caller input
        ↓
Part A — EDA
        ↓
Part B — Preprocessing
        ↓
Part C — Feature Engineering
        ↓
Part D — Training
        ↓
Inference Bootstrap
        ↓
completed inference-ready attempt
```

Level 5 contained:

```text
14 certification cases
```

The main question was:

> Can the master production pipeline correctly orchestrate the complete backend from one external request?

---

# 7. Level 5 — Successful Pipeline Coverage

The success paths covered:

### XGBoost complete pipeline

A full raw dataset was sent through:

```text
A → B → C → D(XGBoost) → Bootstrap
```

The final attempt had to:

- complete every stage;
- produce training artifacts;
- produce inference bootstrap artifacts;
- expose `inference_ready = true`;
- leave no stage or execution in a stale running state.

---

### Isolation Forest complete pipeline

The same master workflow was tested with Isolation Forest to verify that model dispatch worked correctly through the unified pipeline.

---

### Multi-KPI complete pipeline

The master pipeline was tested with multiple KPI datasets.

This verified that:

- Part A split KPI datasets correctly;
- Part B ran per KPI;
- Part C ran per KPI;
- Part D trained site models under the correct KPI;
- bootstrap saved mappings for the complete trained KPI set;
- artifacts remained isolated by KPI.

---

# 8. Level 5 — Fresh Attempt Semantics

Level 5 verified the architectural rule:

```text
master pipeline request
        ↓
new attempt
```

Running the master pipeline again under the same logical run was expected to produce a fresh attempt rather than mutate the previous completed attempt.

This validated the distinction between:

```text
RUN
└── ATTEMPT 0001
└── ATTEMPT 0002
```

rather than treating one logical run as one mutable execution directory.

---

# 9. Level 5 — Stop-on-Failure Semantics

One of the most important parts of Level 5 was deliberately failing individual pipeline stages.

The suite exercised failures in:

```text
Part A
Part B
Part C
Part D
Inference Bootstrap
```

For each failure, the master workflow had to stop at the correct boundary.

Conceptually:

```text
A succeeds
B succeeds
C fails
        ↓
D must not run
Bootstrap must not run
```

The test therefore verified:

- correct `failed_stage`;
- correct stage status;
- no downstream execution after failure;
- no false `inference_ready`;
- no incomplete downstream artifact publication.

---

# 10. Level 5 — Retry and Resubmission Behavior

The suite included failure/resubmission behavior to ensure that failed attempts did not corrupt later executions.

Coverage included:

- failed master-pipeline attempt;
- resubmission after failure;
- creation of a valid later attempt;
- preservation of the earlier failed attempt's execution history.

This verified that the backend retained an audit trail instead of overwriting failure history.

---

# 11. Level 5 — Completed Attempt Immutability

A completed attempt was treated as immutable.

The suite verified that an already completed pipeline attempt could not be silently modified by later stage calls or resubmissions.

A new master run under the same logical run had to use:

```text
new attempt
```

instead of rewriting the completed attempt.

---

# 12. Level 5 — Run Management and Registry Consistency

Although Level 6 later tested run management in much greater depth, Level 5 already performed integration checks between:

```text
API response
Manifest V2
run registry
filesystem
attempt state
```

The suite verified that the completed master pipeline reported a coherent state across these representations.

---

# 13. Level 5 — Caller Input Ownership

The master pipeline copied the caller's source file into the run/attempt-owned storage area.

The certification checked that later execution did not depend on the original external path remaining available.

This included the caller-file deletion scenario:

```text
caller submits input
        ↓
backend creates run-owned copy
        ↓
caller copy may disappear
        ↓
backend attempt remains self-contained
```

This is important for API/UI deployment where uploaded temporary files cannot be treated as permanent backend storage.

---

# 14. Level 5 — Public API and Schema Errors

Level 5 also tested API/schema failure behavior around the master pipeline.

The goal was to distinguish:

```text
request/schema failure
```

from:

```text
valid request whose internal pipeline stage fails
```

The suite therefore included public/schema error coverage so malformed requests did not create misleading completed/failed pipeline state.

---

## Level 5 Result

After all 14 cases passed:

```text
LEVEL 5 — PASSED
```

Level 5 certified:

> The complete production training pipeline can create an inference-ready attempt from raw input while correctly handling success, stage failure, retries, attempts, artifacts, input ownership and public API errors.

---
