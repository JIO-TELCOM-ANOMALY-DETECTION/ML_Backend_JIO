# Phase 5 — Training Lifecycle — Final Technical Report

**Package location:** `app/workflows/`  
**Phase scope:** `inference_bootstrap.py`, `training_pipeline.py`

---

## 1. Purpose

Phase 5 completes the production training lifecycle after the individually  
callable A→B→C→D workflows are already available.

The phase has two responsibilities:

```
completed Part D
    ↓
inference_bootstrap.py
    ↓
self-contained inference-ready saved state

and

training_pipeline.py
    ↓
compose:
A → B → C → D → inference_bootstrap
```

Part E itself is not executed in this phase.

The attempt becomes inference-ready only after:

```
Part D completed
AND
inference_bootstrap completed
```

---

# 2. Files

```
app/workflows/
├── inference_bootstrap.py
└── training_pipeline.py
```

Both files were independently syntax-checked and runtime smoke-tested.

---

# 3. `inference_bootstrap.py`

## Responsibility

`inference_bootstrap.py` converts one immutable completed Part D attempt into  
the self-contained state later consumed by pure Part E.

```
completed Part D snapshot
+
persisted Part B contract/request
+
persisted Part C contract/request
+
immutable raw training input
    ↓
bootstrap staging state
    ↓
inference_config.json
history/
cache/
models/
inference_results/
    ↓
Run Management publication
    ↓
runs/<run_id>/inference/<attempt_id>/
```

Bootstrap does not perform inference.

---

# 4. Completed-D preflight before execution creation

The final version performs immutable Part D preflight **before** creating a new  
`inference_bootstrap` execution.

It resolves:

```
run
attempt
manifest
authoritative successful Part D result
```

and validates the persisted Part D training configuration against the supplied  
`TrainingStageRequest`.

Therefore:

```
D completed using training config X
bootstrap retry submitted with training config Y
```

is rejected as:

```
COMPLETED_PART_D_TRAINING_CONFIG_MISMATCH
```

before a new bootstrap execution is started.

This preserves the attempt rule:

> a completed Part D stage is immutable; changing completed training settings  
> requires a new attempt.

The bootstrap-only policy itself may still be retried because it belongs to the  
separate incomplete/failed bootstrap stage.

---

# 5. Authoritative Part D snapshot

Bootstrap accepts only the supported:

```
part_d_snapshot_version = "1.0"
stage = "part_d"
```

and requires non-empty training records.

After `prepare_stage_execution()` it reloads the exact authoritative Part D  
prerequisite selected for that execution and verifies it matches the preflight  
snapshot.

This protects the boundary between:

```
preflight
→ stage creation
→ bootstrap construction
```

against unexpected state drift.

---

# 6. Persisted Part B and Part C reconstruction

Bootstrap does not reuse live in-memory objects from the original training  
request.

It reloads the authoritative successful:

```
part_b/result.json
part_c/result.json
```

through the Run Management artifact resolver and reconstructs:

```
PartBHandoff
PartCHandoff
```

It also reloads the exact successful persisted request snapshots:

```
PreprocessingStageRequest
FeatureEngineeringStageRequest
```

This is necessary because the saved inference contract must preserve both:

```
original effective configuration
+
resolved configuration actually used during training
```

---

# 7. Dataset-contract continuity

Before saved state can be created:

```
Part B DatasetInputConfig
=
Part C DatasetInputConfig
```

and the Part D snapshot's persisted dataset contract must equal the same B/C  
dataset contract.

Therefore bootstrap refuses a saved state assembled from inconsistent training  
lineage.

The physical training `input_file` itself is not frozen into future inference  
configuration. Future Part E calls receive new incoming data.

---

# 8. KPI continuity across B/C/D

Bootstrap constructs KPI maps from:

```
Part B preprocessing results
Part C feature-engineering results
Part D training records
```

and requires:

```
B KPI set
=
C KPI set
=
D KPI set
```

Part D training records must additionally:

```
have unique KPI names
status = completed
model_type = request.training.model_type
```

No KPI may silently disappear between preprocessing, feature engineering,  
training, and inference-state creation.

---

# 9. Common resolved B/C contract

The saved inference configuration represents one coherent pipeline contract.

Bootstrap therefore requires all KPI Part B results to share the same resolved  
frequency/preprocessing contract and all KPI Part C results to share the same  
resolved feature-engineering contract.

The saved contract stores:

```
preprocessing:
    config
    resolved

feature_engineering:
    config
    resolved
```

Part E can therefore later verify that current code resolves the stored  
configuration exactly as it did during training.

---

# 10. Final history requirement

Bootstrap calculates the final history contract from the actual Part B and  
Part C resolved settings.

Conceptually:

```
part_b_days =
max(
    1,
    phase_2.recent_same_type_lookback_days,
    phase_2.last_week_lookback_days,
    phase_3.maximum_lookback_days,
    phase_4.minimum_history_days if enabled
)
```

Part B point requirement is at least:

```
part_b_days × points_per_day
```

and if Prophet Phase 4 is enabled it must also cover:

```
prophet_minimum_history_points
```

Part C contributes:

```
minimum_history_points
maximum_lookback_points + 1
```

Final requirement:

```
final_required_history_points =
max(
    Part B required points,
    Part C minimum_history_points,
    Part C maximum_lookback_points + 1
)
```

and:

```
cache_days =
final_required_history_days
+
max_gap_days
```

Bootstrap also freezes:

```
max_gap_ratio
late_data_reconstruction_enabled
```

for future Part E reconstruction.

---

# 11. Raw history and cache

The initial raw history is copied from the immutable attempt-owned original  
training input:

```
attempt/input/<training source>
    ↓
history/raw_history.csv
```

The initial raw cache is then created from the trailing configured cache window:

```
cache/raw_cache.csv
```

Timestamp handling:

```
parse UTC
reject invalid timestamp values
find maximum timestamp
retain:
max - cache_days + bucket_minutes
through
max
```

An empty initial cache is rejected.

---

# 12. Processed history and cache

For every trained KPI, bootstrap copies the Part B final cleaned dataset as  
persistent processed history:

```
Part B final_dataset_file
    ↓
history/processed/<kpi>.csv
```

and creates:

```
cache/processed/<kpi>.csv
```

from the same trailing cache window.

Part C's feature-engineered training dataset is **not** used as the persistent  
processed history.

This preserves the intended inference reconstruction lifecycle:

```
raw history
→ Part A
→ Part B
→ Part C features rebuilt when necessary
```

rather than treating historical Part C features as permanent source history.

---

# 13. Self-contained Part D model package

Part E receives only:

```
runs/<run_id>/inference/<attempt_id>/
```

Therefore inference cannot depend on model files living elsewhere inside the  
training-attempt tree.

For each KPI bootstrap copies the complete finalized Part D training package  
into:

```
models/<safe-kpi>/training/
```

This is the main production adaptation from the temporary A→E test workflow.

---

# 14. Part D source-path validation

Part D artifact paths are persisted in JSON and later reloaded by bootstrap.

The final bootstrap therefore revalidates that the registered Part D source  
artifacts:

```
exist
have the expected file/directory type
remain below the owning run root
```

A corrupted snapshot pointing outside the run is rejected as:

```
BOOTSTRAP_PART_D_SOURCE_OUTSIDE_RUN
```

---

# 15. Copied-package validation

Bootstrap does not build the saved inference model contract from the original  
Part D files after copying.

Instead:

```
Part D training package
    ↓ copytree
bootstrap models/<kpi>/training/
    ↓
read copied metadata.json
read copied decision_settings.json
    ↓
build saved model contract
```

This proves that the package actually being published is independently usable.

The runtime sanity test explicitly mutated the original metadata after  
`copytree()` and verified bootstrap still succeeded from the copied package.

---

# 16. Saved series/model consistency

The copied Part D metadata must contain:

```
series_models
```

and decision settings must contain exactly the same series keys.

Every saved series must provide:

```
identity
relative model_file
decision_settings
```

Model paths are normalized and cannot:

```
be absolute
contain ".."
escape the copied training package
```

Bootstrap also validates:

```
Part D snapshot model_files
=
metadata series_models model files
```

and:

```
saved series count
=
Part D trained_series
```

This prevents the saved inference contract from describing a different set of  
models than Part D actually finalized.

---

# 17. Portable model paths

The final saved contract stores model paths relative to the published  
inference-state root.

Example:

```
models/KPI_A/training/model/series_001.json
```

rather than:

```
C:\...
/server/...
runs/<run>/attempts/.../part_d/...
```

This makes the inference-ready directory self-contained and portable.

---

# 18. XGBoost saved contract

For XGBoost bootstrap stores per KPI:

```
model_feature_columns
target_column
series
```

and per series:

```
identity
model_file
decision_settings
```

`target_column` is mandatory for the XGBoost contract.

The top-level model contract also freezes:

```
threshold_direction
```

used by the completed training request.

---

# 19. Isolation Forest saved contract

For Isolation Forest bootstrap stores per KPI:

```
model_feature_columns
series
```

and per series:

```
identity
model_file
decision_settings
```

No XGBoost target column is added to the Isolation Forest contract.

The top-level Isolation Forest contract likewise freezes:

```
threshold_direction
```

---

# 20. KPI filesystem names

Bootstrap uses deterministic sanitized KPI directory names.

If two logical KPI names sanitize to the same filesystem component, bootstrap  
disambiguates their directory names without changing the original logical KPI  
identities.

The saved contract remains keyed by the real KPI names.

---

# 21. `SavedInferenceContract`

Bootstrap writes one validated:

```
inference_config.json
```

containing:

```
run_id
created_at_utc
model_type

dataset
preprocessing
feature_engineering
history
storage
model
```

The storage contract contains only inference-root-relative paths.

---

# 22. Registered bootstrap outputs

Bootstrap registers stable bootstrap artifacts through Run Management,  
including:

```
inference_config.json
raw_history.csv
raw_cache.csv
processed history per KPI
processed cache per KPI
```

Run Management remains responsible for:

```
output validation
checksums where requested
result.json persistence
manifest transition
```

---

# 23. Atomic publication and activation

Bootstrap initially writes into the execution-specific staging state supplied by  
Run Management.

On:

```
manager.complete_stage(...)
```

Run Management owns the final lifecycle:

```
validate staging outputs
    ↓
publish/move staged state
    ↓
runs/<run_id>/inference/<attempt_id>/
    ↓
remap persisted paths
    ↓
mark inference_bootstrap completed
    ↓
activate this attempt as active_inference_attempt_id
```

The workflow itself does not manually update the active inference pointer.

---

# 24. Bootstrap error lifecycle

Errors before bootstrap execution creation—most importantly completed-D config  
mismatch—propagate as domain errors to the future API error handler.

Once a bootstrap execution exists:

```
construction/publication error
→ manager.fail_stage()
→ failed StandaloneStageResponse
```

A failed bootstrap does **not** invalidate or rerun completed Part D.

The attempt remains eligible for bootstrap retry.

---

# 25. `training_pipeline.py`

## Responsibility

`training_pipeline.py` composes the existing frozen stage workflows.

It provides:

```
run_training_stage_workflow()
run_training_pipeline()
```

It contains no direct A/B/C/D ML calls.

---

# 26. Standalone final training lifecycle

`run_training_stage_workflow()` is the behavior intended behind the final  
standalone training endpoint.

It first inspects persisted lineage:

```
Part D completed?
bootstrap completed?
```

Cases:

### Case A — neither complete

```
run/retry Part D
    ↓
if D succeeds
    ↓
run bootstrap
```

### Case B — D completed, bootstrap incomplete/failed

```
reuse completed D
    ↓
bootstrap only
```

Part D is not rerun.

### Case C — D + bootstrap completed

Rejected as:

```
TRAINING_ATTEMPT_ALREADY_INFERENCE_READY
```

because the lifecycle is already complete.

### Case D — bootstrap completed, D incomplete

Rejected as:

```
INCONSISTENT_TRAINING_LIFECYCLE
```

because bootstrap's canonical prerequisite is Part D.

---

# 27. Bootstrap-only retry

The key production retry rule is:

```
D execution_0001 completed
bootstrap execution_0001 failed
```

then a later training-endpoint retry performs:

```
D execution count remains unchanged
bootstrap execution_0002 starts
```

This is required by completed-stage immutability.

The standalone response can include either:

```
part_d + inference_bootstrap
```

for a fresh lifecycle, or:

```
inference_bootstrap only
```

for a bootstrap-only retry.

---

# 28. Standalone training response semantics

Fresh D + bootstrap success:

```
status = completed
requested_stage = part_d
next_stage = inference
inference_ready = true
```

D success + bootstrap failure:

```
status = partially_completed
next_stage = inference_bootstrap
inference_ready = false
```

D failure:

```
exact Part D failed response returned
bootstrap not launched
```

---

# 29. Master training request

`run_training_pipeline()` consumes:

```
TrainingPipelineRequest
```

which intentionally contains:

```
NO attempt_id
```

Therefore every master invocation is a fresh training attempt.

Selection:

```
run_id omitted
→ Part A creates new run + fresh attempt

run_id supplied
→ Part A creates fresh attempt under existing run
```

A failed master attempt is resumed through the corresponding standalone stage  
endpoint rather than by submitting the master pipeline again.

---

# 30. Master stage sequence

The master delegates exactly:

```
run_part_a_workflow()
    ↓
run_part_b_workflow()
    ↓
run_part_c_workflow()
    ↓
run_training_stage_workflow()
        ├── run_part_d_workflow()
        └── run_inference_bootstrap_workflow()
```

No ML execution path is duplicated.

---

# 31. Part C default-profile behavior

When the master request contains:

```
feature_engineering = None
```

the generated Part C request contains:

```
model_type_hint = training.model_type
```

and Part C resolves the model-matched default profile using the shared workflow  
utility.

With an explicit Part C configuration:

```
feature_engineering = explicit config
model_type_hint = None
```

The explicit config remains authoritative.

---

# 32. Master failure semantics

### Part A failure

No previous training stage completed:

```
status = failed
failed_stage = part_a
```

No B/C/D/bootstrap call is made.

### Part B failure

A completed:

```
status = partially_completed
failed_stage = part_b
```

### Part C failure

A+B completed:

```
status = partially_completed
failed_stage = part_c
```

### Part D failure

A+B+C completed:

```
status = partially_completed
failed_stage = part_d
```

Bootstrap is not launched.

### Bootstrap failure

A+B+C+D completed:

```
status = partially_completed
failed_stage = inference_bootstrap
next_stage = inference_bootstrap
inference_ready = false
```

---

# 33. Successful master response

Only after all five canonical training lifecycle stages complete:

```
part_a
part_b
part_c
part_d
inference_bootstrap
```

does the master return:

```
status = completed
next_stage = inference
inference_ready = true
```

The active inference-ready saved state is already published by Run Management  
at that point.

---

# 34. Responsibility boundary

```
training_pipeline.py
→ stage composition only

inference_bootstrap.py
→ D-to-saved-inference-state conversion

Run Management
→ stage legality, manifest authority, publication, activation

individual Phase 4 workflows
→ A/B/C/D execution orchestration

ML modules
→ EDA, preprocessing, features, model training

Part E
→ later independent inference calls
```

---

# 35. Sanity results

Final `inference_bootstrap.py`:

```
INFERENCE_BOOTSTRAP_SYNTAX=PASS
INFERENCE_BOOTSTRAP_RUNTIME_SMOKE=PASS
INFERENCE_BOOTSTRAP_INDEPENDENT_SANITY=PASS
```

Runtime coverage included:

```
XGBoost bootstrap success
Isolation Forest bootstrap success
raw history/cache creation
processed history/cache creation
self-contained copied model package
portable relative model paths
copied-package metadata usage
completed-D config mismatch before execution creation
Part D path escape rejection
non-completed D training-record rejection
publication + active inference-attempt transition
```

Final `training_pipeline.py`:

```
TRAINING_PIPELINE_SYNTAX=PASS
TRAINING_PIPELINE_RUNTIME_SMOKE=PASS
TRAINING_PIPELINE_INDEPENDENT_SANITY=PASS
```

Runtime coverage included:

```
fresh D → bootstrap success
D failure stops bootstrap
completed D → bootstrap-only retry
bootstrap failure after new D
bootstrap failure after reused D
duplicate completed lifecycle rejection
inconsistent bootstrap-without-D rejection

full master A→B→C→D→bootstrap success
model-matched omitted Part C profile
explicit Part C config preservation
A failure
B failure
C failure
D failure
bootstrap failure
```

---

# 36. Final assessment

Phase 5 now completes the training side of the final backend lifecycle.

```
TRAINING

A
↓
B
↓
C
↓
D
↓
inference_bootstrap
↓
self-contained published inference state
↓
active_inference_attempt_id
```

After this phase the backend has a stable, retry-safe boundary between training  
and future inference.

The next workflow phase is:

```
Phase 6
└── part_e.py
```

which should remain a thin wrapper around the already-tested pure Part E  
inference runner.