# Level 6 Testing Coverage Report

## Telecom Anomaly Detection Backend

**Project:** JIO Internship — Telecom Anomaly Detection Backend  
**Testing Level:** Level 6  
**Primary Scope:** Run Management Integrity Certification  
**Status:** PASSED

---

## 15.1 Objective

Level 6 deliberately moved away from ML mathematics.

The ML stages were already heavily tested.

Level 6 focused on the operational state model:

```text
RUN
  ↓
ATTEMPT
  ↓
STAGE
  ↓
EXECUTION
```

It asked:

> Can the backend safely manage the lifecycle of multiple attempts, stages, retries and artifacts without corrupting run state?

The Level 6 generator was external-only and imported no `app.*` modules.

It contained:

```text
14 cases
```

---

# 16. Level 6 — Exact Coverage

The 14 Level 6 cases covered:

## Case 01 — Basic run + registry consistency

Verified creation of a valid logical run and agreement between run state and the central registry.

---

## Case 02 — Immutable attempt input/request ownership

Verified that an attempt receives its own immutable:

```text
input
request
```

state and does not continue depending on the external caller's mutable files.

---

## Case 03 — Successful stage execution lifecycle

Verified the normal stage lifecycle:

```text
created/pending
        ↓
running
        ↓
completed
```

and that the execution record matched the stage state.

---

## Case 04 — Failed stage execution lifecycle

Verified:

```text
running
        ↓
failed
```

including persistence of failure/error information.

---

## Case 05 — Failed-stage retry preserves execution history

A failed stage was rerun within the same attempt.

The test required:

```text
Execution 1 = failed
Execution 2 = completed
```

rather than overwriting Execution 1.

This established execution history as append-style audit state.

---

## Case 06 — Completed-stage immutability

A completed stage could not be rerun inside the same attempt.

This protects completed stage artifacts and execution history from silent replacement.

---

## Case 07 — Prerequisite enforcement after failed upstream stage

A downstream stage could not run when an upstream prerequisite had failed.

Example:

```text
Part B failed
        ↓
Part C prohibited
```

---

## Case 08 — Fresh-attempt sequencing under one logical run

Verified:

```text
Run
├── Attempt 0001
└── Attempt 0002
```

and correct ordering/latest-attempt behavior.

---

## Case 09 — Run/attempt status derivation and event history

Verified that run-level and attempt-level status were derived consistently from their executions/stages and that event history recorded lifecycle operations.

---

## Case 10 — Inference activation after completed bootstrap

Verified that a run became inference-ready only after a valid completed training attempt reached successful inference bootstrap.

---

## Case 11 — Registry ↔ Manifest V2 synchronization

Verified that the registry and Manifest V2 represented the same authoritative run/attempt state.

---

## Case 12 — Session-wide orphaned-running audit

Inspected the complete test session for records incorrectly left in:

```text
running
```

after the associated operation had finished or failed.

This catches lifecycle cleanup defects that may not be visible from a single request response.

---

## Case 13 — Cross-run attempt isolation

Verified that attempts and artifacts belonging to one logical run could not be confused with or attached to another run.

---

## Case 14 — Deep artifact/path containment

Verified that owned artifacts remained below the correct:

```text
run
attempt
stage
execution
```

roots.

This protected against path escape and cross-run/cross-attempt ownership errors.

---

# 17. Level 6 — Main Architectural Rules Certified

Level 6 established the following important behavior:

### Completed stages are immutable

```text
completed stage
→ cannot rerun inside same attempt
```

---

### Failed stages are retryable

```text
failed execution
        ↓
new execution under same stage
```

with previous execution history preserved.

---

### Master pipeline creates a new attempt

A new complete pipeline execution under the same logical run does not mutate a completed previous attempt.

---

### Prerequisites are enforced

A later stage cannot bypass an incomplete/failed required upstream stage.

---

### Inference readiness is attempt-specific

A logical run is not inference-ready merely because some files happen to exist.

Inference readiness is tied to a successful bootstrap on the correct completed attempt.

---

### Registry, manifest and filesystem must agree

No one representation is allowed to silently contradict the others.

---

## Level 6 Result

After repeated successful runs:

```text
LEVEL 6 — PASSED
```

Level 6 certified:

> The backend's RUN → ATTEMPT → STAGE → EXECUTION model behaves correctly across success, failure, retry, immutability, prerequisites, multiple attempts, registry/manifest synchronization and artifact ownership.

---
