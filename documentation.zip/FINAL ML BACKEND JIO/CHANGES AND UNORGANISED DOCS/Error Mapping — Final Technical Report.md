**Scope:** Final public HTTP error classification contract  
**Primary consumer:** `app/api/error_handlers.py` and all API route modules  
**Status:** Frozen

---

# 1. Purpose

This document defines **how backend failures are classified into HTTP responses**.

It does **not** explain the implementation details of `error_handlers.py`. Its job is to define the policy:

```
Which failures become 404?
Which become 409?
Which become 422?
Which remain 500?
What information is allowed to be exposed?
```

The central rule is fail-closed:

```
Every TelecomBackendError
        ↓
HTTP 500 by default
```

Only explicitly reviewed application `error_code` values may become public 4xx responses.

---

# 2. Two Different Codes

Every backend API failure can contain two different kinds of code.

## HTTP status

Examples:

```
404
409
422
500
```

This describes the HTTP meaning of the failure.

## Application `error_code`

Examples:

```
API_RUN_NOT_FOUND
COMPLETED_STAGE_IS_IMMUTABLE
NO_FORWARD_INFERENCE_DATA
INCONSISTENT_STAGE_LINEAGE
MODEL_NOT_FOUND
```

This identifies the exact backend condition.

Therefore:

```
HTTP status
≠
application error_code
```

Multiple distinct internal failures can correctly share HTTP 500 while still  
having different `error_code` values.

---

# 3. Final Fail-Closed Rule

The final decision process is:

```
TelecomBackendError occurs
        ↓
normalize error_code
        ↓
is the code explicitly approved as public?
        │
        ├── approved 404
        ├── approved 409
        ├── approved 422
        │
        └── otherwise
              ↓
            HTTP 500
```

In compact form:

```
404 / 409 / 422 = OPT-IN

500 = DEFAULT
```

This protects the backend from accidentally misclassifying an internal failure  
as a caller mistake.

---

# 4. Public Error Response Shape

Every API-level error uses:

```
{
  "status": "failed",
  "error": {
    "error_type": "...",
    "message": "...",
    "error_code": "...",
    "details": {}
  }
}
```

The mapping policy controls:

```
HTTP status
public message
public error_code
public details
```

---

# 5. Final 404 Policy

404 is only for a **public logical resource that the API boundary knows the  
caller requested and that genuinely does not exist**.

Approved codes:

```
API_RUN_NOT_FOUND
API_ATTEMPT_NOT_FOUND
```

## `API_RUN_NOT_FOUND`

```
HTTP:
404

message:
The requested run was not found.

details:
run_id
```

## `API_ATTEMPT_NOT_FOUND`

```
HTTP:
404

message:
The requested training attempt was not found.

details:
run_id
attempt_id
```

---

# 6. Why Low-Level Missing-State Codes Are Not Automatically 404

These are not public by default:

```
RUN_NOT_FOUND
ATTEMPT_NOT_FOUND
REGISTERED_RUN_DIRECTORY_NOT_FOUND
MODEL_NOT_FOUND
artifact missing
manifest missing
```

A low-level missing-state error may mean the backend itself expected the state  
to exist.

Example:

```
registry says run exists
        ↓
backend tries to resolve it
        ↓
run state is missing
```

That is an internal backend failure:

```
→ 500
```

Therefore routes translate only genuine public lookups:

```
RUN_NOT_FOUND
        ↓
route confirms this is caller-owned lookup
        ↓
API_RUN_NOT_FOUND
        ↓
404
```

---

# 7. Final 409 Policy

409 means:

```
request is valid
+
backend state is healthy
+
current lifecycle prevents the requested operation
```

Approved codes:

```
COMPLETED_STAGE_IS_IMMUTABLE
STAGE_EXECUTION_ALREADY_RUNNING
STAGE_PREREQUISITE_NOT_COMPLETED
RUN_NOT_INFERENCE_READY
TRAINING_ATTEMPT_ALREADY_INFERENCE_READY
```

---

# 8. `COMPLETED_STAGE_IS_IMMUTABLE`

Meaning:

```
caller attempted to change/rerun a completed stage
inside the same immutable training attempt
```

HTTP:

```
409
```

Allowed details:

```
attempt_id
stage_name
successful_execution_id
required_action
```

---

# 9. `STAGE_EXECUTION_ALREADY_RUNNING`

Meaning:

```
the requested stage already has an active execution
```

HTTP:

```
409
```

Allowed details:

```
attempt_id
stage_name
execution_id
```

---

# 10. `STAGE_PREREQUISITE_NOT_COMPLETED`

Meaning:

```
caller requested a stage before its required upstream stage completed
```

HTTP:

```
409
```

Allowed details:

```
attempt_id
stage_name
required_stage
```

---

# 11. `RUN_NOT_INFERENCE_READY`

Meaning:

```
caller requested inference
but the run has no active inference-ready training attempt
```

HTTP:

```
409
```

Allowed details:

```
run_id
```

---

# 12. `TRAINING_ATTEMPT_ALREADY_INFERENCE_READY`

Meaning:

```
caller attempted to repeat the training lifecycle on an attempt that is already finalized for inference
```

HTTP:

```
409
```

Allowed details:

```
run_id
attempt_id
part_d_execution_id
bootstrap_execution_id
```

---

# 13. Why `RUN_LOCK_TIMEOUT` Is Not Public 409

The low-level lock implementation is shared by multiple backend components.

Therefore:

```
RUN_LOCK_TIMEOUT
```

does not prove that:

```
the caller's run is simply busy
```

It may also represent registry or internal lock contention.

Final policy:

```
RUN_LOCK_TIMEOUT
→ 500
```

If a future API-specific condition such as:

```
API_RUN_BUSY
```

is introduced, that could be reviewed separately for 409.

---

# 14. Final 422 Policy

422 means:

> The caller can reasonably fix the request or supplied data.

There are two public 422 groups:

```
A. API-boundary input/file validation
B. confirmed Part E caller-data conditions
```

---

# 15. API Input/File 422 Codes

Approved API-boundary codes:

```
API_INPUT_FILE_NOT_FOUND
API_INPUT_PATH_NOT_FILE
API_INPUT_FILE_EXTENSION_INVALID
API_INPUT_FILE_EMPTY
API_INPUT_FILE_TOO_LARGE
API_INPUT_FILENAME_INVALID
API_INPUT_CSV_PARSE_FAILED
API_INPUT_CSV_ENCODING_INVALID
API_INPUT_CSV_EMPTY
```

These codes are intentionally prefixed with:

```
API_
```

because the route must know that the failure belongs to the caller's input.

---

# 16. Generic File-Service Codes Remain 500

Generic shared-service codes are not public by default:

```
FILE_NOT_FOUND
PATH_IS_NOT_FILE
INVALID_FILE_EXTENSION
EMPTY_FILE
FILE_TOO_LARGE
EMPTY_CSV
CSV_PARSE_FAILED
CSV_ENCODING_ERROR
```

Reason:

```
the same file service is used for:
caller-owned files
and
backend-owned files
```

So:

```
EMPTY_FILE
```

could mean:

```
uploaded CSV is empty
→ caller issue
```

or:

```
internal cache/intermediate file became empty
→ backend issue
```

The code alone is ambiguous.

Therefore generic codes remain:

```
500
```

until a route translates a caller-owned failure into an `API_*` code.

---

# 17. API File Boundary Translation

Example:

```
caller CSV parsing fails
        ↓
file_service emits CSV_PARSE_FAILED
        ↓
route knows this is the request-owned CSV
        ↓
translate to API_INPUT_CSV_PARSE_FAILED
        ↓
422
```

By contrast:

```
internal cache CSV fails
        ↓
CSV_PARSE_FAILED
        ↓
no API translation
        ↓
500
```

This separation is deliberate.

---

# 18. Public API File Messages

## `API_INPUT_FILE_NOT_FOUND`

```
422
The supplied input file was not found.
```

## `API_INPUT_PATH_NOT_FILE`

```
422
The supplied input path is not a regular file.
```

## `API_INPUT_FILE_EXTENSION_INVALID`

```
422
The supplied input file type is not supported.
```

Allowed details:

```
received_extension
allowed_extensions
```

## `API_INPUT_FILE_EMPTY`

```
422
The supplied input file is empty.
```

## `API_INPUT_FILE_TOO_LARGE`

```
422
The supplied input file exceeds the permitted size.
```

Allowed details:

```
file_size_bytes
maximum_size_bytes
maximum_size_gb
```

## `API_INPUT_FILENAME_INVALID`

```
422
The supplied input file name is invalid.
```

## `API_INPUT_CSV_PARSE_FAILED`

```
422
The supplied CSV file could not be parsed.
```

## `API_INPUT_CSV_ENCODING_INVALID`

```
422
The supplied CSV file encoding is not supported.
```

## `API_INPUT_CSV_EMPTY`

```
422
The supplied CSV contains no usable data.
```

---

# 19. Confirmed Part E Caller-Data 422 Codes

Approved inference caller-data codes:

```
NO_FORWARD_INFERENCE_DATA
NO_FORWARD_DATA_IN_REQUESTED_INFERENCE_WINDOW
INFERENCE_HISTORY_MAX_GAP_DAYS_EXCEEDED
INFERENCE_HISTORY_MAX_GAP_RATIO_EXCEEDED
```

These are public because they describe the relationship between the caller's  
new inference data and the requested inference operation.

---

# 20. `NO_FORWARD_INFERENCE_DATA`

Meaning:

```
input contains no new timestamps beyond finalized history
```

HTTP:

```
422
```

---

# 21. `NO_FORWARD_DATA_IN_REQUESTED_INFERENCE_WINDOW`

Meaning:

```
new timestamps exist
but no rows fall inside the requested inference window
```

HTTP:

```
422
```

Allowed details:

```
new_period_start
new_period_end_exclusive
inference_days
```

---

# 22. `INFERENCE_HISTORY_MAX_GAP_DAYS_EXCEEDED`

Meaning:

```
incoming inference continuity gap exceeds configured allowed duration
```

HTTP:

```
422
```

Allowed details:

```
series
gap_points
gap_days
max_gap_days
```

---

# 23. `INFERENCE_HISTORY_MAX_GAP_RATIO_EXCEEDED`

Meaning:

```
incoming inference gap ratio exceeds configured limit
```

HTTP:

```
422
```

Allowed details:

```
series
gap_points
gap_ratio
max_gap_ratio
```

---

# 24. Uncertain/Internal Part E Validation Remains 500

Examples:

```
INFERENCE_MODEL_TYPE_CONTRACT_MISMATCH
INFERENCE_PART_C_FEATURE_COLUMNS_MISMATCH
HISTORY_RUNNER_PART_B_KPI_SET_MISMATCH
INFERENCE_HISTORY_BUCKET_MISALIGNMENT
LATE_DATA_RECONSTRUCTION_DISABLED
unknown history validation codes
```

These may represent:

```
saved model contract corruption
saved history/cache inconsistency
training/inference mismatch
internal implementation assumptions
```

Therefore:

```
→ 500
```

unless explicitly reviewed later.

---

# 25. FastAPI/Pydantic 422

FastAPI schema validation is separate from backend error mapping.

Example:

```
{
  "inference_days": 0
}
```

when the request schema requires:

```
inference_days >= 1
```

Response:

```
HTTP 422
error_type = RequestValidationError
error_code = REQUEST_VALIDATION_FAILED
message = The request did not satisfy the API schema.
```

Safe details include only:

```
type
loc
msg
```

Raw:

```
input
ctx
```

are intentionally excluded.

---

# 26. Final 500 Policy

Every backend error not explicitly listed as public 404/409/422 becomes:

```
HTTP 500
```

Examples include:

```
configuration failures
registry failures
manifest failures
artifact failures
model failures
internal file failures
lock subsystem failures
saved-state inconsistencies
unknown validation codes
internal Part E contract mismatches
pipeline failures
reporting failures
agent failures
email failures
future unknown TelecomBackendError codes
```

---

# 27. Public 500 Response Policy

Public response:

```
{
  "status": "failed",
  "error": {
    "error_type": "SpecificBackendError",
    "message": "An internal backend error occurred while processing the request.",
    "error_code": "SPECIFIC_INTERNAL_CODE",
    "details": {}
  }
}
```

Rules:

```
specific application error_code retained
generic message
no public details
full diagnostics server-side only
```

---

# 28. Known 500 vs Unknown 500

## Known 500

Example:

```
INCONSISTENT_STAGE_LINEAGE
```

Meaning:

```
HTTP = 500
specific internal diagnosis exists
```

Use:

```
error_code
+
diagnostic family
+
logs
```

for targeted investigation.

## Unknown 500

Unexpected Python exception:

```
HTTP 500
error_code = INTERNAL_SERVER_ERROR
```

This requires broader traceback/log investigation.

---

# 29. Diagnostic Families

500 errors are further classified server-side into:

```
RUN_STATE
REGISTRY
MANIFEST
ARTIFACT
LOCK_INTERNAL
CONFIGURATION
FILE_IO
VALIDATION
MODEL
PIPELINE
INFERENCE_CONTRACT
HISTORY_STATE
REPORTING
AGENT
EMAIL
UNKNOWN
```

This classification does **not** change the HTTP status.

It only narrows debugging.

---

# 30. Diagnostic Family Examples

```
INCONSISTENT_STAGE_LINEAGE
→ 500
→ RUN_STATE
```

```
RUN_REGISTRY_WRITE_FAILED
→ 500
→ REGISTRY
```

```
MODEL_NOT_FOUND
→ 500
→ MODEL
```

```
INFERENCE_PART_C_FEATURE_COLUMNS_MISMATCH
→ 500
→ INFERENCE_CONTRACT
```

```
HISTORY_RUNNER_PART_B_KPI_SET_MISMATCH
→ 500
→ HISTORY_STATE
```

```
EMPTY_FILE from shared backend service
→ 500
→ FILE_IO
```

```
unknown InputValidationError
→ 500
→ VALIDATION
```

---

# 31. Information Exposure Rules

## Approved 4xx

Return:

```
fixed safe public message
canonical application error_code
explicitly approved details only
```

## 500

Return:

```
generic message
specific error_code
details = {}
```

Never expose:

```
filesystem paths
raw parser/library errors
tracebacks
internal object repr
backend directory structure
raw environment/configuration values
```

---

# 32. Detail Allowlisting

The system does not expose every internal `error.details` field.

Instead:

```
public error policy
        ↓
explicit detail_keys
        ↓
only those keys may be returned
```

Everything else is discarded.

Example:

```
API_RUN_NOT_FOUND
→ only run_id
```

Even if the backend exception also contains:

```
run_directory
registry_file
original_error
debug_context
```

those are not returned.

---

# 33. Final Public Mapping Table

## 404

```
API_RUN_NOT_FOUND
API_ATTEMPT_NOT_FOUND
```

## 409

```
COMPLETED_STAGE_IS_IMMUTABLE
STAGE_EXECUTION_ALREADY_RUNNING
STAGE_PREREQUISITE_NOT_COMPLETED
RUN_NOT_INFERENCE_READY
TRAINING_ATTEMPT_ALREADY_INFERENCE_READY
```

## 422 — API input/file

```
API_INPUT_FILE_NOT_FOUND
API_INPUT_PATH_NOT_FILE
API_INPUT_FILE_EXTENSION_INVALID
API_INPUT_FILE_EMPTY
API_INPUT_FILE_TOO_LARGE
API_INPUT_FILENAME_INVALID
API_INPUT_CSV_PARSE_FAILED
API_INPUT_CSV_ENCODING_INVALID
API_INPUT_CSV_EMPTY
```

## 422 — confirmed inference caller-data

```
NO_FORWARD_INFERENCE_DATA
NO_FORWARD_DATA_IN_REQUESTED_INFERENCE_WINDOW
INFERENCE_HISTORY_MAX_GAP_DAYS_EXCEEDED
INFERENCE_HISTORY_MAX_GAP_RATIO_EXCEEDED
```

## 500

```
EVERY OTHER TelecomBackendError CODE
```

---

# 34. Final Mapping Principle

The frozen policy is:

```
public 4xx must be proven safe
500 does not need to be proven
```

Therefore:

```
known public condition
→ explicit 404 / 409 / 422

ambiguous
internal
new
unknown
→ 500
```

This prevents the backend from:

```
incorrectly blaming the caller
or
exposing internal information
```

while preserving specific error codes for server-side diagnosis.

**Final status: Frozen mapping contract.**