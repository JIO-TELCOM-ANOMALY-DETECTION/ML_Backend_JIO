# API Module — Final Technical Summary

**Module Location:** `app/api/`

## Files

| File                     | Main Responsibility                                                            |
| ------------------------ | ------------------------------------------------------------------------------ |
| `__init__.py`            | Stable public API-package import surface                                       |
| `dependencies.py`        | Shared FastAPI dependencies, Run Manager resolution, and route logging helpers |
| `error_handlers.py`      | Central safe HTTP error translation and fail-closed error policy               |
| `health.py`              | Basic application liveness endpoint                                            |
| `runs.py`                | Read-only run/attempt inspection endpoints                                     |
| `eda.py`                 | Production standalone Part A endpoint                                          |
| `preprocessing.py`       | Production standalone Part B endpoint                                          |
| `feature_engineering.py` | Production standalone Part C endpoint                                          |
| `training.py`            | Production standalone Part D + inference-bootstrap endpoint                    |
| `pipeline.py`            | Master A→B→C→D→bootstrap training endpoint                                     |
| `inference.py`           | Production Part E inference endpoint                                           |

Together these files form the complete production **HTTP/API boundary** for the current ML backend.

---

# 1. Purpose of `app/api`

The API module exposes the backend's production HTTP surface while keeping the HTTP layer intentionally thin.

Its role is:

```
HTTP request
    ↓
Pydantic/FastAPI validation
    ↓
small caller-owned boundary checks
    ↓
shared Run Manager / logger dependency
    ↓
workflow delegation
    ↓
safe workflow response
```

It does not implement Parts A–E itself.

The central architectural rule is:

```
API
→ transport and public-boundary concerns

Workflows
→ lifecycle orchestration

Run Management
→ run/attempt/execution/invocation state and lineage

ML
→ Parts A-E computation
```

---

# 2. Final Production HTTP Surface

## Application health

```
GET /health
```

## Run inspection

```
GET /api/v1/runs
GET /api/v1/runs/{run_id}
GET /api/v1/runs/{run_id}/attempts/{attempt_id}
```

## Standalone stage execution

```
POST /api/v1/eda/run
POST /api/v1/preprocessing/run
POST /api/v1/feature-engineering/run
POST /api/v1/training/run
```

## Complete training pipeline

```
POST /api/v1/pipeline/run
```

## Production inference

```
POST /api/v1/inference/run
```

---

# 3. API Module Architecture

```
                         Client
                           │
                           ▼
                        FastAPI
                           │
          ┌────────────────┼────────────────┐
          ▼                ▼                ▼
       /health          /runs/*        execution routes
                                            │
                                            ▼
                                  app/api route modules
                                            │
                                            ▼
                                      workflows
                                            │
                                            ▼
                                     Run Management
                                            │
                                            ▼
                                       ML Parts A-E
```

Run-inspection endpoints form a read-only control-plane surface, while stage/pipeline/inference endpoints delegate execution into workflows.

---

# 4. `dependencies.py`

This file centralizes reusable API infrastructure.

Its responsibilities include:

```
shared/lazy RunManager access
FastAPI dependency aliasing
API logger access
run-scoped workflow logger access
```

Route files therefore do not repeatedly construct Run Managers or logging infrastructure.

A normal route receives:

```
manager: RunManagerDependency
```

through FastAPI dependency injection.

The route can then request a run-scoped logger through the shared logging helper.

---

# 5. Why Run Manager Construction Is Centralized

The API does not independently create one manager per endpoint.

Centralizing it provides:

- one consistent registry/manifest configuration;
    
- one Run Management façade;
    
- testability through dependency injection;
    
- less duplicated setup logic;
    
- clearer application-lifecycle ownership.
    

---

# 6. `error_handlers.py`

`error_handlers.py` owns the complete HTTP translation boundary.

Routes raise structured backend exceptions.

The error layer determines:

```
HTTP status
safe public error code
safe public message
safe public details
internal logging behavior
```

Routes therefore do not manually create arbitrary `JSONResponse` objects for each failure.

---

# 7. Error Philosophy

The final policy is **fail closed**:

```
known safe caller/lifecycle error
→ explicit 4xx mapping

unknown backend error
→ 500
```

The API never guesses that an unfamiliar internal failure is the caller's fault.

---

# 8. Public 404 Boundary

A public 404 is used only when caller-owned identity absence is genuinely established.

Examples include:

```
unknown run
unknown caller-selected attempt
```

where applicable.

If registry state says the run exists but internal run/manifest/artifact state is broken, that is not reclassified as a public missing resource.

It remains an internal failure.

---

# 9. Public 409 Boundary

Lifecycle/state conflicts are represented separately from malformed input.

Examples include:

```
run not inference-ready
stage conflict
stage prerequisite conflict
execution conflict
```

These are not generic 422 validation errors.

They express:

> The request is structurally valid, but the current workflow lifecycle does not permit it.

---

# 10. Public 422 Boundary

422 covers validated caller-owned input problems such as:

```
Pydantic request validation
invalid caller file
missing caller file
bad CSV
unsupported extension
empty CSV
oversized CSV
certain known inference-data/history constraints
```

The external CSV routes deliberately translate only file-service codes proven to be caller-owned.

---

# 11. Internal 500 Boundary

Internal failures remain internal, including examples such as:

```
registry says run exists but state is broken
manifest corruption
artifact resolution failure
saved contract corruption
model artifact loss
history/cache corruption
unknown file-service error
unexpected backend exception
unexpected Python exception
```

This preserves a clear security and ownership boundary.

---

# 12. Safe Error Details

Public error responses do not expose arbitrary internal exception details.

The error layer and route-specific translators use explicit allowlists.

Internal values such as:

```
filesystem paths
tracebacks
OS error strings
registry internals
manifest internals
model locations
history/cache locations
```

are not exposed merely because they exist inside the backend exception.

---

# 13. `health.py`

The health route is deliberately independent from the workflow stack.

```
GET /health
→ {"status": "healthy"}
```

It proves only application liveness.

It does not check models, runs, manifests, files, history/cache, or external dependencies.

---

# 14. `runs.py`

`runs.py` is the API's read-only run/attempt inspection surface.

It does not execute ML workflows.

Its role is to provide safe summaries of the authoritative run-management state.

The route layer reads through the Run Management/registry/manifest abstractions rather than arbitrarily browsing run folders.

---

# 15. Run Inspection Responsibility

The run API is intended to answer questions such as:

```
Which runs exist?
What is this run's current status?
Which attempt is latest?
Which attempt is active for inference?
What happened in a specific attempt?
```

without exposing raw physical artifact layouts.

This makes it a control-plane interface rather than an execution route.

---

# 16. `eda.py` — Part A API

The Part A route is the first standalone execution boundary.

It can establish a new logical run/attempt when required and executes Part A through the workflow layer.

Because Part A receives a caller-owned source CSV, the route performs external-file preflight before lifecycle-owned execution begins.

---

# 17. `preprocessing.py` — Part B API

Part B operates from authoritative Part A lineage rather than taking another raw external training CSV.

The route therefore focuses on:

```
caller run/attempt identity
stage request/config
workflow delegation
```

and lets Run Management/artifact resolution determine the exact upstream Part A output.

It does not guess physical filenames.

---

# 18. `feature_engineering.py` — Part C API

Part C similarly consumes authoritative Part B lineage.

The route preserves the frozen configuration rule that Part C can operate using either:

```
explicit feature-engineering configuration
```

or the approved:

```
model_type_hint/default profile
```

behavior defined in the workflow/schema layer.

The HTTP route does not calculate features.

---

# 19. `training.py` — Part D + Bootstrap API

The standalone training route executes the composed training lifecycle:

```
Part D
    ↓
inference_bootstrap
```

rather than stopping after model fitting.

This means successful production training prepares the attempt for later Part E use.

The route itself does not manually build inference configuration/history/cache state; that remains below the API.

---

# 20. `pipeline.py` — Master Training Route

The master route performs:

```
Part A
  ↓
Part B
  ↓
Part C
  ↓
Part D
  ↓
inference_bootstrap
```

through the production workflow layer.

The master request intentionally has no public `attempt_id`.

Every master pipeline call creates a **fresh attempt**.

This preserves immutable attempt lineage.

---

# 21. Master Pipeline Run Semantics

The caller may provide:

```
existing run_id
```

to create another complete attempt under that logical run, or allow the workflow to establish a new run as defined by the request/workflow contract.

What the caller cannot do is instruct the master endpoint to overwrite an existing completed attempt.

---

# 22. Standalone Rerun Semantics

The standalone routes follow the frozen V1 lineage rule:

```
completed upstream stages are immutable
```

A downstream/not-yet-completed stage may execute in the current attempt when prerequisites allow.

If an already-completed upstream stage needs to change, a new attempt is required.

---

# 23. `inference.py` — Part E API

The inference request contains only:

```
run_id
input_file
inference_days
```

There is no public:

```
attempt_id
```

The active inference-ready training attempt is resolved internally through Run Management.

---

# 24. Why Part E Has No Public Attempt Selector

The production inference state is published by the completed training/bootstrap lifecycle.

Therefore the source of truth is:

```
run_id
    ↓
active_inference_attempt_id
```

Allowing the caller to point to an arbitrary training attempt would bypass that publication contract.

---

# 25. Inference External File Boundary

Inference once again receives a caller-owned raw CSV.

It therefore performs the same general external-file preflight family used by the other external-source routes.

After the workflow begins, Run Management creates the request-owned copy and the Part E lifecycle becomes authoritative.

---

# 26. Part E Ownership Below the API

`inference.py` does not implement:

```
inference readiness
active-attempt resolution
request snapshots
invocation IDs
saved contract loading
history/cache validation
late-data classification
A/B/C reconstruction
model loading
prediction
result publication
history/cache commit
```

It delegates once to the Part E workflow.

---

# 27. Training vs Inference Identity Model

Training uses:

```
RUN
  ↓
ATTEMPT
  ↓
STAGE
  ↓
EXECUTION
```

Part E uses inference invocations attached to the authoritative inference-ready training attempt:

```
RUN
  ↓
active inference-ready ATTEMPT
  ↓
INFERENCE REQUEST / INVOCATION
```

The API never generates attempt, execution, or invocation identifiers itself.

---

# 28. Public Responses

The production API uses workflow response schemas rather than ad-hoc dictionaries for execution routes.

These responses expose safe lifecycle/business information such as:

```
status
run_id
attempt_id or training_attempt_id
stage
execution/invocation identity where applicable
summary
safe error
```

They intentionally avoid exposing physical backend paths.

---

# 29. Logging Strategy

The API uses shared logging helpers rather than manually constructing Python loggers.

Patterns include:

```
API logger
```

for API-level diagnostics and:

```
run-scoped workflow/component logger
```

for operations associated with a known run.

Inference deliberately reuses the configured:

```
pipeline
```

logging component instead of adding an unconfigured `"inference"` logger.

---

# 30. External File Validation Strategy

For routes receiving caller-owned CSVs, the API reuses the shared file service.

Preflight includes the relevant generic checks:

```
exists
regular file
.csv extension
non-empty file
configured maximum size
encoding
CSV parsing
non-zero data rows
```

The API does not reimplement Pandas/file validation independently.

---

# 31. External File Ownership Transition

The conceptual boundary is:

```
caller-owned path
    ↓
API preflight
    ↓
workflow / Run Management begins
    ↓
backend-owned request/run copy
    ↓
ML execution
```

After the transition, failures involving copied inputs or generated artifacts are not automatically reclassified as caller file errors.

---

# 32. No Filesystem Guessing

Production route files do not construct paths such as:

```
runs/<run_id>/attempt_.../...
```

or search for "latest" stage folders.

Artifact resolution belongs to Run Management and the manifest/registry lineage contracts.

This eliminates an important source of race conditions and lineage ambiguity.

---

# 33. No Manifest Mutation in Route Files

API routes do not directly edit Manifest V2.

Workflow and Run Management lifecycle functions own:

```
attempt creation
stage execution creation
completion/failure
inference publication
invocation registration
active inference attempt state
```

The HTTP layer only requests those operations.

---

# 34. No Direct ML Orchestration From API

Production execution routes depend on workflow entry points.

They do not manually coordinate:

```
Part A runner
Part B runner
Part C runner
Part D runner
Part E runner
```

This keeps business sequencing out of FastAPI route functions.

---

# 35. Security Boundary

The API architecture prevents several classes of unsafe exposure.

The caller does not receive:

```
arbitrary physical paths
raw manifests
raw registry documents
Python tracebacks
OS errors
saved model locations
history/cache locations
internal exception details
```

unless an explicit safe public field is intentionally part of a response contract.

---

# 36. `app/api/__init__.py`

The package init exports the normal application-assembly surface:

```
register_exception_handlers

health_router
runs_router
eda_router
preprocessing_router
feature_engineering_router
training_router
pipeline_router
inference_router
```

It does not create the FastAPI application.

---

# 37. Why Application Assembly Is Separate

The final application root should own:

```
FastAPI(...)
exception-handler registration
router inclusion
startup configuration
application metadata
```

Therefore the remaining application boundary is:

```
app/main.py
```

The API module is complete as a package even though application assembly still occurs one level above it.

---

# 38. Intended `app.main` Integration

Conceptually the next layer will do:

```
create FastAPI app
        ↓
register_exception_handlers(app)
        ↓
include health_router
include runs_router
include eda_router
include preprocessing_router
include feature_engineering_router
include training_router
include pipeline_router
include inference_router
```

`app/api/__init__.py` exists specifically to make that assembly clean and explicit.

---

# 39. Responsibility Matrix

|Concern|API|Workflows|Run Management|ML|
|---|---|---|---|---|
|HTTP routing|✅||||
|Pydantic/FastAPI request boundary|✅||||
|Safe HTTP errors|✅||||
|Caller file preflight|✅||||
|Workflow sequencing||✅|||
|Attempt/stage lifecycle||✅|✅||
|Registry/manifest truth|||✅||
|Artifact lineage/resolution|||✅||
|Run/stage locking|||✅||
|EDA/preprocessing/features/training/inference math||||✅|
|Model loading/scoring||||✅|
|History/cache processing||||✅ / workflow-owned orchestration|

This separation is one of the central architectural achievements of the completed backend.

---

# 40. Final API Package Tree

```
app/api/
│
├── __init__.py
├── dependencies.py
├── error_handlers.py
├── health.py
├── runs.py
├── eda.py
├── preprocessing.py
├── feature_engineering.py
├── training.py
├── pipeline.py
└── inference.py
```

---

# 41. Final Endpoint Map

```
GET  /health

GET  /api/v1/runs
GET  /api/v1/runs/{run_id}
GET  /api/v1/runs/{run_id}/attempts/{attempt_id}

POST /api/v1/eda/run
POST /api/v1/preprocessing/run
POST /api/v1/feature-engineering/run
POST /api/v1/training/run
POST /api/v1/pipeline/run
POST /api/v1/inference/run
```

---

# 42. Module Completion Status

Completed/frozen API responsibilities:

```
shared dependencies       COMPLETE
central error handling    COMPLETE
health                    COMPLETE
run inspection            COMPLETE
Part A route              COMPLETE
Part B route              COMPLETE
Part C route              COMPLETE
Part D/bootstrap route    COMPLETE
master pipeline route     COMPLETE
Part E inference route    COMPLETE
package public exports    COMPLETE
```

Remaining work is not another API route.

The next layer is application assembly:

```
app/main.py
```

---

# 43. Final Assessment

The API module now provides a coherent production boundary for the complete backend lifecycle:

```
training:
A → B → C → D → inference bootstrap

inference:
active inference-ready attempt → Part E

observation:
run/attempt read-only endpoints

infrastructure:
health + dependencies + safe global errors
```

The module consistently preserves:

- immutable attempt lineage;
    
- authoritative manifest/registry state;
    
- no filesystem guessing;
    
- no caller-selected inference attempt;
    
- thin routes;
    
- centralized failure mapping;
    
- safe public response boundaries;
    
- workflow/Run Management/ML separation.
    

## Final Status

```
API module structure        PASS
HTTP responsibility split  PASS
error boundary              PASS
lineage boundary            PASS
workflow delegation         PASS
inference boundary          PASS
package exports             PASS

Blocking issues             NONE
Status                      FROZEN
```