### Changes made

Added a new **run-management exception family** under `TelecomBackendError`:

- `RunManagementError`
    
    - base error for the new run-management layer.
        
- `RunNotFoundError`
    
    - unknown/missing `run_id`.
        
- `AttemptNotFoundError`
    
    - unknown/missing `attempt_id`.
        
- `StagePrerequisiteError`
    
    - B before A, C before B, D before C, inference before an inference-ready attempt.
        
- `StageConflictError`
    
    - prevents changing an already-completed stage inside the same immutable attempt.
        
- `ArtifactResolutionError`
    
    - expected upstream result/artifact cannot be safely found.
        
- `RunRegistryError`
    
    - local JSON registry read/write or mapping failures.
        
- `RunLockError`
    
    - run-level concurrency/locking failures.
        

Also updated the base exception documentation so `to_dict()` explicitly supports **workflow manifests and run-management records**.

### Preserved unchanged

All existing exception families remain available:

```text
ConfigurationError
InputValidationError
FileProcessingError
RunDirectoryError
RunManifestError
PipelineExecutionError
PreprocessingError
ModelExecutionError
ModelNotFoundError
ResultCombinationError
ReportingError
AgentExecutionError
EmailDeliveryError
```

### Documentation note

The important architectural change to record later is:

> `exceptions.py` now separates **run lifecycle/lineage errors** from actual **pipeline/ML execution errors**, allowing the future API layer to distinguish missing runs, missing prerequisites, immutable-stage conflicts, registry problems and locking problems from genuine server failures.

No existing A–E ML exception behavior was removed or changed.