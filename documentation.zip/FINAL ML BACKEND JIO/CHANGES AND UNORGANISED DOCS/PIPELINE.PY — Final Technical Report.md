# Pipeline API — Final Technical Report

**File:** `app/api/pipeline.py`  
**Final implementation:** v1  
**Module:** `app/api/`  
**Status:** Final sanity checked — PASS / suitable to freeze  
**Primary role:** Production master HTTP endpoint for one fresh training attempt through **Part A → Part B → Part C → Part D → inference bootstrap**.

---

# 1. Purpose

`pipeline.py` is the API-layer entry point for executing the complete production training pipeline in one request.

The final lifecycle is:

```
Part A — EDA
    ↓
Part B — Preprocessing
    ↓
Part C — Feature Engineering
    ↓
Part D — Training
    ↓
inference_bootstrap
    ↓
attempt becomes inference-ready
```

The route itself remains intentionally thin:

```
HTTP request
    ↓
Pydantic request validation
    ↓
optional public run validation
    ↓
caller-owned CSV preflight
    ↓
workflow logger
    ↓
run_training_pipeline(...)
    ↓
TrainingPipelineResponse
```

---

# 2. Architectural Position

```
Client / UI
    ↓
POST /api/v1/pipeline/run
    ↓
app/api/pipeline.py
    ↓
run_training_pipeline()
    ├── run_part_a_workflow()
    ├── run_part_b_workflow()
    ├── run_part_c_workflow()
    └── run_training_stage_workflow()
            ├── Part D
            └── inference_bootstrap
```

The API route delegates orchestration to the workflow layer rather than calling individual stages itself.

---

# 3. Router Contract

Router prefix:

```
/api/v1/pipeline
```

Endpoint:

```
POST /api/v1/pipeline/run
```

Request:

```
TrainingPipelineRequest
```

Response:

```
TrainingPipelineResponse
```

---

# 4. Master Request Contract

The frozen master request contains:

```
run_id | None
run_metadata
dataset
preprocessing
feature_engineering | None
training
inference_bootstrap
```

It intentionally does **not** contain:

```
attempt_id
```

---

# 5. Fresh-Attempt Rule

Every master pipeline request starts a fresh training attempt.

Two supported modes exist.

## New logical run

```
run_id omitted
→ create new run
→ create first attempt
→ A → B → C → D → bootstrap
```

## Existing logical run

```
run_id supplied
→ keep same logical run
→ create new attempt
→ A → B → C → D → bootstrap
```

---

# 6. Why `attempt_id` Is Forbidden

The master endpoint is not a resume endpoint.

It represents:

```
start a fresh full training lineage
```

not:

```
continue an existing attempt
```

Therefore retry/recovery of a failed attempt is performed through the corresponding standalone stage endpoint.

Examples:

```
Part B failed
→ POST /api/v1/preprocessing/run

Part C failed
→ POST /api/v1/feature-engineering/run

Part D/bootstrap failed
→ POST /api/v1/training/run
```

---

# 7. Why the API Does Not Create Attempts Directly

Part A is already the canonical workflow entry point that creates or selects the correct run/attempt lifecycle.

The master workflow constructs an `EDAStageRequest` from the master request and lets:

```
run_part_a_workflow()
```

create the fresh attempt.

This preserves one authoritative run-creation path.

---

# 8. Public Existing-Run Validation

When:

```
request.run_id is not None
```

the route performs:

```
manager.registry.exists(request.run_id)
```

If the caller references an unknown logical run:

```
API_RUN_NOT_FOUND
→ HTTP 404
```

Safe public detail:

```
run_id
```

---

# 9. New-Run Requests Skip Public Run Lookup

When:

```
request.run_id is None
```

there is no public run resource to validate.

The route proceeds directly to caller-owned input-file validation.

The workflow later creates the new run.

---

# 10. No Attempt Lookup in This Route

The route never calls:

```
manager.resolve_attempt(...)
```

because `TrainingPipelineRequest` contains no `attempt_id`.

This is a deliberate difference from the standalone B/C/D routes.

---

# 11. Registered Run vs Broken Backend State

`manager.registry.exists()` is used only to prove genuine caller-owned absence.

If a supplied run is registered but later technical state is broken:

```
manifest problem
directory problem
registry/manifest inconsistency
workflow resolution failure
```

the failure is not converted into public 404.

It remains internal/fail-closed.

---

# 12. Why the Master Route Has an External File Boundary

Unlike Parts B/C/D, the master pipeline always starts a fresh attempt and introduces a new caller-owned dataset.

Therefore:

```
request.dataset.input_file
```

is an API-boundary external CSV.

This is the same ownership model as a new-attempt Part A request.

---

# 13. CSV Preflight Before State Creation

Before calling the workflow, the route calls:

```
read_csv_file(request.dataset.input_file)
```

This validates the external input before the workflow creates a new run/attempt.

The ordering is intentional:

```
validate caller target
    ↓
validate caller CSV
    ↓
create run/attempt through workflow
```

---

# 14. Why Full CSV Parsing Happens at the API Boundary

Simple existence checks are not enough to distinguish caller-owned failures such as:

```
encoding failure
CSV parser failure
no readable columns
zero rows
```

before state creation.

Therefore the route performs a complete `read_csv_file()` preflight.

---

# 15. Duplicate CSV Read Is Intentional V1 Behavior

The API parses the original caller file during preflight.

Later:

```
Part A workflow
→ copies the caller file into immutable attempt-owned storage
→ Part A reads the persisted copy
```

Therefore a normal master request performs two reads:

```
external validation read
+
immutable workflow read
```

This extra I/O is accepted in V1 to preserve clean API error ownership.

---

# 16. Why the Preflight DataFrame Is Discarded

The preflight DataFrame is not passed into the workflow.

The authoritative training source must remain:

```
immutable attempt-owned copied input
```

not an in-memory DataFrame originating from the external path.

This preserves reproducibility and lineage.

---

# 17. Frozen External-File Mapping

The master route uses the same mapping as the frozen Part A API.

```
FILE_NOT_FOUND
→ API_INPUT_FILE_NOT_FOUND
→ 422

PATH_IS_NOT_FILE
→ API_INPUT_PATH_NOT_FILE
→ 422

INVALID_FILE_EXTENSION
→ API_INPUT_FILE_EXTENSION_INVALID
→ 422

EMPTY_FILE
→ API_INPUT_FILE_EMPTY
→ 422

FILE_TOO_LARGE
→ API_INPUT_FILE_TOO_LARGE
→ 422

CSV_PARSE_FAILED
→ API_INPUT_CSV_PARSE_FAILED
→ 422

CSV_ENCODING_ERROR
→ API_INPUT_CSV_ENCODING_INVALID
→ 422

EMPTY_CSV
→ API_INPUT_CSV_EMPTY
→ 422
```

A successfully parsed DataFrame with zero rows also becomes:

```
API_INPUT_CSV_EMPTY
→ 422
```

---

# 18. Sanity Check: Mapping Equality with `eda.py`

The final freeze-level check compared:

```
pipeline.py::_INPUT_FILE_ERROR_MAP
```

against:

```
eda.py::_INPUT_FILE_ERROR_MAP
```

Result:

```
maps_equal = True
```

Therefore the two routes use the same caller-owned external CSV policy.

---

# 19. Safe File-Error Details

Only approved details are copied from low-level file errors.

For invalid extension:

```
received_extension
allowed_extensions
```

For excessive size:

```
file_size_bytes
maximum_size_bytes
maximum_size_gb
```

Physical paths and parser internals are not exposed.

---

# 20. Unknown File-Service Failures Stay Internal

If `read_csv_file()` produces a code that is not in the caller-owned mapping, for example:

```
CSV_READ_FAILED
FILE_SIZE_READ_FAILED
```

the route re-raises the original backend error.

It is not translated into 422.

The global fail-closed handler then returns 500.

---

# 21. Why Post-Boundary File Failures Are Not Reclassified

The translation helper exists only around:

```
request.dataset.input_file
```

during API preflight.

Once the workflow creates backend-owned persisted state, later failures such as:

```
attempt input missing
Part A generated file missing
Part B artifact failure
Part C artifact failure
bootstrap artifact failure
```

are backend-owned failures.

They must not become caller `API_INPUT_*` errors.

---

# 22. Validation Ordering for Existing Runs

For requests with `run_id`:

```
validate public run exists
    ↓
validate external CSV
    ↓
workflow
```

Therefore an invalid public run is rejected before expensive CSV parsing.

---

# 23. Validation Ordering for New Runs

For requests without `run_id`:

```
validate external CSV
    ↓
workflow creates run + attempt
```

This prevents caller-owned file errors from creating unnecessary run state.

---

# 24. Logger Selection

The route calls:

```
get_workflow_logger(
    request.run_id,
    component_name="pipeline",
)
```

The shared dependency logic chooses the best available logger.

---

# 25. New-Run Logger

When:

```
request.run_id = None
```

the logical run does not yet exist.

Therefore the route initially uses the process/API logger.

This mirrors the accepted Part A V1 behavior.

---

# 26. Existing-Run Logger

When:

```
request.run_id supplied
```

the route can obtain the existing run-scoped pipeline logger immediately.

---

# 27. One Workflow Call Only

The route calls:

```
run_training_pipeline(...)
```

exactly once.

It does not manually call:

```
run_part_a_workflow()
run_part_b_workflow()
run_part_c_workflow()
run_part_d_workflow()
run_inference_bootstrap_workflow()
```

This is the correct separation of concerns.

---

# 28. Why API-Level Manual Orchestration Would Be Wrong

Manual orchestration inside the API would duplicate:

```
stage request construction
failure propagation
Part C default-profile selection
D/bootstrap composition
stage summary accumulation
fresh-attempt semantics
```

These responsibilities already belong to the workflow layer.

---

# 29. Master Workflow — Part A

The master workflow creates:

```
EDAStageRequest
```

from:

```
request.run_id
request.run_metadata
request.dataset
```

Part A then establishes:

```
run_id
attempt_id
```

for the remainder of the master lifecycle.

---

# 30. Master Workflow — Part B

After successful Part A, the workflow creates:

```
PreprocessingStageRequest(
    run_id,
    attempt_id,
    preprocessing=request.preprocessing
)
```

Part B resolves the authoritative successful Part A handoff through Run Management.

---

# 31. Master Workflow — Part C

After successful Part B, the workflow creates:

```
FeatureEngineeringStageRequest
```

using the same run and attempt.

The API route does not construct this request.

---

# 32. Part C Default-Profile Behavior

When:

```
request.feature_engineering is None
```

the workflow passes:

```
model_type_hint = request.training.model_type
```

This preserves the historical model-matched default behavior.

---

# 33. Explicit Part C Config

When:

```
request.feature_engineering is not None
```

the workflow passes the explicit configuration and does not need to inject a model hint.

The API route does not modify this behavior.

---

# 34. Master Workflow — Final Training Lifecycle

After successful Part C, the master workflow constructs:

```
TrainingStageRequest(
    run_id,
    attempt_id,
    training=request.training,
    inference_bootstrap=request.inference_bootstrap
)
```

and calls:

```
run_training_stage_workflow()
```

---

# 35. Why Master D Includes Bootstrap

`run_training_stage_workflow()` is the final production standalone training lifecycle:

```
Part D
→ inference_bootstrap
```

Therefore the master workflow automatically receives the same final behavior.

No separate bootstrap call is needed in the API route.

---

# 36. Inference Bootstrap Purpose

Bootstrap converts completed Part D training into the persistent saved state consumed by Part E.

It prepares:

```
inference_config.json
history/
cache/
models/
inference_results/
```

and publishes the inference state through Run Management.

---

# 37. What Pipeline Success Means

Master success means:

```
Part A completed
Part B completed
Part C completed
Part D completed
inference_bootstrap completed
```

Only then:

```
inference_ready = true
next_stage = inference
```

---

# 38. What Pipeline Success Does Not Mean

The pipeline does **not** execute Part E inference.

It only prepares an inference-ready training attempt.

Part E remains a separate API lifecycle.

---

# 39. Part A Failure Semantics

If Part A returns a structured failure:

```
status = failed
failed_stage = part_a
inference_ready = false
```

No later stage is started.

---

# 40. Part B Failure Semantics

If Part A succeeds but Part B fails:

```
status = partially_completed
failed_stage = part_b
inference_ready = false
```

Part C/D/bootstrap are not started.

---

# 41. Part C Failure Semantics

If A and B succeed but C fails:

```
status = partially_completed
failed_stage = part_c
inference_ready = false
```

D/bootstrap are not started.

---

# 42. Part D Failure Semantics

If A/B/C succeed and Part D fails:

```
status = partially_completed
failed_stage = part_d
inference_ready = false
```

Bootstrap is not started.

---

# 43. Bootstrap Failure Semantics

If A/B/C/D succeed but bootstrap fails:

```
status = partially_completed
failed_stage = inference_bootstrap
next_stage = inference_bootstrap
inference_ready = false
```

Part D remains completed and immutable.

---

# 44. Recovery After Bootstrap Failure

A failed master attempt is not resumed by calling the master endpoint again.

Instead:

```
POST /api/v1/training/run
run_id + attempt_id
```

uses the standalone training lifecycle.

Because Part D is already complete, it can perform a bootstrap-only retry.

---

# 45. Why Master Resubmission Is Not Resume

Suppose:

```
attempt_0001
A ✓
B ✓
C ✗
```

Calling:

```
POST /api/v1/pipeline/run
```

again creates:

```
attempt_0002
```

It does not continue `attempt_0001`.

This is intentional immutable lineage behavior.

---

# 46. TrainingPipelineResponse

The master workflow returns:

```
status
run_id
attempt_id
stages
message
failed_stage
next_stage
inference_ready
summary
error
```

The response does not expose physical filesystem paths.

---

# 47. Stage Execution Summaries

`stages` is a tuple of stage execution summaries launched during the master request.

A successful full run contains:

```
part_a
part_b
part_c
part_d
inference_bootstrap
```

---

# 48. Final Success Response

Conceptually:

```
status = completed
failed_stage = None
next_stage = inference
inference_ready = true
completed_stage_count = 5
```

The exact stage count derives from the five execution summaries.

---

# 49. No Run/Attempt Mutation in API

The route itself does not call:

```
create_run()
start_attempt()
prepare_stage_execution()
complete_stage()
fail_stage()
```

Run Management mutations occur only through workflows.

---

# 50. No Manifest Mutation in API

`pipeline.py` never directly writes:

```
manifest.json
registry state
stage records
execution records
inference state
```

This protects the workflow/Run Management boundary.

---

# 51. No Artifact Resolution in API

The route does not resolve:

```
A→B handoff
B→C handoff
C→D handoff
model package
bootstrap files
```

Run Management and individual workflows remain authoritative.

---

# 52. No Part E Execution

The master endpoint ends at:

```
inference-ready saved state
```

It does not call the Part E runner.

The later `inference.py` route consumes the active inference attempt.

---

# 53. Pydantic Validation

`TrainingPipelineRequest` validates the complete request before route execution.

This includes:

```
run_id shape
run metadata
dataset config
preprocessing config
feature-engineering config
training config
bootstrap config
```

Invalid request shapes become:

```
REQUEST_VALIDATION_FAILED
→ 422
```

---

# 54. Extra `attempt_id` Is Rejected

Because the master schema intentionally has no `attempt_id`, supplying one is an extra forbidden field.

Result:

```
REQUEST_VALIDATION_FAILED
→ 422
```

This enforces fresh-attempt semantics at the schema boundary.

---

# 55. Invalid Training Model

An unsupported discriminator such as:

```
random_forest
```

does not reach the workflow.

It is rejected by request validation.

---

# 56. Invalid Bootstrap Config

Invalid values such as:

```
negative max_gap_days
out-of-range max_gap_ratio
```

are rejected before pipeline state creation.

---

# 57. Public 404 Contract

The only master-route public resource lookup is optional `run_id`.

```
unknown supplied run
→ API_RUN_NOT_FOUND
→ 404
```

There is no `API_ATTEMPT_NOT_FOUND` path because no attempt is supplied.

---

# 58. Public 422 Contract

Caller-owned request/file issues include:

```
REQUEST_VALIDATION_FAILED
API_INPUT_FILE_NOT_FOUND
API_INPUT_PATH_NOT_FILE
API_INPUT_FILE_EXTENSION_INVALID
API_INPUT_FILE_EMPTY
API_INPUT_FILE_TOO_LARGE
API_INPUT_CSV_PARSE_FAILED
API_INPUT_CSV_ENCODING_INVALID
API_INPUT_CSV_EMPTY
```

---

# 59. Internal 500 Contract

Examples that remain fail-closed:

```
registry backend failure
registered-run technical corruption
CSV_READ_FAILED
internal workflow exception
persisted artifact corruption
manifest inconsistency
unknown future backend code
```

The route does not broaden public error mappings.

---

# 60. Security / Information Exposure

The route never exposes:

```
input absolute path
run directory
attempt directory
stage directory
handoff path
model path
history/cache path
bootstrap staging path
manifest path
```

Approved 422 details are explicitly allowlisted.

---

# 61. TOCTOU Boundary

As with fresh standalone Part A, a small time-of-check/time-of-use window exists:

```
API preflight reads external CSV
        ↓
workflow later copies the external file
```

The external file could theoretically change between these operations.

The workflow still performs the authoritative copy/read and will fail if necessary.

This is an accepted V1 tradeoff.

---

# 62. Why Preflight Still Adds Value Despite TOCTOU

The main goal is not to make the external file immutable before the workflow.

The goal is to ensure normal caller-owned file failures are identified before run/attempt creation.

The immutable copy remains the workflow authority.

---

# 63. Route-Level Sanity Check

The final implementation was reviewed against:

```
TrainingPipelineRequest
TrainingPipelineResponse
run_training_pipeline()
run_training_stage_workflow()
file_service.read_csv_file()
frozen error handler policy
frozen eda.py file-boundary strategy
```

No blocking mismatch was found.

---

# 64. Syntax Verification

The exact final file passes:

```
python -m py_compile
```

Result:

```
PIPELINE_API_V1_SYNTAX=PASS
```

---

# 65. Runtime Regression

The final route regression passed:

```
PIPELINE_API_V1_RUNTIME_SMOKE=PASS
PIPELINE_API_V1_FULL_REGRESSION=PASS
```

The runtime suite was rerun during the final freeze-level sanity check and remained green.

---

# 66. Regression Coverage

The route-level suite covered:

```
new run + full five-stage success
existing run + fresh attempt behavior
new-run API logger
existing-run run-scoped logger

unknown run → 404
registry technical failure → 500

missing file → 422
path not file → 422
wrong extension → 422
empty file → 422
oversized file → 422
CSV parse failure → 422
CSV encoding failure → 422
empty CSV → 422
zero-row CSV → 422
unknown CSV read failure → 500

safe extension details
safe size details
no physical-path leakage
no raw parser-detail leakage

feature config omitted
→ model-matched workflow default preserved

explicit feature config preserved
bootstrap policy passthrough

Part A structured failure
Part B structured failure
Part C structured failure
Part D structured failure
bootstrap structured failure

attempt_id forbidden
invalid run ID rejected
invalid training model rejected
invalid bootstrap config rejected
```

---

# 67. Final Freeze Finding — No Duplicate Orchestration

The implementation correctly avoids API-level stage composition.

The authoritative execution sequence remains:

```
run_training_pipeline()
```

This ensures standalone and master paths continue to reuse the same stage workflows.

---

# 68. Final Freeze Finding — Bootstrap Is Included Exactly Once

The API does not call bootstrap directly.

Instead:

```
run_training_pipeline()
→ run_training_stage_workflow()
→ Part D + inference_bootstrap
```

Therefore bootstrap is included exactly once in the full master lifecycle.

---

# 69. Final Freeze Finding — Part C Defaults Remain Workflow-Owned

The API route does not construct Part C model defaults.

The master workflow alone applies:

```
feature_engineering omitted
→ model_type_hint = training.model_type
```

This preserves the frozen integration behavior.

---

# 70. Final Freeze Finding — Caller CSV Mapping Is Correct

The external-file map was directly compared with final `eda.py`.

Result:

```
identical mapping
```

No public error-code drift was found.

---

# 71. Final Freeze Finding — No Attempt Resume Through Master API

The request schema and route contain no `attempt_id`.

The workflow documentation and implementation both confirm every master call creates a new attempt.

This is fully aligned with the agreed immutable lineage policy.

---

# 72. Relationship with Standalone APIs

```
eda.py
→ standalone Part A
→ may create/retry A according to A request mode

preprocessing.py
→ standalone Part B recovery/execution

feature_engineering.py
→ standalone Part C recovery/execution

training.py
→ standalone D + bootstrap recovery/finalization

pipeline.py
→ fresh full A→B→C→D→bootstrap attempt
```

The master endpoint composes workflow behavior but does not replace standalone recovery endpoints.

---

# 73. Relationship with `inference.py`

Successful master pipeline response:

```
inference_ready = true
```

means Part E can subsequently run.

`pipeline.py` itself does not process inference data.

---

# 74. Final Responsibility Boundary

```
pipeline.py
→ HTTP request boundary
→ optional run existence
→ external CSV preflight
→ logger
→ one master workflow call

TrainingPipelineRequest
→ complete request validation

run_training_pipeline()
→ A/B/C/D/bootstrap sequencing
→ failure aggregation
→ Part C model hint integration

individual workflows
→ stage-specific orchestration

Run Management
→ run/attempt/execution lineage
→ artifacts
→ bootstrap publication

ML modules
→ actual A/B/C/D computation

inference.py / Part E workflow
→ later pure inference execution

error_handlers.py
→ safe HTTP mapping
```

---

# 75. Final Compact Contract

```
FILE:
app/api/pipeline.py

ROLE:
Master fresh-attempt training API.

ENDPOINT:
POST /api/v1/pipeline/run

REQUEST:
TrainingPipelineRequest

RESPONSE:
TrainingPipelineResponse

MASTER LIFECYCLE:
Part A
→ Part B
→ Part C
→ Part D
→ inference_bootstrap

ATTEMPT RULE:
No attempt_id accepted.
Every request starts a fresh attempt.

RUN RULE:
run_id omitted
→ new logical run

run_id supplied
→ fresh attempt under existing logical run

EXTERNAL INPUT:
request.dataset.input_file

PRE-WORKFLOW VALIDATION:
optional public run existence
+
full caller CSV parse/validation

PUBLIC 404:
API_RUN_NOT_FOUND

PUBLIC 422 FILE CODES:
API_INPUT_FILE_NOT_FOUND
API_INPUT_PATH_NOT_FILE
API_INPUT_FILE_EXTENSION_INVALID
API_INPUT_FILE_EMPTY
API_INPUT_FILE_TOO_LARGE
API_INPUT_CSV_PARSE_FAILED
API_INPUT_CSV_ENCODING_INVALID
API_INPUT_CSV_EMPTY

REQUEST 422:
REQUEST_VALIDATION_FAILED

UNKNOWN/INTERNAL:
fail-closed 500

DELEGATE:
run_training_pipeline()

SUCCESS:
five stage summaries
next_stage = inference
inference_ready = true

DOES NOT:
accept attempt_id
resume failed attempt
manually call A/B/C/D/bootstrap
build Part C defaults in API
mutate Manifest V2
resolve artifacts
activate inference directly
run Part E
reshape master response
```

---

# 76. Final Assessment

`app/api/pipeline.py` is correctly aligned with the final production backend architecture.

Its governing rule is:

```
The API validates the public master request and the caller-owned CSV.

The master workflow creates the fresh attempt and composes A→B→C→D→bootstrap.

Individual workflows remain authoritative for stage execution.

Run Management remains authoritative for lineage and persisted state.

Successful bootstrap marks the attempt inference-ready.

Part E remains a separate later API lifecycle.
```

The final implementation preserves the frozen HTTP policy:

```
genuine missing caller run → 404
invalid request/caller CSV → 422
structured workflow stage failure → TrainingPipelineResponse
internal/unapproved failure → 500
```

**Final status: PASS / suitable to freeze.**