### Changes made

- Removed old Manifest V1 exports:
    
    - `start_pipeline_stage`
        
    - `complete_pipeline_stage`
        
    - `fail_pipeline_stage`
        
    - `skip_pipeline_stage`
        
- Added Manifest V2 exports for:
    
    - run statuses
        
    - attempt statuses
        
    - execution statuses
        
    - inference invocation statuses
        
    - record/stage validation
        
    - attempt creation/status/summary
        
    - stage execution start/complete/fail/cancel
        
    - active inference-attempt handling
        
    - inference invocation start/complete/fail
        
    - run metadata updates
        
- Added public constants:
    
    ```text
    WORKFLOW_SCHEMA_VERSION
    TRAINING_STAGE_NAMES
    VALID_ATTEMPT_STATUSES
    VALID_EXECUTION_STATUSES
    VALID_INFERENCE_INVOCATION_STATUSES
    RECORD_ID_PATTERN
    ```
    
- Preserved all existing file-service and run-directory exports.
    

### Documentation note

> `app/services/__init__.py` now exposes the Manifest V2 run → attempt → stage → execution lifecycle API, replacing the older flat pipeline-stage manifest interface.

No new logic was added; this file only exposes the updated Services public API.