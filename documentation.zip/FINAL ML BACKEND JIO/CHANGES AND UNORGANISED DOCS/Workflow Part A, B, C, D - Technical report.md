# Phase 4 — Individual Workflows — Final Technical Report

**Package location:** `app/workflows/`  
**Phase scope:** `part_a.py`, `part_b.py`, `part_c.py`, `part_d.py`

---

## 1. Purpose

Phase 4 turns the already-tested A→B→C→D ML pipeline into four independently  
callable production workflow stages.

The ML modules themselves remain unchanged.

Production responsibility is divided as:

```
Run Management
    ↓
stage identity / lineage / prerequisite authority
    ↓
Individual workflow
    ↓
reconstruct exact previous-stage contract
    ↓
existing ML runner
    ↓
validate cross-stage persistence contract
    ↓
persist result.json
```

This phase intentionally stops at completed Part D.

```
A → B → C → D
              ↓
       next stage:
   inference_bootstrap
```

The D→Part-E saved-state lifecycle belongs to Phase 5.

---

# 2. Files

```
app/workflows/
├── part_a.py
├── part_b.py
├── part_c.py
└── part_d.py
```

All four files were independently syntax-checked and runtime smoke-tested before  
the next file was created.

---

# 3. `part_a.py`

## Responsibility

Part A is the entry point for one training attempt.

It connects:

```
EDAStageRequest
    ↓
Run Management run/attempt selection
    ↓
attempt-owned immutable input
    ↓
existing Part A EDA runner
    ↓
A→B persisted handoff
```

## Run/attempt selection

The workflow preserves the final request semantics:

```
no run_id
→ create new run
→ create new attempt

run_id only
→ resolve existing run
→ create new attempt

run_id + attempt_id
→ resolve existing attempt
→ normally retry failed Part A
```

Run Management remains responsible for rejecting illegal transitions such as a  
completed immutable Part A rerun.

## Attempt-owned input

The external caller path is not passed directly to Part A after attempt creation.

Instead:

```
request.dataset.input_file
    ↓
Run Management copy
    ↓
attempt_context.input_file
    ↓
build_runtime_dataset_config()
    ↓
run_eda_pipeline()
```

This makes the training attempt independent of later mutation/deletion of the  
caller-owned source file.

## Part A result validation

Before successful persistence Part A must provide:

```
at least one KPI result
unique KPI identities
valid nonblank string KPI names
```

Part A therefore becomes the authoritative downstream KPI enumeration.

## Persisted result

The workflow calls:

```
build_part_a_result_snapshot()
```

which stores:

```
runtime DatasetInputConfig
EDARunnerResult
```

for exact later reconstruction by Part B.

---

# 4. `part_b.py`

## Responsibility

Part B executes normal/training preprocessing once per authoritative Part A KPI.

```
successful Part A result.json
    ↓
load_part_a_handoff()
    ↓
KPIEDARunResult[]
    ↓
run_preprocessing_pipeline() per KPI
    ↓
PreprocessingRunnerResult[]
    ↓
B→C result snapshot
```

## Exact Part B runner contract

Each call receives:

```
kpi_result
dataset_config
preprocessing_config
resolved Part A bucket
workflow-owned KPI output directory
logger
```

No site-level preprocessing logic exists in the workflow.

## KPI continuity

The workflow requires:

```
Part A KPI set
=
Part B result KPI set
```

It also checks each individual runner result retains the KPI identity it was  
called for.

Therefore a KPI cannot silently:

```
disappear
appear
duplicate
change identity
```

between A and B.

## Filesystem collision protection

Distinct KPI names may sanitize to the same path.

Example:

```
KPI/A
KPI?A
```

Both can sanitize to:

```
KPI_A
```

The workflow deterministically disambiguates only the directory names while  
preserving original KPI identities inside all contracts.

## Stable output validation

`PreprocessingRunnerResult.final_dataset_file` must:

```
exist
be a file
remain inside that KPI's workflow-owned Part B output directory
```

because Part C later treats it as the authoritative cleaned dataset.

## Persisted result

```
DatasetInputConfig
resolved BucketConfig
PreprocessingRunnerResult[]
```

are persisted through:

```
build_part_b_result_snapshot()
```

---

# 5. `part_c.py`

## Responsibility

Part C reconstructs exact Part B results and runs the existing feature-  
engineering pipeline once per KPI.

```
successful Part B result.json
    ↓
load_part_b_handoff()
    ↓
PreprocessingRunnerResult[]
    ↓
resolve Part C request
    ↓
run_feature_engineering_pipeline() per KPI
    ↓
FeatureEngineeringRunnerResult[]
    ↓
C→D snapshot
```

## Part C configuration resolution

Two modes are preserved:

```
explicit feature_engineering config
→ pass unchanged

feature_engineering omitted
→ model_type_hint
→ resolve_feature_engineering_config()
→ model-matched default profile
```

This keeps model-profile selection at the workflow boundary without moving model  
logic into Part C.

## KPI continuity

The workflow requires:

```
Part B KPI set
=
Part C result KPI set
```

and checks per-call identity equality.

## Source provenance

For each KPI:

```
FeatureEngineeringRunnerResult.source_file
=
PreprocessingRunnerResult.final_dataset_file
```

This protects the persisted C→D lineage.

## Stable Part C output contract

Before C is marked successful the workflow verifies:

```
reported output_directory
= workflow-owned KPI directory

final_dataset_file exists
site_summary_file exists
optional corrected-history audit stays under KPI root

feature_columns
= resolved_config.feature_columns

minimum_history_points >= 1
```

Headline site/row counts are also checked for non-negative/basic consistency.

## Persisted result

The exact:

```
FeatureEngineeringRunnerResult[]
+
DatasetInputConfig
```

is stored via:

```
build_part_c_result_snapshot()
```

for later annotation-driven reconstruction by Part D.

---

# 6. `part_d.py`

## Responsibility

Part D executes only the canonical training stage.

It does **not** run inference bootstrap.

```
successful Part C result.json
    ↓
load_part_c_handoff()
    ↓
build_part_d_runner_inputs()
    ↓
run_training() per KPI
    ↓
validate finalized Part D package
    ↓
persist D→bootstrap snapshot
```

This separation is critical because:

```
D succeeds
bootstrap fails
```

must allow:

```
retry bootstrap only
```

without violating completed-stage immutability by retraining D.

---

# 7. Exact C→D contract

For every KPI, `build_part_d_runner_inputs()` supplies:

```
kpi_name
input_file
dataset_columns
feature_config
minimum_history_points
metadata
```

The Part D request/workflow supplies:

```
model_type
training_config
output_directory
```

The final call remains exactly:

```
run_training(
    model_type=...,
    input_file=...,
    output_directory=...,
    dataset_columns=...,
    feature_config=...,
    minimum_history_points=...,
    training_config=...,
    metadata=...,
)
```

---

# 8. Training ownership

The workflow never dispatches directly to:

```
XGBoost fixed
XGBoost Optuna
Isolation Forest fixed
Isolation Forest Optuna
```

It calls only the public:

```
app.ml.training.run_training()
```

The Part D runner remains owner of:

```
model/config dispatch
site-series usability inspection
validation
chronological splits
fixed/Optuna selection
training/testing/calibration
model serialization
final training package creation
```

---

# 9. Part D per-KPI result validation

The workflow defensively validates the returned `PartDTrainingResult` before it  
can become persistent workflow state.

Checks include:

```
status == completed
returned model_type == requested model_type
returned input_file == Part C final dataset
returned output_directory == workflow KPI directory
returned minimum_history_points == Part C contract
```

The nested `TrainingValidationResult` must also agree on:

```
model_type
input_file
minimum_history_points
non-empty unique model_feature_columns
```

Target contract:

```
XGBoost
→ target_column required

Isolation Forest
→ target_column must be None
```

---

# 10. Series/model coherence

The successful Part D runner guarantees every valid series trains successfully.

The workflow therefore checks:

```
total_series
=
valid_series
+
skipped_invalid_series

trained_series
=
valid_series

len(skipped_series)
=
skipped_invalid_series

len(model_files)
=
trained_series
```

A successful result must contain at least one valid/trained series.

---

# 11. Model file contract

Model files must remain inside:

```
<Part D KPI output>/
└── training/
    └── model/
```

Model suffix is checked against model type:

```
XGBoost
→ .json

Isolation Forest
→ .joblib
```

---

# 12. Full Part D package validation

Before D is marked complete, the workflow requires the complete finalized  
training package:

```
training/
├── model/
│   └── model files
├── split_plan.json
├── training_config.json
├── feature_contract.json
├── final_hyperparameters.json
├── training_summary.json
├── decision_settings.json
├── usable_row_counts.json
└── metadata.json
```

Every required path must:

```
exist
have the expected file/directory type
remain below the workflow-owned KPI training root
```

This prevents Phase 5 from receiving a partially finalized Part D package.

---

# 13. Hyperparameter-tuning boundary

Part D workflow records:

```
hyperparameter_tuning_enabled
hyperparameter_tuning_method
```

in parent pipeline metadata/summary.

It does not perform tuning itself.

When tuning is disabled:

```
hyperparameter_tuning_method = None
```

When enabled, the validated training schema supplies the selected method.

---

# 14. Part D snapshot

The persisted D→bootstrap snapshot is:

```
{
  "part_d_snapshot_version": "1.0",
  "stage": "part_d",
  "dataset_config": {},
  "training_config": {},
  "training_records": []
}
```

Each training record contains the Part E bootstrap-critical contract:

```
kpi_name
status
model_type

training_directory
model_directory
metadata_file
decision_settings_file
model_files

model_feature_columns
target_column
minimum_history_points

total_series
valid_series
trained_series
skipped_invalid_series
```

Phase 5 can therefore reconstruct the inference-ready saved state without  
rerunning Part D.

---

# 15. Error lifecycle across all four workflows

The common pattern is:

```
Run Management rejects stage before execution creation
→ propagate domain error
→ future API error handler

execution successfully started
+
ML/contract failure
→ manager.fail_stage()
→ structured failed StandaloneStageResponse

execution succeeds
→ manager.complete_stage()
→ successful StandaloneStageResponse
```

If failure persistence itself cannot complete, the original failure is  
propagated rather than being silently replaced by a secondary persistence  
exception.

---

# 16. Public response boundary

The four individual workflow responses expose:

```
run_id
attempt_id
stage
execution_id
status
next_stage
summary/error
```

They intentionally do not expose physical server filesystem paths.

Physical paths remain inside:

```
result.json
Manifest V2
internal runner contracts
```

---

# 17. Phase 4 progression

Successful independent progression is:

```
part_a.py
    ↓
next_stage = part_b

part_b.py
    ↓
next_stage = part_c

part_c.py
    ↓
next_stage = part_d

part_d.py
    ↓
next_stage = inference_bootstrap
inference_ready = false
```

Part D completion alone does not activate Part E.

---

# 18. Independent sanity results

Each workflow was tested independently before continuing.

```
PART_A_SYNTAX=PASS
PART_A_RUNTIME_SMOKE=PASS
PART_A_INDEPENDENT_SANITY=PASS

PART_B_SYNTAX=PASS
PART_B_RUNTIME_SMOKE=PASS
PART_B_INDEPENDENT_SANITY=PASS

PART_C_SYNTAX=PASS
PART_C_RUNTIME_SMOKE=PASS
PART_C_INDEPENDENT_SANITY=PASS

PART_D_SYNTAX=PASS
PART_D_RUNTIME_SMOKE=PASS
PART_D_INDEPENDENT_SANITY=PASS
```

Part D tests included both:

```
XGBoost
Isolation Forest
```

and verified:

```
fixed/Optuna metadata forwarding
C→D input mapping
sanitized KPI collision handling
training package existence
model file count/suffix
target contract
series counts
result identity
failure persistence
invalid prerequisite handling
```

---

# 19. Final assessment

Phase 4 now provides four independently callable production workflows while  
preserving the existing ML interfaces.

```
Part A
→ authoritative KPI discovery

Part B
→ cleaned persistent KPI datasets

Part C
→ feature-engineered training datasets + frozen feature contract

Part D
→ completed per-site model packages + D→bootstrap snapshot
```

No Part E logic exists in this phase.

The next phase can build:

```
inference_bootstrap.py
training_pipeline.py
```

on top of these frozen individual workflows.