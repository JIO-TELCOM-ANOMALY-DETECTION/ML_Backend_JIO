# Dependencies — Final Technical Report

**File:** `app/api/dependencies.py`  
**Status:** Sanity checked — suitable to freeze

---

# Important non-blocking observation — logging for brand-new runs

The only notable limitation found during the final sanity check is related to
**logging for requests that do not yet have a `run_id`**.

Examples:

```text
new standalone Part A request
new master A→B→C→D→bootstrap request
```

At the moment the API receives one of these requests, the final `run_id` does
not exist yet.

The `run_id` is created later by Run Management inside the Part A workflow:

```text
HTTP request arrives
    ↓
dependencies.py resolves dependencies
    ↓
run_id does not exist yet
    ↓
API logger is supplied
    ↓
Part A workflow creates run
    ↓
real run_id now exists
```

Because dependency injection happens **before** the workflow creates the run,
`dependencies.py` cannot truthfully call:

```python
get_run_logger(run_id, ...)
```

at the beginning of the request.

Doing so would require inventing a temporary/fake run ID, which would create
misleading log directories.

Therefore the current design intentionally uses:

```text
get_workflow_logger(None)
    ↓
process-level API logger
```

for a brand-new run.

## Why this matters more for the master pipeline

For a standalone Part A request this limitation is small.

The request begins using the API logger, Part A creates the run, and the request
finishes.

For the master training pipeline, however, the same logger supplied at the
beginning is passed through the complete workflow call:

```text
Part A
↓
Part B
↓
Part C
↓
Part D
↓
inference bootstrap
```

So when the master pipeline itself creates a brand-new run, that particular
pipeline invocation may continue writing orchestration messages to the
process-level API logger rather than:

```text
logs/<generated_run_id>/pipeline.log
```

even though the real `run_id` becomes known after Part A.

## What this does NOT affect

This is strictly an **observability/log-routing issue**.

It does not affect:

```text
run creation
attempt creation
execution IDs
Manifest V2
registry state
stage lineage
artifact paths
training
bootstrap
inference readiness
workflow responses
error persistence
```

Run Management still creates and persists the correct real `run_id`.

All run-specific artifacts and manifests still belong to the correct run.

Therefore this is **not a blocking backend correctness issue**.

## Why the current implementation is safer than inventing a run ID

A tempting alternative would be to create some temporary logger identity before
Part A starts.

For example:

```text
temporary_run_123
```

and later switch to the actual generated run.

That would cause unnecessary problems:

```text
logs split between two identities
temporary log directories
unclear correlation with Manifest V2
possible confusion during debugging
```

The current behavior is therefore deliberately conservative:

```text
run_id known
→ use run-scoped logger

run_id not known
→ use API logger
```

No synthetic run identity is introduced.

## Possible future enhancement

If we decide that every new master pipeline must immediately switch to a
run-scoped logger after Part A creates the run, the improvement belongs at the
**workflow/orchestration boundary**, not inside `dependencies.py`.

Conceptually:

```text
master request begins
↓
API logger
↓
Part A creates run_id
↓
obtain get_run_logger(real_run_id, "pipeline")
↓
use that logger for B→C→D→bootstrap
```

That can be added later if run-level log separation becomes important.

It does not require changing the Run Management or ML architecture.

For V1, the current behavior is acceptable.

---

# 1. Purpose of `dependencies.py`

`dependencies.py` is the shared infrastructure dependency layer for the FastAPI
routes.

Its job is to prevent every route from manually constructing infrastructure
objects.

Instead of routes doing:

```python
manager = RunManager()
logger = ...
```

each endpoint receives standard dependencies from one place.

The file intentionally contains no Part A–E business logic.

---

# 2. Main dependency — `RunManager`

The module exposes:

```python
get_run_manager()
```

which lazily creates:

```python
RunManager()
```

The function is cached:

```python
@lru_cache(maxsize=1)
```

so one process normally reuses the same `RunManager` facade.

Conceptually:

```text
FastAPI route 1 ─┐
FastAPI route 2 ─┼→ shared RunManager
FastAPI route 3 ─┘
```

This is safe for the current V1 architecture because actual run/manifest
mutation safety belongs to the Run Management locking layer.

The shared manager itself is not the source of run isolation.

---

# 3. Why RunManager creation is lazy

The manager is not created directly as a module-global object.

Instead:

```python
@lru_cache(maxsize=1)
def get_run_manager() -> RunManager:
    return RunManager()
```

This means merely importing:

```text
app.api.dependencies
```

does not immediately initialize the configured registry facade.

The manager is created when FastAPI first resolves the dependency.

This keeps imports cleaner and makes dependency overrides/testing easier.

---

# 4. FastAPI RunManager alias

The module exposes:

```python
RunManagerDependency
```

using FastAPI's `Annotated + Depends` pattern.

Route functions can therefore remain small:

```python
async def endpoint(
    request: SomeRequest,
    manager: RunManagerDependency,
):
    ...
```

The route does not need to know how the manager is built.

---

# 5. Process-level API logger

The module exposes:

```python
get_api_logger()
```

which returns:

```text
telecom_anomaly_backend.api
```

This logger is appropriate for:

```text
general HTTP/API events
startup-level API messages
requests where a run does not exist yet
```

Its level comes from:

```text
settings.log_level
```

Handler configuration remains owned by the application/server logging setup.

`dependencies.py` does not install duplicate handlers.

---

# 6. Why the API logger is cached

Like the RunManager dependency:

```python
get_api_logger()
```

uses:

```python
@lru_cache(maxsize=1)
```

This ensures routes consistently obtain the same process-level logger object
rather than repeatedly rebuilding logging configuration.

---

# 7. Run-scoped component logger helper

Once a valid `run_id` exists, the module provides:

```python
get_run_component_logger(
    run_id,
    component_name,
    ...
)
```

This delegates to the existing Core logging infrastructure:

```python
get_run_logger(...)
```

Conceptually:

```text
run_001
├── pipeline log
├── preprocessing log
├── run-management log
└── API/run-specific log
```

The API dependency layer therefore does not create a second logging system.

It reuses the already-established Core module.

---

# 8. `get_workflow_logger()`

The convenience helper:

```python
get_workflow_logger(run_id, ...)
```

implements the final decision:

```text
run_id exists
→ run-scoped logger

run_id is None
→ API logger
```

This is useful because the route does not need repeated branching logic.

---

# 9. API logger dependency alias

The module also exposes:

```python
ApiLoggerDependency
```

through the FastAPI `Annotated + Depends` pattern.

Routes that only need the generic API logger can therefore request it directly.

---

# 10. What `dependencies.py` deliberately does not do

The file does not:

```text
run workflows
run ML modules
inspect request bodies
create runs directly
create attempts directly
resolve stage artifacts
read/write manifests
translate exceptions to HTTP responses
define API routes
perform Part E inference
```

Those responsibilities remain separated:

```text
dependencies.py
→ infrastructure injection

error_handlers.py
→ exception-to-HTTP mapping

route modules
→ HTTP endpoint definitions

workflows
→ orchestration

Run Management
→ lifecycle and persistence

ML
→ A/B/C/D/E computation
```

---

# 11. Runtime lifecycle

Typical existing-run request:

```text
FastAPI
↓
RunManagerDependency
↓
shared RunManager

request.run_id
↓
get_workflow_logger(run_id)
↓
run-scoped component logger

route
↓
workflow
```

Typical brand-new request:

```text
FastAPI
↓
RunManagerDependency
↓
shared RunManager

no run_id yet
↓
API logger

route
↓
Part A / master workflow
↓
Run Management generates real run_id
```

---

# 12. Sanity-check results

The file passed syntax and independent dependency testing:

```text
DEPENDENCIES_SYNTAX=PASS
DEPENDENCIES_RUNTIME_SMOKE=PASS
```

The runtime test confirmed:

```text
RunManager constructed once
same cached manager returned repeatedly
API logger reused
new-run logging does not create fake run logger
existing run uses get_run_logger()
component name and include_console forwarded correctly
```

The final contract review additionally confirmed:

```text
app.core.settings import      PASS
app.core.get_run_logger       PASS
RunManager import             PASS
RunManager() constructor      PASS
FastAPI Depends usage         PASS
configured component logging  PASS
```

---

# 13. Final assessment

`dependencies.py` is intentionally small and correctly limited to dependency
wiring.

Final architecture:

```text
FastAPI routes
    ↓
dependencies.py
    ├── shared RunManager
    ├── API logger
    └── run-scoped logger helpers
    ↓
workflows / Run Management
```

The only noted limitation is:

> A brand-new master training request cannot begin with a run-scoped logger
> because its real `run_id` does not exist until Part A creates it.

This does not affect backend correctness and can be improved later at the
workflow/orchestration boundary if strict per-run logging for brand-new master
pipeline executions is required.

**Final status: PASS / suitable to freeze.**
