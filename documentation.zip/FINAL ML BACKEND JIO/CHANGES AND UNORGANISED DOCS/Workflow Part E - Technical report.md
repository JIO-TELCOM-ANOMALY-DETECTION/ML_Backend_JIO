# Phase 6 — Part E Workflow — Final Technical Report

**Package location:** `app/workflows/`  
**Phase scope:** `part_e.py`

---

## 1. Purpose

Phase 6 provides the final production workflow wrapper around the already-tested  
pure Part E inference module.

The workflow is intentionally thin.

It does **not** reimplement:

```
saved-contract loading
history/cache validation
late-data reconstruction
Part A/B/C reconstruction
feature validation
model loading
prediction
anomaly decisions
history commit
result staging
result publication
```

Those remain inside the existing Part E ML module.

The workflow only provides the production boundary:

```
InferenceRequest
    ↓
Run Management
    ↓
active inference-ready training attempt
    ↓
request-owned copied input
    ↓
existing run_inference_pipeline()
    ↓
Part E-owned invocation_id
    ↓
Run Management invocation registration
    ↓
public workflow response
```

---

# 2. File

```
app/workflows/
└── part_e.py
```

Public workflow function:

```
run_part_e_workflow(...)
```

---

# 3. Runtime request contract

Part E continues using the existing production:

```
app.schemas.inference.request.InferenceRequest
```

The request remains intentionally small:

```
run_id
input_file
inference_days
```

No preprocessing, feature-engineering, threshold, model, history, or cache  
configuration is supplied by the inference caller.

Those settings are already frozen inside the published:

```
inference_config.json
```

created by Phase 5 bootstrap.

---

# 4. Run Management boundary

The workflow does not resolve a physical run/inference path itself.

Instead it enters:

```
manager.inference_session(...)
```

Run Management then owns:

```
run lookup
active_inference_attempt_id resolution
inference-ready state resolution
run lock
request_id generation
request snapshot persistence
incoming file copy
request directory creation
failure persistence
invocation registration
manifest updates
registry synchronization
```

This keeps Part E workflow logic independent of registry/filesystem lookup  
implementation details.

---

# 5. Run lock

`inference_session()` holds one run-level lock for the complete Part E  
operation.

Conceptually:

```
acquire run lock
    ↓
prepare request context
    ↓
Part E runner
    ↓
history mutation
    ↓
result publication
    ↓
invocation registration
    ↓
release run lock
```

This is important because Part E mutates persistent history/cache state.

Two simultaneous inference calls against the same active saved state must not  
independently advance the same history boundary.

---

# 6. Request-owned input copy

The external request initially contains a caller-owned path:

```
request.input_file
```

Run Management copies that file into:

```
inference/<attempt_id>/requests/<request_id>/input/
```

The workflow then reconstructs the runtime `InferenceRequest` so the actual Part  
E ML runner receives:

```
context.input_file
```

rather than the original caller path.

Therefore once the inference session starts:

```
external source path
≠
authoritative runtime input
```

The copied request artifact becomes the immutable input for that invocation.

---

# 7. Existing Part E runner call

The workflow invokes only the existing public Part E entry point:

```
run_inference_pipeline(
    request=runtime_request,
    run_directory=context.inference_state_directory,
    logger_override=logger,
)
```

The `run_directory` supplied here is the published self-contained inference-state  
root:

```
runs/<run_id>/inference/<training_attempt_id>/
```

It is not:

```
the wider logical run directory
the Part D execution directory
the original training attempt directory
```

This matches the final Phase 5 bootstrap architecture.

---

# 8. Part E-owned invocation identity

There are two different identifiers in the production inference lifecycle.

## Run Management request ID

Generated before the Part E runner starts:

```
request_000001
request_000002
...
```

Purpose:

```
request snapshot
copied incoming file
request-level error/result persistence
```

## Part E invocation ID

Generated inside the existing Part E runner:

```
<run_id>_<timestamp>_<uuid fragment>
```

Purpose:

```
actual model/history inference execution identity
published inference result directory
Manifest V2 inference invocation identity
```

The workflow never substitutes:

```
request_id
```

for:

```
invocation_id
```

Part E remains authoritative for invocation identity.

---

# 9. Invocation-ID validation

Immediately after the Part E runner returns, the workflow requires:

```
invocation_id is a string
invocation_id is nonblank
```

A missing/blank identifier is rejected before Run Management invocation  
registration.

The production workflow schema and Manifest V2 additionally constrain persisted  
invocation IDs using the shared safe-record identifier contract.

The final run-ID length constraint was deliberately designed so the real Part E  
generated invocation ID remains inside that shared record-ID limit.

---

# 10. Runner result validation

Before registering the invocation, the workflow defensively validates the  
returned `InferenceRunnerResult`.

These checks are not a second inference implementation.

They protect the production workflow boundary against runner-contract drift.

---

## 10.1 Run identity

Required:

```
result.run_id
=
runtime_request.run_id
```

Mismatch:

```
PART_E_RUN_ID_MISMATCH
```

---

## 10.2 Active inference-state root

The resolved:

```
context.inference_state_directory
```

must exist.

Missing state:

```
PART_E_STATE_DIRECTORY_MISSING
```

---

## 10.3 Published output containment

The returned:

```
result.output_directory
```

must be physically below the active inference-state root.

Conceptually:

```
inference/<attempt_id>/
└── inference_results/
    └── <invocation_id>/
```

A result outside that saved state is rejected as:

```
PART_E_OUTPUT_OUTSIDE_STATE
```

---

## 10.4 Published output existence

The returned inference result directory must exist.

Error:

```
PART_E_OUTPUT_DIRECTORY_MISSING
```

---

## 10.5 Part E result manifest

The returned:

```
result.manifest_file
```

must:

```
exist
be a file
have result.output_directory as its direct parent
```

Errors:

```
PART_E_MANIFEST_MISSING
PART_E_MANIFEST_DIRECTORY_MISMATCH
```

---

# 11. Why history is reported as committed

The workflow's public summary includes:

```
history_committed = true
```

only for a returned `InferenceRunnerResult`.

This is valid because the existing Part E runner returns that result only after:

```
all ready-series inference completes
+
row-level outputs are staged
+
staged manifest is written
+
commit_history_pipeline() succeeds
+
manifest is updated to history_committed=true
+
result directory is published
```

The returned runner result therefore represents a technically completed Part E  
inference, not an intermediate model-scoring state.

---

# 12. Public result summary

The successful workflow response exposes only headline inference information:

```
model_type
inference_start
inference_end_exclusive
total_saved_series
completed_series
skipped_series_count
unmodelled_part_c_series
output_count
history_committed
```

It intentionally does not expose:

```
physical inference-state directory
output_directory
manifest_file
raw history path
processed history paths
cache paths
model paths
request directory
copied input path
```

Those remain internal through Run Management and Manifest V2.

---

# 13. Invocation completion

Once the runner result passes workflow validation, the workflow calls:

```
session.complete(
    invocation_id=<Part E invocation_id>,
    result_payload=<full JSON-safe InferenceRunnerResult>,
    output_directory=<Part E result directory>,
    metrics=<public summary>,
)
```

Run Management then owns final registration.

---

# 14. Run Management completion behavior

The Run Manager finalization path validates:

```
invocation_id
output directory containment
output directory existence
result payload persistence
```

It then creates the inference invocation record:

```
status = running
```

and finalizes it:

```
status = completed
result_file
metrics
```

Manifest V2 is the technical source of truth.

---

# 15. Failure-aware invocation registration

The final Run Manager already protects several partial-registration cases.

### Failure before invocation registration

The request is persisted as a request-level failure.

### Invocation started but completion persistence fails

Run Management best-effort transitions that invocation from:

```
running
→ failed
```

rather than leaving an orphaned running invocation.

### Invocation completed but registry synchronization fails

The completed Manifest V2 invocation remains authoritative.

The registry is rebuildable and the technically completed inference is not  
misclassified as failed solely because index synchronization failed.

The Part E workflow relies on this Run Management behavior rather than  
duplicating it.

---

# 16. Inference-session finalization

The inference context manager distinguishes:

```
normal completion
request failure
invocation-completion failure
```

`session.complete()` marks the session finalized even if its internal completion  
path raises after Run Management has already persisted the appropriate failure  
state.

Therefore context-manager exit does not incorrectly record a second  
request-level failure for the same completion attempt.

---

# 17. Failure boundary before active attempt resolution

If failure occurs before Run Management can establish:

```
training_attempt_id
```

the workflow cannot truthfully construct:

```
InferenceWorkflowResponse
```

because the public response requires the active training attempt identity.

These errors propagate to the future API error handler.

Examples include:

```
run not found
no active inference attempt
active saved state unavailable
request preparation failure
input-copy failure
```

---

# 18. Failure before invocation ID exists

The current public `InferenceWorkflowResponse` requires:

```
invocation_id
```

It is not optional.

Therefore if the Part E runner fails before returning a valid invocation ID:

```
request/session already exists
but
no truthful invocation_id exists
```

the workflow does **not**:

```
invent an ID
reuse request_id
return invocation_id=None
```

Instead:

```
Run Management records request-level failure
+
original exception propagates
+
API layer returns WorkflowErrorResponse
```

This avoids the earlier response-validation bug where a legitimate Part E  
failure could be replaced by a secondary Pydantic error.

---

# 19. Failure after a valid invocation ID exists

Once Part E returns a valid invocation ID, later workflow/registration failures  
can truthfully include that ID.

The workflow can return:

```
status = failed
run_id
training_attempt_id
invocation_id
stage = inference
error
```

The invocation ID is always the real Part E-produced identifier.

---

# 20. `session.complete()` failure

If invocation registration/finalization fails after a valid Part E result:

```
session.complete()
→ Run Management persists correct request/invocation failure state
→ session becomes finalized
→ original exception propagates back to workflow
→ workflow returns failed InferenceWorkflowResponse with the real invocation ID
```

No second request failure is created by `__exit__`.

---

# 21. Successful response

Successful Phase 6 response:

```
status = completed
run_id
training_attempt_id
invocation_id
stage = inference
message
summary
error = None
```

No physical server paths are exposed.

---

# 22. Relationship to Phase 5

Phase 5 creates:

```
runs/<run_id>/inference/<attempt_id>/
├── inference_config.json
├── history/
├── cache/
├── models/
├── inference_results/
└── requests/
```

and sets:

```
active_inference_attempt_id
```

Phase 6 then resolves that active attempt through Run Management and runs Part E  
against exactly that saved state.

Therefore:

```
Phase 5
= training → reusable inference state

Phase 6
= repeated independent inference invocations against that state
```

---

# 23. Sequential inference

The workflow keeps the run lock across the complete Part E operation.

After one successful invocation:

```
persistent history/cache advances
```

A later invocation starts only after that first operation releases the run lock.

This preserves the sequential-history model already validated by the Part E  
integration tests.

---

# 24. Late-data / reconstruction responsibility

The workflow does not inspect timestamps or decide whether late data requires  
reconstruction.

That remains inside Part E's history subsystem using the saved contract from  
Phase 5.

The workflow simply gives Part E:

```
copied new input
+
published saved inference-state root
```

and allows the existing ML/history module to decide:

```
normal forward path
or
late-data reconstruction path
```

---

# 25. Model responsibility

The workflow does not know whether the active saved run contains:

```
XGBoost
or
Isolation Forest
```

beyond reporting the model type returned by the inference runner.

Model-specific loading, feature compatibility, prediction, residual decisions,  
and directional anomaly rules remain inside the existing Part E module.

---

# 26. Memory behavior

Phase 6 adds no large in-memory aggregation.

The existing Part E runner continues its memory-conscious design:

```
lightweight saved model plan
+
one site's dataframe
+
one loaded estimator
```

per scoring iteration.

The workflow only retains:

```
request
session context
final lightweight InferenceRunnerResult
summary
```

---

# 27. Persistence ownership

Responsibility split:

```
Part E ML
→ history/cache mutation
→ row-level inference outputs
→ inference manifest
→ result directory publication

Run Management
→ request snapshot
→ copied caller input
→ inference request lifecycle
→ invocation lifecycle in Manifest V2
→ registry synchronization

Part E workflow
→ orchestration boundary only
```

This avoids duplicated persistence logic.

---

# 28. Final sanity checks

Final syntax/runtime checks:

```
PART_E_SYNTAX=PASS
PART_E_RUNTIME_SMOKE=PASS
PART_E_INDEPENDENT_SANITY=PASS
PHASE6_PART_E_FINAL_SANITY=PASS
```

Runtime coverage included:

```
successful inference
request-owned copied input
correct active state directory passed to runner
real Part E invocation ID registration
public path hiding

runner failure before invocation ID
blank invocation ID
wrong returned run ID
output path outside inference state
missing Part E manifest
session.complete() failure
failure before inference-session context creation
```

---

# 29. Contract-level sanity conclusions

Verified against current production contracts:

```
InferenceRequest
→ run_id + input_file + inference_days

InferenceWorkflowResponse
→ invocation_id required

Run Management
→ request ID separate from invocation ID
→ active inference attempt resolution
→ full-run lock during Part E
→ copied input ownership
→ failure-aware invocation registration

InferenceRunnerResult
→ returned only after history commit and published result directory
```

No blocking mismatch remains in the final Part E workflow.

---

# 30. Final assessment

Phase 6 is complete.

The final production workflow chain is now:

```
TRAINING LIFECYCLE

Part A
↓
Part B
↓
Part C
↓
Part D
↓
inference_bootstrap
↓
published self-contained inference state
↓
active_inference_attempt_id


RUNTIME INFERENCE LIFECYCLE

InferenceRequest
↓
Run Management inference session
↓
request-owned input copy
↓
active inference-state root
↓
existing Part E runner
↓
history/cache commit
↓
published invocation results
↓
Part E invocation registration
↓
InferenceWorkflowResponse
```

`part_e.py` is therefore ready to be frozen