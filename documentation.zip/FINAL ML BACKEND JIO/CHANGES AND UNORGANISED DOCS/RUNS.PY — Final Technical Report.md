# Runs API — Final Technical Report

**File:** `app/api/runs.py`  
**Final implementation:** v4  
**Module:** `app/api/`  
**Status:** Final sanity checked — suitable to freeze  
**Primary role:** Read-only inspection of historical and currently executing backend runs through Run Management + Manifest V2.

---

# 1. Purpose

`runs.py` provides the HTTP endpoints used to **inspect run lifecycle state that already exists**.

It answers questions such as:

```
What runs exist?
What is the current status of a run?
Which attempts belong to that run?
Which stages are pending, running, completed, or failed?
Which physical stage execution is currently active?
Which execution completed successfully?
Is this run currently inference-ready?
Which training attempt is serving Part E?
What historical safe errors/metrics are available?
```

The module works for both:

```
historical/completed runs
and
currently executing runs
```

It is therefore the API/UI read layer for the persisted run-control state.

---

# 2. What `runs.py` Does NOT Do

The file is deliberately read-only.

It does not:

```
create runs
create attempts
start stages
retry stages
cancel stages
run Part A
run Part B
run Part C
run Part D
run inference bootstrap
run Part E
activate inference attempts
mutate Manifest V2
mutate the registry
resolve model artifacts for execution
generate plots
generate reports
read arbitrary result files
guess the newest execution folder
scan run directories with glob()
```

Execution remains owned by:

```
stage API routes
        ↓
workflows
        ↓
Run Management
        ↓
ML modules
```

`runs.py` only observes the resulting persisted state.

---

# 3. Position in the Final Architecture

```
UI / API client
      │
      ▼
app/api/runs.py
      │
      ├── RunManager / RunRegistry
      │
      └── Manifest V2
      │
      ▼
public workflow run schemas
      │
      ▼
safe JSON response
```

The file never reaches directly into ML A–E.

---

# 4. Main Data Sources

Two existing components are used.

## Run Registry

Purpose:

```
lightweight run discovery/index
```

Used for:

```
list known runs
prove whether a caller-requested run is registered
```

The registry is not the detailed technical truth.

---

## Manifest V2

Purpose:

```
authoritative technical run state
```

It contains:

```
run identity
run status
attempts
canonical stages
executions
active/successful execution pointers
inference-ready pointer
inference invocations
metrics
errors
summaries
timestamps
```

Therefore the read hierarchy is:

```
Registry
→ discover/identify run

Manifest V2
→ explain what is happening or what happened
```

---

# 5. Why Folder Scanning Is Not Used

The module never attempts:

```
glob(...)
find newest folder
sort execution directories
guess result.json
```

That would be unsafe because a run may contain:

```
failed retries
old executions
partial executions
temporary/staging folders
multiple attempts
```

Instead Manifest V2 explicitly records:

```
active_execution_id
successful_execution_id
```

The public run view follows those persisted identities.

---

# 6. Public Router

The router is defined under:

```
/api/v1/runs
```

and tagged:

```
runs
```

Final endpoints:

```
GET /api/v1/runs

GET /api/v1/runs/{run_id}

GET /api/v1/runs/{run_id}/attempts/{attempt_id}
```

All are read-only `GET` endpoints.

---

# 7. Endpoint 1 — List Runs

```
GET /api/v1/runs
```

Purpose:

```
list all registered backend runs
```

This can support a UI page such as:

```
Current Runs
Previous Runs
Run History
```

---

# 8. List-Runs Processing Flow

```
manager.list_runs()
        ↓
registry records
        ↓
for each registered run
        ↓
manager.get_manifest(run_id)
        ↓
validated Manifest V2
        ↓
_build_run_summary()
        ↓
RunSummaryResponse
        ↓
sort newest first
```

The registry supplies discovery.

The manifest supplies the full current/historical state.

---

# 9. Why `GET /runs` Loads Manifest V2

The registry intentionally stores only lightweight index information.

It is not sufficient to accurately return:

```
attempt statuses
stage statuses
active execution
successful execution
inference readiness
inference invocation state
historical safe errors
```

Therefore the V1 list endpoint favors correctness and consistency over maximum  
listing performance.

Each registered run is resolved to its current Manifest V2 state.

---

# 10. List Ordering

The final list is sorted by:

```
created_at_utc
then run_id
```

in descending order.

Therefore:

```
newest run
→ first
```

This is more useful for UI history than relying on registry-key order.

---

# 11. Fail-Closed List Behavior

If one registered run has corrupt/unreadable technical state, the list endpoint  
does not silently omit it.

Instead:

```
registered run
→ Manifest V2 cannot be resolved safely
→ request fails
→ 500
```

This prevents the API from returning an apparently complete run list while  
quietly hiding known registry state.

This is an intentional V1 fail-closed choice.

---

# 12. Endpoint 2 — Get One Run

```
GET /api/v1/runs/{run_id}
```

Purpose:

```
return the latest persisted state of one run
```

The same endpoint supports:

```
brand-new/created run
currently running run
partially completed run
failed run
completed run
inference-ready run
historical run
```

---

# 13. Targeted Run Lookup

Single-run lookup deliberately does **not** call:

```
manager.list_runs()
```

to establish existence.

That earlier design was rejected because one unrelated malformed registry entry  
could break lookup of a perfectly healthy target run.

The final path uses the registry's targeted storage-independent existence  
operation:

```
manager.registry.exists(run_id)
```

only to establish whether this specific caller-owned run identity is registered.

Then:

```
manager.get_manifest(run_id)
```

performs the authoritative technical resolution.

---

# 14. Why the Targeted Registry Check Is Narrow

The registry check exists only for correct API 404 ownership semantics.

It does not:

```
return registry details to the user
read artifacts
decide run status
replace RunManager resolution
```

Its only decision is:

```
requested run is not registered
→ caller-owned missing resource
→ API_RUN_NOT_FOUND
```

After registration has been established, all technical resolution remains with  
`RunManager.get_manifest()`.

---

# 15. Missing Run — Public 404

If:

```
manager.registry.exists(run_id) == False
```

the route raises:

```
RunNotFoundError
error_code = API_RUN_NOT_FOUND
```

The frozen global error handler converts this to:

```
HTTP 404
```

with safe details:

```
{
  "run_id": "..."
}
```

---

# 16. Registered But Broken Run — Internal 500

A very different situation is:

```
registry contains run_id
        ↓
manager.get_manifest(run_id)
        ↓
registered run directory missing
manifest missing
manifest identity mismatch
registry record corrupt
technical state inconsistent
```

These errors are **not** translated to `API_RUN_NOT_FOUND`.

They remain internal backend failures:

```
→ HTTP 500
```

This preserves the frozen fail-closed error-mapping contract.

---

# 17. Why the 404/500 Distinction Matters

Consider:

```
Case A:
caller asks for run_999
registry has never heard of run_999
→ 404

Case B:
registry says run_001 exists
but its technical state disappeared
→ 500
```

Both involve "missing something", but they have different ownership:

```
unknown public resource
vs
broken backend state
```

`runs.py` preserves that distinction.

---

# 18. Endpoint 3 — Get Attempt Detail

```
GET /api/v1/runs/{run_id}/attempts/{attempt_id}
```

Purpose:

```
show detailed persisted state for one training attempt
```

This is the most useful endpoint for a pipeline-progress UI.

---

# 19. Attempt Detail Example

A currently executing master pipeline may return stage states conceptually like:

```
Part A               completed
Part B               completed
Part C               running
Part D               pending
inference_bootstrap  pending
```

For the running Part C stage, the response can also include:

```
active_execution_id = execution_0001
```

For completed Part A/B:

```
successful_execution_id = execution_0001
```

---

# 20. Missing Attempt — Public 404

The route first proves that the run itself exists.

Then it checks:

```
manifest["attempts"][attempt_id]
```

If the caller-requested attempt is genuinely absent:

```
AttemptNotFoundError
error_code = API_ATTEMPT_NOT_FOUND
```

The global error handler returns:

```
HTTP 404
```

with:

```
run_id
attempt_id
```

---

# 21. Attempt Detail Uses Full Run Consistency

The final v4 implementation does not build the requested attempt in isolation  
and ignore the rest of the run-level control state.

After confirming that the requested attempt exists, it builds the authoritative:

```
RunSummaryResponse
```

from the same manifest and selects the requested `AttemptView` from it.

Why?

Because the attempt response also contains:

```
active_inference_attempt_id
inference_ready
```

Those are run-level state.

Therefore:

```
GET /runs/{run_id}
and
GET /runs/{run_id}/attempts/{attempt_id}
```

must enforce the same inference-pointer consistency rules.

This prevents one endpoint from accepting a corrupt manifest that the other  
endpoint rejects.

---

# 22. Existing Public Response Schemas Reused

`runs.py` does not create duplicate API models.

It reuses the frozen workflow run schemas:

```
ExecutionView
StageView
AttemptView
InferenceInvocationView
RunSummaryResponse
AttemptDetailResponse
WorkflowErrorDetail
WorkflowErrorRecord
```

This keeps run inspection aligned with the schema package already designed for  
this purpose.

---

# 23. Manifest-to-Public Conversion

The central conversion chain is:

```
Manifest V2
        ↓
_build_execution_view()
        ↓
_build_stage_view()
        ↓
_build_attempt_view()
        ↓
_build_inference_invocation_view()
        ↓
_build_run_summary()
        ↓
public Pydantic response
```

The builders do more than copy fields.

They also verify important consistency relationships before exposing state.

---

# 24. `_build_execution_view()`

Input:

```
one Manifest V2 stage execution record
```

Public output:

```
execution_id
status
started_at_utc
completed_at_utc
safe metrics
safe error
```

Not exposed:

```
request_file
result_file
error_file
output_directory
metadata containing physical paths
registered output file paths
```

The execution's embedded:

```
execution_id
```

must match its dictionary key.

A mismatch is treated as internal corruption.

---

# 25. `_build_stage_view()`

Input:

```
one canonical stage record
```

Output:

```
stage
status
active_execution_id
successful_execution_id
executions[]
```

Canonical stages are read according to the existing Manifest V2 stage list:

```
part_a
part_b
part_c
part_d
inference_bootstrap
```

Missing/malformed stage records fail closed.

---

# 26. Stage Identity / Execution History

Each execution under a stage is converted independently.

The resulting execution views are ordered by their execution IDs.

Current IDs use forms such as:

```
execution_0001
execution_0002
```

so this produces deterministic retry history.

---

# 27. Active Execution Invariant

Normal Manifest V2 stage start performs:

```
execution.status = running
stage.status = running
stage.active_execution_id = execution_id
```

The public reader now explicitly verifies this relationship.

If:

```
stage.status == running
```

then there must be:

```
exactly one running execution
AND
active_execution_id must exist
AND
active_execution_id must point to that running execution
```

Otherwise:

```
RUN_VIEW_RUNNING_STAGE_INCONSISTENT
→ 500
```

---

# 28. Non-Running Stage Invariant

If:

```
stage.status != running
```

then:

```
active_execution_id must be null
AND
no execution may still have status=running
```

Otherwise:

```
RUN_VIEW_NON_RUNNING_STAGE_HAS_ACTIVE_EXECUTION
→ 500
```

This prevents public UI state such as:

```
Part C = failed
but execution_0001 = running
```

from being displayed as if it were trustworthy.

---

# 29. Successful Execution Invariant

A persisted:

```
successful_execution_id
```

must point to an execution whose status is:

```
completed
```

Otherwise:

```
RUN_VIEW_SUCCESSFUL_EXECUTION_INCONSISTENT
→ 500
```

---

# 30. Completed Stage Invariant

If:

```
stage.status == completed
```

then:

```
successful_execution_id
```

must exist.

Otherwise:

```
RUN_VIEW_COMPLETED_STAGE_WITHOUT_SUCCESS
→ 500
```

This matches the final Manifest V2 completion operation, which writes both  
together.

---

# 31. Non-Completed Stage Successful-Pointer Invariant

The reverse relationship is also enforced.

If:

```
stage.status != completed
```

then:

```
successful_execution_id
```

must be null.

Otherwise:

```
RUN_VIEW_NON_COMPLETED_STAGE_HAS_SUCCESS
→ 500
```

This prevents contradictory state such as:

```
stage = failed
successful_execution_id = execution_0001
```

from silently reaching the UI.

---

# 32. `_build_attempt_view()`

One attempt view contains:

```
attempt_id
status
created_at_utc
updated_at_utc
started_at_utc
completed_at_utc
five canonical stage views
safe summary
safe historical errors
```

The attempt's embedded ID must match the manifest dictionary key.

---

# 33. `_build_inference_invocation_view()`

One Part E invocation exposes:

```
invocation_id
training_attempt_id
status
started_at_utc
completed_at_utc
safe metrics
safe error
```

Not exposed:

```
request_file
input path
output_directory
result_file
error_file
internal metadata
```

---

# 34. Inference Invocation Training-Attempt Integrity

Each invocation must reference a training attempt that actually exists in the  
same run.

If:

```
invocation.training_attempt_id
```

does not belong to the current run's attempts:

```
RUN_VIEW_INFERENCE_ATTEMPT_UNKNOWN
→ 500
```

This prevents orphaned inference history from being presented as valid.

---

# 35. Inference Invocation Ordering

Invocation views are sorted using:

```
started_at_utc availability
started_at_utc
invocation_id
```

The logic safely handles invocations whose start timestamp is null.

This is useful for historical Part E inspection.

---

# 36. `_build_run_summary()`

This is the central authoritative converter.

It builds:

```
run identity + metadata
run lifecycle status
attempt views
inference-ready state
inference invocation views
safe run summary
safe run errors
```

and validates run-level pointer coherence.

---

# 37. Latest Attempt Integrity

If:

```
latest_attempt_id
```

is not null, it must reference an attempt that actually exists in:

```
manifest["attempts"]
```

Otherwise:

```
RUN_VIEW_LATEST_ATTEMPT_UNKNOWN
→ 500
```

---

# 38. Active Inference Attempt Integrity

If:

```
active_inference_attempt_id
```

is not null, it must reference an existing attempt.

Otherwise:

```
RUN_VIEW_ACTIVE_INFERENCE_ATTEMPT_UNKNOWN
→ 500
```

---

# 39. `inference_ready` Pointer Consistency

The final reader requires:

```
inference_ready = true
→ active_inference_attempt_id must exist
```

and:

```
active_inference_attempt_id exists
→ inference_ready must be true
```

Contradictory states fail closed.

---

# 40. Active Inference Attempt Must Actually Be Ready

The final v4 reader goes further than checking the boolean/pointer pair.

If:

```
inference_ready = true
```

the active attempt must contain:

```
part_d
    status = completed
    successful_execution_id != null

AND

inference_bootstrap
    status = completed
    successful_execution_id != null
```

Otherwise:

```
RUN_VIEW_INFERENCE_READY_ATTEMPT_INVALID
→ 500
```

This mirrors the existing Run Management activation rule.

---

# 41. Why D + Bootstrap Are Checked

Part E is only allowed to use an attempt after:

```
Part D completed
        ↓
inference_bootstrap completed
        ↓
stable inference state published
        ↓
attempt activated
```

Therefore a manifest stating:

```
inference_ready = true
```

while bootstrap is failed/pending is internally inconsistent.

`runs.py` refuses to display that as valid status.

---

# 42. Old vs Active Inference Attempt

A run may legitimately contain:

```
attempt_0001
→ completed
→ currently serving inference

attempt_0002
→ newer retraining attempt
→ currently running
```

Therefore:

```
active_inference_attempt_id
```

does **not** have to equal:

```
latest_attempt_id
```

The reader intentionally does not enforce that equality.

This preserves the system's designed ability to keep an older working model  
serving inference while retraining a new attempt.

---

# 43. Attempt-Level `inference_ready`

For:

```
GET /runs/{run_id}/attempts/{attempt_id}
```

the returned boolean means:

> Is this exact requested attempt currently the run's active inference-ready  
> attempt?

Therefore:

```
run inference_ready = true
active attempt = attempt_0002
requested attempt = attempt_0001
```

returns:

```
inference_ready = false
```

for attempt 0001.

This is intentional.

---

# 44. Public Data Safety

Manifest V2 intentionally contains internal technical values.

Examples:

```
absolute run directories
request_file
result_file
error_file
output_directory
model/artifact paths
raw exception messages
original_error
```

`runs.py` does not directly serialize the manifest.

All dynamic mappings pass through public-safety conversion first.

---

# 45. Sensitive-Key Filtering

The reader drops mapping fields representing:

```
path
paths
file
files
directory
directories
root

*_path
*_paths
*_file
*_files
*_directory
*_directories
*_root
```

It also removes diagnostic fields such as:

```
original_error
traceback
stack_trace
exception
raw_error
```

---

# 46. Path-Value Redaction

Key filtering is the main protection.

As defense in depth, string values that look like absolute filesystem paths are  
also redacted.

Examples:

```
/var/app/runs/...
C:\backend\runs\...
\\server\share\...
```

become:

```
[redacted]
```

This protects even against an unexpectedly named summary/metric key containing  
a physical path.

---

# 47. Safe JSON Conversion

`_public_json_value()` safely handles:

```
None
bool
int
finite float
str
Path
date
datetime
Enum
Pydantic model
mapping
sequence
set/frozenset
```

Non-finite floats become:

```
null
```

Opaque objects never expose `repr()`.

They become:

```
{
  "type": "ObjectType"
}
```

This avoids accidental leakage through arbitrary object representations.

---

# 48. Public Metrics

Execution and inference metrics may be useful for the UI.

They are therefore retained after sanitization.

Example conceptual values:

```
kpi_count
row_count
completed_series
cache_days
training count summaries
```

Path-bearing/internal metric fields are removed or redacted.

---

# 49. Public Summary Handling

Run and attempt `summary` dictionaries are generic Manifest V2 structures.

They are not blindly trusted.

They pass through:

```
_public_mapping()
```

which:

```
requires mapping type
removes internal keys
redacts path-like values
normalizes JSON values
```

Malformed summary structure causes an internal 500 rather than being silently  
coerced.

---

# 50. Historical Error Safety

Manifest errors are intentionally diagnostic and may contain internal details.

For example:

```
original_error
request_file
filesystem paths
raw backend messages
```

Therefore historical errors are never copied directly to the API.

---

# 51. Safe Historical Error Shape

`_public_error_record()` returns only:

```
error_type
generic safe message
error_code
details = {}

timestamp_utc
scope
attempt_id
training_attempt_id
stage_name
execution_id
invocation_id
```

The raw persisted:

```
message
details
```

are sealed.

---

# 52. Generic Historical Error Message

Stored internal error text is replaced with:

```
A backend error occurred during this operation.
```

This allows the UI to show that an operation failed while avoiding disclosure of:

```
filesystem paths
library messages
parser internals
implementation details
```

The stable `error_code` remains available for diagnosis.

---

# 53. Current Execution Error Safety

Execution/invocation current errors are similarly converted by:

```
_public_error_detail()
```

which exposes:

```
error_type
generic message
error_code
details={}
```

No raw error message/details are reflected.

---

# 54. Error Mapping Relationship

`runs.py` does not implement the entire HTTP error policy.

It only creates the API-boundary codes where it has ownership/context:

```
API_RUN_NOT_FOUND
API_ATTEMPT_NOT_FOUND
```

Everything else propagates to the frozen global `error_handlers.py`.

---

# 55. Why Internal View-Consistency Errors Become 500

Internal reader errors use codes such as:

```
RUN_VIEW_RUNNING_STAGE_INCONSISTENT
RUN_VIEW_SUCCESSFUL_EXECUTION_INCONSISTENT
RUN_VIEW_LATEST_ATTEMPT_UNKNOWN
RUN_VIEW_INFERENCE_READY_ATTEMPT_INVALID
```

These are deliberately not public 4xx codes.

The global handler therefore applies:

```
unknown/unapproved backend code
→ 500
```

with:

```
generic public message
details={}
```

This is exactly the intended fail-closed behavior.

---

# 56. Current-Run Status / Polling Behavior

`runs.py` provides **persisted current state**, not push streaming.

Typical UI flow:

```
pipeline starts
        ↓
UI polls GET /runs/{run_id}
        ↓
Manifest currently says Part B running
        ↓
UI renders Part B running

later
        ↓
UI polls again
        ↓
Manifest now says Part B completed / Part C running
```

No WebSocket is required for V1.

---

# 57. Why Reads Do Not Acquire the Long-Lived Run Lock

The module does not acquire a run lock simply to display status.

Manifest persistence uses atomic file replacement.

Therefore the reader sees:

```
previous complete persisted manifest
or
new complete persisted manifest
```

rather than a half-written JSON file.

Run locks remain necessary for state mutation, especially Part E history/cache  
updates, but a read-only status endpoint does not need to hold them.

---

# 58. Concurrency Interpretation

The response is a snapshot.

It means:

> This was the latest complete Manifest V2 state when this request resolved.

A pipeline may progress immediately after the response is generated.

Therefore the endpoint is suitable for:

```
status polling
UI progress views
historical inspection
```

but it is not a transactional "freeze the run while viewing it" operation.

---

# 59. Registry / Manifest Race Handling

The targeted existence check occurs before authoritative manifest resolution.

If the requested run is absent at the boundary:

```
→ 404
```

If the run is known and technical state then breaks/races during resolution:

```
→ internal error
→ 500
```

This is deliberately conservative.

The route does not convert every later `RUN_NOT_FOUND` into a public 404.

---

# 60. Result Files and Reports

The current `runs.py` does **not** read:

```
Part A result.json
Part B result.json
Part C result.json
Part D result.json
inference output files
report files
plot files
```

It returns:

```
lifecycle state
safe summaries
safe metrics
safe errors
inference readiness
```

Detailed domain result retrieval/reporting can be added later through a  
dedicated results/reporting API without changing this file's core role.

---

# 61. Why Result Retrieval Is Kept Separate

The run-status API should remain lightweight in responsibility:

```
What happened?
What is happening?
```

rather than:

```
Load every large domain artifact and generate analysis.
```

This separation avoids mixing:

```
run control-plane state
with
reporting/data-plane content
```

---

# 62. Dependency Use

Endpoints receive:

```
RunManagerDependency
ApiLoggerDependency
```

from the already-frozen `dependencies.py`.

Routes do not construct a new manager or logger themselves.

This keeps infrastructure wiring centralized.

---

# 63. Logging

Successful read operations log only lightweight API diagnostics such as:

```
number of listed runs
run_id read
run_id + attempt_id read
```

No manifest paths or result paths are intentionally logged by this router's  
normal success path.

Error logging remains primarily centralized in the global error handler.

---

# 64. Route Validation

`run_id` uses the frozen:

```
RunId
```

schema.

`attempt_id` uses:

```
AttemptId
```

Therefore malformed IDs are rejected by FastAPI/Pydantic before Run Management  
execution.

Example:

```
run_id longer than allowed contract
→ RequestValidationError
→ 422 REQUEST_VALIDATION_FAILED
```

---

# 65. Complete Read Flow — List

```
GET /api/v1/runs
        ↓
RunManager.list_runs()
        ↓
for each run
        ↓
RunManager.get_manifest(run_id)
        ↓
Manifest V2
        ↓
validate identities/pointers
        ↓
sanitize metrics/summaries/errors
        ↓
RunSummaryResponse[]
        ↓
newest first
```

---

# 66. Complete Read Flow — One Run

```
GET /api/v1/runs/{run_id}
        ↓
targeted registry exists check
        │
        ├── absent
        │      ↓
        │  API_RUN_NOT_FOUND
        │      ↓
        │     404
        │
        └── registered
               ↓
        RunManager.get_manifest()
               ↓
        technical validation
               ↓
        _build_run_summary()
               ↓
        RunSummaryResponse
```

---

# 67. Complete Read Flow — One Attempt

```
GET /api/v1/runs/{run_id}/attempts/{attempt_id}
        ↓
public run resolution
        ↓
attempt membership check
        │
        ├── absent
        │      ↓
        │ API_ATTEMPT_NOT_FOUND
        │      ↓
        │     404
        │
        └── exists
               ↓
        _build_run_summary()
               ↓
        enforce run-level consistency
               ↓
        select requested AttemptView
               ↓
        calculate whether this exact attempt
        is active for inference
               ↓
        AttemptDetailResponse
```

---

# 68. Final Sanity-Check Issues Resolved

Several issues were intentionally caught before freeze.

## Issue 1 — Single-run lookup used full registry listing

Earlier behavior:

```
GET /runs/run_001
→ manager.list_runs()
→ unrelated corrupt registry entry could break run_001 lookup
```

Final behavior:

```
targeted registry existence check
→ only requested run determines public absence
```

Resolved.

---

## Issue 2 — Running Stage Could Lack Active Pointer

Earlier reader could accept:

```
stage.status = running
active_execution_id = null
execution_0001.status = running
```

Final reader rejects it with internal 500.

Resolved.

---

## Issue 3 — Non-Running Stage Could Retain Active/Running Execution

Final reader now rejects:

```
stage.status = failed/pending/completed
while
active_execution_id != null
or
some execution.status = running
```

Resolved.

---

## Issue 4 — Non-Completed Stage Could Retain Successful Pointer

Final reader now rejects:

```
stage.status != completed
successful_execution_id != null
```

Resolved.

---

## Issue 5 — `inference_ready` Could Point to an Attempt Without Completed D/Bootstrap

Final reader now verifies:

```
active attempt
├── part_d completed + successful execution
└── inference_bootstrap completed + successful execution
```

Resolved.

---

## Issue 6 — Attempt Endpoint Could Bypass Run-Level Pointer Checks

Earlier:

```
GET attempt
→ build only requested attempt
```

could theoretically return an attempt response while run-level inference state  
was corrupt.

Final:

```
prove attempt exists
→ build authoritative run summary
→ select requested attempt
```

Resolved.

---

# 69. Final Regression Coverage

Final v4 validation includes the original runtime suite plus targeted invariant  
tests.

Passed:

```
RUNS_API_V4_SYNTAX=PASS
RUNS_API_V4_FULL_REGRESSION=PASS
```

The inherited base smoke also passed in the v4 environment.

---

# 70. Normal Runtime Cases Tested

Coverage includes:

```
historical completed/failed run
currently running run
multiple runs
multiple attempts
stage progress
pending stages
running stage
completed stages
successful execution IDs
active execution IDs
inference invocation ordering
old attempt vs active inference attempt
safe summaries
safe metrics
safe historical errors
```

---

# 71. HTTP Boundary Cases Tested

Coverage includes:

```
genuinely unknown run
→ API_RUN_NOT_FOUND
→ 404

genuinely unknown attempt
→ API_ATTEMPT_NOT_FOUND
→ 404

registered target whose technical state breaks
→ 500

malformed run_id
→ Pydantic 422

unrelated corrupt registry entry
→ does not break valid targeted run lookup
```

---

# 72. Security Cases Tested

Regression verifies that responses do not expose:

```
/secret/... paths
raw original_error
raw persisted error messages
request_file
result_file
output_directory
manifest_file
model_file
```

Path-looking metric values are redacted.

Historical errors keep only safe identity/context.

---

# 73. Consistency-Corruption Cases Tested

Explicit corrupt-state tests verify 500 for:

```
running stage without active pointer

non-running stage retaining active/running execution

non-completed stage retaining successful execution pointer

inference_ready=true while active attempt lacks valid completed
Part D / inference_bootstrap state

attempt-detail request against that same corrupt inference-ready state
```

This demonstrates that the run view fails closed rather than displaying  
contradictory lifecycle state.

---

# 74. Known V1 Boundary — List Scalability

`GET /runs` currently loads each registered run's Manifest V2.

This is correct for current V1 expectations but is not intended as an  
unbounded high-scale query strategy.

If the registry eventually contains very large numbers of runs, future options  
include:

```
pagination
registry-denormalized safe summary fields
dedicated database query layer
separate lightweight list response
```

That is a future scalability concern, not a current correctness issue.

---

# 75. Known V1 Boundary — Polling Rather Than Push

Current status is retrieved through repeated GET calls.

No:

```
WebSocket
Server-Sent Events
push notification
```

is implemented.

For V1:

```
poll persisted Manifest state
```

is sufficient and keeps the API/control architecture simple.

---

# 76. Known V1 Boundary — No Result/Report Download Yet

This router does not yet expose detailed stage-result artifacts.

Future modules may add:

```
results endpoint
reporting endpoint
visualization endpoint
```

Those should use the authoritative successful execution/artifact resolver  
rather than modifying `runs.py` into a filesystem browser.

---

# 77. Final Responsibility Boundary

```
runs.py
→ observe existing run state

eda.py
→ HTTP endpoint that launches Part A workflow

preprocessing.py
→ launches Part B workflow

feature_engineering.py
→ launches Part C workflow

training.py
→ launches D → bootstrap lifecycle

pipeline.py
→ launches master A → B → C → D → bootstrap

inference.py
→ launches Part E

reporting/visualization module
→ later generates domain reports/plots
```

This keeps run inspection distinct from execution.

---

# 78. Final Compact File Contract

```
FILE:
app/api/runs.py

ROLE:
Read-only API for historical and current backend run state.

ROUTER PREFIX:
/api/v1/runs

ENDPOINTS:
GET /api/v1/runs
GET /api/v1/runs/{run_id}
GET /api/v1/runs/{run_id}/attempts/{attempt_id}

DATA SOURCES:
Run Registry
Manifest V2

TECHNICAL TRUTH:
Manifest V2

PUBLIC RESPONSE MODELS:
RunSummaryResponse
AttemptDetailResponse
AttemptView
StageView
ExecutionView
InferenceInvocationView

PUBLIC MISSING RUN:
API_RUN_NOT_FOUND → 404

PUBLIC MISSING ATTEMPT:
API_ATTEMPT_NOT_FOUND → 404

INTERNAL CORRUPTION:
500 via frozen error handler

READ SAFETY:
no filesystem guessing
no arbitrary result loading
no state mutation
no raw manifest serialization
no raw persisted error details

STATUS INVARIANTS:
running stage ↔ exactly one matching active running execution
completed stage ↔ successful completed execution
non-running stage → no active/running execution
non-completed stage → no successful execution pointer

INFERENCE INVARIANTS:
active inference attempt must exist
inference_ready and active pointer must agree
active inference-ready attempt must have completed successful:
part_d
inference_bootstrap

CURRENT STATUS MODEL:
poll latest atomic Manifest V2 snapshot

HISTORICAL STATUS MODEL:
same endpoint reads persisted completed/failed state

SIDE EFFECTS:
read operations + debug logging only

DOES NOT:
run ML
run workflows
create attempts
mutate manifests
generate reports
generate plots
read arbitrary stage result files
```

---

# 79. Final Assessment

`app/api/runs.py` now provides the required read-only control-plane view for the  
backend.

Its core flow is:

```
registered run
        ↓
authoritative Manifest V2
        ↓
consistency validation
        ↓
information sanitization
        ↓
existing workflow run schemas
        ↓
safe API status response
```

It supports both:

```
past run inspection
and
current execution progress
```

without becoming part of the execution path itself.

The final implementation preserves the architecture established earlier:

```
Registry
→ discovery

Manifest V2
→ technical truth

Run Management
→ lifecycle authority

runs.py
→ public read-only projection

error_handlers.py
→ safe HTTP failure representation
```

All blocking sanity-check findings were corrected and regression-tested before  
this report was finalized.

**Final status: PASS / suitable to freeze.**