# Level 2 — Part B Preprocessing Integration Test Report

**Status:** PASS  
**Purpose:** Certify standalone Part B through the production API together with the real Part A → Part B handoff, preprocessing execution, lifecycle enforcement, retry behavior, persisted stage state, and Part B-specific error handling.

## Cases Passed

| Case | Job | Result |
|---|---|---|
| 01 — Realistic preprocessing | Run Part A on data containing gaps, missing values, invalid values, duplicate timestamps, and an outlier; delete the original caller CSV; then verify Part B completes from the persisted Part A handoff. | PASS |
| 02 — Multi KPI | Verify Part B processes all KPIs produced by Part A and preserves the expected multi-KPI workflow. | PASS |
| 03 — Prerequisite | Force Part A failure and verify Part B cannot start before Part A completes; confirm no Part B execution is created. | PASS |
| 04 — Immutability | Complete Part B, call it again in the same attempt, and verify `409 COMPLETED_STAGE_IS_IMMUTABLE` with no extra Part B execution. | PASS |
| 05 — Failure + retry | Force a real Part B runtime failure on 10-minute data without a custom gap profile, persist the failed execution, retry the same attempt with corrected configuration, and complete as a new execution. | PASS |
| 06 — Missing targets | Verify unknown run and unknown attempt return the correct public `404` error families. | PASS |
| 07 — Schema errors | Verify missing preprocessing config, forbidden Part B input-file semantics, and invalid preprocessing configuration are rejected with standardized `422 / REQUEST_VALIDATION_FAILED` without creating runs. | PASS |

## A → B Handoff Proved

The realistic case verified:

```text
Part A → completed
backend-owned attempt input + Part A artifacts persisted
original external caller CSV deleted
Part B → completed
```

This proves Part B does not depend on the original caller file after the attempt has started. It consumes the authoritative Part A handoff and persisted run artifacts.

## Retry Result Proved

The retry case verified:

```text
Part A on 10-minute data → completed

Part B execution_0001
→ failed
→ missing required custom 10-minute gap profile

same run_id + attempt_id

Part B execution_0002
→ completed

successful_execution_id
→ execution_0002
```

This confirms a failed Part B stage can be retried inside the same attempt, while a completed Part B stage remains immutable.

## What Level 2 Proved

- Part A → Part B integration works through the production workflow.
- Part B uses persisted upstream artifacts rather than the caller's original CSV.
- Real preprocessing conditions are handled successfully.
- Multi-KPI Part B execution works.
- Part B prerequisite enforcement works.
- Failed Part B executions remain persisted.
- Same-stage retry creates a new execution in the same attempt.
- Completed Part B cannot be changed inside the same attempt.
- Public 404/409/422 error families behave correctly.
- Schema-level failures do not create logical runs.
- `/runs` state agrees with the stage execution responses.
- Successful Part B leaves the attempt ready to continue to Part C.

## Final Result

**7/7 logical cases passed — Level 2 / Part B certified.**
