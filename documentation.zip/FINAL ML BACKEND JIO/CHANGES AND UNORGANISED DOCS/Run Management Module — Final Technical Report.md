# [[Run Management Intermittent Stale-Execution BUG — Summary]]
# Run Management Module — Final Technical Report

**Module:** `app/run_management/`  
**Role:** Production run identity, attempt lifecycle, immutable lineage, artifact lookup, filesystem coordination, registry persistence, and run-level concurrency control.

---

# 1. Purpose

`app/run_management/` is the orchestration-support layer between the future API/workflows and the already-built Core/Services/ML modules.

Its architectural position is:

```text
API
 ↓
Run Management
 ↓
Workflows
 ↓
Parts A / B / C / D / E
```

The module answers:

```text
Which run is this?
Which attempt is active?
Which stage execution is authoritative?
Can this stage run safely?
Where should this execution write?
Which prior result should the workflow consume?
Which training attempt should Part E use?
How is run_id resolved to persistent storage?
```

It deliberately does **not** implement EDA, preprocessing, feature engineering, training, or inference algorithms.

---

# 2. Package Tree

```text
app/
└── run_management/
    ├── __init__.py
    ├── models.py
    ├── identifiers.py
    ├── lineage.py
    ├── locking.py
    ├── artifact_resolver.py
    ├── manager.py
    └── registry/
        ├── __init__.py
        ├── base.py
        └── local_json.py
```

---

# 3. Responsibility Split

```text
models.py
→ internal runtime contracts

identifiers.py
→ attempt/execution/request identifier generation

lineage.py
→ V1 immutable-attempt and prerequisite rules

locking.py
→ OS-level exclusive file locks

artifact_resolver.py
→ authoritative Manifest V2 artifact lookup

registry/base.py
→ storage-independent registry interface

registry/local_json.py
→ V1 local JSON registry

manager.py
→ high-level façade coordinating all of the above

__init__.py
→ public Run Management interface
```

---

# 4. Core Runtime Hierarchy

The module implements:

```text
RUN
└── ATTEMPT
    └── STAGE
        └── EXECUTION
```

A run is a long-lived logical job.

An attempt is one immutable training lineage.

A stage represents:

```text
part_a
part_b
part_c
part_d
inference_bootstrap
```

A failed stage can receive another execution:

```text
part_c/
├── execution_0001  failed
└── execution_0002  completed
```

The successful execution pointer, not directory order, is authoritative.

---

# 5. Physical Training Layout

Run Management creates deeper run-owned storage beneath the top-level directory service:

```text
runs/<run_id>/
└── attempts/
    └── attempt_0001/
        ├── request.json
        ├── input/
        │   └── <copied source CSV>
        └── stages/
            ├── part_a/
            │   └── execution_0001/
            │       ├── request.json
            │       ├── result.json
            │       ├── error.json
            │       └── outputs/
            ├── part_b/
            ├── part_c/
            ├── part_d/
            └── inference_bootstrap/
```

Every retry receives a new execution folder.

Old files are not overwritten as the authoritative history.

---

# 6. `models.py`

Internal frozen dataclasses:

### `RunRegistryRecord`

Lightweight registry/index record:

```text
run_id
run_directory
status
run_metadata
latest_attempt_id
active_inference_attempt_id
inference_ready
timestamps
manifest/workflow versions
```

### `RunContext`

Resolved run information:

```text
run_id
run_directory
manifest_path
registry_record
```

### `AttemptContext`

Resolved immutable-attempt locations:

```text
run_id
attempt_id
attempt_directory
input_directory
stages_directory
request_file
input_file
```

### `StageExecutionContext`

Exact locations supplied to a workflow:

```text
run_id
attempt_id
stage_name
execution_id

execution_directory
request_file
output_directory
result_file
error_file

prerequisite_results
```

For `inference_bootstrap`, it also carries an execution-specific inference-state staging directory.

### `ArtifactReference`

Represents one safely resolved authoritative artifact.

### `OutputRegistration`

Workflow-to-manager request to register an output file.

### `InferenceRequestContext`

Stores the manager-side Part E request snapshot.

Important:

```text
request_id != invocation_id
```

`request_id` belongs to Run Management.

`invocation_id` belongs to the existing Part E runner.

---

# 7. `identifiers.py`

Generates scoped monotonic IDs:

```text
attempt_0001
attempt_0002

execution_0001
execution_0002

request_000001
request_000002
```

The manager does not generate Part E invocation IDs.

## Part E length compatibility

The existing Part E invocation format appends:

```text
_<22-character UTC timestamp>_<8-character UUID>
```

to `run_id`.

That suffix consumes 32 characters.

Manifest V2 record IDs are capped at 128 characters.

Therefore Run Management enforces:

```text
maximum production run_id length = 96
```

This avoids a rare future failure where a valid run ID could produce an invalid Part E invocation ID.

---

# 8. `lineage.py`

The V1 stage order is:

```text
part_a
 ↓
part_b
 ↓
part_c
 ↓
part_d
 ↓
inference_bootstrap
```

Immediate prerequisites:

```text
part_a               → none
part_b               → part_a
part_c               → part_b
part_d               → part_c
inference_bootstrap  → part_d
```

## Immutable completed-stage rule

Within one attempt:

```text
completed stage
→ cannot rerun/change
→ create a new attempt if it must change
```

## Failed-stage rule

```text
failed stage
→ retry allowed
→ new execution ID
→ successful upstream stages reused
```

## Safety checks

`ensure_stage_can_start()` rejects:

- completed-stage reruns;
- another currently-running execution of the same stage;
- missing prerequisites;
- impossible historical lineage where downstream work is completed while an upstream stage is incomplete.

---

# 9. Inference Activation Rule

An attempt can become the active Part E source only when:

```text
part_d completed
AND
inference_bootstrap completed
AND
stable inference_config.json exists
```

The manifest pointer is:

```text
active_inference_attempt_id
```

and the independent availability flag is:

```text
inference_ready
```

A newer training attempt does not remove the older working inference attempt.

Example:

```text
run_001

attempt_0001  completed + active for inference
attempt_0002  new retraining attempt
```

While attempt 0002 trains:

```text
active_inference_attempt_id = attempt_0001
inference_ready = true
run status = created/running/... for latest training activity
```

---

# 10. `locking.py`

Provides:

```text
FileLock
RunLock
```

The implementation uses standard-library operating-system locks:

```text
Windows
→ msvcrt.locking

POSIX
→ fcntl.flock
```

The lock file may remain on disk.

Ownership is represented by the OS lock, not file existence.

This avoids stale-file deadlocks after normal process crashes.

---

# 11. Why Part E Requires a Long-Lived Run Lock

Part E mutates persistent:

```text
raw history
raw cache
processed history
processed cache
```

after successful inference.

Two simultaneous inference calls against one saved run could otherwise race.

Therefore:

```text
RunManager.inference_session(...)
```

holds the run lock for the **complete Part E operation**, not merely for manifest writes.

---

# 12. `registry/base.py`

Defines storage-independent:

```text
RunRegistry
```

with:

```text
create()
get()
update()
exists()
list_runs()
```

Higher layers do not need to know whether the implementation is:

```text
local JSON
MongoDB
SQL
another database
```

---

# 13. `registry/local_json.py`

V1 registry implementation.

Configured through Core:

```text
run_registry_backend = local_json
run_registry_file = <configured path>/runs.json
```

The document contains lightweight run index records.

It does **not** replace Manifest V2.

Architecture:

```text
Local registry
→ searchable identity/index

Manifest V2 + run folder
→ detailed technical truth
```

## Registry persistence

Writes use the existing atomic JSON file service.

Read-modify-write changes are protected by an exclusive registry lock.

This prevents normal lost-update races between backend processes sharing the same filesystem.

---

# 14. `artifact_resolver.py`

The resolver never searches directories heuristically.

It uses Manifest V2:

```text
attempt
 ↓
stage
 ↓
successful_execution_id
 ↓
execution.result_file / registered outputs
```

Main functions:

```text
resolve_attempt_input()
resolve_successful_execution_record()
resolve_stage_result()
resolve_stage_outputs()
resolve_prerequisite_results()
get_inference_state_directory()
resolve_active_inference_state()
```

---

# 15. Artifact Containment Rule

Every resolved artifact path is checked against:

```text
runs/<run_id>/
```

A persisted path escaping the run root is rejected.

Therefore corrupted/malicious manifest content such as:

```text
../../outside.json
```

cannot silently become an authoritative workflow handoff.

---

# 16. `manager.py`

`RunManager` is the public façade.

It composes:

```text
Core
Services
Manifest V2
Registry
Lineage
Locking
Artifact Resolver
```

It deliberately contains no:

```text
run_eda_pipeline()
run_preprocessing_pipeline()
run_feature_engineering_pipeline()
run_training()
run_inference_pipeline()
```

calls.

Workflows remain responsible for invoking ML modules.

---

# 17. Run Creation

Flow:

```text
RunManager.create_run()
        ↓
validate run ID / Part E length compatibility
        ↓
create top-level run directories
        ↓
create Manifest V2
        ↓
create local registry entry
        ↓
RunContext
```

If registry creation fails during initial run creation, the newly created run/log directories are rolled back because no workflow artifacts exist yet.

---

# 18. Run Resolution

Flow:

```text
run_id
 ↓
registry.get()
 ↓
expected configured run directory
 ↓
validate filesystem run
 ↓
load Manifest V2
 ↓
verify manifest run_id
 ↓
refresh stale registry metadata from manifest
 ↓
RunContext
```

Manifest V2 is treated as technical truth.

The registry is an index.

---

# 19. Attempt Creation

Flow:

```text
existing run
 ↓
acquire run lock
 ↓
generate attempt ID
 ↓
create attempt directory
 ↓
save exact attempt request.json
 ↓
copy source CSV into attempt/input/
 ↓
Manifest V2 create_attempt_record()
 ↓
latest_attempt_id updated
 ↓
run status = created
 ↓
registry sync
```

The copied input receives checksum-enabled metadata through Manifest V2.

The external original is not used as mutable attempt state.

---

# 20. Stage Preparation

`prepare_stage_execution()`:

```text
resolve run
 ↓
run lock
 ↓
load manifest
 ↓
ensure_stage_can_start()
 ↓
generate execution ID
 ↓
create execution folder
 ↓
save exact stage request.json
 ↓
resolve authoritative prerequisite result
 ↓
start_stage_execution()
 ↓
attempt/run status = running
 ↓
return StageExecutionContext
```

The ML workflow then runs outside the lock for A-D training stages.

Manifest state prevents conflicting starts.

---

# 21. Stage Completion

For ordinary A-D stages:

```text
workflow result
 ↓
save result.json
 ↓
register outputs
 ↓
complete execution
 ↓
derive attempt/run status
 ↓
registry sync
```

The exact successful `result.json` becomes the future stage handoff.

---

# 22. Stage Failure / Retry

Failure:

```text
exception
 ↓
error.json
 ↓
Manifest V2 failed execution
 ↓
attempt/run derived status
```

The execution folder stays intact.

Retry:

```text
same attempt
same stage
new execution ID
```

The previous failed request/error/output remains historical.

---

# 23. Bootstrap Saved-State Staging

Bootstrap receives a special directory:

```text
.../inference_bootstrap/<execution_id>/
└── outputs/
    └── inference_state/
```

The future bootstrap workflow must create a **self-contained Part E saved-run root** there.

At minimum it must contain:

```text
inference_config.json
```

and every saved model/storage dependency referenced by that contract must remain beneath this saved-run root.

---

# 24. Bootstrap Publication

Successful bootstrap publication is:

```text
execution-local staging root
 ↓
validate inference_config.json
 ↓
validate registered bootstrap outputs are self-contained
 ↓
atomic directory rename
 ↓
runs/<run_id>/inference/<attempt_id>/
```

After rename:

- result snapshot paths are recursively remapped from staging to stable paths;
- registered bootstrap output paths are remapped to stable paths;
- the stage is marked complete;
- the attempt becomes the active inference source.

This prevents stale manifest/result references to a directory that no longer exists.

---

# 25. Bootstrap Recovery

If bootstrap state was successfully created and the stage completed but a later activation/index update fails, the manager exposes:

```text
activate_inference_attempt(run_id, attempt_id)
```

It revalidates:

```text
Part D completed
bootstrap completed
stable inference_config.json exists
```

before changing the active inference pointer.

---

# 26. Part E Ownership Boundary

The existing Part E runner owns its invocation ID.

Therefore Run Management does **not** generate a competing `invocation_id`.

Instead it creates an internal pre-call:

```text
request_000001
```

under the active saved-run root:

```text
inference/<attempt_id>/requests/request_000001/
├── request.json
├── input/<copied inference CSV>
├── result.json
└── error.json
```

The workflow constructs the real production `InferenceRequest` using the copied input path.

---

# 27. Part E Session Flow

```text
manager.inference_session(run_id, request, input)
        ↓
resolve active inference attempt
        ↓
acquire run lock
        ↓
snapshot request + input
        ↓
workflow calls existing Part E
        ↓
Part E generates invocation_id internally
        ↓
Part E scores + commits history + publishes result
        ↓
session.complete(
    invocation_id=result.invocation_id
)
        ↓
Manifest V2 registers exact invocation
        ↓
release run lock
```

This preserves the existing Part E implementation while preventing concurrent history/cache mutation.

---

# 28. Part E Failure Before Invocation Registration

If Part E raises before a successful invocation result returns:

```text
request/error.json
```

is persisted and Manifest V2 receives a structured:

```text
inference_request_failed
```

event/error containing the manager-side `request_id`.

No fake Part E invocation ID is invented.

---

# 29. Part E Result Location

Run Management requires Part E's returned final output directory to remain below:

```text
runs/<run_id>/inference/<active_attempt_id>/
```

An escaped output path is rejected.

---

# 30. Registry / Manifest Transaction Boundary

V1 uses two atomic JSON files:

```text
manifest.json
runs.json
```

They are not one database transaction.

Therefore an exceptional filesystem failure can theoretically occur after one commits and before the other does.

Design response:

```text
Manifest V2 = technical truth
Registry = rebuildable/searchable index
```

`resolve_run()` refreshes stale registry metadata from Manifest V2.

This boundary is intentional for the local V1 implementation and is removable later by replacing the registry backend.

---

# 31. Dependency Boundary

The final sanity check confirms `app/run_management/` imports neither:

```text
app.ml.*
```

nor:

```text
app.schemas.*
```

The module therefore stays independent of the actual A-E algorithm implementations and public workflow request models.

Workflows bridge those layers later.

---

# 32. Public Interface

Main public objects include:

```text
RunManager

RunRegistry
LocalJsonRunRegistry

RunContext
AttemptContext
StageExecutionContext
InferenceRequestContext
ArtifactReference
OutputRegistration

RunLock
FileLock

lineage helpers
artifact resolver helpers
identifier helpers
```

Normal future API/workflow code should primarily depend on:

```text
RunManager
+
returned contexts
```

rather than individually coordinating low-level internals.

---

# 33. Final Runtime Sanity Coverage

The module passed a full clean-project runtime smoke test covering:

```text
run creation
registry persistence
96-character run-ID rule
attempt input snapshot
prerequisite rejection
successful A
completed-stage immutability
failed B + retry
C progression
D progression
failed bootstrap
bootstrap retry
bootstrap publication
stable-path remapping
inference activation
activation recovery
new retraining attempt
old active inference preservation
Part-E-owned invocation ID
successful Part E registration
failed Part E request recording
artifact path containment
run lock collision
```

All module files also pass Python syntax validation and internal export/import checks.

---

# 34. Known V1 Boundaries

## Local filesystem locking

The current lock is appropriate for processes sharing the same filesystem.

A future horizontally distributed deployment using independent local filesystems would require a distributed locking mechanism.

## Registry and manifest are separate persistence units

They are individually atomic but not transactionally coupled.

## Part E post-commit registration

Part E itself can commit/publish its persistent inference state before Run Management records the returned invocation in the top-level Manifest V2.

If the later manifest write fails, the Part E result directory and manager request snapshot remain recovery evidence.

## Bootstrap must be self-contained

Because the existing Part E loader resolves saved model/storage paths beneath the supplied `run_directory`, the future bootstrap workflow must create a portable self-contained saved-run root.

---

# 35. Final Assessment

The Run Management module now provides the production control plane required between the API/workflow layer and the already-tested A-E ML modules.

The final separation is:

```text
Core / Services
→ generic configuration, errors, files, manifest mechanics

Run Management
→ identity, attempts, execution lineage, registry, locks, artifact resolution

Workflows
→ A/B/C/D/E orchestration and handoffs

ML modules
→ actual data/model algorithms
```

The module is ready to be cross-checked with the workflow schemas and then used as the foundation for the actual workflow execution package.
