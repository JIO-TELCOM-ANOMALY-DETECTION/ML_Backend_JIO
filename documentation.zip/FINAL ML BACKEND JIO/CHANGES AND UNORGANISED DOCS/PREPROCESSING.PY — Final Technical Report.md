# Preprocessing API — Final Technical Report

**File:** `app/api/preprocessing.py`  
**Final implementation:** v1  
**Module:** `app/api/`  
**Status:** Final sanity checked — PASS / suitable to freeze  
**Primary role:** Production HTTP endpoint for standalone Part B preprocessing execution.

---

# 1. Purpose

`preprocessing.py` is the API-layer entry point for running **Part B — Preprocessing** independently inside an existing training attempt.

Its responsibility is intentionally small:

```
HTTP request
    ↓
Pydantic request validation
    ↓
caller-owned run / attempt validation
    ↓
run-scoped workflow logger
    ↓
run_part_b_workflow(...)
    ↓
StandaloneStageResponse
```

The route does not implement preprocessing algorithms and does not own Part B stage lifecycle logic.

---

# 2. Architectural Position

```
Client / UI
    ↓
POST /api/v1/preprocessing/run
    ↓
app/api/preprocessing.py
    ↓
app/workflows/part_b.py
    ↓
Run Management
    ↓
app/ml/preprocessing/
    ↓
Services / filesystem
```

The API file is therefore a thin HTTP bridge into the already-frozen Part B workflow.

---

# 3. Router Contract

Router prefix:

```
/api/v1/preprocessing
```

Endpoint:

```
POST /api/v1/preprocessing/run
```

Request model:

```
PreprocessingStageRequest
```

Response model:

```
StandaloneStageResponse
```

---

# 4. Request Contract

The frozen workflow request contains exactly:

```
run_id
attempt_id
preprocessing
```

where:

```
preprocessing
→ PreprocessingConfig
```

Part B always targets an existing training attempt.

Unlike Part A, it cannot create:

```
a new run
or
a new attempt
```

---

# 5. Why No Dataset Path Is Present

Part B does not accept a new external dataset.

Its authoritative input is produced by successful Part A inside the same immutable attempt.

Conceptually:

```
Part A successful execution
        ↓
A→B persisted handoff/result snapshot
        ↓
Part B
```

Therefore the Part B API request contains no:

```
input_file
dataset path
output_directory
```

Those are not caller-owned Part B inputs.

---

# 6. Why This Route Is Thinner Than `eda.py`

Part A is responsible for introducing a caller-owned CSV into a new attempt.

Part B is not.

Therefore `preprocessing.py` does not need:

```
read_csv_file()
validate_input_file()
API_INPUT_FILE_*
API_INPUT_CSV_*
```

All Part B data is already backend-owned persisted attempt state.

---

# 7. Public Run Validation

The route first checks:

```
manager.registry.exists(request.run_id)
```

This operation is used only to determine whether the caller referenced a genuinely unknown public run.

If not registered:

```
API_RUN_NOT_FOUND
→ HTTP 404
```

Safe public detail:

```
run_id
```

---

# 8. Why Generic `RUN_NOT_FOUND` Is Not Automatically 404

A low-level `RUN_NOT_FOUND` can mean multiple things.

Example:

```
caller references completely unknown run
→ caller-owned absence
```

but also:

```
registry knows run
→ backend later cannot resolve its technical state
→ internal corruption/failure
```

Therefore only the route-level proven public absence is translated to:

```
API_RUN_NOT_FOUND
```

Later low-level run failures remain internal and default to 500.

---

# 9. Public Attempt Validation

After proving the run is registered, the route calls:

```
manager.resolve_attempt(
    request.run_id,
    request.attempt_id,
)
```

If the specific caller-requested attempt is missing:

```
AttemptNotFoundError
        ↓
API_ATTEMPT_NOT_FOUND
        ↓
HTTP 404
```

Safe details:

```
run_id
attempt_id
```

---

# 10. Why Only `AttemptNotFoundError` Is Translated

`resolve_attempt()` also validates technical attempt state.

It may fail for internal reasons such as:

```
attempt request snapshot missing
attempt immutable input missing
path containment violation
registered run state broken
manifest inconsistency
```

The route does not reinterpret those as public 404s.

It catches only the exact caller-owned missing-attempt condition.

---

# 11. No Part A Prerequisite Check in the API

The route deliberately does not inspect:

```
manifest["attempts"][...]["stages"]["part_a"]
```

and does not manually test:

```
Part A status
successful_execution_id
```

That would duplicate Run Management lifecycle authority.

---

# 12. Where the Part A Prerequisite Is Enforced

The Part B workflow begins with:

```
manager.prepare_stage_execution(
    run_id,
    attempt_id,
    "part_b",
    ...
)
```

Run Management resolves the canonical required upstream stage and requires a successful authoritative Part A execution before Part B can begin.

Therefore prerequisite enforcement belongs below the API route.

---

# 13. Public Prerequisite Conflict

If Part A is not completed:

```
STAGE_PREREQUISITE_NOT_COMPLETED
→ HTTP 409
```

The route does not catch or rewrite this error.

The frozen global error handler already recognizes the lifecycle code.

Approved safe details:

```
attempt_id
stage_name
required_stage
```

---

# 14. Why 409 Is Correct for Missing Prerequisite

This condition means:

```
request shape is valid
run exists
attempt exists
backend state is healthy
but lifecycle order does not permit Part B yet
```

Therefore:

```
409 Conflict
```

is the correct public meaning.

---

# 15. Completed Part B Immutability

If Part B is already successfully completed inside the attempt:

```
COMPLETED_STAGE_IS_IMMUTABLE
→ HTTP 409
```

The API route does not manually inspect Part B state.

Run Management owns this rule.

---

# 16. Immutable Attempt Rule

A completed upstream/downstream stage cannot be changed inside the same immutable attempt.

Conceptually:

```
attempt_0001
Part A completed
Part B completed

caller tries Part B again
        ↓
COMPLETED_STAGE_IS_IMMUTABLE
```

To change completed preprocessing settings:

```
create a new training attempt
```

rather than mutating the completed lineage.

---

# 17. Already-Running Part B Conflict

If Part B already has an active execution:

```
STAGE_EXECUTION_ALREADY_RUNNING
→ HTTP 409
```

Safe details may include:

```
attempt_id
stage_name
execution_id
```

The route simply lets the workflow/Run Management error propagate.

---

# 18. Retry Legality

Part B may be retried in the same attempt only when Run Management considers the stage eligible.

Typical valid case:

```
Part A completed
Part B failed
        ↓
retry Part B
```

Typical invalid case:

```
Part B already completed
        ↓
cannot retry in same attempt
```

The API route does not encode these rules.

---

# 19. Why Retry Logic Belongs in Run Management

If API routes independently implemented stage legality, the same rule would need to be duplicated in:

```
preprocessing.py
feature_engineering.py
training.py
pipeline.py
```

That would create lifecycle drift.

Instead:

```
Run Management
→ one authoritative lineage/retry policy
```

and all routes/workflows rely on it.

---

# 20. Run-Scoped Logger

Part B always has a real:

```
run_id
```

before the request reaches this route.

Therefore the route obtains:

```
get_workflow_logger(
    request.run_id,
    component_name="pipeline",
)
```

which resolves to the existing run-scoped pipeline logger.

There is no process-level/new-run logger case for Part B.

---

# 21. Why `component_name="pipeline"`

The standalone route participates in the same orchestration lifecycle as the training pipeline.

Using:

```
pipeline
```

keeps orchestration messages grouped consistently under the existing run logging configuration.

The route does not introduce a separate logging system.

---

# 22. Workflow Delegation

After target validation:

```
return run_part_b_workflow(
    request=request,
    manager=manager,
    logger=logger,
)
```

The route does not reshape successful or failed workflow responses.

---

# 23. Part B Workflow Responsibilities

The frozen Part B workflow owns:

```
prepare Part B execution
resolve successful Part A prerequisite
load authoritative A→B handoff
reconstruct Part A output contract
enumerate Part A KPI set
run preprocessing per KPI
create deterministic KPI output directories
validate result identity
validate result output containment
validate final dataset existence
validate exact A→B KPI continuity
build B→C snapshot
complete Part B stage
persist failure after stage start
return StandaloneStageResponse
```

None of this is duplicated in the API route.

---

# 24. Part A Handoff Resolution

The workflow receives the authoritative prerequisite through:

```
execution.prerequisite_results
```

and loads the Part A handoff from the resolved successful execution.

The route never:

```
scans folders
chooses newest result
opens result.json directly
```

Manifest V2 / Run Management remains the authoritative source.

---

# 25. Part B KPI Enumeration

Part A defines the authoritative downstream KPI set.

Part B must produce exactly one corresponding result per KPI.

The workflow validates:

```
same KPI count
same KPI identities
no duplicates
no missing KPI
no additional KPI
```

If continuity fails, Part B is not marked successful.

This validation remains entirely below the API layer.

---

# 26. Output Containment

The Part B workflow validates that each:

```
final_dataset_file
```

exists inside the workflow-owned KPI output directory.

This protects against:

```
missing final dataset
unexpected output path
artifact escaping its execution root
```

The API route does not inspect these filesystem paths.

---

# 27. B→C Handoff

After all preprocessing outputs pass validation:

```
Part B workflow
        ↓
build_part_b_result_snapshot()
        ↓
manager.complete_stage(...)
```

This persisted result becomes the authoritative input for Part C.

The route does not build the handoff itself.

---

# 28. Structured Part B Success Response

Successful execution returns a standard:

```
StandaloneStageResponse
```

conceptually:

```
status = completed
requested_stage = part_b
next_stage = part_c
inference_ready = false
```

with safe summary metrics.

---

# 29. Part B Summary Metrics

The workflow may report safe headline values such as:

```
kpi_count
total_input_rows
final_rows
prophet_enabled_kpis
```

These are workflow-owned metrics.

The API route simply returns the typed response.

---

# 30. Structured Part B Failure

Once a Part B execution has safely started, an ML/handoff/contract failure is persisted through:

```
manager.fail_stage(...)
```

and the workflow returns:

```
StandaloneStageResponse(
    status="failed",
    ...
)
```

The API route returns that structured response unchanged.

---

# 31. Why a Structured Failed Stage Is Not Automatically HTTP 500

A workflow response with:

```
status="failed"
```

represents a known execution lifecycle result.

It may include:

```
run_id
attempt_id
execution_id
stage
workflow error detail
```

The route does not convert every such result into a global exception.

This preserves the workflow response contract used by the standalone stages and master pipeline.

---

# 32. Pre-Execution Lifecycle Errors vs Started-Execution Failures

Two categories are intentionally different.

## Before Part B execution exists

Examples:

```
Part A prerequisite incomplete
Part B already completed
Part B already running
```

These propagate as exceptions:

```
→ global error handler
→ 409
```

## After Part B execution starts

Examples:

```
preprocessing ML failure
KPI continuity failure
handoff contract failure
output validation failure
```

The workflow persists the failed execution and returns a structured stage response.

The route preserves this distinction.

---

# 33. No External File Validation

`preprocessing.py` does not import or call:

```
read_csv_file
validate_input_file
```

because Part B does not own a new external file boundary.

This is an important architectural distinction from `eda.py`.

---

# 34. Why Internal Artifact Errors Are Not 422

Suppose the successful Part A result points to a backend artifact that is unexpectedly missing.

That is not:

```
caller supplied a bad Part B file
```

because Part B has no caller file.

It is backend-owned persisted state.

Therefore such failures remain internal rather than being translated into `API_INPUT_*` 422 codes.

---

# 35. Pydantic Validation

`PreprocessingStageRequest` itself validates:

```
run_id shape
attempt_id shape
complete PreprocessingConfig
```

The schema uses the shared workflow ID contracts and existing Part B configuration schema.

Malformed request data is rejected before the route executes:

```
RequestValidationError
→ REQUEST_VALIDATION_FAILED
→ HTTP 422
```

---

# 36. Extra Fields Are Rejected

Workflow schema models use the frozen strict request contract.

Therefore unexpected request fields such as:

```
input_file
output_directory
dataset
```

are not accepted by the Part B route.

This prevents accidental reintroduction of old temporary pipeline semantics.

---

# 37. Preprocessing Configuration Ownership

The complete user-facing Part B configuration remains defined in:

```
app.schemas.preprocessing
```

The API route does not redefine:

```
outlier settings
gap profiles
phase controls
Prophet settings
usability thresholds
value bounds
timeline correction
```

This avoids schema duplication.

---

# 38. Frequency Resolution

Part B configuration may contain user-facing duration/settings that later need to be resolved against the Part A bucket.

That resolution belongs to the preprocessing implementation/schema/workflow stack.

The API route passes:

```
request.preprocessing
```

unchanged into the workflow.

---

# 39. No Direct RunManager Construction

The route receives:

```
RunManagerDependency
```

from `dependencies.py`.

It does not instantiate:

```
RunManager()
```

inside the endpoint.

This preserves the shared dependency architecture.

---

# 40. Why Dependency Injection Matters

Centralized dependency creation provides:

```
one shared RunManager facade
easier tests
FastAPI dependency overrides
consistent configuration
no repeated registry construction
```

The route therefore remains infrastructure-light.

---

# 41. No Manifest Mutation

`preprocessing.py` never calls:

```
save_run_manifest
prepare_stage_execution
complete_stage
fail_stage
```

directly.

The workflow calls the RunManager methods.

The API layer only performs read-only public-target validation before delegation.

---

# 42. No Registry Mutation

The route uses:

```
manager.registry.exists()
```

only as a targeted read.

It does not:

```
create registry records
update registry status
remove runs
modify metadata
```

---

# 43. No Artifact Resolver Use in the Route

The API route does not call:

```
resolve_stage_result()
resolve_successful_execution_record()
artifact_resolver
```

Part B workflow / Run Management already handle authoritative prerequisite resolution.

---

# 44. Error Handler Relationship

The route raises only the two API-boundary public missing-resource codes it can prove:

```
API_RUN_NOT_FOUND
API_ATTEMPT_NOT_FOUND
```

Everything else is left to:

```
app/api/error_handlers.py
```

for final HTTP mapping and public sanitization.

---

# 45. Final 404 Behavior

```
unknown caller run
→ API_RUN_NOT_FOUND
→ 404
```

```
known caller run + unknown caller attempt
→ API_ATTEMPT_NOT_FOUND
→ 404
```

---

# 46. Final 409 Behavior

The route allows Run Management/workflow lifecycle codes to propagate:

```
STAGE_PREREQUISITE_NOT_COMPLETED
→ 409
```

```
COMPLETED_STAGE_IS_IMMUTABLE
→ 409
```

```
STAGE_EXECUTION_ALREADY_RUNNING
→ 409
```

No duplicate route mapping is required.

---

# 47. Final 422 Behavior

Part B route-specific 422s come only from request/schema validation.

Examples:

```
invalid run_id shape
invalid attempt_id shape
missing preprocessing config
invalid preprocessing settings
extra forbidden fields
```

These become:

```
REQUEST_VALIDATION_FAILED
→ 422
```

There is no Part B `API_INPUT_FILE_*` family.

---

# 48. Final 500 Behavior

Examples that remain internal include:

```
registered run cannot be resolved technically
manifest corruption
attempt-owned state missing
Part A artifact corruption
unexpected Run Management failure
unknown future backend code
```

The frozen fail-closed handler returns 500 by default.

---

# 49. Runtime Flow — Normal Part B

```
POST /api/v1/preprocessing/run
        ↓
PreprocessingStageRequest validation
        ↓
registry confirms run exists
        ↓
resolve_attempt confirms caller attempt exists
        ↓
run-scoped pipeline logger
        ↓
run_part_b_workflow()
        ↓
prepare_stage_execution(part_b)
        ↓
resolve successful Part A prerequisite
        ↓
load A→B handoff
        ↓
run preprocessing per KPI
        ↓
validate outputs + KPI continuity
        ↓
persist B→C snapshot
        ↓
complete Part B
        ↓
StandaloneStageResponse(completed)
```

---

# 50. Runtime Flow — Missing Run

```
request run_id
        ↓
registry.exists(run_id) = false
        ↓
API_RUN_NOT_FOUND
        ↓
global error handler
        ↓
404
```

Workflow is not called.

---

# 51. Runtime Flow — Missing Attempt

```
known run
        ↓
resolve_attempt(run_id, attempt_id)
        ↓
AttemptNotFoundError
        ↓
API_ATTEMPT_NOT_FOUND
        ↓
404
```

Workflow is not called.

---

# 52. Runtime Flow — Registered But Broken Run

```
registry says run exists
        ↓
resolve_attempt()
        ↓
internal RUN_NOT_FOUND / manifest-related failure
        ↓
not translated by route
        ↓
global fail-closed handler
        ↓
500
```

This preserves caller-vs-backend ownership.

---

# 53. Runtime Flow — Part A Not Completed

```
run + attempt exist
        ↓
workflow
        ↓
prepare_stage_execution(part_b)
        ↓
Part A successful execution absent
        ↓
STAGE_PREREQUISITE_NOT_COMPLETED
        ↓
409
```

The API route does not manually inspect Part A.

---

# 54. Runtime Flow — Part B Already Completed

```
run + attempt exist
        ↓
workflow
        ↓
Run Management sees completed Part B
        ↓
COMPLETED_STAGE_IS_IMMUTABLE
        ↓
409
```

---

# 55. Runtime Flow — Part B Already Running

```
run + attempt exist
        ↓
workflow
        ↓
active Part B execution exists
        ↓
STAGE_EXECUTION_ALREADY_RUNNING
        ↓
409
```

---

# 56. Runtime Flow — Started Part B Later Fails

```
prepare_stage_execution succeeds
        ↓
Part B execution exists
        ↓
ML / handoff / contract error
        ↓
workflow fail_stage(...)
        ↓
StandaloneStageResponse(status="failed")
        ↓
route returns response unchanged
```

---

# 57. Final Sanity Check

The exact generated `preprocessing.py` was reviewed against the frozen:

```
PreprocessingStageRequest
run_part_b_workflow()
workflow package exports
dependencies.py
RunManager target lookup behavior
error mapping policy
```

No blocking mismatch was found.

---

# 58. Syntax Verification

The exact file passed Python compilation:

```
PREPROCESSING_API_V1_SYNTAX=PASS
```

---

# 59. Runtime Regression

The final route regression passed:

```
PREPROCESSING_API_V1_RUNTIME_SMOKE=PASS
PREPROCESSING_API_V1_FULL_REGRESSION=PASS
```

The regression was rerun again during the freeze-level sanity check and remained green.

---

# 60. Regression Coverage

The tests explicitly covered:

```
normal Part B execution
correct run-scoped workflow logger
missing run → API_RUN_NOT_FOUND / 404
missing attempt → API_ATTEMPT_NOT_FOUND / 404
registered-but-broken run → 500
Part A prerequisite incomplete → 409
Part B completed/immutable → 409
Part B already running → 409
internal workflow failure after boundary → 500
structured Part B failed response returned unchanged
missing preprocessing config → Pydantic 422
malformed attempt ID → Pydantic 422
unexpected external input_file field → Pydantic 422
safe 409 detail filtering
no path leakage in 500 response
```

---

# 61. Security / Information Exposure

The route itself exposes no physical paths.

For public 404s it supplies only:

```
run_id
attempt_id
```

Lifecycle 409 details are sanitized by the global error handler.

Internal failures return generic 500 responses with empty public details.

The route never serializes:

```
run directory
attempt directory
Part A handoff path
Part B output directory
result file
manifest path
```

---

# 62. Known V1 Boundaries

There are no blocking limitations specific to this route.

The main architectural boundary is deliberate:

```
Part B status/prerequisite checks are not performed twice at API level
```

This means the API depends on Run Management/workflow correctness for lifecycle decisions—which is the intended architecture.

---

# 63. Relationship with `eda.py`

```
eda.py
→ Part A
→ may create run/attempt
→ owns caller external CSV validation

preprocessing.py
→ Part B
→ always existing run/attempt
→ owns no external file validation
```

This is a key distinction between the two routes.

---

# 64. Relationship with Future `feature_engineering.py`

Part C is expected to follow nearly the same routing pattern:

```
existing run
existing attempt
schema config
public target validation
run-scoped logger
workflow delegation
```

Its main additional schema concern is:

```
feature_engineering config
or
model_type_hint
```

That concern already belongs to `FeatureEngineeringStageRequest`.

---

# 65. Final Responsibility Boundary

```
preprocessing.py
→ HTTP + caller run/attempt identity

PreprocessingStageRequest
→ Part B request/config validation

Part B workflow
→ orchestration + handoff/output checks

Run Management
→ prerequisite / execution / immutability authority

ML preprocessing module
→ actual preprocessing transformations

error_handlers.py
→ safe HTTP mapping
```

No layer responsibility is duplicated.

---

# 66. Final Compact Contract

```
FILE:
app/api/preprocessing.py

ROLE:
Standalone Part B HTTP route.

ENDPOINT:
POST /api/v1/preprocessing/run

REQUEST:
PreprocessingStageRequest

REQUEST FIELDS:
run_id
attempt_id
preprocessing

RESPONSE:
StandaloneStageResponse

PUBLIC 404:
API_RUN_NOT_FOUND
API_ATTEMPT_NOT_FOUND

LIFECYCLE 409:
STAGE_PREREQUISITE_NOT_COMPLETED
COMPLETED_STAGE_IS_IMMUTABLE
STAGE_EXECUTION_ALREADY_RUNNING

REQUEST 422:
REQUEST_VALIDATION_FAILED

DEFAULT UNKNOWN/INTERNAL:
500 through global fail-closed handler

LOGGER:
run-scoped pipeline logger

WORKFLOW:
run_part_b_workflow()

INPUT SOURCE:
authoritative successful Part A handoff/result

DOES NOT:
read external CSV
validate external file
inspect Part A manually
decide retry legality
call preprocessing ML directly
mutate Manifest V2
resolve artifacts directly
reshape workflow response
```

---

# 67. Final Assessment

`app/api/preprocessing.py` is a correctly bounded production Part B route.

Its governing rule is:

```
The API proves only caller-owned run/attempt identity.

Run Management proves lifecycle legality.

The Part B workflow proves preprocessing/handoff correctness.

The ML module performs the actual transformation.
```

This produces a clean separation of concerns while preserving the frozen error model:

```
genuine missing caller resource → 404
healthy lifecycle conflict → 409
invalid request schema → 422
internal/unexpected failure → 500
started-stage failure → structured workflow response
```

**Final status: PASS / suitable to freeze.**