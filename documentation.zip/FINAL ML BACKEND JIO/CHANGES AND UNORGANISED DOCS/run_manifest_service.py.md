### Main change

The manifest is upgraded from the old flat V1:

```text
run
└── stages
```

to **Manifest V2**:

```text
run
├── attempts
│   └── attempt_0001
│       └── stages
│           ├── part_a
│           │   └── executions
│           ├── part_b
│           ├── part_c
│           ├── part_d
│           └── inference_bootstrap
│
└── inference
    └── invocations
```

This directly supports our V1 rule that **attempt history and failed/retried stage executions are never overwritten**.

### New capabilities

Added support for:

- **Run states**
    
    - `created`
        
    - `running`
        
    - `partially_completed`
        
    - `completed`
        
    - `failed`
        
    - `cancelled`
        
- **Attempt records**
    
    - `create_attempt_record()`
        
    - `set_attempt_status()`
        
    - attempt request/input metadata
        
    - attempt-specific errors and summaries
        
- **Stage execution history**
    
    - `start_stage_execution()`
        
    - `complete_stage_execution()`
        
    - `fail_stage_execution()`
        
    - `cancel_stage_execution()`
        

Example:

```text
part_c
├── execution_0001 → failed
└── execution_0002 → completed
```

The stage records both:

```text
active_execution_id
successful_execution_id
```

- **Artifact tracking**
    
    - `record_output_file()` now records exactly:
        
        ```text
        attempt_id
        stage_name
        execution_id
        ```
        
    - outputs are retained both globally and inside their execution.
        
- **Inference readiness**
    
    - `active_inference_attempt_id`
        
    - `inference_ready`
        
    - `set_active_inference_attempt()`
        
    - `clear_active_inference_attempt()`
        

This lets an older successful training attempt remain the inference source while a newer retraining attempt is still running.

- **Part E invocation history**
    
    - `start_inference_invocation()`
        
    - `complete_inference_invocation()`
        
    - `fail_inference_invocation()`
        

So one training run can later have many inference calls.

- **Versioning**
    
    - manifest version now comes from:
        
        ```python
        settings.run_manifest_version
        ```
        
    - workflow schema version also stored and validated.
        
- **Run metadata**
    
    - supports later fields such as:
        
        ```text
        employee_code
        employee_name
        run_name
        ```
        
    - this service stores them but deliberately does not enforce business/uniqueness rules.
        

### Important responsibility boundary

This service **does not decide lineage rules**.

For example, it does not decide:

> “Is retrying Part C allowed?”

That will be the future Run Manager's job.

This service only provides the safe persistence operations necessary to record:

```text
run
→ attempt
→ stage
→ execution
→ output/error
```

### Intentional V1 change

The old functions such as:

```text
start_pipeline_stage()
complete_pipeline_stage()
fail_pipeline_stage()
skip_pipeline_stage()
```

have been replaced by the more precise **attempt + execution-aware functions**.

Also, `skipped` is no longer a normal stage state because A→D stages are not optional in our current workflow design.

### Documentation note

> `run_manifest_service.py` is now Manifest V2 and acts as the persistent technical history of a run. It records multiple immutable training attempts, repeated executions of failed stages, exact output/error provenance, the active inference-ready training attempt, and future Part E invocation history, while leaving lineage decisions and orchestration to the Run Management layer.