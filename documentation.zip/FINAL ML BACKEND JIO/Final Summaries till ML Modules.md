# [[APP.MAIN.PY — Final Technical Report]]
# [[PERSONAL NOTES]]
# [[Planning Board Pipeline]]
# [[CHANGES MADE FOR PIPELINING]]
# [[SERVICES Modules]]
# [[CORE Modules]]
# [[ML Modules]]

# [[SCHEMA Modules]]
# [[Pipeline and Workflow Made for test]]

# [[Test Database Creation and Tester Files]]
# [[Planning board post pipelining final works]]

# The folder structure of final summaries is made to mimic the actual project structure
